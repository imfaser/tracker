# App Config（轻量）

`app-config` 提供测试台所需的 3 字段持久化配置，通过 Rust `config.json` 落盘，界面在 `/config` 编辑。

## 字段

| 字段             | 含义                                                          | 校验                           | 头透传                                      |
| ---------------- | ------------------------------------------------------------- | ------------------------------ | ------------------------------------------- |
| `backendUrl`     | Vercel AI SDK 后端地址（例如 `https://example.com/api/chat`） | 空或合法 URL                   | —（作为 `AssistantChatTransport` 的 `api`） |
| `userId`         | 用户标识                                                      | 必填，1–64 字符，trim 后非空   | `x-user-id`                                 |
| `conversationId` | 会话标识                                                      | 可选，0–128 字符，空则后端自建 | `x-conversation-id`                         |

`config.json` 位置（对齐 `run-deck`）：

- 开发期（默认 `cargo tauri dev`，`not(prod)`）：`<project_root>/.app/config.json` → 如 `D:\code\tauri\deepshow\.app\config.json`，启动时 `eprintln!("[Config] using file: ...")`
- 产线包（`tauri build -- --features prod`）：`%APPDATA%\deepshow\config.json`（Windows）或 `~/.config/deepshow/config.json`（Linux/macOS，`APPDATA`/`HOME`/`XDG_CONFIG_HOME` 依次回退），与 `run-deck` 的 `data_dir + APP_ID` 同构（见 `src-tauri/src/config/dirs.rs`）

## 优先级

`app-config.backendUrl` > `VITE_CHAT_API_URL` > `/api/chat`

`userId` 为空时不发网络请求，直接在 thread 提示去 `/config` 配置。

## 后端要求（Vercel AI SDK v7）

后端需 `ai@^7` 的 `UIMessage Stream`：

```ts
import {
  streamText,
  convertToModelMessages,
  createUIMessageStreamResponse,
  toUIMessageStream,
} from 'ai';
export async function POST(req: Request) {
  const headers = Object.fromEntries(req.headers.entries());
  const userId = headers['x-user-id'];
  const conversationId = headers['x-conversation-id'];
  const { messages } = await req.json();
  const result = streamText({ model, messages: await convertToModelMessages(messages) });
  return createUIMessageStreamResponse({ stream: toUIMessageStream({ stream: result.stream }) });
}
```

## 调试

```bash
# 直接用 header 调通
curl -X POST https://example.com/api/chat \
  -H "Content-Type: application/json" \
  -H "x-user-id: u_12345" \
  -H "x-conversation-id: c_67890" \
  -d '{"messages":[{"role":"user","content":[{"type":"text","text":"hello"}]}]}'
```

配置后无需重启，前端 `useConfig` + `useChatRuntime` 会自动使用新 `api` 与 headers。

## 线程与 HITL（ask_user）

后端为 `InMemorySaver[thread_id]` 模型（见 `POST /chat/stream` 约定）：

- **首包** `POST /chat/stream {messages:[human]}` 无 `thread_id` 时，后端 `tid = f"thread_{uuid4().hex}"` 建档，返回 `X-Thread-Id: thread_xxx`（CORS 已 `expose`），`SSE start.messageId` 为 `msgId` 非 `tid`
- **前台持久化** `src/lib/thread-id.ts` 捕获 `X-Thread-Id` 落 `localStorage.threadId` + 内存，`src/lib/assistant.ts` 的 `fetch` 包装对后续请求自动注入 `payload.thread_id` / `payload.id`，命中 `config={"configurable":{"thread_id":tid}}` 的 `__interrupt__`
- **ask_user 续跑** 工具进入 `requires-action` 且 `toolName==='ask_user'` 时，`ToolFallback` 渲染单行输入（`Input + 提交`，空校验、去重锁），提交以 `tool{content:"3"}` 经 `addResult` 回填，`body.thread_id` 保持同 `tid`，后端 `Command(resume="3")` 续跑 `task(math)` 并继续 `SSE`
- **过期重建** `InMemorySaver` 重启/过期时，后端对旧 `tid` 返回 `404` 或 `thread not found`/`interrupt not found`，前端 `clearThreadId()` 并 `toast.error('会话已过期，已重置为新会话')`，下次发消息自动重建新 `thread_xxx`；生产建议换持久化 `checkpointer`
