# Switch from fetch-direct to Tauri invoke

Starter 默认通过 `fetch` 直连 OpenAI-compatible API（`VITE_OPENAI_API_KEY` 在前端内存）。如需将 key 收敛到 Rust 侧，改为经 `invoke('chat')` 中转，按以下步骤操作，**UI 无需改动**（`Thread` 保持不变）。

## 1. 在 Rust 侧添加 command

已提供存根 `src-tauri/src/cmd/chat.rs`。启用它：

1. 将 `src-tauri/src/cmd/chat.rs` 的模块在 `src-tauri/src/lib.rs` 中注册：

```rust
mod cmd;
// in run():
builder.invoke_handler(tauri::generate_handler![cmd::chat::chat])
```

2. 在 `src-tauri/Cargo.toml` 按需添加 `reqwest`（或 `tauri-plugin-http`）依赖，用于向真实 LLM 转发。

3. 将 API key 从 `.env` 迁移到系统环境或 Tauri `config`，不要再通过 `VITE_` 前缀暴露到前端。

## 2. 在前端切换 Adapter

编辑 `src/lib/assistant.ts`，将 `createChatModelAdapter().run` 的 `fetch(apiUrl, ...)` 分支替换为：

```ts
import { invoke } from '@tauri-apps/api/core';

// inside run():
const text = await invoke<string>('chat', {
  messages: openAiMessages,
  model,
});
yield { content: [{ type: 'text' as const, text }] };
```

其他逻辑（缺 key 提示、流式解析、abort）可保留或简化。`Thread` 与 `AssistantRuntimeProvider` 无需改动，`useAssistantRuntime()` 仍返回 `useLocalRuntime(adapter)`。

## 3. 验证

```bash
npm run build
cargo check
# 设置 Rust 侧环境变量后
npm run tauri dev
```

在 chat 输入框发送消息，应经 Rust 转发并流式回显，与 fetch-direct 表现一致。

## 何时切换

- 需要避免 key 出现在前端 bundle / devtools
- 需要审计、限流、或改用内部网关

否则保持 fetch-direct 即可，starter 的 `.env` 方案已满足演示与开发。
