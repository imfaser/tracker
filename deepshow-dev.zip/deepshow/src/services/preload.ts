import { mutate } from 'swr';
import { getConfig } from './cmds';
import type { Config } from '@/schemas/config';

export interface PreloadedData {
  config: Config;
}

export async function preloadAppData(): Promise<PreloadedData> {
  const config = await getConfig();
  await mutate('config', config, { revalidate: false });
  return { config };
}
