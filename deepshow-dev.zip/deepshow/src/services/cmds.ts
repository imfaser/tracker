import { invoke } from '@tauri-apps/api/core';
import { parseConfig, type Config } from '@/schemas/config';

const LS_KEY = 'deepshow-config';

function readLocalFallback(): Config {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      return parseConfig(JSON.parse(raw));
    }
  } catch {}
  return parseConfig({});
}

function writeLocalFallback(cfg: Config) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(cfg));
  } catch {}
}

export async function getConfig(): Promise<Config> {
  try {
    const raw = await invoke<unknown>('get_config');
    const cfg = parseConfig(raw);
    writeLocalFallback(cfg);
    return cfg;
  } catch {
    return readLocalFallback();
  }
}

export async function getConfigPath(): Promise<string> {
  try {
    return await invoke<string>('get_config_path');
  } catch {
    return '(web preview: localStorage)';
  }
}

export async function updateConfig(newConfig: Config): Promise<void> {
  writeLocalFallback(newConfig);
  const payload = {
    backend_url: newConfig.backendUrl,
    user_id: newConfig.userId,
    conversation_id: newConfig.conversationId,
  };
  try {
    await invoke('update_config', { newConfig: payload });
  } catch (e) {
    console.warn('[config] update_config invoke failed, using local fallback', e);
  }
}
