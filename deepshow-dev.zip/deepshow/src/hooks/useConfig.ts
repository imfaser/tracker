import useSWR from 'swr';
import { useLockFn } from 'ahooks';
import { toast } from 'sonner';
import { getConfig, updateConfig } from '@/services/cmds';
import { parseConfig, type Config } from '@/schemas/config';

export function useConfig() {
  const {
    data: config,
    error,
    isLoading,
    mutate,
  } = useSWR<Config>('config', getConfig, {
    revalidateOnFocus: false,
    revalidateOnMount: false,
    shouldRetryOnError: false,
    fallbackData: parseConfig({}),
  });

  const patchConfig = useLockFn(async (updater: (draft: Config) => void) => {
    if (!config) {
      return;
    }
    const next = structuredClone(config);
    updater(next);
    await mutate(
      updateConfig(next).then(() => next),
      {
        optimisticData: next,
        rollbackOnError: true,
        populateCache: true,
        revalidate: false,
      }
    ).catch(() => {
      toast.error('配置保存失败，已回滚');
    });
  });

  const setBackendUrl = (v: string) =>
    patchConfig((c) => {
      c.backendUrl = v;
    });
  const setUserId = (v: string) =>
    patchConfig((c) => {
      c.userId = v;
    });
  const setConversationId = (v: string) =>
    patchConfig((c) => {
      c.conversationId = v;
    });
  const setAll = (next: Config) =>
    patchConfig((c) => {
      c.backendUrl = next.backendUrl;
      c.userId = next.userId;
      c.conversationId = next.conversationId;
    });

  return {
    config,
    error,
    isLoading,
    patchConfig,
    setBackendUrl,
    setUserId,
    setConversationId,
    setAll,
    mutate,
  };
}
