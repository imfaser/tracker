import type { ReactNode } from 'react';
import TitleBar from './TitleBar';

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="h-screen bg-background text-foreground overflow-hidden flex flex-col">
      <TitleBar />
      <main className="pt-10 flex-1 min-h-0 overflow-hidden flex flex-col">{children}</main>
    </div>
  );
}
