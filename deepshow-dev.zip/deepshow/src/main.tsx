import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Toaster } from 'sonner';
import { preloadAppData } from '@/services/preload';
import App from './App';
import './index.css';

async function bootstrap() {
  try {
    await preloadAppData();
  } catch (e) {
    console.warn('[preload] failed, continuing with defaults', e);
  }

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
      <Toaster position="top-center" offset={44} richColors />
    </StrictMode>
  );
}

bootstrap().catch((e) => {
  console.error(e);
});
