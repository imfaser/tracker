import { z } from 'zod';

export const ConfigSchema = z.object({
  backendUrl: z
    .string()
    .trim()
    .refine((v) => v === '' || URL.canParse(v), { message: 'URL 格式无效' })
    .default(''),
  userId: z.string().trim().max(64, '用户 ID 最多 64 字符').default(''),
  conversationId: z.string().trim().max(128, '会话 ID 最多 128 字符').default(''),
});

export const ConfigFormSchema = ConfigSchema.extend({
  userId: z.string().trim().min(1, '用户 ID 不能为空').max(64, '用户 ID 最多 64 字符'),
});

export type Config = z.infer<typeof ConfigSchema>;

// Rust side uses snake_case; normalize to camelCase before parsing.
function normalizeKeys(raw: unknown): unknown {
  if (raw == null || typeof raw !== 'object' || Array.isArray(raw)) {
    return raw;
  }
  const rec = raw as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(rec)) {
    const camel = k.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());
    out[camel] = v;
  }
  return out;
}

export function parseConfig(raw: unknown): Config {
  const normalized = normalizeKeys(raw);
  const pass1 = ConfigSchema.parse(normalized);
  return ConfigSchema.parse(pass1);
}
