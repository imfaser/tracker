const STORAGE_KEY = 'threadId';

// 不再用 localStorage（跨重启污染 InMemorySaver），改用 sessionStorage + 内存，标签页/应用重启即失活
// 首次加载时顺手清理旧 localStorage 残留，避免旧 tid 串线
let memoryCache: string | null = null;
let memoryInitialized = false;

function readStorage(): string | null {
  try {
    if (typeof window === 'undefined') return null;
    // 迁移清理：删掉旧 localStorage 残留
    try {
      if (window.localStorage?.getItem(STORAGE_KEY)) {
        window.localStorage.removeItem(STORAGE_KEY);
      }
    } catch {}
    const s = window.sessionStorage?.getItem(STORAGE_KEY);
    return s ?? null;
  } catch {
    return null;
  }
}

function writeStorage(value: string): void {
  try {
    if (typeof window === 'undefined') return;
    window.sessionStorage?.setItem(STORAGE_KEY, value);
  } catch {
    // sessionStorage unavailable, fallback to memory only
  }
}

function removeStorage(): void {
  try {
    if (typeof window === 'undefined') return;
    window.sessionStorage?.removeItem(STORAGE_KEY);
    // 双保险清旧 localStorage
    try {
      window.localStorage?.removeItem(STORAGE_KEY);
    } catch {}
  } catch {
    // ignore
  }
}

export function getThreadId(): string | null {
  if (!memoryInitialized) {
    memoryCache = readStorage();
    memoryInitialized = true;
  }
  // Prefer memory cache but sync from storage if memory is null
  if (memoryCache) {
    return memoryCache;
  }
  const stored = readStorage();
  if (stored) {
    memoryCache = stored;
    return stored;
  }
  return null;
}

export function setThreadId(id: string): void {
  const trimmed = id.trim();
  if (!trimmed) {
    return;
  }
  memoryCache = trimmed;
  memoryInitialized = true;
  writeStorage(trimmed);
}

export function clearThreadId(): void {
  memoryCache = null;
  memoryInitialized = true;
  removeStorage();
}

// For tests: reset memory without touching storage logic more than needed
export function resetThreadIdCacheForTest(): void {
  memoryCache = null;
  memoryInitialized = false;
}
