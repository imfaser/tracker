'use client';

import { defineToolkit } from '@assistant-ui/react';
import { useState } from 'react';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

// 官方文档 Tool UI -> Interactive Tool UIs -> User Input Collection
// https://www.assistant-ui.com/docs/tools/tool-ui#user-input-collection
// type: "human" + addResult exactly once, 无需 "use generative" / humanTool()，runtime 会把 tool result 作为消息续跑

const askUserParams = z.object({
  prompt: z.string().optional(),
  question: z.string().optional(),
  message: z.string().optional(),
});

type AskUserArgs = z.infer<typeof askUserParams>;

function AskUserUI(props: {
  args: AskUserArgs;
  result?: unknown;
  addResult: (r: unknown) => void;
  status: { type: string };
}) {
  const { args, result, status } = props;
  const [value, setValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (result !== undefined) {
    const text = String((result as { content?: unknown })?.content ?? result);
    return (
      <div className="rounded-md bg-muted/50 p-3 text-sm">
        <span className="text-muted-foreground">已回复：</span>
        <span className="font-medium">{text}</span>
      </div>
    );
  }

  const prompt = args?.prompt ?? args?.question ?? args?.message ?? '请输入回复';
  const isCompleted = status?.type === 'complete';

  if (isCompleted) return null;

  const handleSubmit = () => {
    const trimmed = value.trim();
    if (!trimmed) {
      setError('请输入内容');
      return;
    }
    setError(null);
    // 关键：不能解构 addResult（issue #3173），必须 props.addResult 保持 proxy 上下文，否则不发第二包
    props.addResult(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className={cn('flex flex-col gap-2 rounded-lg border bg-card p-3')}>
      <p className="text-sm font-medium">{prompt}</p>
      <div className="flex gap-2">
        <Input
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            if (error) setError(null);
          }}
          onKeyDown={handleKeyDown}
          placeholder="请输入..."
          autoFocus
          className="flex-1 h-8"
          aria-label="ask_user input"
        />
        <Button size="sm" onClick={handleSubmit}>
          提交
        </Button>
      </div>
      {error && <p className="text-destructive text-xs">{error}</p>}
      <p className="text-muted-foreground text-xs">提交后将以 tool 内容续跑同一 thread</p>
    </div>
  );
}

export const toolkit = defineToolkit({
  ask_user: {
    type: 'human' as const,
    description: 'Ask the user for missing parameter (e.g. radius)',
    parameters: askUserParams,
    render: AskUserUI as unknown as (props: unknown) => React.ReactNode,
  },
  askUser: {
    type: 'human' as const,
    description: 'Ask the user for missing parameter',
    parameters: askUserParams,
    render: AskUserUI as unknown as (props: unknown) => React.ReactNode,
  },
});
