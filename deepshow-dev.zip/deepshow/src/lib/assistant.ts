import { useMemo } from 'react';
import { useChatRuntime, AssistantChatTransport } from '@assistant-ui/react-ai-sdk';
import { useConfig } from '@/hooks/useConfig';
import { toast } from 'sonner';
import { clearThreadId, getThreadId, setThreadId } from '@/lib/thread-id';

const DEFAULT_API_URL = '/api/chat';

function getEnv(name: string): string | undefined {
  return (import.meta as unknown as { env: Record<string, string | undefined> }).env?.[name];
}

export function useAssistantRuntime() {
  const { config } = useConfig();

  const api = useMemo(() => {
    const cfgUrl = config?.backendUrl?.trim();
    if (cfgUrl) {
      return cfgUrl;
    }
    const envUrl = getEnv('VITE_CHAT_API_URL')?.trim();
    if (envUrl) {
      return envUrl;
    }
    return DEFAULT_API_URL;
  }, [config?.backendUrl]);

  const headers = useMemo<Record<string, string>>(() => {
    const h: Record<string, string> = {};
    const uid = config?.userId?.trim();
    const cid = config?.conversationId?.trim();
    if (uid) {
      h['x-user-id'] = uid;
    }
    if (cid) {
      h['x-conversation-id'] = cid;
    }
    return h;
  }, [config?.userId, config?.conversationId]);

  const hasUserId = Boolean(config?.userId?.trim());

  const transport = useMemo(
    () =>
      new AssistantChatTransport({
        api,
        headers,
        fetch: async (input, init) => {
          if (!hasUserId) {
            return new Response(
              JSON.stringify({
                error: 'Missing x-user-id. Please configure userId in /config.',
              }),
              {
                status: 400,
                headers: { 'Content-Type': 'application/json' },
              }
            );
          }

          // Inject stored thread_id into JSON body when present
          // 后端取 `payload.id || payload.thread_id` 作为 tid，必须让两者都对齐到 storedTid
          let nextInit: RequestInit | undefined = init;
          const storedTid = getThreadId();
          if (storedTid && init?.body && typeof init.body === 'string') {
            try {
              const payload = JSON.parse(init.body as string);
              const hasMessages =
                payload && typeof payload === 'object' && Array.isArray(payload.messages);
              if (
                hasMessages ||
                'thread_id' in payload ||
                'id' in payload ||
                'threadId' in payload
              ) {
                const payloadAny = payload as Record<string, unknown>;
                const nextPayload: Record<string, unknown> = {
                  ...payloadAny,
                  thread_id: storedTid,
                  id: storedTid,
                  threadId: storedTid,
                };
                if (
                  payloadAny.thread_id !== storedTid ||
                  payloadAny.id !== storedTid ||
                  payloadAny.threadId !== storedTid
                ) {
                  nextInit = { ...init, body: JSON.stringify(nextPayload) };
                }
              }
            } catch {
              // ignore parse errors, forward original init
            }
          }

          const resp = await fetch(input as RequestInfo, nextInit);

          // Capture X-Thread-Id from response headers (CORS exposed), fallback to SSE start.messageMetadata.threadId
          try {
            const tidHeader = resp.headers.get('X-Thread-Id') ?? resp.headers.get('x-thread-id');
            if (tidHeader && tidHeader.trim()) {
              setThreadId(tidHeader.trim());
            } else if (resp.ok && resp.headers.get('content-type')?.includes('text/event-stream')) {
              // SSE fallback: peek first chunk for threadId without consuming original stream
              const clone = resp.clone();
              const reader = clone.body?.getReader();
              if (reader) {
                const decoder = new TextDecoder();
                const { value } = await reader.read();
                if (value) {
                  const text = decoder.decode(value);
                  const m = text.match(/"threadId"\s*:\s*"([^"]+)"|"thread_id"\s*:\s*"([^"]+)"/);
                  const sseTid = m?.[1] || m?.[2];
                  if (sseTid) setThreadId(sseTid);
                }
                try {
                  await reader.cancel();
                } catch {}
              }
            }
          } catch {
            // ignore header/SSE read errors
          }

          // Detect stale thread (InMemorySaver lost, e.g. server restart) - backend now sends X-Error-Code: thread_not_found
          if (resp.status === 404) {
            const errCode = resp.headers.get('X-Error-Code') ?? resp.headers.get('x-error-code');
            if (errCode === 'thread_not_found') {
              clearThreadId();
              toast.error('会话已过期，已重置为新会话');
            } else {
              try {
                const clone = resp.clone();
                const text = await clone.text();
                if (
                  text.toLowerCase().includes('thread not found') ||
                  text.toLowerCase().includes('interrupt not found') ||
                  text.toLowerCase().includes('thread_id')
                ) {
                  clearThreadId();
                  toast.error('会话已过期，已重置为新会话');
                } else {
                  clearThreadId();
                }
              } catch {
                clearThreadId();
              }
            }
          }

          return resp;
        },
      }),
    [api, headers, hasUserId]
  );

  const runtime = useChatRuntime({ transport });

  return runtime;
}
