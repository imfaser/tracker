import { describe, it, expect, beforeEach } from 'vitest';
import { getThreadId, setThreadId, clearThreadId, resetThreadIdCacheForTest } from './thread-id';

describe('thread-id', () => {
  beforeEach(() => {
    resetThreadIdCacheForTest();
    window.localStorage.clear();
    window.sessionStorage.clear();
  });

  it('writes and reads threadId', () => {
    setThreadId('thread_95a0abc');
    expect(getThreadId()).toBe('thread_95a0abc');
    expect(window.sessionStorage.getItem('threadId')).toBe('thread_95a0abc');
    // 旧 localStorage 不应残留
    expect(window.localStorage.getItem('threadId')).toBeNull();
  });

  it('clear removes threadId', () => {
    setThreadId('thread_xxx');
    clearThreadId();
    expect(getThreadId()).toBeNull();
    expect(window.sessionStorage.getItem('threadId')).toBeNull();
  });

  it('get after clear returns null without storage', () => {
    setThreadId('thread_a');
    clearThreadId();
    resetThreadIdCacheForTest();
    expect(getThreadId()).toBeNull();
  });

  it('trims whitespace', () => {
    setThreadId('  thread_trim  ');
    expect(getThreadId()).toBe('thread_trim');
  });

  it('ignores empty', () => {
    setThreadId('   ');
    expect(getThreadId()).toBeNull();
  });
});
