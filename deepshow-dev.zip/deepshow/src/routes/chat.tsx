import { createFileRoute } from '@tanstack/react-router';
import { AssistantRuntimeProvider, AuiConfig, Tools } from '@assistant-ui/react';
import { Thread } from '@/components/assistant-ui/thread';
import { useAssistantRuntime } from '@/lib/assistant';
import { toolkit } from '@/lib/toolkit';

export const Route = createFileRoute('/chat')({
  component: ChatPage,
});

function ChatPage() {
  const runtime = useAssistantRuntime();
  // oxlint-disable-next-line new-cap, react/capitalized-calls
  const config = AuiConfig({ tools: Tools({ toolkit }) });

  return (
    <AssistantRuntimeProvider runtime={runtime} config={config}>
      <div className="flex flex-1 min-h-0 flex-col overflow-hidden">
        <Thread />
      </div>
    </AssistantRuntimeProvider>
  );
}
