import { useEffect, useState } from 'react';
import { createFileRoute } from '@tanstack/react-router';
import { useMemoizedFn } from 'ahooks';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useConfig } from '@/hooks/useConfig';
import { ConfigFormSchema } from '@/schemas/config';
import { getConfigPath } from '@/services/cmds';
import { LABELS } from '@/constants/labels';

export const Route = createFileRoute('/config')({
  component: ConfigPage,
});

function ConfigPage() {
  const { config, error, isLoading, mutate, setAll } = useConfig();
  const [backendUrl, setBackendUrl] = useState('');
  const [userId, setUserId] = useState('');
  const [conversationId, setConversationId] = useState('');
  const [errors, setErrors] = useState<{
    backendUrl?: string;
    userId?: string;
    conversationId?: string;
  }>({});
  const [saving, setSaving] = useState(false);
  const [configPath, setConfigPath] = useState<string>('');

  useEffect(() => {
    getConfigPath()
      .then(setConfigPath)
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (config) {
      setBackendUrl(config.backendUrl);
      setUserId(config.userId);
      setConversationId(config.conversationId);
    }
  }, [config]);

  const isDirty =
    config != null &&
    (backendUrl !== config.backendUrl ||
      userId !== config.userId ||
      conversationId !== config.conversationId);

  const validate = useMemoizedFn(() => {
    const result = ConfigFormSchema.safeParse({ backendUrl, userId, conversationId });
    if (result.success) {
      setErrors({});
      return true;
    }
    const fieldErrors: typeof errors = {};
    for (const issue of result.error.issues) {
      const field = issue.path[0] as keyof typeof errors;
      if (!fieldErrors[field]) {
        fieldErrors[field] = issue.message;
      }
    }
    setErrors(fieldErrors);
    return false;
  });

  const handleSave = useMemoizedFn(async () => {
    if (!validate()) {
      return;
    }
    setSaving(true);
    const next = {
      backendUrl: backendUrl.trim(),
      userId: userId.trim(),
      conversationId: conversationId.trim(),
    };
    let ok = false;
    try {
      await setAll(next);
      ok = true;
    } catch {
      ok = false;
    }
    if (ok) {
      toast.success(LABELS.settings.saved);
    } else {
      toast.error(LABELS.settings.saveFailed);
    }
    setSaving(false);
  });

  const handleGenerate = useMemoizedFn(() => {
    const id = crypto.randomUUID();
    setConversationId(id);
  });

  if (error) {
    return (
      <div className="flex-1 min-h-0 overflow-y-auto [scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border/50 [&::-webkit-scrollbar-track]:bg-transparent">
        <div className="max-w-2xl mx-auto p-8 space-y-4">
          <p className="text-sm text-destructive">
            配置加载失败：{String((error as Error)?.message ?? error)}
          </p>
          <Button variant="outline" onClick={() => mutate()}>
            重试
          </Button>
        </div>
      </div>
    );
  }

  if (!config || isLoading) {
    return (
      <div className="flex-1 min-h-0 overflow-y-auto [scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border/50 [&::-webkit-scrollbar-track]:bg-transparent">
        <div className="max-w-2xl mx-auto p-8">
          <p className="text-muted-foreground text-sm">加载配置中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-0 overflow-y-auto [scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border/50 [&::-webkit-scrollbar-track]:bg-transparent">
      <div className="max-w-2xl mx-auto p-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{LABELS.settings.title}</h1>
          <p className="text-muted-foreground text-sm mt-1">
            快速测试用：配置后端与身份标识，保存后立即生效
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{LABELS.settings.title}</CardTitle>
            <CardDescription>{LABELS.settings.backendUrlHint}</CardDescription>
            {configPath ? (
              <p className="text-xs text-muted-foreground break-all">配置文件：{configPath}</p>
            ) : null}
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium">{LABELS.settings.backendUrl}</label>
              <Input
                value={backendUrl}
                onChange={(e) => setBackendUrl(e.target.value)}
                onBlur={validate}
                placeholder={LABELS.settings.backendUrlPlaceholder}
              />
              {errors.backendUrl ? (
                <p className="text-xs text-destructive">{errors.backendUrl}</p>
              ) : (
                <p className="text-xs text-muted-foreground">{LABELS.settings.backendUrlHint}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">
                {LABELS.settings.userId} <span className="text-destructive">*</span>
                <span className="ml-1 text-xs text-muted-foreground">
                  ({LABELS.settings.required})
                </span>
              </label>
              <Input
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                onBlur={validate}
                placeholder={LABELS.settings.userIdPlaceholder}
              />
              {errors.userId && <p className="text-xs text-destructive">{errors.userId}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">{LABELS.settings.conversationId}</label>
              <div className="flex gap-2">
                <Input
                  value={conversationId}
                  onChange={(e) => setConversationId(e.target.value)}
                  onBlur={validate}
                  placeholder={LABELS.settings.conversationIdPlaceholder}
                  className="flex-1"
                />
                <Button type="button" variant="outline" onClick={handleGenerate}>
                  {LABELS.settings.generate}
                </Button>
              </div>
              {errors.conversationId ? (
                <p className="text-xs text-destructive">{errors.conversationId}</p>
              ) : (
                <p className="text-xs text-muted-foreground">通过请求头 x-conversation-id 透传</p>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={handleSave} disabled={!isDirty || saving}>
                {saving ? '保存中...' : LABELS.settings.save}
              </Button>
            </div>
            {!isDirty && <p className="text-xs text-muted-foreground text-right">无未保存的修改</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
