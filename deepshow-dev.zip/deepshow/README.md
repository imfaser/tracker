# deepshow — Tauri + Assistant UI Starter

基于 `D:\code\tauri\run-deck` 抽取的极简 starter：**前端重、Tauri 极简、开箱即带 AI 对话**。

## Tech Stack

- Vite 8.2.2 + React 19.2.8 + TypeScript 7 + Tailwind 4.3.3 + shadcn/base-nova (`@base-ui/react 1.7.0`) + TanStack Router (hashHistory) + Zustand 5.0.15 + immer 11.1.18
- Assistant UI 0.15.16 + `@assistant-ui/react-ai-sdk 1.4.7` / `ai 7.0.77` + `@ai-sdk/react 4.0.80`（Vercel AI SDK `UIMessage Stream`，`useChatRuntime` + `AssistantChatTransport`）
- 应用配置 `app-config`（Rust `config.json` 持久化：`backendUrl` / `userId*` / `conversationId`，`/config` 可视化编辑）
- Tauri 2（仅 `opener` + `dialog` 插件，`decorations:false` 无边框）
- 包管理：**npm**（`package-lock.json`）
- 质量门禁：`oxlint 1.79.0 / oxfmt 0.64.0 / tsc -b / vite build / cargo check`

## Quick Start

```bash
npm install
cp .env.example .env  # 填入 VITE_OPENAI_API_KEY
npm run dev           # Vite only
npm run tauri         # Tauri dev (npm run dev + 一并启动)
npm run build         # 前端构建（tsc -b && vite build）
just lint && just format-check && just test && just web-build && cargo check
```

## Env / Config

- **首选**：应用内 `/config`（`src-tauri/src/config/mod.rs` → `.app/config.json`）配置 `backendUrl` / `userId`（必填）/ `conversationId`，保存后即时生效（见 `docs/config.md`）。
- **回退**：`.env` 仅作兜底，参见 `.env.example`：

```
VITE_OPENAI_API_KEY=sk-...
VITE_CHAT_API_URL=https://api.openai.com/v1/chat/completions
VITE_CHAT_MODEL=gpt-4o-mini
```

未配置 `userId` 或后端地址时，chat 仍可打开，发送消息会显示引导去 `/config` 的错误态而非崩溃（见 `src/lib/assistant.ts` 的 header 注入 `x-user-id` / `x-conversation-id`）。

切换到 Rust 持有 key：`docs/switch-to-invoke.md`。

## Routes

- `/` → redirect `/chat`
- `/chat` — `AssistantRuntimeProvider` + `Thread`（assistant-ui，Vercel AI SDK `useChatRuntime`）
- `/config` — 应用配置（backendUrl / userId / conversationId，`x-user-id` / `x-conversation-id` 头透传）
- HashHistory（Tauri 必须，见 `src/router.tsx`）

## React Compiler

项目启用 `babel-plugin-react-compiler`（`@rolldown/plugin-babel + @vitejs/plugin-react`）。**禁止手动 `useMemo/useCallback`**，由 Compiler 兜底。

### react-hook-form `form.watch()` 坑

`useForm().watch()` 被编译器标记为 known-incompatible，渲染期调用会让**整个文件** bailout，`vite build` 出现：

```
Skipped: ... Use of incompatible library
```

必须改用 `useWatch`：

```tsx
// ✗ 错误：导致文件跳过编译
<Switch checked={form.watch('enabled')} />;

// ✓ 正确
import { useWatch } from 'react-hook-form';
const enabled = useWatch({ control: form.control, name: 'enabled' });
<Switch checked={enabled} />;
```

自检：

```bash
npm run build 2>&1 | grep -i "Skipped"
# 应无输出；若有，定位对应文件并改用 useWatch
```

详见：react-hook-form Discussion #12524；`AGENTS.md` 中展开。

## Project Structure

```
src/
  components/ui/            shadcn 20+ 组件
  components/assistant-ui/  thread / thread-list 等（shadcn registry 拉取）
  components/layout/        AppLayout + TitleBar (frameless)
  components/theme-provider.tsx  localStorage 版
  lib/assistant.ts          Vercel AI SDK useChatRuntime + AssistantChatTransport (headers: x-user-id/x-conversation-id)
  lib/utils.ts              cn()
  routes/                   file-based（routeTree.gen.ts 自动生成）
  store/app.ts              zustand + immer
  schemas/config.ts         zod 校验（backendUrl/userId/conversationId）
  services/cmds.ts          get_config/update_config invoke
  hooks/useConfig.ts        SWR 乐观更新
src-tauri/
  src/config/mod.rs + dirs.rs  轻量 config.json 持久化
  src/lib.rs + setup.rs + tauri.conf.json + capabilities/default.json
  docs/config.md            配置与 Vercel 后端对接说明
```

## Tauri Shell

- `tauri.conf.json: windows[0].decorations:false` + `TitleBar` 的 `getCurrentWindow()` 控制（minimize/maximize/close + 拖拽）
- 仅 `opener`/`dialog` 插件，capabilities 仅 `core:window:*` 最小集
- `lib.rs: on_window_event` 关闭 main 时清理子窗口
