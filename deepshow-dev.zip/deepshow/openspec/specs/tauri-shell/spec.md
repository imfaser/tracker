# Tauri Shell

## Purpose

Defines the minimal Tauri shell for the starter: a frameless window with a React TitleBar, just enough plugins and capabilities to ship a desktop chat app while keeping Rust surface minimal.

## Requirements

### Requirement: Frameless window with React TitleBar

The system SHALL run with `decorations:false` and render a React `TitleBar` that provides window controls (minimize, toggleMaximize, close) and theme toggle, and the window SHALL remain draggable via `data-tauri-drag-region` while controls themselves are non-draggable.

#### Scenario: Window controls work

- **WHEN** the user clicks minimize, maximize/restore, or close in the TitleBar
- **THEN** the system invokes the corresponding `getCurrentWindow()` action and the window state updates accordingly.

#### Scenario: Window is draggable but controls are not

- **WHEN** the user drags the TitleBar background
- **THEN** the window moves, but clicking or dragging the control buttons does not initiate a drag.

### Requirement: Main window cleans up child windows on close

The system SHALL close any secondary webview windows when the `main` window receives `CloseRequested`, preventing orphan windows on exit.

#### Scenario: Closing main closes all windows

- **WHEN** the user closes the main window while secondary windows are open
- **THEN** secondary windows are closed before the app exits.

### Requirement: Only opener and dialog plugins are included

The system SHALL include `tauri-plugin-opener` and `tauri-plugin-dialog` and SHALL NOT include business plugins (logging/MCP/DB) from `run-deck`.

#### Scenario: Starter builds without extra crates

- **WHEN** the starter is built with `cargo check` and `npm run build`
- **THEN** the build succeeds with only `tauri`, `tauri-plugin-opener`, and `tauri-plugin-dialog` as Tauri dependencies.

### Requirement: Tauri config uses npm

The system SHALL configure `tauri.conf.json` with `beforeDevCommand: "npm run dev"`, `devUrl: "http://localhost:6917"` (or documented port), and `frontendDist: "../dist"`, and capabilities SHALL be defined in `capabilities/default.json`.

#### Scenario: npm dev launches the app

- **WHEN** a developer runs `npm run tauri dev` (or `cargo tauri dev`)
- **THEN** the Tauri CLI launches Vite via npm and loads the dev URL without referencing pnpm.

### Requirement: Capabilities grant only required window permissions

The system SHALL grant only the window permissions needed for TitleBar controls (minimize/maximize/close/isMaximized/onResized) in `capabilities/default.json`.

#### Scenario: Permissions are minimal

- **WHEN** the capabilities file is inspected
- **THEN** it contains window permissions for the required actions and does not grant filesystem, shell, or other broad permissions.
