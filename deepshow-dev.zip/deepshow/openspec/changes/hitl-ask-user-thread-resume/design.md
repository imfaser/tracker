## Context

当前 `src/lib/assistant.ts` 以 `useChatRuntime({ transport: new AssistantChatTransport({ api, headers }) })` 直连 `POST /chat/stream`，`Thread` 在 `src/routes/chat.tsx` 以 `AssistantRuntimeProvider` 包裹。`src/components/assistant-ui/tool-fallback.tsx` 已有 `requires-action/interrupt` 的 `Allow/Deny` 审批，但无 `ask_user` 补参输入。后端为 `InMemorySaver[tid]` 模型：首包无 `thread_id` 时 `thread_xxx = f"thread_{uuid4().hex}"` 建档并经 `X-Thread-Id` 响应头（已 `expose`）返回，`start.messageId` 为 `msgId` 非 `tid`；续跑依赖 `payload.id || payload.thread_id` 命中 `config={"configurable":{"thread_id":tid}}` 并 `Command(resume)`。参见 `proposal.md` Why。

约束：`routeTree.gen.ts` 自动生成勿手改；启用 `babel-plugin-react-compiler` 禁止手写 `useMemo/useCallback`；`TitleBar` 为 Tauri 无边框拖拽区。

## Goals / Non-Goals

**Goals:**

- 首包可靠捕获 `X-Thread-Id` 并持久化，后续请求自动续同一个 `tid`
- `ask_user` 中断可输入并以 `tool{content}` + `thread_id` 续跑，`__interrupt__` 正确 `resume`
- 丢失的 `tid`（重启/过期）可清理并重建，不卡死

**Non-Goals:**

- 不引入持久化 `checkpointer`（仍 `InMemorySaver`），不改后端 `X-Thread-Id` 协议
- 不为所有工具做通用 JSON Schema 表单生成，仅 `ask_user` 单行输入闭环（可扩展点预留）
- 不改 `Thread` 分组归并逻辑，仅扩展 `ToolFallback` 输入态

## Decisions

**Decision: `fetch` 包装捕获头 + 重写 body 注入 `thread_id`**

- 做法：`AssistantChatTransport({ fetch: async (input, init) => { resp = await fetch(input,init); tid=resp.headers.get('X-Thread-Id'); if(tid) persist; return resp } })` 捕获；请求侧 `init.body` 为 JSON 时 `JSON.parse` 后注入 `{ ...payload, thread_id: stored||payload.thread_id, id: stored||payload.id }` 再 `JSON.stringify`
- 备选：让 `useChatRuntime` 传 `id` prop 暴露 tid。拒绝：`@assistant-ui/react-ai-sdk` 的 `useChatRuntime` 未暴露 `id` 透传，改 `fetch` 更贴合现有 `headers` 动态重建模式（已用 `useMemo` 随 `config` 重建 transport）
- 持久化：`src/lib/thread-id.ts` 小模块 + `localStorage("threadId")` + 内存变量，`Zustand` 也可但单 key 无需 store，避免额外重渲染

**Decision: `ToolFallback` 扩展 `ask_user` 输入态，与 `Approval` 并存**

- 做法：`ToolFallbackImpl` 内判 `toolName==='ask_user' || interrupt?.type==='ask_user'` 时渲染 `Input + Button`，`submitted` 锁，空值校验，提交调 `addResult(value)`（`assistant-ui` 会转成 `tool{content}` 消息）；若后端要求 `resume` 通道则改 `resume(value)`
- 备选：为每个工具注册 `tool({ render })`。拒绝：当前仅 `ask_user` 需 HITL，通用兜底更快；`render` 方案可后增不冲突
- `useWatch` 约束：输入用 `react-hook-form` + `useWatch`，不在渲染期调 `form.watch()`

**Decision: 失效清理策略**

- 做法：`fetch` 收到 `404` 或 `error` 含 `thread not found` / `interrupt not found` 时清 `localStorage` + 内存，回 `toast` 提示会话过期，下次发消息自动新 `tid`
- 备选：静默重建不提示。拒绝：用户会困惑为何历史丢了，提示更可预期

## Risks / Trade-offs

- [Risk] `AssistantChatTransport` 的 `fetch` 重写 `body` 可能与流式编码冲突 → Mitigation：仅当 `init.body` 为 `string` 且 `JSON.parse` 成功且含 `messages` 时才注入，其他（`FormData`/流）原样透传
- [Risk] `X-Thread-Id` 未暴露导致 `get` 为 null → Mitigation：仅当头存在才写存储，缺失时当新 thread，不阻塞首包
- [Risk] `InMemorySaver` 重启丢数据导致旧 `tid` 永久 404 → Mitigation：清理 + 重建 + 提示，文档注明生产应换持久化 checkpointer
- [Risk] `addResult` vs `resume` 语义选错导致 `Command(resume)` 不触发 → Mitigation：先按 `tool{content}` 的 `addResult` 实现，联调时若后端收不到 `resume` 则切 `resume`，UI 层抽象 `resolveAskUser(value)` 兼容两者

## Migration Plan

1. 上线：无 DB 迁移，仅前端发版；旧 `localStorage.threadId` 若存在且有效则复用，无则首包重建
2. 回滚：前端回退到当前版本，仅丢 `ask_user` 续跑能力，普通对话不受影响；`X-Thread-Id` 头忽略即可
3. 部署顺序：前端先发，后端已就绪无需发版

## Open Questions

- `ask_user` 未来是否需多字段结构化表单？当前按单行字符串闭环，扩展为 `zod` 表单时再加通用 `ToolHumanInput` 组件
- 后端错误码对 `thread not found` 是否有稳定标识？当前按字符串匹配，后续可约 `code: "THREAD_NOT_FOUND"` 更可靠
