## Why

前端当前对 `ask_user` 人机交互无 UI：工具因缺参进入 `requires-action/interrupt` 后线程停滞，用户无入口补参。后端已实现 `InMemorySaver[thread_id]` + `X-Thread-Id` 响应头 + `Command(resume)` 续跑的 HITL 闭环，首包 `POST /chat/stream {messages:[human]}` 建 `thread_xxx` 并从头回传，后续 `POST /chat/stream {messages:[..., tool{content:"3"}], thread_id}` 命中同 `thread_id` 续跑，但前端既不持久化 `thread_id` 也不渲染补参表单，导致工具永远无法恢复。

## What Changes

- 首包捕获并持久化 `X-Thread-Id`（CORS 已 `expose`），`localStorage` + 内存 store 双写，`SSE start.messageId` 不当作 `tid`
- 续跑注入：后续 `/chat/stream` 请求自动带 `payload.id || payload.thread_id = tid`（经 `AssistantChatTransport` 的 `fetch` 包装改写 `body`），命中 `Saver[tid].__interrupt__`
- `ask_user` HITL UI：在 `ToolFallback` 内判 `status.type==='requires-action'` 且 `toolName==='ask_user'`（或 `interrupt.type==='ask_user'`）时渲染单行输入 + 提交，提交内容以 `tool{content}` 回填，触发 `Command(resume="3")` 续跑 `task(math)` 等后续节点
- 清理与重建：`InMemorySaver` 丢失（404/interrupt not found）时清掉本地 `threadId` 并提示重建新 thread
- 文档与可观测：说明 `X-Thread-Id` 链路与 ask_user 恢复流程

## Capabilities

### New Capabilities

- `thread-hitl`: 线程持久化与 ask_user 人机补参闭环（tid 捕获/注入、续跑、失效重建、UI 输入态）

### Modified Capabilities

- `assistant-runtime`: 从 fetch 直连 `AssistantChatTransport` 扩展为携带 `thread_id` 的 HITL 感知运行时，`Thread` 保持 `AssistantRuntimeProvider` 用法不变

## Impact

- `src/lib/assistant.ts`：`fetch` 包装捕获头、注入 `thread_id`，新增 `src/lib/thread-id.ts` 或 `src/store/thread.ts` 持久化
- `src/components/assistant-ui/tool-fallback.tsx`：新增 `ask_user` 输入态（与现有 `Approval` 并存）
- `src/components/assistant-ui/thread.tsx`：`toolUI ?? ToolFallback` 保持，归组不变
- 后端：无改动，复用现有 `POST /chat/stream` 与 `X-Thread-Id` 约定
- 兼容：`InMemorySaver` 丢 thread 属于预期，回退为新 thread；不影响无 HITL 的普通对话
