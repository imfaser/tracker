## MODIFIED Requirements

### Requirement: LocalRuntime with fetch-direct chat

The system SHALL provide a chat runtime via `useChatRuntime` + `AssistantChatTransport` (`@assistant-ui/react-ai-sdk`, `ai@^7`) that calls the configured chat endpoint via `fetch`, injects identity headers (`x-user-id`, `x-conversation-id`), and persists/attaches `thread_id` for HITL resumption, streaming `UIMessage` parts into the thread without requiring `Thread` changes.

#### Scenario: User sends a message and receives a streamed reply

- **WHEN** the user sends a text message
- **THEN** the runtime invokes the transport with `{messages, system, tools}` plus any stored `thread_id`/`id`, forwards to the configured API endpoint, and streams `UIMessage` parts into the thread

#### Scenario: API key missing is surfaced

- **WHEN** no `OPENAI_API_KEY` is configured and the user sends a message
- **THEN** the system presents a non-crashing error state in the thread (error primitive) indicating that the key is missing and how to configure it, without exposing the key value

#### Scenario: ThreadId is persisted from response header

- **WHEN** the backend returns `X-Thread-Id` on a `/chat/stream` response
- **THEN** the runtime captures it from the `fetch` response headers and persists it for subsequent requests

#### Scenario: Resume reuses thread_id

- **WHEN** a `thread_id` is stored
- **THEN** the next `/chat/stream` request includes `thread_id` (and `id` for compatibility) so the backend can resolve `InMemorySaver[tid].__interrupt__` via `config={"configurable":{"thread_id":tid}}`

## ADDED Requirements

### Requirement: Tool fallback supports human-in-the-loop for ask_user

The system SHALL extend the generic `ToolFallback` to handle `ask_user` human-in-the-loop interrupts by rendering an inline input and resuming the run with the user-provided content.

#### Scenario: ask_user interrupt shows input

- **WHEN** the model returns a `tool-call` with `toolName === 'ask_user'` and `status.type === 'requires-action'`
- **THEN** the thread renders `ToolFallback` with an input field and submit button alongside the tool name/args, not just `Allow/Deny`

#### Scenario: Submit sends tool result with thread_id

- **WHEN** the user submits a non-empty value (e.g., `"3"`) in the `ask_user` input
- **THEN** the frontend sends `tool{content:"3"}` in the next `/chat/stream` body together with the stored `thread_id`, the backend executes `Command(resume="3")`, and the assistant stream continues

#### Scenario: Approval and data inputs coexist

- **WHEN** a tool requires both approval and data (e.g., custom `approval` options plus `ask_user`)
- **THEN** the fallback preserves the existing `Allow/Deny` approval UI and adds the data input without breaking either path
