## Purpose

为基于 `InMemorySaver[thread_id]` 的后端提供完整的人机交互闭环：首包建 thread 并持久化 `X-Thread-Id`，`ask_user` 工具进入 `requires-action` 时渲染补参输入，续跑时命中同 `thread_id` 的 `__interrupt__` 并以 `Command(resume)` 继续，避免工具因缺参永久停滞。

## ADDED Requirements

### Requirement: ThreadId is captured and persisted on first stream

The system SHALL capture the `X-Thread-Id` response header from the first `POST /chat/stream` and persist it for the session so subsequent requests can resume the same `thread_id`.

#### Scenario: First message creates thread and header is stored

- **WHEN** the user sends the first human message with no `thread_id` in the request
- **THEN** the backend creates `tid = f"thread_{uuid4().hex}"` in `InMemorySaver[tid]` and returns `X-Thread-Id: thread_xxx` (CORS exposed)
- **AND** the frontend reads `X-Thread-Id` from the fetch response, stores it in `localStorage` and in-memory store, and does not treat `start.messageId` (SSE `msgId`) as `tid`

#### Scenario: Header missing does not crash

- **WHEN** `X-Thread-Id` is absent
- **THEN** the frontend keeps no `thread_id` and the next request proceeds as a new thread creation

### Requirement: Subsequent requests resume the same thread_id

The system SHALL attach `payload.id || payload.thread_id = tid` on every subsequent `/chat/stream` request when a `tid` is stored, so the backend resolves `InMemorySaver[tid]` via `config={"configurable":{"thread_id":tid}}`.

#### Scenario: Follow-up message reuses stored thread

- **WHEN** a `tid` is stored and the user sends a follow-up or a tool result
- **THEN** the request body includes `thread_id` (and `id` for compatibility) equal to the stored `tid`

#### Scenario: No stored tid creates new thread

- **WHEN** no `tid` is stored
- **THEN** the request is sent without `thread_id`/`id` and the backend creates a new thread as in the first-message flow

### Requirement: ask_user interrupt renders human input and resumes

The system SHALL render a human input UI when a tool call enters `requires-action` with `ask_user` interrupt, collect the user-provided value (e.g., `"3"`), and resume the run by sending a `tool` message with that content and the stored `thread_id`.

#### Scenario: ask_user shows input instead of hanging

- **WHEN** the stream yields a tool call `ask_user` with `status.type === 'requires-action'`
- **THEN** `ToolFallback` shows an input field + submit (not just `Allow/Deny`) with the pending `argsText` visible

#### Scenario: Submit resumes via Command

- **WHEN** the user submits value `"3"` in the `ask_user` input
- **THEN** the frontend sends `POST /chat/stream {messages:[..., tool{content:"3"}], thread_id:"thread_xxx"}`
- **AND** the backend executes `Command(resume="3")` from the `ask_user` interrupt and continues `task(math)` streaming
- **AND** the input locks to prevent duplicate submits

#### Scenario: Empty submit is rejected

- **WHEN** the user submits empty or whitespace-only content for `ask_user`
- **THEN** the system keeps the input open, shows a validation message, and does not send a resume request

### Requirement: Lost thread is detected and recoverable

The system SHALL detect when a stored `tid` no longer exists in `InMemorySaver` (e.g., server restart) and recover by clearing the stale `tid` and allowing a new thread to be created.

#### Scenario: Stale thread clears and retries

- **WHEN** a resume request with a stored `tid` receives a backend error indicating `thread not found` / `__interrupt__ not found` (e.g., 404 or specific error code)
- **THEN** the frontend clears `localStorage` and in-memory `tid`, shows a non-crashing message that the session expired, and the next user message creates a fresh `thread_xxx`

#### Scenario: Clear does not lose history of fresh thread

- **WHEN** the stale `tid` is cleared
- **THEN** subsequent messages stream normally under the new `tid` returned in `X-Thread-Id`
