## 1. 线程持久化与注入

- [x] 1.1 新增 `src/lib/thread-id.ts`（`getThreadId/setThreadId/clearThreadId` 封装 `localStorage.getItem("threadId")` + 内存缓存，`localStorage` 不可用时降级内存）并验证 `vitest` 读写与 `clear` 后 `get` 为空
- [x] 1.2 改造 `src/lib/assistant.ts` 的 `AssistantChatTransport({ fetch })`：响应侧 `resp.headers.get("X-Thread-Id")` 捕获并 `setThreadId`，请求侧若 `init.body` 为 JSON 且含 `messages` 则注入 `thread_id/id`，验证首包后 `localStorage.threadId` 写入且续包 `payload.thread_id` 与之前 `X-Thread-Id` 一致（`fetch` mock 单测）
- [x] 1.3 处理 `tid` 丢失/过期：在 `fetch` 包装内识别 `404` 或 `thread not found`/`interrupt not found` 错误体，`clearThreadId` 并 `toast` 提示会话过期，下次发消息重建新 `tid`，验证 `clear` 后新首包产生新 `X-Thread-Id`

## 2. ask_user 人机输入态

- [x] 2.1 扩展 `src/components/assistant-ui/tool-fallback.tsx`：`ToolFallbackImpl` 内判 `toolName==='ask_user'` 或 `interrupt?.type==='ask_user'` 时渲染 `ToolAskUserInput`（`Input + Button`，空值校验，`submitted` 锁），提交调用 `addResult(value)`（备用 `resume(value)` 抽象），验证输入空时不发送且显示校验，提交 `"3"` 后触发 `tool{content:"3"}` 且按钮 disabled
- [x] 2.2 保证与审批共存：`ToolFallbackApproval` 保持 `Allow/Deny`，`ask_user` 分支与审批分支互斥/共存不覆盖，验证 `requires-action` 为 `ask_user` 时显示输入，为普通 `interrupt` 时仍显示审批
- [x] 2.3 可及性与样式：输入回车提交、焦点管理、暗色适配，验证键盘 `Enter` 提交与 `ThreadViewport` 细滚动条不遮挡

## 3. 集成与回归

- [x] 3.1 `src/routes/chat.tsx` 保持 `AssistantRuntimeProvider(runtime) + Thread` 零改动，验证 `Thread` 分组 `groupPartByType` 下 `ask_user` 的 `tool-call` 正确进 `ToolFallback` 而非 `ToolGroup` 折叠吞没
- [x] 3.2 端到端联调：首包 `POST /chat/stream {messages:[human]}` 建 `thread_xxx` 并从 `X-Thread-Id` 落盘，追问 `POST /chat/stream {messages:[..., tool{content:"3"}], thread_id}` 命中 `Saver[tid]` 并 `Command(resume="3")` 续跑 `task(math)`，验证 `SSE` 继续产出且前端不卡在 `requires-action`
- [x] 3.3 门禁与文档：`just lint && just format-check && just test && just web-build` 通过，`vite build 2>&1 | grep -i Skipped` 无新增 bailout，更新 `docs/config.md` 说明 `X-Thread-Id` 链路与过期重建策略
