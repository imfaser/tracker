## Why

`D:\code\tauri\run-deck` 已演进为重业务桌面应用（126 个前端文件 + 6 个 Rust crates：logging/draft/mcp/nimg/db/parquet-export），不再适合作为新项目起点。团队需要一个**前端重、Tauri 极简、开箱即带 AI 对话**的 starter，以便快速孵化下一代 Tauri 产品。`D:\code\tauri\deepshow` 当前为空仓库，正好承载该模板。

## What Changes

- 从 `run-deck` 抽取前端骨架：`Vite 8.2.2 + React 19.2.8 + TypeScript 7 + Tailwind 4.3.3 + shadcn/base-nova + TanStack Router(hashHistory) + Zustand 5.0.15 + immer 11.1.18`，保留 `ThemeProvider`、`AppLayout`、`TitleBar` 无边框窗口、`components/ui/*` 20+ 组件、`lib/utils`、`index.css` 的 oklch 设计系统。
- 集成 **Assistant UI 0.15.16**：通过 `npx shadcn add @assistant-ui/thread` 引入 `Thread` / `ThreadList`，采用 `LocalRuntime + ChatModelAdapter` 直连模式，`fetch` 直连 OpenAI-compatible API（`OPENAI_API_KEY` 经 `.env` 注入），预留切换到 `invoke('chat')` Rust 中转的扩展位。
- Tauri 极简壳：`src-tauri` 仅保留 `lib.rs / main.rs / build.rs / tauri.conf.json / capabilities/default.json`，插件仅 `tauri-plugin-opener 2.5.4 + tauri-plugin-dialog 2.7.2`，`decorations:false` 无边框 + `on_window_event` 子窗口清理，保留 `tauri.conf.json` 的 `beforeDevCommand: npm run dev`。
- 包管理 **从 pnpm 切换为 npm**：删除 `pnpm-lock.yaml` / `pnpm-workspace.yaml`，生成 `package-lock.json`，`Cargo.toml` workspace 收敛为 `members=["src-tauri"]`。
- 保留工程门禁与编译：`oxlint 1.79.0 + oxfmt 0.64.0 + tsc -b + vite build + cargo check/test`，保留 `justfile` 与 `babel-plugin-react-compiler 1.0.0`（需遵守 `useWatch` 替代 `watch()` 规则）。
- **移除**：`dexie/konva/echarts/xstate/rxjs/mitt` 等领域库、`services/cmds.ts` 全量、`label-3d/mcp-panel/config/task` 模块、`crates/*` 6 个业务 crate、自定义 `cache://` 协议。

## Capabilities

### New Capabilities

- `assistant-runtime`: Assistant UI 运行时与对话能力（Thread/Composer/Message primitives、LocalRuntime 接线、fetch 直连、tool fallback）。
- `tauri-shell`: 极简 Tauri 外壳（无边框 TitleBar、窗口控制、opener/dialog 插件、capabilities、npm 前缀）。
- `frontend-starter`: 前端 starter 骨架（Vite+React+Tailwind+shadcn+TanStack Router+Zustand+immer+Theme、npm、oklch 设计系统、React Compiler 约束）。

### Modified Capabilities

- 无（`deepshow` 为空仓库，无既有 spec 需修改）。

## Impact

- 影响目录：`D:\code\tauri\deepshow` 全量（前、后端、配置、文档均为新建）。
- 依赖：新增 `@assistant-ui/react 0.15.16`、`@assistant-ui/react-markdown 0.14.12`、`@base-ui/react 1.7.0`，升级 `zustand/immer/vite/@vitejs/plugin-react/oxlint/oxfmt` 至最新；Tauri Rust 无额外业务依赖。
- 兼容性：TanStack Router 必须使用 `createHashHistory()`（Tauri 不支持 BrowserHistory）；`components.json` 需新增 `registries["@assistant-ui"]` 风格感知 URL，否则 Base UI 与 Radix 组件混用失败。
- 风险：React Compiler 与 `react-hook-form` 的 `watch()` 已知 bailout；Base UI 1.7 需验证 `Thread` 样式与 oklch 变量兼容。
