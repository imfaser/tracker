## Context

See `proposal.md` – Why for motivation. `run-deck` (`D:\code\tauri\run-deck`) is the source; `deepshow` (`D:\code\tauri\deepshow`) is the empty target. `run-deck` couples a rich React frontend (Vite 8.1.5, React 19.2.8, Tailwind 4.3.3, shadcn `base-nova`, TanStack Router file-based, Zustand+immer, React Compiler) with a heavy Rust workspace (6 crates + logging rotation + `cache://` protocol + MCP). The starter must keep the former's shell intact, add Assistant UI 0.15.16 on the freshest `base-nova`/`@base-ui/react 1.7.0`, switch `pnpm → npm`, and collapse Tauri to a window shell with only `opener`/`dialog`. Existing empty-store `deepshow` has no prior specs, so all deltas are new.

## Goals / Non-Goals

**Goals:**

- Reproduce `run-deck`'s build/quality pipeline on npm without pnpm.
- Ship a working chat route on day one (fetch-direct `LocalRuntime`) with `.env` key.
- Preserve `TitleBar` frameless UX and the oklch design system so future features don't re-solve windowing/theming.
- Keep Zustand+immer as the only app store and document the upgrade path to `invoke('chat')`.

**Non-Goals:**

- Migrating business modules (`label-3d`, `nimg`, `db`, `parquet-export`, `draft`, M41 logging/MCP internals).
- Implementing auth/cloud persistence for Assistant UI (left to app code via `assistant-runtime` switch).
- Introducing a server (Next.js, Vercel AI SDK) – Tauri desktop stays offline-first.

## Decisions

### 1. Assistant UI runtime = `LocalRuntime` + `ChatModelAdapter` fetch-direct (over AI SDK)

**Choice:** `useLocalRuntime(new ChatModelAdapter(fetch))`. `Thread` from `@assistant-ui/thread` renders inside `AssistantRuntimeProvider`. Endpoint reads `import.meta.env.VITE_OPENAI_API_KEY` / `VITE_CHAT_API_URL` + default model from docs.

**Why:** `docs/runtimes/pick-a-runtime` – AI SDK's `useChatRuntime + AssistantChatTransport` requires a server `streamText().toUIMessageStreamResponse()` handler. Tauri has no server; adding one violates "Tauri 极简". `LocalRuntime` wraps the core `ExternalStoreRuntime` but owns state, so branching/editing/regeneration work with one `run` method and no server.

**Alternative considered:** AI SDK v7. Rejected – would require Cloudflare/Next sidecar and complicate npm starter.

**Switch lane:** Document a drop-in replacement where `ChatModelAdapter.run` calls `invoke('chat', {messages, system, tools})` and a minimal Rust `chat` command holds the key (no `Thread` change).

### 2. UI flavor = Base UI (`base-nova`, `@base-ui/react 1.7.0`) over Radix

**Choice:** Keep `components.json` `style: base-nova`, add `registries["@assistant-ui"]="https://r.assistant-ui.com/styles/{style}/{name}.json"`. `npx shadcn add @assistant-ui/thread` then resolves the Base UI variant.

**Why:** `docs/installation#Manual Setup` – flavor is resolved from `style`. `base-*` → Base UI, otherwise Radix. Base UI is MUI's 2025 rewrite, smaller bundle, better Tailwind 4 alignment, and is what `base-nova` already targets in `run-deck`. User explicitly wants "最新最好".

**Alternative:** Radix. Rejected – older, larger, and would require restyling `run-deck`'s `button.tsx`/`dialog.tsx` cva variants.

### 3. Routing = TanStack Router `createHashHistory()` retained

**Choice:** Copy `router.tsx:1:18` hash history and `routeTree.gen.ts` generation verbatim. `__root.tsx` conditionally bypasses `AppLayout` only if a future window route needs it.

**Why:** Tauri webviews have no server fallback; hash history survives reload.

### 4. State = Zustand 5.0.15 + `zustand/middleware/immer` + `immer 11.1.18`

**Choice:** `create<State>()(immer(set=>({…})))` pattern from `run-deck/src/store/app.ts`. `use-immer` kept for local draft cases. Assistant UI's internal `zustand` dep (0.15.16 pulls it) stays compatible.

**Why:** Matches locked preference ("记住使用 immer"). `immer` draft mutation avoids manual spreads for chat metadata.

### 5. Quality gates + React Compiler retained

**Choice:** Keep `oxlint 1.79.0` + `oxfmt 0.64.0` + `tsc -b` + `vite build` + `cargo check/test` in the same order, and `justfile` recipes `lint/lint-fix/format/format-check/typecheck/web-build/test`. Keep `@rolldown/plugin-babel` + `babel-plugin-react-compiler 1.0.0` + `@vitejs/plugin-react`.

**Why:** Preserves `run-deck`'s fast Rust lint/format and documents the `react-hook-form` `watch()` → `useWatch` rule to avoid compiler bailout.

### 6. Tauri shell = frameless TitleBar + opener/dialog only

**Choice:** `tauri.conf.json` `windows[0].decorations:false`, `setup.rs:5` only `.plugin(opener).plugin(dialog)`, `capabilities/default.json` grants only `window:allow-minimize/allow-maximize/allow-close/allow-is-maximized/allow-on-resized`. `lib.rs:26` `on_window_event` keeps main→child cleanup.

**Why:** Adds ~15 lines over a bare shell but avoids "后面扩展比较麻烦". Matches locked preference.

### 7. Package manager = npm (no workspace)

**Choice:** Delete `pnpm-lock.yaml`/`pnpm-workspace.yaml`, commit `package-lock.json`, `beforeDevCommand: "npm run dev"`, `Cargo.toml` `members=["src-tauri"]`.

**Why:** Broadest npm compatibility requested; Rust workspace independent of JS pm.

## Risks / Trade-offs

- **Base UI 1.7 + `Thread` oklch clash →** Verify `npx shadcn add @assistant-ui/thread` output against `index.css` variables; mitigation: snapshot `after` and adjust `thread.tsx` class overrides (low risk, visual only).
- **React Compiler bailout (`watch()`) →** Mitigation: docs + example `useWatch` form in `chat.tsx`; `vite build` fails fast with `Skipped: ... incompatible library` as signal.
- **Fetch-direct key exposure →** Mitigation: document `.env` is dev-only, provide `docs/switch-to-invoke.md` snippet and a stub `src-tauri/src/cmd/chat.rs` that is not wired until opt-in.
- **Vite target mismatch →** Preserve `run-deck/vite.config.ts:61` `build.target` logic (`chrome105`/`safari13`) or Tauri webview may lack features.
- **Hash routing surprise →** Mitigation: starter README callout "Tauri must use hash history".

## Migration Plan

1. Scaffold `deepshow` on npm (init, install pinned versions, `components.json` with registry).
2. Copy-filter `run-deck` skeleton (allowlist in `frontend-starter` spec) and add `assistant-ui/thread` + `lib/assistant.ts` + `routes/chat.tsx`.
3. Collapse `src-tauri` to minimal shell (lib/main/build/tauri.conf/capabilities) with `decorations:false` + opener/dialog.
4. Wire `vite.config.ts` + `tsconfig` aliases + `justfile` + `ox*` configs, run ordered gates, fix alias/style drifts.
5. Validate: `npm run dev` (open chat, send mock message), `npm run build`, `cargo check`, `npx shadcn add @assistant-ui/thread --overwrite` idempotency.
6. Rollback: change is isolated to `deepshow`; archiving the change reverts via `openspec archive` – no impact on `run-deck`.

## Open Questions

- None that block spec/design – model identifier default (e.g., `gpt-4o-mini`) can be chosen at implement time and documented in `.env.example` without changing requirements.
