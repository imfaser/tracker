## Purpose

Provides the AI chat interface for the starter using Assistant UI primitives and a fetch-direct LocalRuntime, so every new Tauri project starts with a working conversational UI without a server.

## ADDED Requirements

### Requirement: Assistant UI primitives are available

The system SHALL provide a chat thread built from Assistant UI primitives (`Thread`, `Composer`, `Message`, `ActionBar`, `BranchPicker`) that renders inside `AssistantRuntimeProvider` and handles auto-scroll, streaming, and keyboard interaction without additional wiring.

#### Scenario: Thread renders with composer

- **WHEN** the user navigates to the chat route (`/chat` or `/`)
- **THEN** the system displays a scrollable message viewport, a composer input, and send/cancel controls, and the composer submits on Enter and disables send when empty or while a run is in flight.

#### Scenario: Assistant response streams and is cancellable

- **WHEN** an assistant run is in progress
- **THEN** the composer shows Cancel, the viewport auto-scrolls to the bottom, and activating Cancel stops the stream and returns the composer to Send state.

### Requirement: LocalRuntime with fetch-direct chat

The system SHALL provide a `LocalRuntime` backed by a `ChatModelAdapter` that calls an OpenAI-compatible chat completions endpoint via `fetch`, with the API key read from environment (`OPENAI_API_KEY` via Vite `import.meta.env` / `.env`) and request payload mapping `messages + system + tools` from the runtime.

#### Scenario: User sends a message and receives a streamed reply

- **WHEN** the user sends a text message
- **THEN** the runtime invokes `ChatModelAdapter.run`, forwards `{messages, system, tools}` to the configured API endpoint, and streams `UIMessage` parts into the thread.

#### Scenario: API key missing is surfaced

- **WHEN** no `OPENAI_API_KEY` is configured and the user sends a message
- **THEN** the system presents a non-crashing error state in the thread (error primitive) indicating that the key is missing and how to configure it, without exposing the key value.

### Requirement: OpenAI-compatible endpoint is configurable

The system SHALL allow the chat endpoint and model identifier to be configured without code changes (env or config), defaulting to an OpenAI-compatible URL and a documented default model.

#### Scenario: Override endpoint via env

- **WHEN** `VITE_CHAT_API_URL` (or equivalent documented var) is set to a custom OpenAI-compatible base URL
- **THEN** the runtime uses that URL for subsequent chat requests.

### Requirement: Tool fallback and markdown rendering

The system SHALL render markdown in assistant messages and provide a fallback renderer for tool calls that have no registered UI, without breaking the thread layout.

#### Scenario: Tool call without UI shows fallback

- **WHEN** the model returns a tool call for which no `Tool UI` renderer is registered
- **THEN** the thread renders the generic `ToolFallback` (tool name + args) in place of the custom UI.

#### Scenario: Markdown response is rendered

- **WHEN** an assistant message contains markdown (headings, code blocks, lists)
- **THEN** the message renders formatted content via the assistant-ui markdown pipeline.

### Requirement: Switching to Tauri invoke backend is documented

The system SHALL document how to switch the `ChatModelAdapter` from fetch-direct to `invoke('chat', {messages})` so the API key can be held in Rust, and the switch SHALL require no change to `Thread` or primitive usage.

#### Scenario: Developer follows Rust-proxy guide

- **WHEN** a developer replaces the fetch implementation with a `invoke('chat')` call per the guide and provides a Rust `chat` command
- **THEN** chat continues to function with identical UI behavior, and the key is no longer read from the frontend env.
