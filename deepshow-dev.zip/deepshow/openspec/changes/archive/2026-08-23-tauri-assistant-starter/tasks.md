## 1. 工程与包管理初始化

- [x] 1.1 初始化 npm 工程与依赖：以 `run-deck/package.json:12:53` 为基线创建 `package.json`（`private:true, type:module`），固定版本 `react 19.2.8 / @assistant-ui/react 0.15.16 / @assistant-ui/react-markdown 0.14.12 / @base-ui/react 1.7.0 / @tanstack/react-router 1.170.32 / zustand 5.0.15 / immer 11.1.18 / use-immer 0.11.0 / tailwindcss 4.3.3 / vite 8.2.2 / @vitejs/plugin-react 6.1.0 / zod 4.4.3 / @tauri-apps/api 2.11.1 / plugin-opener 2.5.4 / plugin-dialog 2.7.2 / oxlint 1.79.0 / oxfmt 0.64.0`，运行 `npm install` 验证 `package-lock.json` 生成且无 pnpm 产物
- [x] 1.2 迁移配置：复制 `run-deck/tsconfig.json + tsconfig.app.json + tsconfig.node.json + vite.config.ts:1:65 (保留 tanstackRouter+react+compiler+tailwind, host/tauri 逻辑) + components.json (追加 registries["@assistant-ui"]) + .oxfmtrc.json + .oxlintrc.json`，校验 `tsc -b` 无错且 `@/*` 别名解析通过
- [x] 1.3 引入质量门禁与 justfile：从 `run-deck/justfile` 复制 `lint/lint-fix/format/format-check/typecheck/web-build/test` recipes，验证 `just lint && just format-check` 可执行

## 2. Tauri 极简壳

- [x] 2.1 创建 `src-tauri/` 最小集：`Cargo.toml (members=["src-tauri"]) / build.rs / src/lib.rs + src/main.rs (含 lib.rs:26 on_window_event main→child 清理) / tauri.conf.json (beforeDevCommand:"npm run dev", devUrl:"http://localhost:6917", frontendDist:"../dist", windows[0].decorations:false) / capabilities/default.json (仅 window:allow-* for minimize/maximize/close/isMaximized/onResized)`，验证 `cargo check` 通过
- [x] 2.2 接线插件：`src-tauri/src/setup.rs` 仅 `plugin(opener).plugin(dialog)`，验证 `cargo check && npm run build` 成功且 `dist/` 产出

## 3. 前端骨架迁移

- [x] 3.1 复制设计系统：`run-deck/src/index.css:1:133 (oklch) + src/lib/utils.ts (cn) + src/components/ui/* (20 files) + src/components/theme-provider.tsx (简化为 localStorage 版，不依赖 invoke)`，验证 `vite build` 样式变量在暗/亮色下生效
- [x] 3.2 复制路由与布局骨架：`run-deck/src/main.tsx + src/App.tsx + src/router.tsx:1:18 (createHashHistory) + src/routes/__root.tsx + src/components/layout/AppLayout.tsx + src/components/layout/TitleBar.tsx:1:205 (含 getCurrentWindow 窗口控制与 theme toggle, data-tauri-drag-region)`，验证 `npm run dev` 后 TitleBar 拖拽与窗口按钮可用且路由 hash 刷新不丢
- [x] 3.3 引入 Zustand+immer：创建 `src/store/app.ts` 采用 `create<State>()(immer(...))` 模式（参考 `run-deck/src/store/app.ts:1:61`），验证 store draft 变更触发响应且无额外兼容问题

## 4. Assistant UI 接线

- [x] 4.1 安装组件：执行 `npx shadcn@latest add @assistant-ui/thread @assistant-ui/thread-list`（风格感知 registry），核对 `src/components/assistant-ui/thread.tsx` 拉取为 Base UI 版且与 `base-nova` 兼容，验证 `vite build` 无样式冲突
- [x] 4.2 实现运行时：新建 `src/lib/assistant.ts` 导出 `createAssistantRuntime()`（`useLocalRuntime` + `ChatModelAdapter`），`run` 内 `fetch(VITE_CHAT_API_URL ?? openai compatible, {messages, system, tools})` 并以 `async *` 流式产出 `UIMessage` parts，`VITE_OPENAI_API_KEY` 缺失时抛可展示错误，验证无 key 时线程显示错误态而非崩溃
- [x] 4.3 创建对话路由：新建 `src/routes/chat.tsx` 与 `src/routes/index.tsx`（重定向至 `/chat`），在 `chat.tsx` 以 `AssistantRuntimeProvider` 包裹 `Thread`，配置 `ToolFallback` 与 markdown 渲染，验证 `npm run dev` 下发送消息可触发 fetch 流式回复且 Cancel/重发可用

## 5. 配置与文档

- [x] 5.1 环境与切换文档：新增 `.env.example (VITE_OPENAI_API_KEY, VITE_CHAT_API_URL, VITE_CHAT_MODEL)` 与 `docs/switch-to-invoke.md`（说明如何将 `ChatModelAdapter` 改为 `invoke('chat')` 并提供 `src-tauri/src/cmd/chat.rs` 存根），验证按文档切换后 UI 无需改动
- [x] 5.2 React Compiler 约束文档：在 `README`/`AGENTS.md` 追加 `form.watch() → useWatch` 规则及 bailout 自检命令，验证 `vite build` 日志无 `Skipped: ... incompatible library`

## 6. 验证与门禁

- [x] 6.1 前端门禁：依次执行 `just lint && just format-check && just test (vitest) && just web-build (tsc -b && vite build)`，验证全部通过且 `Thread` 在构建后仍可用
- [x] 6.2 Rust 门禁与联调：执行 `cargo check && cargo test`，`npm run tauri dev` 手动验证 chat 往返、TitleBar 窗口控制、主题持久化、hash 路由刷新
