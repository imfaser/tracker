## MODIFIED Requirements

### Requirement: LocalRuntime with fetch-direct chat

The system SHALL provide a Vercel AI SDK runtime via `@assistant-ui/ai-sdk` (`useChatRuntime` + `AssistantChatTransport`, `ai@^7` / `@ai-sdk/react@^4`) that targets the endpoint from `app-config` and injects identity headers, replacing the previous `LocalRuntime`/`ChatModelAdapter` fetch-direct OpenAI-compatible implementation, while preserving `Thread`/`Composer`/`AssistantRuntimeProvider` usage without changes.

#### Scenario: User sends a message and receives a streamed reply

- **WHEN** the user sends a text message with a valid `backendUrl`, `userId` and optional `conversationId` configured
- **THEN** the runtime invokes `AssistantChatTransport` against the configured `api` (`app-config.backendUrl` or fallback), includes `x-user-id` and `x-conversation-id` in request headers, and streams `UIMessage` parts into the thread with auto-scroll and cancel support.

#### Scenario: API key missing is surfaced

- **WHEN** `userId` is empty (the Vercel AI SDK identity is not configured) and the user attempts to send a message
- **THEN** the system does not call the backend and presents a non-crashing error state in the thread indicating that `userId` is required and how to configure it in `/config`, without exposing header values.

### Requirement: OpenAI-compatible endpoint is configurable

The system SHALL allow the chat endpoint to be configured via `app-config.backendUrl` without code changes, with fallback to `VITE_CHAT_API_URL` and a documented default only when the config value is empty, and SHALL send `x-user-id` and `x-conversation-id` as request headers on every chat request when those config values are present.

#### Scenario: Override endpoint via env

- **WHEN** `VITE_CHAT_API_URL` (or equivalent documented var) is set to a custom URL and `app-config.backendUrl` is empty
- **THEN** the runtime uses that env URL for subsequent chat requests.

#### Scenario: Override endpoint via app-config

- **WHEN** `app-config.backendUrl` is set to a custom Vercel AI SDK URL
- **THEN** the runtime uses that URL for subsequent chat requests and includes `x-user-id` and `x-conversation-id` headers when non-empty.

### Requirement: Switching to Tauri invoke backend is documented

The system SHALL document how to switch the `ChatModelAdapter` from fetch-direct to `invoke('chat', {messages})` so the API key can be held in Rust, and the switch SHALL require no change to `Thread` or primitive usage.

#### Scenario: Developer follows Rust-proxy guide

- **WHEN** a developer replaces the fetch implementation with a `invoke('chat')` call per the guide and provides a Rust `chat` command
- **THEN** chat continues to function with identical UI behavior, and the key is no longer read from the frontend env.

> Note: This requirement is retained unchanged for the OpenAI-compatible proxy path; for the Vercel AI SDK path the transport is `AssistantChatTransport` and headers carry identity instead of a bearer token. The guide SHALL call out both paths.
