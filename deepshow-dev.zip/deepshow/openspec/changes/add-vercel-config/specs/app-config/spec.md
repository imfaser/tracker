## Purpose

Provides a lightweight, persistent application configuration for the test harness — backend URL, user identity and conversation identity — so the chat runtime can target different Vercel AI SDK backends without editing environment files or restarting.

## ADDED Requirements

### Requirement: App configuration is persisted via Rust

The system SHALL persist application configuration to a JSON file managed by Rust (Tauri commands `get_config` / `update_config`) and reload it on startup, so settings survive restarts and are consistent across windows.

#### Scenario: Configuration survives restart

- **WHEN** the user saves backendUrl, userId and conversationId and then closes and reopens the app
- **THEN** the system loads the same three values from `config.json` without requiring `.env` edits.

#### Scenario: Fresh install creates defaults

- **WHEN** no `config.json` exists on first launch
- **THEN** the system creates one with `backendUrl = ""`, `userId = ""`, `conversationId = ""` and returns those defaults to the frontend.

#### Scenario: Concurrent saves are serialized

- **WHEN** the user triggers two saves in rapid succession
- **THEN** the system serializes the writes so the last save wins and the file is not corrupted.

### Requirement: Configuration fields are validated

The system SHALL validate `backendUrl` as a URL when non-empty, require `userId` to be non-empty (1–64 chars, trimmed), and allow `conversationId` to be empty or 1–128 chars, rejecting invalid input before persistence and surfacing field-level errors.

#### Scenario: Invalid backend URL is rejected

- **WHEN** the user enters `not-a-url` for backendUrl and attempts to save
- **THEN** the system shows an inline validation error and does not invoke `update_config`.

#### Scenario: Empty userId is rejected

- **WHEN** the user clears userId and attempts to save or send a chat message
- **THEN** the system shows a required-field error and blocks the operation, with a message directing the user to the configuration page.

#### Scenario: ConversationId may be empty and can be generated

- **WHEN** the user leaves conversationId empty or clicks "Generate"
- **THEN** the system accepts empty as valid or fills a UUID (via `crypto.randomUUID()`) before saving.

### Requirement: Configuration is editable in a dedicated UI

The system SHALL provide a `/config` route with a form containing three inputs (Backend URL, User ID*, Conversation ID), a Save action with success/error feedback, accessible from the TitleBar via a new Config tab, and the form SHALL use controlled inputs / `useWatch` (not `form.watch()` in render) to remain React Compiler safe.

#### Scenario: User edits and saves configuration

- **WHEN** the user navigates to Config via the TitleBar, edits any field, and clicks Save
- **THEN** the system validates locally, calls `update_config` with the full config, shows a success toast on completion, and subsequent chat requests use the new values without requiring a reload.

#### Scenario: Navigation to config is discoverable

- **WHEN** the app renders the TitleBar on any route
- **THEN** a Config tab (with Settings icon) is visible alongside Chat/Overview and navigates to `/config` when clicked.

#### Scenario: Unsaved changes are visible

- **WHEN** the user modifies a field without saving and attempts to navigate away
- **THEN** the Save button is enabled and the field shows a dirty indication; the system does not auto-persist until Save is pressed.

### Requirement: Configuration drives runtime with env fallback

The system SHALL use `app-config.backendUrl` as the primary chat endpoint, falling back to `VITE_CHAT_API_URL` and then `DEFAULT_API_URL` only when the config value is empty, and SHALL treat `VITE_OPENAI_API_KEY` as not required for the Vercel AI SDK path.

#### Scenario: Backend URL resolution order

- **WHEN** `backendUrl` in config is set to `https://example.com/api/chat`
- **THEN** chat requests target that URL regardless of `VITE_CHAT_API_URL`; when `backendUrl` is empty, the system uses `VITE_CHAT_API_URL` if set, otherwise the built-in default.

#### Scenario: Missing backendUrl blocks chat with guidance

- **WHEN** both config backendUrl and env fallback are empty or invalid and the user sends a message
- **THEN** the system does not issue a network request and shows an error in the thread directing the user to configure the backend URL.
