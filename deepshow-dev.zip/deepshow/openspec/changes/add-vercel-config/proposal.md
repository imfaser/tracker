## Why

deepshow 当前以 OpenAI 兼容的 `fetch` 直连（`src/lib/assistant.ts` + `VITE_CHAT_API_URL`/`VITE_OPENAI_API_KEY`）为唯一的聊天后端，没有可持久化的运行时配置，也不支持 Vercel AI SDK 协议。实际接入的后端是 Vercel AI SDK（`streamText` / `UIMessage Stream`），需要通过请求头透传 `x-user-id` 与 `x-conversation-id`，并允许用户在界面上快速修改后端地址以做联调测试。缺少这层配置导致每次切换环境都要改 `.env` 并重启，且无法做多用户/多会话测试。

## What Changes

- 新增轻量持久化配置层（Rust `config.json` + TS `zod` 校验），字段：`backendUrl`、`userId`（必填）、`conversationId`，支持在应用内「配置」页面读写并立即生效。
- 新增 `/config` 路由与导航入口（TitleBar 新增 Config Tab），表单校验 `backendUrl` 为合法 URL、`userId` 非空、`conversationId` 可选，提供「随机生成」与保存反馈。
- 将 `assistant-runtime` 从 `useLocalRuntime(ChatModelAdapter)` 迁移到 Vercel AI SDK v7：`useChatRuntime` + `AssistantChatTransport`（`@assistant-ui/ai-sdk`、`ai@^7`、`@ai-sdk/react@^4`），`backendUrl` 作为 `api`，`x-user-id`/`x-conversation-id` 通过 `headers` 透传；移除对 `VITE_OPENAI_API_KEY` 的强依赖（`.env` 仅作回退）。
- 保留 React Compiler 安全约束（表单禁止 `form.watch()` 渲染期调用，改用受控 `Input`/`useWatch`）与现有质量门禁。

## Capabilities

### New Capabilities

- `app-config`: 轻量应用配置能力 — 后端地址、用户 ID、会话 ID 的持久化、校验、读写与在 UI 中的编辑。

### Modified Capabilities

- `assistant-runtime`: 运行时的后端协议与透传方式变更 — 从 OpenAI 兼容 fetch-direct 切换为 Vercel AI SDK `UIMessage Stream`，并通过 headers 注入 user/conversation 标识；端点与鉴权改为由 `app-config` 驱动。

## Impact

- **Rust**：新增 `src-tauri/src/config/mod.rs` 与 `src-tauri/src/config/dirs.rs`（简化版）、注册 `get_config`/`update_config` commands，`Cargo.toml` 仅增 `serde` 相关（不引入 `Draft`/`logging`/`Draft` 等重依赖），`capabilities` 保持最小权限。
- **Frontend**：新增 `src/schemas/config.ts`、`src/services/cmds.ts` config 段、`src/hooks/useConfig.ts`（SWR + optimistic）、`src/routes/config.tsx`、`src/constants/labels.ts` 扩展；改动 `src/lib/assistant.ts`（替换为 `useChatRuntime`）、`src/components/layout/TitleBar.tsx`（新增 Config Tab）、`src/routes/chat.tsx`（保持 `AssistantRuntimeProvider` 接线）；`package.json` 新增 `ai`、`@ai-sdk/react`、`@assistant-ui/ai-sdk`。
- **Breaking**：`VITE_OPENAI_API_KEY` 不再是发送消息的必要条件；未配置 `backendUrl` 时回退到 `VITE_CHAT_API_URL`/`DEFAULT` 的优先级改变，需在文档中说明。
- **兼容**：`hashHistory` 路由、`zustand/immer`、`oxlint/oxfmt/vitest/cargo check` 门禁不受影响；不引入 `pnpm`。
