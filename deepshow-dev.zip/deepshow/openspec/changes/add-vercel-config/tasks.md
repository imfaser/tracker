## 1. Rust 轻量配置层

- [x] 1.1 新增 `src-tauri/src/config/mod.rs` 与 `src-tauri/src/config/dirs.rs`（`Config { backend_url, user_id, conversation_id }`，`Default` 为空串，`load_from_file`/`save`/`global` 单例，`dirs::config_file()` 支持 prod `appConfigDir()` / dev `.app/config.json`），并在 `src-tauri/src/lib.rs` 注册 `get_config`/`update_config` commands，验证 `cargo check` 通过且启动日志打印配置路径
- [x] 1.2 配置 `src-tauri/Cargo.toml` 依赖（`serde`/`serde_json`/`anyhow` 已有则复用）与 `capabilities/default.json` 保持最小权限，验证 `cargo check` 与 `npm run tauri dev` 可启动

## 2. 前端配置 Schema 与服务

- [x] 2.1 新增 `src/schemas/config.ts`（`ConfigSchema`：`backendUrl` URL-or-empty、`userId` trim 1–64 必填、`conversationId` 0–128，`parseConfig` 双遍 defaults），并新增 `src/services/cmds.ts` 的 `getConfig`/`updateConfig`（`invoke` + `parseConfig`），验证 `vitest` 新增用例通过（非法 URL、空 userId、超长 conversationId）
- [x] 2.2 新增 `src/hooks/useConfig.ts`（`useSWR('config', getConfig)` + `structuredClone` + `useLockFn` 乐观更新 + `rollbackOnError` + `toast` 成功/失败），验证在配置页修改后 `mutate` 立即反映且并发保存不丢更新

## 3. 配置 UI 与导航

- [x] 3.1 新增 `src/routes/config.tsx`（3 输入：Backend URL / User ID* / Conversation ID，`Generate` 按钮对 conversationId `crypto.randomUUID()`，`Save` 调用 `updateConfig`，内联校验与 disabled 状态，保存后 `toast.success`），验证表单为空 userId 时无法保存且提示必填，`npm run build 2>&1 | grep -i Skipped` 无输出
- [x] 3.2 扩展 `src/constants/labels.ts`（`settings.backendUrl`/`userId`/`conversationId`/`generated`/`saved`/`required`）并改动 `src/components/layout/TitleBar.tsx`（`fixedTabs` 追加 `config`，`Settings` 图标），验证 TitleBar 在 `/chat`、`/overview`、`/config` 均显示 Config Tab 且路由正确

## 4. Vercel AI SDK 运行时迁移

- [x] 4.1 `package.json` 新增 `ai@^7`、`@ai-sdk/react@^4`、`@assistant-ui/ai-sdk@^1.4`，执行 `npm install` 并验证 `npm ls` 无 peer 冲突
- [x] 4.2 重写 `src/lib/assistant.ts`：导出 `useAssistantRuntime()` 内部 `useChatRuntime({ transport: new AssistantChatTransport({ api: config.backendUrl || VITE_CHAT_API_URL || "/api/chat", headers: { "x-user-id": userId, "x-conversation-id": conversationId } }) })`，保留 `VITE_CHAT_API_URL` 回退与 `userId` 为空阻断（thread 内可视错误），验证 `chat.tsx` 保持 `AssistantRuntimeProvider(runtime)` + `Thread` 零改动
- [x] 4.3 联调校验：配置 `backendUrl` 指向 Vercel 后端，填 `userId`/`conversationId`，发送一条消息，验证请求头携带 `x-user-id`/`x-conversation-id`，响应以 `UIMessage Stream` 流式渲染且可取消；清空 `userId` 后发送被阻断并提示去配置页

## 5. 质量门禁与文档

- [x] 5.1 依次执行 `just lint`、`just format-check`、`just test`、`just web-build`、`cargo check`，验证均通过且 `dist/` 产物正常
- [x] 5.2 更新 `README.md` 与 `docs/switch-to-invoke.md`（或新增 `docs/config.md`）：说明 `app-config` 3 字段、头命名 `x-user-id`/`x-conversation-id`、Vercel 后端需 `createUIMessageStreamResponse(toUIMessageStream(...))`，验证文档中示例 `curl -H "x-user-id: ..."` 可复现
