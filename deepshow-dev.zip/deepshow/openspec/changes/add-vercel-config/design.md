## Context

deepshow 是 Tauri 2 + React 19 + Assistant UI 的 starter（见 `openspec/specs/assistant-runtime` / `frontend-starter` / `tauri-shell`）。现状：`src/lib/assistant.ts` 以 `useLocalRuntime(ChatModelAdapter)` 直连 OpenAI 兼容接口，端点与 key 来自 `import.meta.env`；`src/store/app.ts` 仅管 tabs；`src/components/theme-provider.tsx` 用 `localStorage`；`src-tauri` 仅有 `opener/dialog`。参考 `run-deck` 的 `Draft<Config>` + `dirs.rs` + `get_config/update_config` + `useConfig(SWR)` + `PageLayout` 范式，但本 change 明确要求轻量且仅 3 字段，并改用 Vercel AI SDK v7（`@assistant-ui/ai-sdk` + `AssistantChatTransport` / `useChatRuntime`），headers 为 `x-user-id` / `x-conversation-id`。

## Goals / Non-Goals

**Goals:**

- 3 字段持久化配置（backendUrl / userId* / conversationId）可编辑、跨重启一致、立即对聊天生效
- 聊天运行时平滑从 OpenAI fetch 切到 Vercel AI SDK `UIMessage Stream`，`Thread` 零改动
- 头注入可测试（header 可观测），表单 React Compiler 安全

**Non-Goals:**

- 不引入 `run-deck` 的全套 `logging`/`Draft`/`mcp`/`db` 依赖与 `prod` feature 分叉
- 不做多环境/多 profile、权限模型、云同步（AssistantCloud）
- 不做附件/语音等 adapter（预留插槽即可）
- 不在 Rust 侧代理或持有 model key（测试台直连后端）

## Decisions

### D1: 轻量 Rust 配置而非 Zustand persist

- **选择**：新增 `src-tauri/src/config/mod.rs` + `src-tauri/src/config/dirs.rs`（简化版），`Config { backend_url, user_id, conversation_id }`，`OnceLock<Mutex<Config>>` 或 `OnceLock<Draft>` 二选一；`get_config`/`update_config` 两个 commands，文件 `config.json`（dev: `<project_root>/.app/config.json`，prod: `appConfigDir()/config.json`）。
- **理由**：跨窗口一致、随 Tauri 打包路径正确；`localStorage` 在多窗口/打包后不一致且与文档中 `invoke('chat')` 持 key 的安全方向相悖。
- **备选**：纯前端 persist — 拒绝，因后续可能扩展且与 Tauri 能力边界不符。
- **参考**：`run-deck/src-tauri/src/config/mod.rs` 的 `load_from_file` / `save_global` / defaults 模式，裁剪掉 `log_level/shell/mcp` 等域。

### D2: Zod 双遍 defaults + SWR optimistic

- **选择**：`src/schemas/config.ts` 定义 `ConfigSchema`（`backendUrl: url.or("")`，`userId: trim().min(1).max(64)`，`conversationId: trim().max(128)`），`parseConfig` 双遍解析补 nested defaults；`src/hooks/useConfig.ts` 用 `useSWR('config', getConfig)` + `useLockFn` + `structuredClone` + optimistic `mutate`，`toast` 回滚。
- **理由**：与 `run-deck/src/hooks/useConfig.ts` 同构，测试台联调时快速回滚体验好；Zod 保证前后端 schema 对齐。
- **备选**：Zustand persist — 拒绝，因已选 Rust 真实源。

### D3: Vercel AI SDK v7 via `@assistant-ui/ai-sdk`

- **选择**：`package.json` 新增 `ai@^7` + `@ai-sdk/react@^4` + `@assistant-ui/ai-sdk@^1.4`，`src/lib/assistant.ts` 导出 `useAssistantRuntime()` 内部调用 `useChatRuntime({ transport: new AssistantChatTransport({ api, headers }) })`；`api = config.backendUrl || VITE_CHAT_API_URL || "/api/chat"`，`headers = { "x-user-id": userId, "x-conversation-id": conversationId }`。
- **理由**：官方文档 `docs/runtimes/ai-sdk/v7` 明确 `useChatRuntime` 为推荐路径，`AssistantChatTransport` 已处理 system/tools 转发，`Thread` 无需改动；与用户确认“最新版 + 放 head”一致。
- **备选**：手写 `ChatModelAdapter` 解析 SSE — 拒绝，会重复 `ai-sdk` 已实现的 `UIMessage` 编解码；`useAISDKRuntime(useChat(...))` 仅当 `headers` 需函数式动态取值时作为逃生口。
- **动态 headers**：若 `AssistantChatTransport` 的 `headers` 不支持函数，降级为 `useAISDKRuntime` 直连 `useChat({ api, headers })`，或在 `useAssistantRuntime` 内用 `useMemo` 随 `config` 重建 transport（需验证是否会导致 thread 重置 — 设计为重建仅换 transport，不换 thread 实例）。

### D4: 单页 `/config` 而非 PageLayout 侧边栏

- **选择**：`src/routes/config.tsx` 单 `Card` 居中布局，3 个 `Input` + `Generate`（conversationId）+ `Save`，`src/components/layout/TitleBar.tsx` `fixedTabs` 追加 `config`（`LABELS.nav.config` 已存在）。
- **理由**：测试台极简，单页足以；`run-deck` 的 `PageLayout` + `?section=general|mcp` 为多域配置设计，此处过度。
- **备选**：`PageLayout` 侧边栏 — 保留为未来扩展（若后续加 theme/logs 则再拆）。

### D5: 校验与阻断策略

- **选择**：表单层阻止非法保存（inline error + Save disabled）；`assistant` 层二次守卫 — `userId` 空则不发请求并在 thread 抛可视错误；`backendUrl` 空且 env 亦空则提示去配置页。
- **理由**：用户明确 `userId` 必填；Vercel 后端依赖 headers 鉴权，无 userId 的请求无意义，发了也是 401。

## Risks / Trade-offs

- [Headers 大小写与命名] → 后端对 `x-user-id` 大小写敏感可能导致鉴权失败；缓解：与用户已确认命名为 `x-user-id`/`x-conversation-id`，设计中固定全小写并在文档中醒目说明。
- [Transport 重建导致 thread 丢消息] → `config` 变更时重建 `AssistantChatTransport` 可能重置对话；缓解：优先使用支持函数式 headers 的 API，否则将 config 变更与 thread 隔离（保存配置不自动刷新当前 thread，仅影响下一条发送）。
- [Rust vs 前端竞态] → 快速连点 Save 可能丢更新；缓解：`useLockFn` 串行化 + 文件原子写（`write` 前 `create_dir_all`）。
- [Vercel 协议版本漂移] → 后端若切 v6/v5，`createUIMessageStreamResponse` vs `toDataStreamResponse` 不兼容；缓解：依赖锁定 `ai@^7`，README 注明后端需 `createUIMessageStreamResponse(toUIMessageStream(...))`。
- [开发期路径差异] → `.app/config.json` vs `appConfigDir` 可能让开发者误判配置位置；缓解：`dirs.rs` 在启动 log 中打印 `config_file()` 路径。

## Migration Plan

1. 新增 Rust 模块与 commands，`cargo check` 验证，不改现有前端行为（旧 `assistant.ts` 仍工作，仅未注册新路由时不可达）。
2. 新增 TS 配置层与 `/config` 路由，`TitleBar` 加 tab 后可独立验证持久化。
3. 切换 `assistant.ts` 到 `useChatRuntime`，`chat.tsx` 保持 Provider 结构，`npm run build | grep Skipped` 验证 React Compiler 未 bailout。
4. 回滚：若 Vercel 切换异常，保留 `useLocalRuntime` 分支以 feature flag 或 git revert 单提交回退；`config.json` 缺失时自动回退到 env/default。

## Open Questions

- `x-conversation-id` 为空时后端是自动创建会话还是 400？当前设计按“允许空，后端自建”处理，若为严格必填则追加必填校验。
- 是否需要 `conversationId` 的“新建对话”一键重置并清空当前 thread？测试台可能需要，留作可选增强。
