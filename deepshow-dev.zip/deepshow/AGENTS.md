# AGENTS.md — deepshow starter

Tauri 2 + React 19 + Assistant UI starter，基于 run-deck 骨架，npm。

## 包管理

```bash
npm install
npm run dev
npm run build
```

## 质量门禁（顺序）

1. `just lint` — oxlint 1.79
2. `just format-check` — oxfmt 0.64
3. `just test` — vitest
4. `just web-build` — tsc -b && vite build
5. `cargo check`
6. `cargo test`

## React Compiler（重要）

启用 `babel-plugin-react-compiler`，**禁止手动 `useMemo/useCallback`**。

### form.watch() 禁用

`useForm().watch()` 在渲染期调用会导致编译器跳过整个文件，`vite build` 报 `Skipped: ... Use of incompatible library`。

```tsx
// ✗ 错误
<Switch checked={form.watch('enabled')} />;

// ✓ 正确
import { useWatch } from 'react-hook-form';
const enabled = useWatch({ control: form.control, name: 'enabled' });
<Switch checked={enabled} />;
```

自检：`npm run build 2>&1 | grep -i Skipped` 应无输出。

## Zustand + immer

```ts
import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
export const useAppStore = create<AppState>()(
  immer((set) => ({
    tabs: [],
    setActiveTab: (id) =>
      set((s) => {
        s.activeTab = id;
      }),
  }))
);
```

## Assistant UI

- `src/lib/assistant.ts` — `useLocalRuntime(ChatModelAdapter)` fetch 直连 `VITE_CHAT_API_URL`，缺 key 时渲染错误态
- 切换到 Rust 持有 key：`docs/switch-to-invoke.md`（`invoke('chat')` + `src-tauri/src/cmd/chat.rs` 存根）

## 路由

TanStack Router file-based，**必须** `createHashHistory()`（Tauri）。`routeTree.gen.ts` 自动生成。

## 主题

`ThemeProvider` 为 localStorage 版（`deepshow-theme`），`TitleBar` 切换，持久化。

## Tauri

`decorations:false` + `getCurrentWindow()` 窗口控制，插件仅 `opener/dialog`。
