use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize)]
pub struct ChatMessage {
  pub role: String,
  pub content: String,
}

#[derive(Debug, Deserialize)]
pub struct ChatRequest {
  pub messages: Vec<ChatMessage>,
  pub model: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct ChatResponse {
  pub text: String,
}

/// Stub Tauri command for the fetch → invoke switch.
///
/// Wire it in `src-tauri/src/lib.rs`:
/// ```rust
/// mod cmd;
/// builder.invoke_handler(tauri::generate_handler![cmd::chat::chat])
/// ```
///
/// Then replace `fetch` in `src/lib/assistant.ts` with:
/// ```ts
/// import { invoke } from '@tauri-apps/api/core';
/// const text = await invoke<string>('chat', { messages: openAiMessages, model });
/// ```
///
/// The implementation below just echoes. Replace with `reqwest` forwarding
/// to your OpenAI-compatible endpoint, reading the key from env/config
/// instead of `VITE_OPENAI_API_KEY`.
#[tauri::command]
pub async fn chat(req: ChatRequest) -> Result<ChatResponse, String> {
  let last = req
    .messages
    .last()
    .map(|m| m.content.clone())
    .unwrap_or_default();
  Ok(ChatResponse {
    text: format!("[stub chat – wire reqwest here] Echo: {last}"),
  })
}

#[allow(dead_code)]
pub mod _docs {
  pub const SWITCH_GUIDE: &str = "see docs/switch-to-invoke.md";
}
