use tauri::Builder;

pub fn setup_plugins(builder: Builder<tauri::Wry>) -> Builder<tauri::Wry> {
  builder
    .plugin(tauri_plugin_opener::init())
    .plugin(tauri_plugin_dialog::init())
}
