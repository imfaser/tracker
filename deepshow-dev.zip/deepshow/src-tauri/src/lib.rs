mod config;
mod setup;

use setup::setup_plugins;
use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  let builder = tauri::Builder::default()
    .on_window_event(|window, event| {
      if let tauri::WindowEvent::CloseRequested { .. } = event {
        if window.label() == "main" {
          let app = window.app_handle();
          for (label, w) in app.webview_windows() {
            if label != "main" {
              let _ = w.close();
            }
          }
        }
      }
    });
  let builder = setup_plugins(builder);
  let builder = builder.invoke_handler(tauri::generate_handler![
    config::get_config,
    config::get_config_path,
    config::update_config
  ]);

  let app = builder
    .build(tauri::generate_context!())
    .unwrap_or_else(|e| {
      eprintln!("Failed to build Tauri application: {e}");
      std::process::exit(1);
    });

  app.run(|_app_handle, _event| {});
}
