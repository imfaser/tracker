use std::path::PathBuf;

#[allow(dead_code)]
pub const APP_ID: &str = "deepshow";

fn project_root() -> PathBuf {
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest_dir.parent().unwrap_or(&manifest_dir).to_path_buf()
}

/// Get the app home directory.
/// - `prod` feature ON:  OS config dir (APPDATA / XDG) + APP_ID, falls back to .app
/// - `prod` feature OFF: `<project_root>/.app` (dev, 参考 run-deck)
#[cfg(feature = "prod")]
pub fn app_home_dir() -> Result<PathBuf, String> {
    // 优先使用系统配置目录，失败则回退到 .app，避免启动即崩
    if let Ok(appdata) = std::env::var("APPDATA") {
        if !appdata.is_empty() {
            return Ok(PathBuf::from(appdata).join(APP_ID));
        }
    }
    if let Ok(home) = std::env::var("HOME") {
        if !home.is_empty() {
            // Linux/macOS fallback: ~/.config/deepshow
            return Ok(PathBuf::from(home).join(".config").join(APP_ID));
        }
    }
    if let Ok(xdg) = std::env::var("XDG_CONFIG_HOME") {
        if !xdg.is_empty() {
            return Ok(PathBuf::from(xdg).join(APP_ID));
        }
    }
    Ok(project_root().join(".app"))
}

#[cfg(not(feature = "prod"))]
pub fn app_home_dir() -> Result<PathBuf, String> {
    Ok(project_root().join(".app"))
}

/// Config file path (config.json)
pub fn config_file() -> Result<PathBuf, String> {
    Ok(app_home_dir()?.join("config.json"))
}
