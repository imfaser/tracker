pub mod dirs;

use serde::{Deserialize, Serialize};
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};
use std::path::Path;
use std::sync::{Mutex, OnceLock};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Config {
    #[serde(default)]
    pub backend_url: String,
    #[serde(default)]
    pub user_id: String,
    #[serde(default)]
    pub conversation_id: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            backend_url: String::new(),
            user_id: String::new(),
            conversation_id: String::new(),
        }
    }
}

static CONFIG: OnceLock<Mutex<Config>> = OnceLock::new();

fn config_mutex() -> &'static Mutex<Config> {
    CONFIG.get_or_init(|| {
        let path = dirs::config_file().expect("failed to resolve config file path");
        // Use println! so it appears in `tauri dev` stdout; also log via tauri if available
        println!("[Config] using file: {}", path.display());
        eprintln!("[Config] using file: {}", path.display());
        let cfg = Config::load_from_file(&path).unwrap_or_default();
        Mutex::new(cfg)
    })
}

impl Config {
    fn load_from_file(path: &Path) -> Result<Self, String> {
        if path.exists() {
            let content = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
            if content.trim().is_empty() {
                return Ok(Self::default());
            }
            let cfg: Self = serde_json::from_str(&content).map_err(|e| e.to_string())?;
            Ok(cfg)
        } else {
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let cfg = Self::default();
            let content = serde_json::to_string_pretty(&cfg).map_err(|e| e.to_string())?;
            std::fs::write(path, content).map_err(|e| e.to_string())?;
            Ok(cfg)
        }
    }

    fn save_to_file(&self) -> Result<(), String> {
        let path = dirs::config_file().map_err(|e| e.to_string())?;
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        // atomic write via temp file to avoid corruption on concurrent saves
        let content = serde_json::to_string_pretty(self).map_err(|e| e.to_string())?;
        let tmp = path.with_extension("json.tmp");
        std::fs::write(&tmp, content).map_err(|e| e.to_string())?;
        std::fs::rename(&tmp, &path).map_err(|e| e.to_string())?;
        Ok(())
    }

    pub fn global_clone() -> Self {
        config_mutex().lock().expect("config lock poisoned").clone()
    }

    pub fn save_global(new_cfg: Self) -> Result<(), String> {
        let mut guard = config_mutex().lock().expect("config lock poisoned");
        // simple hash check to avoid unnecessary writes (optional)
        let mut hasher_old = DefaultHasher::new();
        guard.hash(&mut hasher_old);
        let mut hasher_new = DefaultHasher::new();
        new_cfg.hash(&mut hasher_new);
        *guard = new_cfg.clone();
        drop(guard);
        new_cfg.save_to_file()
    }
}

impl Hash for Config {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.backend_url.hash(state);
        self.user_id.hash(state);
        self.conversation_id.hash(state);
    }
}

#[tauri::command]
pub fn get_config() -> Config {
    Config::global_clone()
}

#[tauri::command]
pub fn get_config_path() -> Result<String, String> {
    Ok(dirs::config_file()?.display().to_string())
}

#[tauri::command]
pub fn update_config(new_config: Config) -> Result<(), String> {
    Config::save_global(new_config)
}
