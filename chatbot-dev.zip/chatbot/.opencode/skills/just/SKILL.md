---
name: just
description: >
  Reference and authoring guide for `just`, the command runner / task runner (a
  modern, cross-platform replacement for `make`). Use this skill whenever the
  user is working in a project that has a `justfile`, mentions `just` or
  `justfile`, wants to add / refactor / organize project commands, is converting
  a Makefile to `just`, asks about recipes, recipe parameters, dependencies,
  modules, `{{ }}` interpolation, dotenv, or `just` command-line flags — and even
  when they don't say "just" explicitly but are clearly defining repeatable
  project commands or a task runner.
---

# just — command runner

`just` stores project commands as **recipes** in a `justfile`. Run them with
`just <recipe>`. This skill is the canonical reference for writing correct
`justfile`s and wiring `just` into a project.

> **Version note:** This skill is based on the `just` *master* README, which can
> be ahead of the version a user has installed. Feature availability varies by
> release, and several features are marked **unstable** (they need `set unstable`)
> or gated behind a minimum version. Before relying on a feature, check
> `just --version`, and pin the requirement with `set minimum-version := 'X.Y.Z'`
> at the top of the justfile. When unsure, prefer the stable, widely-available
> syntax and verify with `just --dump` / `just --fmt --check`.

## How to use this skill

This file is a **map**. Read the entry below that matches what you're doing, then
open the referenced file for the full syntax, examples, and gotchas. Don't try to
memorize everything — jump to the relevant reference when a task needs it.

When you're not sure which file applies, start from `references/recipes.md`
(the core recipe/parameter model) or `references/cli.md` (running `just`).

## Map

| You need to…                                  | Read |
|-----------------------------------------------|------|
| Install `just`, set up editors/LSP/MCP        | `references/installation.md` |
| Write a recipe, give it parameters/variadics, avoid arg-splitting bugs | `references/recipes.md` |
| Order recipes (dependencies), group/alias/privatize them, gate by OS | `references/organization.md` |
| Use variables, `{{ }}` substitution, strings, format strings | `references/variables.md` |
| Use built-in functions, lists, conditionals, user-defined functions, sigils | `references/functions.md` |
| Control recipe bodies: quiet/shebang/script recipes, indentation, multi-line, in-recipe vars, shell | `references/recipe-bodies.md` |
| Handle environment variables, dotenv, `export`, working directory | `references/environment.md` |
| Use a `set …` configuration option (full list of 29 settings) | `references/settings.md` |
| Use a `[attribute]` on a recipe (e.g. `[cache]`, `[parallel]`, `[confirm]`) | `references/attributes.md` |
| Split a justfile across files: imports, modules, remote/parent/global justfiles, markdown | `references/modules.md` |
| List/run recipes, pass CLI variables, format, choose/confirm, cache, or any `--flag` | `references/cli.md` |

## Quick command reference (discovery & execution)

```console
just                 # run the default recipe
just <recipe>        # run a specific recipe
just <recipe> a b    # run with arguments
just --list          # list recipes with doc-comments
just --summary       # list recipe names only
just --show <recipe> # print a recipe's source
just --dump          # print the whole justfile (canonical formatting)
just --evaluate      # print variable values
just --help          # full command-line syntax
```

## Working in an existing project

If a `justfile` already exists, understand it before editing. Discover its
surface first:

```console
just --list          # recipes + doc-comments
just --dump          # full justfile, canonical formatting
just --show <recipe> # one recipe's source
just --evaluate      # current variable values
```

Then read the relevant reference in this skill to extend or fix it, and validate
with `just --fmt --check` (or `just --dump`) before finishing.

## The two mental models that prevent most bugs

1. **Every recipe line runs in its own shell.** A shell variable or `cd` set on
   one line does *not* persist to the next line, and not to dependent recipes.
   Use a shebang/script recipe (one shell process) when you need real script
   semantics. See `references/recipe-bodies.md` and `references/environment.md`.
2. **`just` variables are not environment variables.** `foo := "x"` is a `just`
   value, interpolated with `{{foo}}`. Loaded `.env` values are *environment*
   variables, read as `$FOO` in recipes — never `{{FOO}}`. See
   `references/environment.md`.

## Authoring tips

- Put a comment directly above each recipe — it becomes that recipe's
  doc-comment shown in `just --list`.
- Keep the justfile at the repo root named `justfile` (or `.justfile` to hide it).
- Run `just --fmt --check` in CI to keep the file canonically formatted.
- When a value might contain spaces (paths, messages), quote the interpolation
  (`touch '{{arg}}'`) or read it as an exported/`$N` argument. See
  `references/recipes.md#avoiding-argument-splitting`.
