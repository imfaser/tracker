# Variables, Expressions & Strings

`just` is a **compile-time evaluator**: top-level assignments are evaluated when
the justfile is loaded, before any recipe runs (use `just --evaluate` to see
them). `{{ }}` substitution is a *later* phase that happens at recipe execution
time.

## Variables & assignment

```just
foo := "hello"
bar := "world"
baz:
  echo {{ foo + " " + bar }}
```

- `:=` is the **only** assignment operator in `just` (confirmed by the grammar:
  `assignment : NAME ':=' expression`). The RHS is evaluated at definition time
  (eagerly) and the result is stored.
- There is **no** `=` deferred-assignment operator (that is `make`, not `just`).
  To defer work, either put the computation inside a recipe body / `shell()` call,
  or use `set lazy` to skip evaluating *unused* variables.
- Print all variables: `just --evaluate` (or `--evaluate-format shell`).
- `set allow-duplicate-variables` permits redefinition (last wins).

## The `lazy` attribute

`set lazy` (1.47.0) skips evaluating **unused** variables (e.g. expensive
backticks):

```just
set lazy
token := `expensive-script-to-get-credentials`
foo:
  curl -H "Authorization: Bearer {{ token }}" https://example.com/foo
bar:
  cargo test   # token NOT evaluated here
```

Exceptions that always evaluate even under `lazy`: `export` assignments and
modules with `set export`.

## Expressions & substitution

Expressions work in assignments, default recipe args, and `{{ }}` substitutions:

```just
tmpdir  := `mktemp -d`
version := "0.2.7"
tardir  := tmpdir / "awesomesauce-" + version
tarball := tardir + ".tar.gz"
```

- **Concatenation** `+`: `'foo' + 'bar'` → `'foobar'`.
- **Path join** `/` — always `/`, even on Windows (avoid for UNC `\\` paths):
  `"a/" / "b"` → `"a//b"`.
- **Logical coalescing** `&&` / `||` (needs `set lists`, unstable 1.53.0; only
  `[]` is false, `''` is true).
- **Escaping `{{`** in bodies: `echo 'I {{{{LOVE}} curly braces!'` (quadruple), or
  wrap: `echo '{{ "{{" }}LOVE}}'`.

`{{ }}` works in recipe bodies and `f''` format strings — **never** inside plain
`'…'`/`"…"` string literals.

## Strings

Forms: `'single'`, `"double'`, `'''triple'''` (indented). `{{ }}` is NOT supported
inside normal string literals.

- **Double-quoted** supports escapes: `\r \n \t \\ \"` and `\u{1F916}` (unicode,
  up to 6 hex digits, 1.36.0), plus line-continuation `\` at line end.
- **Single-quoted** ignores escapes (literal).
- **Triple strings** `'''…'''` / `"""…"""` strip the leading newline and common
  leading whitespace of all non-blank lines:
  ```just
  x := '''
    foo
    bar
  '''          # "foo\nbar\n"
  ```
  Triple-double processes escapes; triple-single does not (unindentation happens
  first).
- **Shell-expanded strings** `x'…'` (1.27.0) — compile-time `$VAR`/`${VAR}`/`~`
  expansion. Cannot see `just` variables or `.env`; usable in settings/import
  paths.

## Format strings (`f` prefix, 1.44.0)

Allow `{{ }}` interpolation **inside** the literal:

```just
name    := "world"
message := f'Hello, {{name}}!'      # "Hello, world!"
```

Evaluates to concatenated literal fragments + evaluated expressions.

## Gotchas for authors

1. Use `{{ }}` only in recipe bodies or `f''` strings — never in `'`/`"` literals.
2. Escape literal `{{` as `{{{{` (bodies) or `f'…{{{{…'`.
3. Prefer `:=` for ordinary eager assignment; `set lazy` to skip unused expensive
   vars (exported vars ignore it).
4. `/` always emits forward slashes — fine for POSIX, wrong for Windows UNC.
5. `x'…'` expands at compile time and cannot see `just` variables or `.env`.
