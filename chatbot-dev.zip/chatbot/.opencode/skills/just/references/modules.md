# Modules, Imports & Justfiles

How to split a justfile across files and run justfiles in other locations.

## Imports — `import`

Flattens the imported file into the **current** namespace. Recipes, variables, and
aliases become directly callable as if written inline. Use when you want shared
items available at top level (no isolation).

```just
import 'foo/bar.just'        # relative to the importing justfile's location
import '/abs/path/bar.just'  # absolute also allowed
import '~/lib/util.just'     # ~/ expands to home
import? 'foo/bar.just'       # optional: missing file is not an error (1.37.0+)
```

- Order-insensitive; imported files may reference later-defined items.
- Recursive; re-importing the same file is allowed.
- Duplicate handling: `set allow-duplicate-recipes` / `set
  allow-duplicate-variables` permit overrides. **Shallower definitions override
  deeper**; two duplicates at the same depth → earlier wins.

## Modules — `mod`

Isolation. A submodule has its **own** namespace, its own settings, and its
recipes can't see/be seen by sibling modules. Use when name collisions or setting
conflicts are a risk.

```just
mod bar                       # looks for bar.just / bar/mod.just / bar/justfile / bar/.justfile
mod foo 'PATH'                # load from explicit PATH (file or dir)
mod? foo                      # optional: missing source is not an error
# foo is a great module!      # doc comment shown in `just --list`
mod foo
```

Submodule resolution order: `foo.just` → `foo/mod.just` → `foo/justfile` →
`foo/.justfile`.

Invoke submodule recipes:
```console
just bar b          # subcommand form
just bar::b         # path-syntax form
just --list foo bar # list nested
```

Notes:
- Submodule recipes run with CWD = the directory containing the submodule source
  (unless `[no-cd]`).
- `justfile()`/`justfile_directory()` always return the **root** justfile.
- Parent env vars are visible in children; env files load per-module per settings.
- An optional-module recipe that depends (transitively) on a missing module is
  **disabled**; invoking it errors, but other recipes run.
- Cross-module variable references are not yet supported.

## Invoking justfiles in other directories

If the first arg contains `/`, `just` splits at the **last** `/`: prefix =
search directory, suffix = recipe (or empty).

```console
just foo/build      # == (cd foo && just build)
just foo/           # == (cd foo && just)   (default recipe)
just foo/a b        # == (cd foo && just a b)
```

Canonical flags (equivalent control):
```console
just --justfile PATH            # load a specific justfile
just --working-directory DIR
```

## Fallback to parent justfiles — `set fallback`

```just
set fallback              # in child justfile
foo:
  echo foo
```
```console
$ just bar     # child lacks `bar` -> searches ../justfile upward
Trying ../justfile
echo bar
bar
```

## Remote justfiles

`just` has no native `http(s)://` import. The supported pattern is an **optional
import + a fetch recipe**:

```just
import? 'foo.just'
fetch:
  curl https://raw.githubusercontent.com/casey/just/master/justfile > foo.just
```

## Global / user justfiles

Recipes available everywhere, independent of cwd.

**Global justfile** (`just -g` / `--global-justfile`) searches in order:
`$XDG_CONFIG_HOME/just/justfile`, `$HOME/.config/just/justfile`, `$HOME/justfile`,
`$HOME/.justfile`.

**User justfile via shell alias:**
```console
alias .j='just --justfile ~/.user.justfile --working-directory .'
```

## Markdown justfiles

`--justfile` ending in `.md` extracts un-indented ```` ```just ```` fenced blocks
into a temp justfile (1.53.0+):
````markdown
# Project
```just
build:
  echo Building…
```
````
```console
just --justfile README.md build
```

## Just scripts (shebang)

Use `just` as a script interpreter — a self-contained executable that is really a
justfile:
```console
#!/usr/bin/env just --justfile        # chdir to script location
# OR (leave cwd unchanged):
#!/usr/bin/env just --working-directory . --justfile
```
```console
chmod +x script && ./script foo
```

## Hiding justfiles

Name it `.justfile` instead of `justfile`. `just` searches both.

## Decision guide

| Goal | Use |
|------|-----|
| Share recipes at top level, no isolation | `import` |
| Isolate subsystems (own settings/namespace/cwd) | `mod` |
| Run a subdir's justfile | `just subdir/recipe` or `--justfile`+`--working-directory` |
| Defer to ancestor recipes | `set fallback` |
| Share source across repos | `import?` + `fetch` recipe |
| Recipes everywhere on a machine | `just -g` / user justfile alias |
| Docs-as-justfile | `--justfile README.md` |
| Self-contained executable | shebang script |
| Keep file out of sight | name it `.justfile` |
