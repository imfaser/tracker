# Environment & Working Directory

The subtleties that cause the most confusion: `just` variables ≠ environment
variables, and each recipe line runs in its own shell.

## Environment variables from the parent

Parent env vars pass through automatically; read them as `$VAR` in recipes:

```just
print_home_folder:
  @echo "HOME is: '${HOME}'"
```

Promote an env var into a `just` variable with `env()`: `x := env("VAR")`.
Referencing an **unset** `$VAR` errors when the shell has `set -u` (default `sh
-cu` includes `-u`). Unexport with `unexport FOO`.

## Exporting `just` variables

Bridge `just` variables into the recipe environment:

```just
export RUST_BACKTRACE := "1"
test:
  cargo test          # sees RUST_BACKTRACE in env
```

```just
test $RUST_BACKTRACE="1":   # parameter prefixed with $ is exported
  cargo test
```

```just
[env("RUST_BACKTRACE", "1")]   # per-recipe env
test:
  cargo test
```

**Pitfall:** exported `just` variables/params are **not** visible to backticks in
the same scope.

`set export` exports **all** `just` variables as env vars (default `false`).

## Dotenv settings

Any of `dotenv-load`, `dotenv-filename`, `dotenv-override`, `dotenv-path`,
`dotenv-required`, `dotenv-command` triggers loading env vars from a file.

- `set dotenv-load` → looks for `.env` in CWD and each ancestor.
- `set dotenv-path := "path"` → single file, relative to CWD (or absolute). CLI:
  `-E`/`--dotenv-path`.
- `set dotenv-filename := "name"` → searched in CWD + ancestors. CLI: `-F`/
  `--dotenv-filename`. (`dotenv-path` checks only CWD; `dotenv-filename` walks up.)
- `set dotenv-required` → error if the file is missing.
- `set dotenv-override` → file vars override existing env vars (default: env wins).
- `set dotenv-command := 'sops -d .enc.env'` → runs a command, loads stdout as env
  (use for secret managers).

```just
set dotenv-load
serve:
  ./server --database $DATABASE_ADDRESS --port $SERVER_PORT
```

**Critical:** loaded dotenv values are **environment variables, NOT `just`
variables** — access them only as `$VAR` in recipes and backticks, never as
`{{VAR}}`. Vars loaded in parent modules are inherited by submodules (1.49.0).

## Sharing env vars between recipes

Impossible by default: each line of each recipe runs in a fresh shell, so env vars
set in one recipe don't carry into a dependent recipe. Workarounds:

- Put shared state in `export`ed `just` variables (visible to every recipe as env
  vars).
- For tools needing activation (e.g. Python venv), call binaries by absolute path
  instead of activating:
  ```just
  venv:
    [ -d foo ] || python3 -m venv foo
  run: venv
    ./foo/bin/python3 main.py
  ```

## Working directory

Default: recipes run in the directory containing the `justfile`.

```just
[no-cd]            # run in the dir `just` was invoked from
@bar:
  pwd
```

```just
set no-cd                        # all recipes default to invocation dir
set working-directory := 'bar'   # all recipes chdir here (rel. to justfile dir)
[working-directory: 'bar']       # single recipe
```

`working-directory` may be an expression (1.51.0); relative paths resolve against
the justfile dir. These settings **do not** affect dotenv search or the CWD of
backtick/`shell()` invocations.

## Changing directory inside a recipe

Each line = new shell, so `cd` on one line doesn't affect the next:

```just
foo:
  pwd      # dir A
  cd bar
  pwd      # still dir A
```

Workarounds: same line (`cd bar && pwd`), or a **shebang/script recipe** (single
shell, `cd` persists). A `cd` inside one recipe never affects the CWD of a recipe
it depends on or that depends on it — use `[no-cd]`/`working-directory` or absolute
paths instead.

## Mental model

- Every recipe **line** = a new shell → no persistent shell vars / no persistent
  `cd` across lines.
- `just` variables ≠ env vars. Use `export`/`$param`/`[env(...)]`/`env()` to bridge;
  dotenv values are env-only (`$VAR`, never `{{VAR}}`).
- Shebang/script recipes = one shell = normal script semantics (vars + `cd` persist).
- CWD defaults to the justfile dir; `[no-cd]`/`working-directory`/`set no-cd`/
  `set working-directory` override it, but never touch dotenv search or backtick/
  `shell()` CWD.
