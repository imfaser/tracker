# Settings (`set`)

`just` has 29 configuration settings. Each may be specified **at most once**,
anywhere in the justfile. Boolean settings can be written as `set NAME` (shorthand
for `set NAME := true`).

> Constraint: settings affect how backticks and many functions behave, so a
> setting's value expression may **not** contain backticks or function calls
> (directly or transitively).

## Table of settings

| Setting | Value | Default | Description |
|---|---|---|---|
| `allow-duplicate-recipes` | boolean | `false` | Later recipes override earlier ones with the same name. |
| `allow-duplicate-variables` | boolean | `false` | Later variables override earlier ones with the same name. |
| `default-list` | boolean | `false` | List recipes instead of running the default recipe. |
| `default-script`<sup>1.52.0</sup> | boolean | `false` | Default recipes to script instead of shell. |
| `dotenv-command`<sup>1.54.0</sup> | string | — | Run a command and load its output as an env file. |
| `dotenv-filename` | string | — | Load a `.env` file with a custom name, if present. |
| `dotenv-load` | boolean | `false` | Load a `.env` file, if present. |
| `dotenv-override` | boolean | `false` | Override existing env vars with `.env` values (default: env wins). |
| `dotenv-path` | string | — | Load `.env` from a custom path; error if missing. Overrides `dotenv-filename`. |
| `dotenv-required` | boolean | `false` | Error if a `.env` file isn't found. |
| `export` | boolean | `false` | Export **all** variables as environment variables. |
| `fallback` | boolean | `false` | Search parent dirs for a justfile if a recipe isn't found. |
| `guards`<sup>1.47.0</sup> | boolean | `false` | Enable the `?` guard sigil on recipe lines. |
| `ignore-comments` | boolean | `false` | Ignore shell recipe lines beginning with `#` (not script recipes). |
| `indentation`<sup>1.56.0</sup> | string | — | Recipe body indentation used by `--fmt`/`--dump`. |
| `lazy`<sup>1.47.0</sup> | boolean | `false` | Don't evaluate unused variables. |
| `lists`<sup>1.53.0</sup> | boolean | `false` | Values may be lists of strings. (Unstable; needs `set unstable`.) |
| `minimum-version`<sup>1.55.0</sup> | string | — | Error if `just` is older, e.g. `"1.55.0"`. Must be first line. |
| `no-cd`<sup>1.51.0</sup> | boolean | `false` | Don't change directory when executing recipes. |
| `no-exit-message`<sup>1.39.0</sup> | boolean | `false` | Don't print exit messages when recipes fail. |
| `positional-arguments` | boolean | `false` | Pass positional arguments (`$1 $2 … $@`). |
| `quiet` | boolean | `false` | Disable echoing recipe lines before executing. |
| `script-interpreter`<sup>1.33.0</sup> | `[COMMAND, ARGS…]` | `['sh', '-eu']` | Interpreter for empty `[script]` recipes. |
| `shell` | `[COMMAND, ARGS…]` | `sh -cu` | Command used for recipe lines and backticks. |
| `tempdir` | string | system default | Where temporary (shebang/script) files are written. |
| `unstable`<sup>1.31.0</sup> | boolean | `false` | Enable unstable features. |
| `windows-powershell` | boolean | `false` | Use PowerShell on Windows as default shell. **Deprecated** — use `[windows] set shell`. |
| `windows-shell` | `[COMMAND, ARGS…]` | — | Windows shell for recipe lines/backticks. **Deprecated** — use `[windows] set shell`. |
| `working-directory`<sup>1.33.0</sup> | string | — | Working directory for recipes/backticks, relative to the justfile dir. |

## Examples

```just
set shell := ["zsh", "-cu"]          # recipe lines run as `zsh -cu '…'`
set dotenv-load                      # load .env if present
set export                           # every just variable becomes an env var
set minimum-version := '1.55.0'      # must be the FIRST line
set unstable
set lists                            # enable list values (unstable)
```

## Shorthand for booleans

```just
set quiet          # equivalent to:
set quiet := true
```

## Where to go next

- Shell selection, `set shell`, `set script-interpreter` → `references/recipe-bodies.md`
- Dotenv (`dotenv-*`), `set export`, `set no-cd`, `set working-directory` →
  `references/environment.md`
- `set unstable` / `set lists` (lists, user-defined functions) → `references/functions.md`
- `set lazy` → `references/variables.md`
- `set allow-duplicate-*`, `set fallback`, `set default-list` → `references/organization.md` /
  `references/modules.md`
- `set minimum-version` → `references/installation.md`
- `set positional-arguments` → `references/recipes.md`
