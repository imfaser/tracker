# Recipe Bodies & Shell

How recipe bodies execute, and how to shape them (quiet, shebang, script,
indentation, multi-line). Recall: each line of a normal recipe runs in its **own
shell** — see also `references/environment.md`.

## Quiet recipes

A leading `@` on a **recipe name** inverts echoing: lines are quiet by default,
and only lines starting with `@` are echoed. (For a normal recipe, a leading `@`
on a single line suppresses just that line's echo.)

```just
@quiet:
  echo hello        # not echoed
  echo goodbye      # not echoed
  @# all done!      # echoed -> "# all done!"
```

`set quiet` makes the whole file quiet; `[no-quiet]` on a recipe overrides it.
Shebang recipes are **quiet by default**.

## Shebang recipes (`#!`)

A recipe whose **first body line** starts with `#!` is written to a temp file and
executed by that interpreter — enables any language.

```just
python:
  #!/usr/bin/env python3
  print('Hello from python!')
```

- Unix: the file is made executable; the OS parses the shebang. Use
  `#!/usr/bin/env -S bash -x` (the `-S` flag) to pass arguments to `env`.
- Windows: no shebang support; `just` splits the line into `cmd + args` and
  appends the temp-file path.

## Script recipes (`[script(COMMAND)]`)

`[script(COMMAND)]` (1.32.0) runs the body via `COMMAND`, avoiding shebang
pitfalls (no `cygpath`, no `/usr/bin/env`, no `noexec` temp-dir requirement).

- `[script]` with no command uses `set script-interpreter := […]` (1.33.0),
  **default `sh -eu`** — *not* `set shell`.
- `set default-script := true` (1.52.0) makes all recipes script recipes unless
  overridden with `[shell]`.

## Safer bash shebang

Recommended incantation so bash shebang recipes behave like normal `just` shell
recipes:

```just
foo:
  #!/usr/bin/env bash
  set -euxo pipefail
  hello='Yo'
  echo "$hello from Bash!"
```

- `-e` exit on any command failure; `-u` exit on undefined variable; `-x` print
  each line; `-o pipefail` exit if any pipeline command fails (bash-specific).

## Temporary files

Both shebang and script recipes write the body to a temp file. Temp-dir precedence
(high→low): `--tempdir` / `JUST_TEMPDIR` env (1.41.0) → per-module `tempdir`
setting → `XDG_RUNTIME_DIR` (Linux) → `std::env::temp_dir()`.

## Indentation

- Recipe lines may use **spaces or tabs, but not mixed**. Within one recipe all
  lines must share the same indentation type; different recipes may differ.
- A recipe must be indented at least one level from the name; further nesting is
  allowed.
- Change the default shell with `set shell := [...]` (see `references/environment.md`).

## Multi-line constructs

Normal recipes run **line by line**, so multi-line shell constructs (`if`/`for`/
`while`) break — extra leading whitespace causes `error: Recipe line has extra
leading whitespace`. Three fixes:

```just
conditional:
  if true; then echo 'True!'; fi        # 1) one line
conditional:
  if true; then \                        # 2) line continuation with \
    echo 'True!'; \
  fi
conditional:
  #!/usr/bin/env sh                      # 3) add a shebang -> real script
  if true; then
    echo 'True!'
  fi
```

Outside recipe bodies, parenthesized expressions and `\` line continuation work
freely (assignments, parameters, dependencies, and inside `{{ }}`):

```just
a := 'foo' + \
     'bar'
recipe:
  echo '{{ \
  "This interpolation " + \
    "has a lot of text." \
  }}'
```

## Setting variables inside a recipe

Recipe lines run in the shell, not in `just`. `just`-style assignment is illegal
mid-recipe, and shell variables don't persist across lines:

```just
foo:
  x := "hello"      # WRONG — not valid shell syntax
foo:
  x=hello && echo $x   # OK — same line
  y=bye
  echo $y              # WRONG — `y` undefined, new shell
```

Workarounds: chain on one line (`x=hello && echo $x`), or use a **shebang/script
recipe** (single shell instance — vars and `cd` persist). See
`references/environment.md`.

## Configuring the shell

`set shell := [...]` controls the command used for shell-recipe lines and
backticks (shebang recipes unaffected). Default `sh -cu`. The command receives the
script as an argument, so most shells need a `-c`-like flag.

```just
set shell := ["python3", "-c"]
foos := `print("foo" * 4)`
foo:
  print("{{foos}}")
```

Common presets: `["bash","-uc"]`, `["zsh","-uc"]`, `["fish","-c"]`, `["nu","-c"]`.
Per-OS: `[windows] set shell := ["powershell.exe", "-NoLogo", "-Command"]`.
Precedence: `--shell`/`--shell-arg` CLI > `set windows-shell` (deprecated) >
`set windows-powershell` (deprecated) > `set shell := [...]`.
