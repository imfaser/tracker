# Recipes & Parameters

A recipe is a named command. The recipe body (indented one level) is executed
line by line by the shell. This file covers the core recipe/parameter model and
the single most common bug: **argument splitting**.

## The default recipe

```just
default: lint build test
build:
  echo Building…
test:
  echo Testing…
lint:
  echo Linting…
```

- Bare `just` runs the recipe tagged `[default]`, or the **first** recipe if none
  is tagged.
- `set default-list := true` makes bare `just` *list* recipes instead of running
  one (useful when no recipe makes sense as the default).

## Recipe parameters

**Positional (required):**

```just
build target:
  cd {{target}} && make
# just build my-awesome-project
```

**Defaulted parameters** (the default may be any expression):

```just
test target tests='all':
  ./test --tests {{tests}} {{target}}
# just test server        -> tests = "all"
# just test server unit   -> tests = "unit"
```

Defaults with operators need parentheses: `input=(arch / "input.dat")`.

**Forwarding arguments to a dependency** — wrap the dependency call in parens:

```just
build target:
  cd {{target}} && make
push target: (build target)     # forwards the arg
default: (build "main")          # literal arg
```

**Options (`[arg]` attributes, 1.46.0+):**

```just
[arg("bar", long="bar")]   foo bar:   # just foo --bar hello
[arg("bar", short="b")]    foo bar:   # just foo -b hello
[arg("bar", long, short="b")]         # both; -abc combines
[arg("bar", long="bar", value="hello")] foo bar:  # flag w/o value sets "hello"
```

A value-less flag is **required** unless the param has a default. Constrain a
param with `[arg(ARG, pattern='\d+')]` (regex anchored `^…$`). `$`-prefixed params
are exported as env vars: `foo $bar:`.

## Variadic parameters (`+` vs `*`)

The **last** parameter may be variadic:

```just
backup +FILES:          # one-or-more; error if none given
  scp {{FILES}} me@server.com:
commit MESSAGE *FLAGS:  # zero-or-more; empty string if none
  git commit {{FLAGS}} -m "{{MESSAGE}}"
```

- `+FILES` → requires **≥1** arg, expands to a space-joined string.
- `*FLAGS` → accepts **0**, empty string if none.
- Both work as options too: `[arg('FILES', long)] +file` → repeatable
  `--file a --file b`.
- With `set unstable` + `set lists`, `[arg('FILES', min='2', max='4')]` limits count.

**Why the distinction matters:** use `+` when the recipe is meaningless without
input (e.g. `backup` needs files); use `*` when it's valid with no extra args
(e.g. `commit` with default flags). Picking wrong forces a dummy arg or silently
allows an invalid no-arg call.

## Avoiding argument splitting

`just` does raw text substitution into the command line **before** the shell
parses it. Quotes the user typed on the CLI are **not** preserved.

```just
foo argument:
  touch {{argument}}
# just foo "some argument.txt"  -> creates TWO files: `some` and `argument.txt`
```

The user's shell collapsed `"some argument.txt"` to one arg, but after
`{{argument}}` is substituted the quotes vanish, so `touch` gets two arguments.

**Fixes (pick by context):**

1. **Quote the interpolation** (preferred; keeps typo-checking):
   ```just
   foo argument:
     touch '{{argument}}'      # works unless value contains a single quote
   ```
2. **`set positional-arguments`** — args reachable as `$1 $2 … $@`; double-quote
   to block re-splitting. `$0` = recipe name; `"$@"` preserves each arg as-quoted.
   Tradeoff: `just` can no longer catch `$2`-vs-`$1` typos.
   ```just
   set positional-arguments
   foo argument:
     touch "$1"
   ```
3. **Exported arguments** (`set export` globally or `$`-prefix per param):
   ```just
   foo $argument:
     touch "$argument"         # env var, safe for all values
   ```
   Tradeoff: loses `just`'s interpolation typo-checking.

**Rule of thumb:** any param whose value *might* contain spaces (paths, queries,
commit messages) must be quoted in the body, or fed via `$N` / `$arg` env form.
The naive `{{x}}` pattern silently mangles multi-word inputs.

## Decision guide

- No sensible default recipe → `set default-list`.
- Need to forward caller args to a dependency → `(dep arg)`.
- Param optional → give it a default; param must repeat → variadic `+`/`*`.
- Param value can contain spaces → quote it, or use positional/`$`-export form.
- Need CLI flags (`--foo`, `-f`) → `[arg(..., long/short)]`.
