# Command-Line Interface

Everything you invoke `just` with: discovery, running, parameterizing, and the
flag reference. For the full list run `just --help` (versions vary).

## Listing & discovery

```console
just --list              # recipes alphabetically, with doc-comments
just --summary           # recipe names only, space-separated
just --list --unsorted   # preserve file order
just --list foo bar      # submodule recipes (space- or ::-separated path)
just --show <recipe>     # print a recipe's source
just --dump              # print the whole justfile (canonical formatting)
just --dump --dump-format json
```

- `set default-list := true` / env `JUST_DEFAULT_LIST=true` / `--default-list` →
  bare `just` lists recipes (per-module).
- `--list-heading TEXT` replaces the heading **and** its trailing newline (pass
  `''` to suppress). `--list-prefix` customizes indentation.

## Running recipes

```console
just                 # default recipe
just build           # one recipe
just build serve     # multiple, in order
just build my-proj   # with arguments
```

**Gotcha:** a parameterized recipe swallows following args even if they name other
recipes:
```just
build project:              # `just build serve` -> make target "serve" (wrong!)
  make {{project}}
```
`--one` restricts the command line to exactly one recipe invocation.

## Setting variables from the CLI

```console
just os=plan9             # NAME=VALUE before recipes
just --set os bsd        # --set NAME VALUE
just foo::bar=VALUE      # submodule: ::-separated path
just --set foo::bar VALUE
```

## Flag reference

| Flag | Description |
|---|---|
| `--list` | List recipes alphabetically |
| `--summary` | List recipe names, space-separated |
| `--unsorted` | List in file order |
| `--default-list` | Default to listing when no recipe given |
| `--list-heading TEXT` | Customize/suppress heading (consumes trailing newline) |
| `--list-prefix TEXT` | Customize recipe indentation in `--list` |
| `--one` | Allow only a single command-line recipe |
| `--set NAME VALUE` | Override a variable |
| `--show RECIPE` | Print a recipe's source |
| `--choose` | Pick recipes via an interactive chooser |
| `--chooser CMD` | Override chooser (default `fzf`; env `JUST_CHOOSER`) |
| `--yes` | Auto-confirm `[confirm]` recipes |
| `--timestamp` | Print `HH:MM:SS` before each command |
| `--timestamp-format FMT` | `strftime`-style timestamp format |
| `--dump` | Print formatted justfile to stdout |
| `--dump-format json` | Dump justfile as JSON |
| `--fmt` | Overwrite justfile with canonical formatting |
| `--fmt --check` | Check formatting; exit 0 ok, 1 + diff if not |
| `--indentation "  "` | Set recipe body indent (also `JUST_INDENTATION`, `set indentation`) |
| `--completions SHELL` | Emit completion script (bash/elvish/fish/nushell/powershell/zsh) |
| `--man` | Print the man page |
| `--unstable` | Enable unstable features (env `JUST_UNSTABLE`) |
| `--no-cache` | Bypass the recipe cache |
| `--clean [path]` | Clear cache entries |
| `--dry-run` | Print what would run, without running |
| `--quiet` / `--silent` | Suppress echo of recipe lines |
| `--evaluate` | Print variable values |
| `--justfile PATH` | Load a specific justfile |
| `--working-directory DIR` | Run as if invoked from DIR |
| `--shell` / `--shell-command` | Override shell for recipe/chooser |
| `--global-justfile` / `-g` | Use the global justfile |
| `--help` | Full flag list |

## Interactive chooser (`--choose`)

Chooser reads recipe names from stdin, prints chosen ones (space-separated) to
stdout. Recipes with arguments, private recipes, and aliases are skipped.

```just
default:
  @just --choose          # make the chooser the default action
```

## Requiring confirmation

```just
[confirm]
delete-all:
  rm -rf *

[confirm("Are you sure you want to delete everything?")]
delete-everything:
  rm -rf *

[confirm("Deploy to " + env + "?")]   # prompt may be an expression (1.49.0)
deploy env:
  echo 'Deploying to {{env}}...'
```

`--yes` overrides all `[confirm]`. An unconfirmed recipe blocks its dependents and
any later CLI recipes.

## Timestamps

```console
just --timestamp recipe
[07:28:46] echo one
```

`--timestamp-format` takes `strftime` syntax. Per-recipe: `[timestamp]` or
`[timestamp('%H:%M:%S%.3f')]`.

## Signal handling

- **Fatal:** `SIGHUP`/`SIGINT`/`SIGQUIT` (terminal close / ctrl-c / ctrl-\),
  `SIGTERM` (`kill`). No running child → `just` exits immediately; child running →
  it waits to avoid orphaning, then halts. `SIGTERM` is forwarded to children
  (1.41.0).
- `[continue]` (1.54.0): keep going if the child exits successfully; explicit
  signals: `[continue("SIGHUP")]`.
- `SIGINFO` (ctrl-t, BSD/macOS only): prints child PIDs + commands.
- Windows: ctrl-c treated as `SIGINT`; other signals unsupported.

## Shell completion

```console
just --completions bash > ~/.local/share/bash-completion/completions/just
# fish: > ~/.config/fish/completions/just.fish
# zsh:  > ~/.zsh/completions/_just  (then fpath+compinit in .zshrc)
```

## Man page

`just --man | groff -mandoc -Tascii | less`.

## Formatting & dumping

```console
just --fmt                 # rewrite justfile canonically (4-space indent)
just --fmt --check         # CI check; 0=ok, 1+diff=needs fmt
just --dump > out          # formatted justfile to stdout
```

Canonical format is **not** under the backward-compat guarantee. With `--justfile
-` or markdown extraction, `--fmt` prints to stdout instead of overwriting.

## Cached recipes (`[cache]`, unstable, 1.54.0)

Script recipes only; skip re-run when the cache matches.

```just
set unstable
[script]
[cache(inputs = "image.png", outputs = "image.jpg", extra = `convert -version`)]
convert:
  convert image.png image.jpg
```

Cache dir `.justcache` (don't commit). Keys don't capture time, undeclared
input/output files, system binaries, OS version, DBs, network, or DNS — verify
the key captures enough context before relying on it. `--no-cache` bypasses;
`--clean [recipe|submodule [recipe]]` clears entries; `-vv` prints cache keys.

## Flag vs env

Env vars (`JUST_*`, e.g. `JUST_UNSTABLE`, `JUST_CHOOSER`, `JUST_INDENTATION`)
inherit into recursive `just` invocations; CLI args do not.
