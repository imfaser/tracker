# Organization & Structure

How to order, document, group, and conditionally enable recipes.

## Dependencies

Syntax: `depender: dependency` (space-separated). Dependencies always run
**before** the depender ("prior dependencies").

```just
a: b
  @echo A
b:
  @echo B
# just a  -> B, then A
```

- A dependency runs **once per invocation** even if listed multiple times.
- Dedup is keyed by **recipe + same arguments**: `just test foo test bar`
  re-runs `build` between the two different args.
- **Subsequent dependency** (runs *after* the recipe) via `&&`:
  ```just
  b: a && c d
    echo 'B!'
  # just b -> A!, B!, C!, D!
  ```
- Mid-recipe dependencies aren't supported; use recursive `just c` (re-runs
  assignments/deps, no arg propagation).

## Parallelism

Per-recipe `[parallel]` runs that recipe's dependencies concurrently:

```just
[parallel]
main: foo bar baz
foo:
  sleep 1
# foo/bar/baz run in parallel under `just main`
```

Limit concurrency with `--jobs N` (1.56.0); `num_jobs()` returns the job count
(empty list if `--jobs` omitted). For parallel *lines within* a recipe, use GNU
`parallel` via a shebang:
`#!/usr/bin/env -S parallel --shebang --ungroup --jobs {{ num_cpus() }}`.

## Documentation comments

A comment immediately above a recipe becomes its doc-comment in `just --list`:

```just
# build stuff
build:
  ./bin/build
# just --list -> "build # build stuff"
```

- `[doc('text')]` overrides/sets the doc; bare `[doc]` suppresses it; value may be
  a const expression (1.56.0).

## Groups

`[group('name')]` clusters recipes in `just --list`:

```just
[group('lint')]
js-lint:
  echo 'Running JS linter…'
[group('lint')]
[group('rust recipes')]
rust-lint:
  echo '…'
```

List group names with `--groups`; `--unsorted` preserves justfile order.

## Aliases

`alias SHORT := target` gives a recipe another name. Target may be a submodule
recipe (`foo::bar`) or a module (1.55.0, then `just f build`):

```just
alias b := build
build:
  echo 'Building!'
# just b -> runs build
```

## Private recipes

A name starting with `_` hides the recipe/alias from `--list` and `--summary`.

```just
test: _test-helper
  ./bin/test
_test-helper:
  ./bin/super-secret-test-helper-stuff
```

`[private]` (1.10.0) hides without renaming — works on recipes and aliases:

```just
[private]
foo:
[private]
alias b := bar
```

Use private recipes for helpers meant only as dependencies.

## Enabling / disabling by platform

Conditional attributes gate items by OS: `[android]`, `[dragonfly]`, `[freebsd]`,
`[linux]`, `[macos]`, `[netbsd]`, `[openbsd]`, `[unix]`, `[windows]`. An item is
enabled only when a matching attribute is active. Applies to all top-level items
(1.56.0), including `set`:

```just
[unix]
run:
  cc main.c && ./a.out
[windows]
run:
  cl main.c && main.exe
```

One justfile adapts to the host OS this way.

## Allow duplicate recipes

`set allow-duplicate-recipes` → redefining a recipe isn't an error; last wins
(default `false`). Same for variables with `set allow-duplicate-variables`. Useful
for overriding recipes across included/generated justfiles.
