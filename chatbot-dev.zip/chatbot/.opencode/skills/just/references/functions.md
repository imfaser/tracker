# Functions, Lists & Conditionals

`just` has a rich expression language. This file covers lists, conditionals,
command evaluation, and the full built-in function catalogue.

## Lists (`set lists`, unstable ≥1.53.0)

Enable with `set unstable` + `set lists`. Lists hold **strings only** (no nesting);
literals flatten: `[["a","b"],[],"c"]` → `["a","b","c"]`.

- Operators: `+`/`/` combine string↔list (string prepended to each element) or
  list↔list (pairwise, equal length). `++` concatenates lists.
- Variadic params are lists: `foo *args:` (one positional arg per element).
- **Mapped dependency**: `build target *platform: *(compile target *platform)`
  runs `compile` once per element.
- `if` without `else` → `[]` when false.

Use `join_list(value, sep?)` to flatten lists for non-upgraded functions.

## Conditional expressions

`if COND { A } else { B }` — branches short-circuit (use to guard backticks).
Supports `==`, `!=`, `=~`/`!~` (regex, single-quoted patterns). Chainable.

```just
foo := if "hello" =~ 'hel+o' { "match" } else { "mismatch" }
bar foo:
  echo {{ if foo == "bar" { "hello" } else { "goodbye" } }}
```

## Command evaluation (backticks)

Store a command's stdout: `` localhost := `hostname` ``. Indented
triple-backticks de-indent like strings. May not start with `#!`. Prefer
`shell(cmd, args…)` for commands built from variables/args.

## Stopping execution — `error()`

`error("msg")` aborts with `Call to function error failed: msg`. Use in `else`
branches to reject invalid states. `assert(cond, msg?)` is the non-fatal variant.

## Built-in functions

**System:** `arch()`, `num_cpus()` (≥1.15), `os()`, `os_family()`
(`unix`/`windows`).
**External:** `shell(command, args…)` (≥1.27; runs via `set shell`).
**Env:** `env(key)`, `env(key, default)` (≥1.15), `env_var(key)`,
`env_var_or_default(key, default)`.
**Executables:** `require(name)` (≥1.39; path or error), `which(name)` (≥1.39; `[]`
if absent, needs `set lists`).
**Invocation:** `is_dependency()`, `num_jobs()` (≥1.56), `recipe_name()` (≥1.53),
`invocation_directory()` / `invocation_directory_native()`.
**Justfile/source/module:** `justfile()`, `justfile_directory()`,
`source_file()`/`source_directory()` (≥1.27), `module_file()`/`module_directory()`/
`module_path()`.
**Process:** `just_executable()`, `just_pid()`, `just_version()` (≥1.55).
**String:** `append(suffix,s)`, `prepend(prefix,s)`, `encode_uri_component(s)`
(≥1.27), `quote(s)` (shell-escape), `replace(s,from,to)`,
`replace_regex(s,re,rep)`, `trim(s)`, `trim_start(s)`, `trim_end(s)`,
`trim_start_match(s,sub)`, `trim_end_match(s,sub)`.
**Case:** `capitalize`, `kebabcase`, `lowercamelcase`, `lowercase`,
`shoutykebabcase`, `shoutysnakecase`, `snakecase`, `titlecase`, `uppercamelcase`,
`uppercase`.
**Path (fallible):** `absolute_path(p)`, `canonicalize(p)` (≥1.24), `extension(p)`,
`file_name(p)`, `file_stem(p)`, `parent_directory(p)`, `without_extension(p)`.
**Path (infallible):** `clean(p)`, `join(a,b…)` (**path** join — use `/` operator
to force `/`).
**FS:** `path_exists(p)` (returns `"true"`/`"false"`), `read(p)` (≥1.39).
**Assert/errors:** `assert(cond, msg?)`, `error(msg)`.
**Hashes/UUID:** `blake3(s)`, `blake3_file(p)` (≥1.25), `sha256(s)`,
`sha256_file(p)`, `uuid()`.
**Random:** `choose(n, alphabet)` (≥1.27; alphabet has no repeats).
**Datetime:** `datetime(fmt)`, `datetime_utc(fmt)` (≥1.30; strftime).
**Semver:** `semver_matches(version, req)` (≥1.16).
**Style:** `style(styles)` (≥1.37; terminal escapes).
**Lists (with `set lists`):** `join_list(v,sep?)`, `split(s,sep?)` (whitespace if
omitted), `len(v)`, `bool(v)`, `show(v)`. `absolute_path`/`append`/`prepend`/
`quote`/`which`/`path_exists`/`is_dependency`/`semver_matches` apply per-element.

**Abbreviations:** `*_directory` → `*_dir`; `invocation_directory_native` →
`invocation_dir_native`.

> NOTE: there is **no** `json()`/`yaml()`/`toml()`/`xml()`/`python()` function in
> current stable `just`. Do not teach them.

## User-defined functions (unstable ≥1.49.0)

```just
set unstable
hello(name) := f"Hello, {{ name }}!"
base := "foo"
join(ext) := base + "." + ext
```

## Sigils (command-line prefixes; combinable `-`, `@`, `?`)

- **`@`** — suppress echoing that command (`@recipe:` silences the whole recipe).
- **`-`** — continue the recipe even if the command exits non-zero (`-rmdir bar`).
- **`?`** (≥1.47, needs `set guards`) — stop the **current** recipe if the command
  exits `1`; `0` continues; other codes reserved. Without `set guards`, `?` is
  treated as part of the command.

## Booleans (lists context)

Canonical true = `"true"`; canonical false = empty list `[]`. Anything non-`[]` is
truthy (incl. `''`). `!expr` → `"true"` if `[]` else `[]`. Comparisons yield
`"true"`/`[]`. `bool(v)` parses `"1"`/`"true"`→`"true"`, `""`/`"0"`/`"false"`/`[]`→`[]`.
