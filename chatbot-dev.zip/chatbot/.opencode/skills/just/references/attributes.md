# Recipe Attributes (`[...]`)

Bracket attributes decorate a recipe (or alias/module). They are **distinct from
`settings`** (`set …`) — settings are file-wide configuration; attributes annotate
individual items. This file is the consolidated index of every attribute.

> Unstable features (`[cache]`, list-valued `[arg(min/max)]`) require
> `set unstable` (and often `set lists`). See `references/settings.md`.

## Categories at a glance

| Attribute | What it does | Needs |
|---|---|---|
| `[default]` | Mark the default recipe (bare `just` runs it) | — |
| `[doc('text')]` / `[doc]` | Set or suppress a recipe's doc-comment | — |
| `[group('name')]` | Cluster recipe under a group in `just --list` | — |
| `[private]` | Hide recipe/alias from `--list`/`--summary` | — |
| `[parallel]` | Run the recipe's dependencies concurrently | — |
| `[confirm]` / `[confirm("prompt")]` | Require terminal confirmation (auto with `--yes`) | — |
| `[arg(...)]` | Turn a parameter into a CLI option/flag | — |
| `[script(COMMAND)]` / `[script]` | Run body via a script interpreter | — |
| `[shell]` | Force a shell recipe when `set default-script` is on | — |
| `[no-quiet]` | Override file-wide `set quiet` | — |
| `[no-cd]` | Run in the invocation directory (don't chdir) | — |
| `[working-directory: 'path']` | chdir this recipe to `path` | — |
| `[timestamp]` / `[timestamp('fmt')]` | Print timestamps before each command | — |
| `[continue]` / `[continue("SIG")]` | Keep going after a signal | — |
| `[env(NAME, VALUE)]` | Export a per-recipe environment variable | — |
| `[cache(...)]` | Skip re-running when the cache matches | `set unstable` |
| `[linux]` `[macos]` `[windows]` `[unix]` `[freebsd]` `[netbsd]` `[openbsd]` `[dragonfly]` `[android]` | Enable item only on that platform | — |
| `[no-exit-message]` | Don't print an exit message when the recipe fails | — |

## Core metadata

```just
[default]
default:
  build test

[doc('Build the project')]
build:
  cc main.c -o main

[doc]                       # suppress the doc-comment entirely
internal:
  echo secret

[group('lint')]
js-lint:
  echo linting…

[private]
_helper:
  echo used only as a dependency

[private]
alias b := bar             # private works on aliases too
```

## Execution behavior

```just
[parallel]
main: foo bar baz          # foo/bar/baz run concurrently

[confirm("Deploy to prod?")]
deploy:
  ./deploy.sh

[no-cd]
commit file:
  git add {{file}}         # runs in the dir `just` was invoked from

[working-directory: 'build']
compile:
  make                     # chdir to ./build first

[timestamp('%H:%M:%S%.3f')]
long-task:
  sleep 2

[continue("SIGHUP")]
test: && cleanup
  python3 main.py          # keep going if SIGHUP arrives

[no-exit-message]
risky:
  false                    # fails silently, no exit message
```

- `[parallel]` runs **dependencies** concurrently; limit with `--jobs N`.
- `[confirm]` blocks its dependents and later CLI recipes until confirmed;
  `--yes` confirms all.
- `[continue]` keeps going after the signal; default handles `SIGINT`.

## Parameters — `[arg(...)]`

Turn a parameter into a CLI option/flag:

```just
[arg("bar", long="bar")]   foo bar:        # just foo --bar hello
[arg("bar", short="b")]    foo bar:        # just foo -b hello
[arg("bar", long, short="b")]
[arg("bar", long="bar", value="hello")] foo bar:   # flag w/o value sets "hello"
```

Sub-options:
- `long` / `short` — define `--bar` / `-b` flags (`-abc` combines).
- `value=VALUE` — flag without an argument takes `VALUE`.
- `flag` — boolean flag: `"true"` when passed, `[]` otherwise (may not have a default).
- `multiple` — accept the option/flag more than once (assigns a list).
- `min=MIN` / `max=MAX` (1.56.0, needs `set lists`) — limit value count.
- `pattern=PATTERN` (anchored regex) — constrain the accepted value.
- `help=HELP` — help string for `--help`.

A value-less flag is **required** unless the parameter has a default.

## Environment — `[env(...)]`

```just
[env("RUST_BACKTRACE", "1")]
test:
  cargo test
```

`[env(NAME, [])]` unsets the variable. `$-prefixed` parameters are exported too:
`foo $bar:`. See `references/environment.md`.

## Platform conditionals

An item with a platform attribute is enabled only when that platform is active;
otherwise it's skipped (and hidden from `--list`). Applies to recipes, aliases,
modules, and `set` lines (1.56.0):

```just
[unix]
run:
  cc main.c && ./a.out
[windows]
run:
  cl main.c && main.exe
[windows]
set shell := ['cmd', '/c']
```

Available: `[android]`, `[dragonfly]`, `[freebsd]`, `[linux]`, `[macos]`,
`[netbsd]`, `[openbsd]`, `[unix]`, `[windows]`.

## Caching — `[cache(...)]` (unstable, 1.54.0)

Script recipes only. `just` hashes a **cache key** and skips the recipe if a
non-empty entry exists. Needs `set unstable` (and `set lists` for list values).

```just
set unstable
set lists

[script]
[cache(inputs = ["lib.c", "main.c"], outputs = "main", extra = `cc --version`)]
build:
  cc lib.c main.c -o main
```

Sub-options:
- `inputs = FILES` — each file hashed (BLAKE3) into the key; any change → re-run.
  Missing inputs / directory paths are errors.
- `outputs = FILES` — not part of the key; all must exist to *skip*, and must
  exist after a successful run (else error). Force re-run by deleting an output.
- `extra = EXPRESSION` — arbitrary expression (often a backtick) included in the
  key; a change causes a miss.
- `environment = EXPRESSION` — list of env-var names included in the key. By
  default, env vars exported/unexported **in the justfile** are in the key, but
  inherited external env vars are not.

Cache storage & control:
- Stored in `.justcache` beside the justfile (don't commit it).
- `--no-cache` bypasses the cache entirely.
- `just --clean` clears entries: `just --clean`, `just --clean foo`,
  `just --clean bar baz` (or `bar::baz` for submodules).
- File locks make concurrent cached runs by multiple `just` processes safe.

**Friendly admonition:** the key does **not** capture wall-clock time, input/output
files you didn't declare, system binaries, OS version, databases, network, or DNS.
Verify the key captures enough context before relying on caching — an incorrect key
silently serves stale results.

## Where to go next

- `[arg(...)]` details → `references/recipes.md`
- `[script]` / `[shell]` / `[no-quiet]` → `references/recipe-bodies.md`
- `[env(...)]` / `[no-cd]` / `[working-directory]` → `references/environment.md`
- `[parallel]` / `[private]` / `[group]` / `[doc]` → `references/organization.md`
- `[confirm]` / `[timestamp]` / `[continue]` → `references/cli.md`
- Platform attributes + `set` equivalents → `references/settings.md`
