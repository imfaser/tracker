# Installation & Setup

`just` is a single static binary (Rust). It needs a POSIX `sh` to run recipe
lines unless you configure a different shell (see `references/recipe-bodies.md`).

## What `just` is

- A **command runner**: stores project commands as *recipes* in a `justfile`.
- Modern replacement for `make` — no `.PHONY`, no tabs-only rule, no cryptic
  errors, first-class parameters, a real expression language, `.env` loading,
  shebang recipes in any language, and modules/imports.
- Cross-platform (Linux/macOS/Windows) with **no runtime dependencies** beyond a
  shell.

## Prerequisites

- Linux/macOS/BSD: any reasonable `sh`.
- Windows: requires `sh` on PATH (from Git for Windows, GitHub Desktop, or
  Cygwin), **or** override the shell:

```just
set shell := ["powershell.exe", "-c"]
hello:
  Write-Host "Hello, world!"
```

```just
set shell := ["cmd.exe", "/c"]
list:
  dir
```

Also settable per invocation: `just --shell powershell.exe --shell-arg -c`.
PowerShell is recommended on Windows 7 SP1+.

## Installation methods

**Package managers:**

| Manager | Command |
|---|---|
| Cargo | `cargo install just` |
| Cargo Binstall | `cargo binstall just` |
| Homebrew | `brew install just` |
| Nix | `nix-env -iA nixpkgs.just` |
| npm | `npm install -g rust-just` |
| pipx | `pipx install rust-just` |
| uv | `uv tool install rust-just` |
| Snap | `snap install --edge --classic just` |
| Conda | `conda install -c conda-forge just` |
| asdf | `asdf plugin add just && asdf install just <version>` |
| arkade | `arkade get just` |
| Spack | `spack install just` |

**OS-specific:** FreeBSD `pkg install just`; OpenBSD `pkg_add just`; Alpine
`apk add just`; Arch `pacman -S just`; Debian 13 / Ubuntu 24.04 `apt install
just`; Fedora `dnf install just`; Gentoo `emerge -av dev-build/just`; NixOS
`nix-env -iA nixos.just`; openSUSE `zypper in just`; Solus `eopkg install just`;
Void `xbps-install -S just`; Windows `choco install just` / `scoop install just`
/ `winget install --id Casey.Just --exact`; macOS `port install just`.

**Pre-built binaries** (releases page):

```console
curl --proto '=https' --tlsv1.2 -sSf https://just.systems/install.sh | bash -s -- --to ~/bin
```

Verify with `SHA256SUMS`: `shasum --algorithm 256 --ignore-missing --check SHA256SUMS`.

**CI / containers:**
- GitHub Actions: `extractions/setup-just@v3` (optionally `just-version:`), or
  `taiki-e/install-action@just`, or `brew install just` / `choco install just`.
- Docker: `COPY --from=ghcr.io/casey/just:latest /just /usr/local/bin/`

## Editor & IDE integration

- **Vim ≥9.1.1042 / Neovim ≥0.11**: built-in. Also `vim-just` and
  `tree-sitter-just`.
- **Emacs**: `just-mode` (highlighting) and `justl` (run/list); or per-file
  `make` mode:
  ```
  # Local Variables:
  # mode: makefile
  # End:
  ```
- **VS Code**: `nefrob/vscode-just`.
- **JetBrains**: plugin #18658 (linux_china).
- **Kakoune / Helix / Micro**: built-in. **Sublime Text**: `Just` package (nk9).
  **Zed**: `zed-just` extension.

## LSP & MCP

- **LSP** (`just-lsp`): go-to-definition, inline diagnostics, completion.
- **MCP** (`just-mcp`): lets an LLM query justfile contents and run recipes.

## Requiring a minimum version

`just` 1.0+ commits to strong backward compatibility (no 2.0; breaking changes
are per-justfile opt-in).

```just
set minimum-version := '1.55.0'
```

Must be at the very top of the file, before any guarded feature. Unstable
features error unless `--unstable`, `set unstable`, or `JUST_UNSTABLE` is set.
