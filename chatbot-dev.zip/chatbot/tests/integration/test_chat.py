from __future__ import annotations

import json
from pathlib import Path

import anyio
import httpx
from fastapi.testclient import TestClient
from server.app import create_app


def _write_jsonc(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "config.jsonc"
    p.write_text(text, encoding="utf-8")
    return p


def _parse_sse(body: bytes) -> list[dict]:
    out: list[dict] = []
    for line in body.decode().splitlines():
        if line.startswith("data: "):
            payload = line[len("data: ") :]
            if payload == "[DONE]":
                out.append({"type": "[DONE]"})
            else:
                out.append(json.loads(payload))
    return out


def test_health() -> None:
    app = create_app()
    client = TestClient(app)
    assert client.get("/health").json() == {"status": "ok"}


def test_chat_stream_test_model_sync(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"agents":{"supervisor":{"model":"test","system":"you are test","description":"test","steps":10}}, "providers":{}}',
            )
        ),
    )
    app = create_app()
    client = TestClient(app)
    payload = {
        "trigger": "submit-message",
        "id": "tid",
        "messages": [{"id": "m1", "role": "user", "parts": [{"type": "text", "text": "hello"}]}],
    }
    r = client.post("/chat", json=payload)
    assert r.status_code == 200
    assert "text/event-stream" in r.headers["content-type"]
    assert r.headers["x-vercel-ai-ui-message-stream"] == "v1"
    assert "data:" in r.text


async def test_chat_stream_invalid_json_returns_422(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"agents":{"supervisor":{"model":"test","system":"you are test","description":"test","steps":10}}, "providers":{}}',
            )
        ),
    )
    app = create_app()
    await anyio.sleep(0)  # noqa: ASYNC115
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/chat", content=b"not json", headers={"Content-Type": "application/json"}
        )
        assert resp.status_code in (400, 422)


async def test_chat_stream_fake_stream_headers_and_events(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"agents":{"supervisor":{"model":"test","system":"you are test","description":"test","steps":10}}, "providers":{}}',
            )
        ),
    )
    app = create_app()
    payload = {
        "trigger": "submit-message",
        "id": "tid",
        "messages": [{"id": "m1", "role": "user", "parts": [{"type": "text", "text": "hi"}]}],
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat", json=payload)
        assert resp.status_code == 200
        assert resp.headers["x-vercel-ai-ui-message-stream"] == "v1"
        assert resp.headers["content-type"].startswith("text/event-stream")
        events = _parse_sse(resp.content)
        types = [e["type"] for e in events]
        assert "start" in types
        assert "finish" in types
        assert types[-1] == "[DONE]" or "finish" in types


async def test_server_importable() -> None:
    await anyio.sleep(0)  # noqa: ASYNC115
    import server

    assert server is not None
