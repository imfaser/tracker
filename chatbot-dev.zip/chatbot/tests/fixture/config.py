from collections.abc import Generator

import pytest
from core.config import AppConfig


@pytest.fixture(autouse=True)
def reset_config_singleton() -> Generator[None]:
    yield


@pytest.fixture
async def dishka_container():  # type: ignore[no-untyped-def]
    """提供 Dishka 容器的测试夹具，支持 container.override。"""
    from server.container import make_container

    c = make_container()
    yield c
    import contextlib

    with contextlib.suppress(Exception):
        await c.close()


@pytest.fixture
def config() -> AppConfig:
    return AppConfig()


@pytest.fixture
def make_config():
    """构造自定义配置的工厂（走构造入参，最高优先级）。"""

    def _make(**overrides) -> AppConfig:
        return AppConfig(**overrides)

    return _make
