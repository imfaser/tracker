from pathlib import Path

from pydantic_ai import Agent
from server.container import make_container
from server.deps import SupervisorDeps


def _write_jsonc(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "config.jsonc"
    p.write_text(text, encoding="utf-8")
    return p


async def test_agent_singleton(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"agents":{"supervisor":{"model":"test","system":"you are test","description":"test","steps":10}}, "providers":{}}',
            )
        ),
    )
    c = make_container()
    a1 = await c.get(Agent[SupervisorDeps, str])
    a2 = await c.get(Agent[SupervisorDeps, str])
    assert a1 is a2
    await c.close()
