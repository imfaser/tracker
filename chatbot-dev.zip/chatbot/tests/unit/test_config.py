from pathlib import Path

import pytest
from core.config import AppConfig


def _write_jsonc(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "config.jsonc"
    p.write_text(text, encoding="utf-8")
    return p


def test_instance_with_empty_config_uses_defaults(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.providers == {}
    assert cfg.agents == {}
    assert cfg.model == ""


def test_constructor_injection_isolated(monkeypatch) -> None:
    cfg = AppConfig(model="test")
    assert cfg.model == "test"
    assert AppConfig().model == ""


def test_instance_with_invalid_jsonc_raises(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{ not json")))
    with pytest.raises(ValueError):
        AppConfig()


def test_instance_parses_jsonc_comments_and_trailing_commas(tmp_path, monkeypatch) -> None:
    text = """
    {
      // 注释应被 json5 忽略
      "model": "test", // 尾逗号
    }
    """
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, text)))
    assert AppConfig().model == "test"


def test_env_placeholder_resolved_for_providers(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-env")
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path, '{"providers":{"deepseek":{"api_key":"{env:DEEPSEEK_API_KEY}"}}}'
            )
        ),
    )
    assert AppConfig().providers["deepseek"].api_key == "sk-env"


def test_env_placeholder_empty_when_missing(tmp_path, monkeypatch) -> None:
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path, '{"providers":{"deepseek":{"api_key":"{env:DEEPSEEK_API_KEY}"}}}'
            )
        ),
    )
    assert AppConfig().providers["deepseek"].api_key == ""


def test_agent_system_file_template_loaded(tmp_path, monkeypatch) -> None:
    prompt = tmp_path / "prompt.md"
    prompt.write_text("hello from file", encoding="utf-8")
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"agents":{"supervisor":{"model":"test","system":"{{file:'
                + str(prompt)
                + '}}","steps":10}}}',
            )
        ),
    )
    assert AppConfig().agents["supervisor"].system == "hello from file"


def test_agent_alias_agents_and_agent(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(_write_jsonc(tmp_path, '{"agent":{"supervisor":{"model":"test"}}}')),
    )
    assert "supervisor" in AppConfig().agents
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(_write_jsonc(tmp_path, '{"agents":{"supervisor":{"model":"test"}}}')),
    )
    assert "supervisor" in AppConfig().agents


def test_provider_canonical_fields(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path, '{"providers":{"deepseek-chat":{"base_url":"https://x","api_key":"k"}}}'
            )
        ),
    )
    p = AppConfig().providers["deepseek-chat"]
    assert p.base_url == "https://x"
    assert p.api_key == "k"


def test_case_sensitive_env_does_not_pollute_agents(monkeypatch) -> None:
    monkeypatch.setenv("AGENT", "1")
    monkeypatch.setenv("AGENTS", "1")
    cfg = AppConfig(agents={"supervisor": {"model": "test"}})
    assert "supervisor" in cfg.agents
