"""便捷测试脚本，使用 httpx2 异步流式请求 /chat.

官方文档：
- httpx2: https://httpx2.pydantic.dev/  (GitHub: https://github.com/pydantic/httpx2)
- httpx:  https://www.python-httpx.org/

用法：
    uv run python run.py                    # 默认 http://localhost:8000
    uv run python run.py --url http://localhost:8000

需先启动服务：
    uv run server          # 或 just dev
"""

from __future__ import annotations

import argparse

import anyio
import httpx2

BASE_URL = "http://localhost:8000"
PAYLOAD = {
    "trigger": "submit-message",
    "id": "test-id",
    "messages": [{"id": "m1", "role": "user", "parts": [{"type": "text", "text": "hello"}]}],
}


async def main() -> None:
    parser = argparse.ArgumentParser(description="httpx2 异步测试脚本")
    parser.add_argument("--url", default=BASE_URL, help="服务地址")
    args = parser.parse_args()

    target = f"{args.url.rstrip('/')}/chat"
    print(f"[async] POST {target}")

    async with (
        httpx2.AsyncClient(timeout=30) as client,
        client.stream("POST", target, json=PAYLOAD) as resp,
    ):
        print(f"status: {resp.status_code}")
        async for line in resp.aiter_lines():
            print(line)


if __name__ == "__main__":
    anyio.run(main)
