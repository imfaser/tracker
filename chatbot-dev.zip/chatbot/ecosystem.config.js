module.exports = {
  apps: [
    {
      name: "chatbot",
      interpreter: "none",
      script: "uv",
      args: "run server",
      cwd: __dirname,
      autorestart: false,
      watch: false,
      env: {
        PYTHONUNBUFFERED: "1",
      },
    },
  ],
};
