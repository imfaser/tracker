from __future__ import annotations

from core.config import AppConfig
from core.deps import SupervisorDeps
from dishka import Provider, Scope, provide
from pydantic_ai import Agent


class AppProvider(Provider):
    @provide(scope=Scope.APP)
    def config(self) -> AppConfig:
        return AppConfig()


class AgentProvider(Provider):
    @provide(scope=Scope.APP)
    def get_supervisor(self, cfg: AppConfig) -> Agent[SupervisorDeps, str]:
        from harness.agent import create_supervisor_agent

        return create_supervisor_agent(cfg)


def make_container():  # type: ignore[no-untyped-def]
    from dishka import make_async_container

    return make_async_container(
        AppProvider(),
        AgentProvider(),
    )
