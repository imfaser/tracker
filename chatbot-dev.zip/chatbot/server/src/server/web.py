from __future__ import annotations

import anyio
from pydantic_ai import Agent

from server.container import make_container
from server.deps import SupervisorDeps


async def _load_agent() -> Agent[SupervisorDeps, str]:
    container = make_container()
    agent = await container.get(Agent[SupervisorDeps, str])
    return agent


agent = anyio.run(_load_agent)
app = agent.to_web(allowed_hosts=["*"])
