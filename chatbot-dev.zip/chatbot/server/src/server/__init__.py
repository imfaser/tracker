from __future__ import annotations

__all__ = ["main"]


def main() -> None:
    import os

    import uvicorn

    from server.app import create_app

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    app = create_app()
    uvicorn.run(app, host=host, port=port)
