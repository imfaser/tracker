from __future__ import annotations

from core.deps import SupervisorDeps

__all__ = ["SupervisorDeps"]
