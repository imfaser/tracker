from __future__ import annotations

from dishka.integrations.fastapi import DishkaRoute, FromDishka
from fastapi import APIRouter, Request
from fastapi.responses import Response
from pydantic_ai import Agent

from server.deps import SupervisorDeps

router = APIRouter(prefix="/chat", route_class=DishkaRoute, tags=["chat"])


@router.post("", response_model=None)
async def chat(
    request: Request,
    agent: FromDishka[Agent[SupervisorDeps, str]],
) -> Response:
    from pydantic_ai.ui.vercel_ai import VercelAIAdapter

    return await VercelAIAdapter.dispatch_request(request, agent=agent, sdk_version=7)


@router.post("/stream", response_model=None)
async def chat_stream(
    request: Request,
    agent: FromDishka[Agent[SupervisorDeps, str]],
) -> Response:
    from pydantic_ai.ui.vercel_ai import VercelAIAdapter

    return await VercelAIAdapter.dispatch_request(request, agent=agent, sdk_version=7)
