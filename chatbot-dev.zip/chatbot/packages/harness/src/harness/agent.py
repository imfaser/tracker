from __future__ import annotations

from core.config import AppConfig
from core.deps import SupervisorDeps
from core.models import create_model
from pydantic_ai import Agent

from harness.capabilities.math import MathCapability


def create_supervisor_agent(cfg: AppConfig) -> Agent[SupervisorDeps, str]:
    acfg = cfg.agents["supervisor"]
    cap = MathCapability()
    if acfg.model == "test":
        return Agent(
            "test", deps_type=SupervisorDeps, system_prompt=acfg.system, capabilities=[cap]
        )
    prov = cfg.providers[acfg.model]
    return Agent(
        create_model(acfg.model, prov),
        deps_type=SupervisorDeps,
        system_prompt=acfg.system,
        capabilities=[cap],
    )
