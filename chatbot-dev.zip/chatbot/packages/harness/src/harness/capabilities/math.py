from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.toolsets import AgentToolset, FunctionToolset

math_toolset = FunctionToolset()


@math_toolset.tool_plain
def circle_area(radius: float) -> float:
    """计算圆面积，公式 π·r²。

    Args:
        radius: 圆的半径。
    """

    return math.pi * radius * radius


@math_toolset.tool_plain
def square_area(side: float) -> float:
    """计算正方形面积，公式 side²。

    Args:
        side: 正方形边长。
    """

    return side * side


@dataclass
class MathCapability(AbstractCapability[Any]):
    def get_toolset(self) -> AgentToolset[Any] | None:
        return math_toolset

    def get_instructions(self) -> str | None:
        return (
            "你是数学助手，手上有 circle_area、square_area 工具。"
            "当用户给出明确的半径/边长并请求面积时，必须调用对应工具，禁止心算。"
            "拿到工具结果后再用自然语言讲清公式、代入和结论。"
        )
