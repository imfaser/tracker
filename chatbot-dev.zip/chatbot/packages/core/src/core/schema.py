from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class LlmProviderConfig(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    type: Literal["openai-chat", "openai-responses", "anthropic", "test"] | None = Field(
        default=None
    )
    base_url: str | None = Field(default=None)
    api_key: str | None = Field(default=None)

    @field_validator("api_key", mode="after")
    @classmethod
    def _resolve_env_placeholder(cls, v: str | None) -> str | None:
        if isinstance(v, str) and v.startswith("{env:") and v.endswith("}"):
            import os

            env_key = v[5:-1].strip()
            return os.getenv(env_key, "")
        return v


class AgentConfig(BaseModel):
    description: str | None = Field(default=None)
    model: str = Field(default="")
    system: str = Field(default="")
    steps: int = Field(default=10, ge=1, le=50)

    @field_validator("system", mode="after")
    @classmethod
    def _validate_system(cls, v: str) -> str:
        if v.startswith("{{file:") and v.endswith("}}"):
            path = v[7:-2].strip()
            p = Path(path)
            if p.exists():
                return p.read_text(encoding="utf-8")
        return v
