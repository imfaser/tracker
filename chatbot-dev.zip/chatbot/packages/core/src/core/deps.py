from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SupervisorDeps:
    request_id: str | None = None
