from __future__ import annotations

import os
from importlib.resources.abc import Traversable
from pathlib import Path
from typing import Any

import json5
from pydantic import AliasChoices, Field
from pydantic_settings import (
    BaseSettings,
    JsonConfigSettingsSource,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

from core.schema import AgentConfig, LlmProviderConfig


def _resolve_config_path() -> Path:
    return Path(os.environ.get("CONFIG_FILE") or "config.jsonc")


class JsoncConfigSettingsSource(JsonConfigSettingsSource):
    def _read_file(self, file_path: Path | Traversable) -> dict[str, Any]:
        p = Path(str(file_path))
        if not p.exists() or not p.read_text(encoding="utf-8").strip():
            return {}
        return json5.loads(p.read_text(encoding="utf-8"))


class AppConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_nested_delimiter="__",
        env_ignore_empty=True,
        populate_by_name=True,
        case_sensitive=True,
    )

    providers: dict[str, LlmProviderConfig] = Field(default_factory=dict)
    agents: dict[str, AgentConfig] = Field(
        default_factory=dict, validation_alias=AliasChoices("agents", "agent")
    )
    model: str = Field(default="")

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        cfg_path = _resolve_config_path()
        sources: list[PydanticBaseSettingsSource] = [env_settings, dotenv_settings]
        if cfg_path.exists():
            sources.append(JsoncConfigSettingsSource(settings_cls, json_file=str(cfg_path)))
        return (init_settings, *sources)
