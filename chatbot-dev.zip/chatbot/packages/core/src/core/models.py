from __future__ import annotations

from core.schema import LlmProviderConfig


def create_model(model_name: str, cfg: LlmProviderConfig):
    match cfg.type:
        case "test":
            return "test"
        case "anthropic":
            from pydantic_ai.models.anthropic import AnthropicModel
            from pydantic_ai.providers.anthropic import AnthropicProvider

            return AnthropicModel(model_name, provider=AnthropicProvider(api_key=cfg.api_key))  # ty: ignore[invalid-argument-type]
        case "openai-responses":
            from pydantic_ai.models.openai import OpenAIResponsesModel
            from pydantic_ai.providers.openai import OpenAIProvider

            return OpenAIResponsesModel(
                model_name, provider=OpenAIProvider(api_key=cfg.api_key, base_url=cfg.base_url)
            )
        case "openai-chat" | None:
            from pydantic_ai.models.openai import OpenAIChatModel
            from pydantic_ai.providers.openai import OpenAIProvider

            return OpenAIChatModel(
                model_name, provider=OpenAIProvider(api_key=cfg.api_key, base_url=cfg.base_url)
            )
