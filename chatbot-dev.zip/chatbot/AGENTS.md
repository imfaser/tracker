# AGENTS.md — chatbot

参考 `deepview/AGENTS.md` 精简，保留高信号、经 `pyproject.toml/justfile` 等可执行源验证的约定。

## 语言要求（强制）

与用户交流**绝对使用中文**，回复/提问/提交信息均用中文。

## 代码注释与导入（强制，沿用 deepview）

- **顶部只写一行用途**，机制写行内 `#`；只注释意图与非显而易见的为什么。
- **绝对禁止相对导入**：`from .`/`from ..` 全禁，统一 `from core...` / `from server...`；`just lint` 已开 `TID252`（`ban-relative-imports = "all"`）直接报错。

## 本仓库是什么

Python 3.14 **uv workspace**，`members = ["packages/*", "server"]`，镜像 `mirrors.aliyun.com`，`uv_build` + `module-name` 的 `src` 布局。

- `core` (`packages/core`) — 共享库 `import core`：`config.py`（`AppConfig` 单例 + `JsoncConfigSettingsSource`）/`schema.py`（`LlmProviderConfig`/`AgentConfig`）。
- `server` (`server/`) — FastAPI 应用 `server:main` → `uvicorn server.app:create_app --factory`，`app.py:create_app` + `container.py:make_container` + `routers/chat.py: POST /chat`（`VercelAIAdapter.dispatch_request sdk_version=7`）。
- 根依赖 `core` + `server`，`lint`/`typecheck`/`test`/`dev` 四组。

已非骨架：`server` 已打通 `pydantic-ai` + `dishka` + `httpx2` 全链路，`core` 已落地配置。

## 质量门禁（必须按序）

```
just lint         # ruff check .
just format       # ruff format . (或 just format-check)
just typecheck    # ty check
just test         # uv run pytest
```

- `ruff`: `py314` 行宽100 双引号 `I,UP,B,SIM,ASYNC,RUF,C4,W,TID` 忽略 `E501`；`uv_build` 等生成物已 `extend-exclude`。
- `ty`: `python-version = 3.14`，`tests/**` 仅 `warn`。
- 单测/单包验证用 `uv run ...`（`just` 不透传参数）：`uv run pytest tests/unit/test_config.py`；`uv run ruff check server/src/server/app.py`。

## 设计原则（个人工程，强制）

- **找不到直接报错，不做兼容**：`container` 直接 `cfg.agents["supervisor"]` / `cfg.providers[model]` 命中，`KeyError` 直接冒泡；错误由下游 `pydantic-ai` 报告。
- **多驱动由用户显式指定**：`type` 决定驱动，`providers` 的 key 即模型名，`agent.model` 直填 key；详见 `core/schema.py:LlmProviderConfig` 与 `config.example.jsonc`，不在此展开，新增模型只加 key。
- **配置即契约**：改驱动改 `config.jsonc`，`get_supervisor` 仅 `get` 后 `create_model` 直给 `Agent`。

## 配置与环境（最易踩坑）

- `AppConfig` 来源优先级 `init > env > dotenv > jsonc`，文件由 `CONFIG_FILE`（默认 `config.jsonc`）指定，`JsoncConfigSettingsSource` 用 `json5` 解析；`just` 的 `set dotenv-load` 额外加载 `.env`，但 `pydantic-settings` 本身也会读 `.env`，故 `uv run server` 同样生效。
- `case_sensitive=True`：宿主 `AGENT=1`（OpenChamber）会污染 `agents`，已设大小写敏感规避；新增 `agents` 相关配置后需同步改 `tests/fixture/config.py` 的 `autouse` 重置。
- `providers`/`agents` 具体字段与示例见 `config.example.jsonc` 与 `core/schema.py`，不在此赘述，`config.jsonc` 被 `.gitignore`。

## 运行与进程

- `just sync` → `uv sync`；`just dev` → `uv run server`。
- `pm2` 单进程 `chatbot`：`just up/down/logs/del [chatbot]` 对应 `ecosystem.config.js: { script:"uv", args:"run server" }`。
- 便测脚本 `run.py`：仅 `import httpx2`（`https://httpx2.pydantic.dev/`，不做 `try/except` 回退），`anyio.run(main)` 异步流式 `POST /chat`，`uv run python run.py --url http://127.0.0.1:8000`（先 `just dev` 或 `pm2` 起服）。

## Dishka + Pydantic AI

- `make_async_container(AppProvider(), AgentProvider())`，`Scope.APP` 单例 `Agent`，`app.py` 中 `setup_dishka(container, app)`，路由用 `DishkaRoute` + `FromDishka[Agent]`（`Any` 绕过 `ty` 仅作过渡，真实类型为 `Agent`）。
- 模型由 `core.models.create_model` 根据 `type` 自动选择三主流（详见 `https://ai.pydantic.dev/llms.txt`），仅 `model=="test"` 时直给 `Agent("test")` 保证 CI 可跑；`VercelAIAdapter` 固定 `sdk_version=7`。

## 测试

- `anyio` 驱动（`anyio_mode = auto`, `-p no:asyncio`），`async def test_*` 直接 `await`，不用 `@pytest.mark.asyncio`；`filterwarnings = ["error"]` 警告即失败；`timeout = 20`，`xfail_strict = true`。
- `tests/conftest.py` 载 `tests/fixture` 插件，`tests/fixture/config.py` 的 `reset_config_singleton` 为 `autouse`；`tests/unit` 与 `tests/integration` 分离，`test_chat` 用 `TestClient` 打 `POST /chat` 验证 `text/event-stream`。

## OpenCode 技能

`.opencode/skills/` 已同步 `deepview`（含 `just`/`uv-package-manager`/`pydantic`/`async-python-patterns` 等 40+），`opencode.json` 侧 `instructions` 为准；按场景加载对应技能，勿猜测。

## Git 提交

沿用 `deepview`：中文 `type(scope): 描述`，`feat/fix/docs/refactor/style/test/perf/build/ci/chore/revert`，一事一提交，不加分支前缀，当前开发分支 `dev`。

## 不要想当然

- 无 `README`/CI，`AGENTS.md` 即唯一入口；`.opencode` 与 `docs` 不参与 `ruff/ty`。
- `uv.lock` 已提交，改依赖后 `just sync` 再提测。
