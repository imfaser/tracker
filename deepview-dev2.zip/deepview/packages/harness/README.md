# agent — DeepView Agent Toolkit

工具治理与继承式代理公共库。

## 边界图

```
Store (store.py)          Discovery (discovery.py)
┌─────────────────┐       ┌──────────────────────┐
│ _entries        │◀─────▶│ _mcp_servers         │
│ _mcp_tools      │ sync │ _tools_by_server     │
└─────────────────┘       │ _last_discover/_ttl  │
         ▲                └──────────────────────┘
         │                           │
         └───────────────────────────┘
                    lifespan 或 BaseAgent 内自挑
```

- Store 极简容器：`register/list/clear/sync_mcp`，不触网，分配由 `BaseAgent.get_graph` 自挑。
- Discovery 全量拉取并 TTL 缓存，结果经 `sync_mcp` 同步。
## 显式生命周期

`server/app.py:lifespan` 或 `BaseAgent._get_checkpointer` 托管 `checkpointer/thread_id`，测试通过 `BaseContext` 隔离。

## 迁移完成

已移除角色视图与绑定层，代理改为 `BaseAgent` 继承，`ask_user` 仅主代理可用。
