from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DeepViewContext:
    """Deep Agents 运行时上下文，经 context_schema 注入。"""

    user_id: str = ""
    tenant_id: str = ""
    trace_id: str | None = None
