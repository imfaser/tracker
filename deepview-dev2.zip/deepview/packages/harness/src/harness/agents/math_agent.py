from __future__ import annotations

from typing import Any

from langchain_core.tools import BaseTool

from harness.agents.base import BaseAgent
from harness.agents.context import BaseContext
from harness.middleware.mcp_bridge import mcp_context_bridge

_MATH_SYSTEM_PROMPT = (
    "你是 DeepView 的数学小助手，语气亲切、耐心、像朋友一样陪伴用户。"
    "你擅长几何与基础计算，手上有 circle_area、square_area 等工具。"
    "【强制规则】当用户给出明确的半径/边长数值并请求计算面积时，你必须调用对应的工具（circle_area 需要 radius，square_area 需要 side），禁止自行心算、估算或用代码块代替工具调用。"
    "拿到工具返回的精确结果后，再用自然、带温度的语言把公式、代入过程和结论讲清楚。"
)


def _resolve_math_tools() -> list[BaseTool]:
    from langchain_core.tools import tool as _tool

    from harness.tools.math import circle_area as _circle_fn
    from harness.tools.math import square_area as _square_fn

    raw_tools: list[BaseTool] = []
    for fn in (_circle_fn, _square_fn):
        wrapped = _tool(fn)
        raw_tools.append(wrapped)
    return raw_tools


_SUBAGENT_DISABLED_TOOLS = frozenset(
    {"ask_user", "ask_user_question", "present_artifacts", "install_skill"}
)


class MathAgent(BaseAgent):
    name = "math"
    description = "数学子代理，处理几何与基础计算"
    context_schema = BaseContext

    def __init__(
        self,
        *,
        checkpointer: Any | None = None,
        config: Any | None = None,
        model: Any | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(checkpointer=checkpointer, config=config, model=model, **kwargs)
        # system 可被 HarnessConfig.system 覆盖
        if config is not None and getattr(config, "system", None):
            try:
                p = str(config.system)
                # 若为路径则读取正文，否则直接作为 prompt
                from pathlib import Path

                fp = Path(p)
                if fp.exists():
                    self._system_prompt = fp.read_text(encoding="utf-8")
                else:
                    self._system_prompt = p
            except Exception:  # noqa: BLE001
                self._system_prompt = _MATH_SYSTEM_PROMPT
        else:
            self._system_prompt = _MATH_SYSTEM_PROMPT

    async def get_graph(self, **kwargs: Any):  # type: ignore[override]
        context = kwargs.get("context")
        if context is None:
            context = BaseContext()
        tools = _resolve_math_tools()
        filtered = [t for t in tools if getattr(t, "name", "") not in _SUBAGENT_DISABLED_TOOLS]
        from deepagents import create_deep_agent

        checkpointer = await self._get_checkpointer()
        model = kwargs.get("model") or self._model
        kwargs.pop("context", None)
        kwargs.pop("model", None)
        kwargs.pop("checkpointer", None)
        kwargs.pop("config", None)
        return create_deep_agent(
            model=model,
            tools=filtered,
            system_prompt=self._system_prompt,
            context_schema=BaseContext,
            checkpointer=checkpointer,
            middleware=[mcp_context_bridge],  # ty: ignore[invalid-argument-type]
            **kwargs,
        )

    def to_recipe(self, context: Any | None = None) -> dict[str, Any]:
        tools = _resolve_math_tools()
        filtered = [t for t in tools if getattr(t, "name", "") not in _SUBAGENT_DISABLED_TOOLS]
        return {
            "name": self.name,
            "description": self.description,
            "system_prompt": self._system_prompt,
            "tools": filtered,
        }
