from __future__ import annotations

from typing import Any

from langchain_core.tools import tool as _tool
from langgraph.types import interrupt

from harness.agents.base import BaseAgent
from harness.agents.context import BaseContext
from harness.agents.math_agent import MathAgent
from harness.middleware.mcp_bridge import mcp_context_bridge

_SUPERVISOR_PROMPT = (
    "你是 DeepView 的调度员，负责将任务委派给子代理。"
    "所有数学计算必须委派给 math 子代理，并明确指示其调用 circle_area 或 square_area 工具，禁止手动计算或估算。"
    "当 math 子代理返回工具结果后，你再用自然语言总结公式、代入过程和结论。"
    "若缺少关键参数（如半径/边长），调用 ask_user 提问获取，禁止猜测。"
)


@_tool
def ask_user(question: str) -> str:
    """向用户发起自由文本提问并等待回答。"""
    if not isinstance(question, str) or not question.strip():
        raise ValueError("question 不能为空")
    payload = {"question": question.strip(), "source": "ask_user"}
    answer = interrupt(payload)
    if isinstance(answer, dict):
        return str(answer.get("answer") or answer.get("question") or "")
    return str(answer)


class SupervisorAgent(BaseAgent):
    name = "supervisor"
    description = "调度员，主代理"
    context_schema = BaseContext

    def __init__(
        self,
        *,
        checkpointer: Any | None = None,
        config: Any | None = None,
        model: Any | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(checkpointer=checkpointer, config=config, model=model, **kwargs)
        if config is not None and getattr(config, "system", None):
            try:
                p = str(config.system)
                from pathlib import Path

                fp = Path(p)
                if fp.exists():
                    self._system_prompt = fp.read_text(encoding="utf-8")
                else:
                    self._system_prompt = p
            except Exception:  # noqa: BLE001
                self._system_prompt = _SUPERVISOR_PROMPT
        else:
            self._system_prompt = _SUPERVISOR_PROMPT

    async def get_graph(self, **kwargs: Any):  # type: ignore[override]
        context = kwargs.get("context")
        if context is None:
            context = BaseContext()
        if isinstance(context, dict):
            tmp = BaseContext()
            tmp.update_from_dict(context)
            context = tmp
        from deepagents import create_deep_agent

        # 已有共享持久化 checkpointer 则直接复用；否则按传入覆盖或回退到内存
        requested_cp = kwargs.get("checkpointer")
        if requested_cp is not None:
            checkpointer = requested_cp
            if self._checkpointer is None:
                self._checkpointer = checkpointer
        else:
            checkpointer = await self._get_checkpointer()
        math_agent = MathAgent(
            checkpointer=checkpointer, config=self._harness_config, model=self._model
        )
        math_recipe = math_agent.to_recipe(context)
        model = kwargs.get("model") or self._model
        interrupt_on = kwargs.get("interrupt_on")
        if interrupt_on and checkpointer is None:
            msg = "interrupt_on requires checkpointer"
            raise ValueError(msg)
        kwargs.pop("context", None)
        kwargs.pop("model", None)
        kwargs.pop("checkpointer", None)
        kwargs.pop("config", None)
        graph = create_deep_agent(
            model=model,
            tools=[ask_user],
            subagents=[math_recipe],  # ty: ignore[invalid-argument-type]
            system_prompt=self._system_prompt,
            context_schema=BaseContext,
            checkpointer=checkpointer,
            middleware=[mcp_context_bridge],  # ty: ignore[invalid-argument-type]
            **kwargs,
        )
        return graph
