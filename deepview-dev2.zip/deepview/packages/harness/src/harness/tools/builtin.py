from __future__ import annotations

from harness.registry import ToolStore


def register_builtin_tools(store: ToolStore) -> None:
    from langchain_core.tools import tool as _tool

    from harness.tools.math import circle_area as _circle_fn
    from harness.tools.math import square_area as _square_fn

    for fn in (_circle_fn, _square_fn):
        wrapped = _tool(fn)
        store.register(wrapped, roles=["math"])
