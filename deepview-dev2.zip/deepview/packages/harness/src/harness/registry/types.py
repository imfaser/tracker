from __future__ import annotations

from collections.abc import Callable
from typing import NotRequired, TypedDict

from langchain_core.tools import BaseTool

ToolFilter = Callable[[BaseTool], bool]


class McpBinding(TypedDict):
    server: str
    filter: NotRequired[ToolFilter]
