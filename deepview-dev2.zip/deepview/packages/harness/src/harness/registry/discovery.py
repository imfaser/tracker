from __future__ import annotations

import logging
import time
from typing import Any

from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)


class McpDiscovery:
    """MCP 发现与 TTL 缓存，不持有角色绑定。"""

    def __init__(self, servers: list[Any] | None = None, *, ttl: int = 300) -> None:
        self._mcp_servers: list[Any] = list(servers or [])
        self._mcp_tools_by_server: dict[str, list[BaseTool]] = {}
        self._last_discover: float | None = None
        self._ttl: int = ttl
        self._discover_count: int = 0

    def configure_mcp_servers(self, servers: list[Any]) -> None:
        self._mcp_servers = list(servers)
        self._mcp_tools_by_server.clear()
        self._last_discover = None

    def snapshot(self) -> dict[str, list[BaseTool]]:
        return dict(self._mcp_tools_by_server)

    async def discover(
        self, *, ttl: int | None = None, refresh: bool = False
    ) -> dict[str, list[BaseTool]]:
        if ttl is not None:
            self._ttl = ttl
        now = time.time()
        if (
            not refresh
            and self._last_discover is not None
            and (now - self._last_discover) < self._ttl
        ):
            return dict(self._mcp_tools_by_server)
        if not self._mcp_servers:
            self._last_discover = now
            return {}
        from langchain_mcp_adapters.client import MultiServerMCPClient

        from harness.sources.mcp import mcp_server_to_connection

        connections: dict[str, dict] = {}
        for cfg in self._mcp_servers:
            name = getattr(cfg, "name", str(cfg))
            if not getattr(cfg, "enabled", True):
                continue
            connections[name] = mcp_server_to_connection(cfg)
        if not connections:
            self._last_discover = now
            return {}
        client = MultiServerMCPClient(connections)  # type: ignore
        result: dict[str, list[BaseTool]] = {}
        for name in list(connections.keys()):
            try:
                tools = await client.get_tools(server_name=name)
                for t in tools:
                    try:
                        md = getattr(t, "metadata", None) or {}
                        md["_source"] = "mcp"
                        object.__setattr__(t, "metadata", md)
                    except Exception:  # noqa: BLE001, S110
                        pass
                result[name] = list(tools)
                self._mcp_tools_by_server[name] = list(tools)
                self._discover_count += 1
            except Exception as exc:  # noqa: BLE001
                logger.warning("MCP discover failed for %s: %s", name, exc)
                result[name] = []
                self._mcp_tools_by_server[name] = []
        self._last_discover = now
        return result
