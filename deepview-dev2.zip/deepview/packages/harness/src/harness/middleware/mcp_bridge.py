"""MCP 上下文桥接中间件。"""

from __future__ import annotations

from langchain.agents.middleware import wrap_tool_call


async def _mcp_bridge(request, handler):  # type: ignore[no-untyped-def]
    tool = getattr(request, "tool", None)
    meta = {}
    if tool is not None:
        meta = getattr(tool, "metadata", {}) or {}
    # 仅对 MCP 源透传，避免污染本地工具参数
    if meta.get("_source") == "mcp":
        runtime = getattr(request, "runtime", None)
        ctx = getattr(runtime, "context", None) if runtime is not None else None
        if ctx is not None:
            # 将租户与追踪信息注入工具输入，供下游 MCP 服务关联
            mcp_meta = {
                "tenant_id": getattr(ctx, "tenant_id", None),
                "trace_id": getattr(ctx, "trace_id", None),
            }
            tool_input = dict(getattr(request, "tool_call", {}).get("args", {}) or {})
            tool_input["_mcp_meta"] = mcp_meta
            if hasattr(request, "override"):
                new_call = dict(request.tool_call)
                new_call["args"] = tool_input
                request = request.override(tool_call=new_call)
            else:
                try:  # noqa: SIM105
                    request.tool_call["args"] = tool_input  # type: ignore[index]
                except Exception:  # noqa: BLE001, S110
                    pass
    return await handler(request)


mcp_context_bridge = wrap_tool_call(_mcp_bridge)
