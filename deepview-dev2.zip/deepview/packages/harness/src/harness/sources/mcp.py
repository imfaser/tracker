from __future__ import annotations


def mcp_server_to_connection(cfg) -> dict:  # type: ignore[no-untyped-def]
    """将 MCPServerConfig 转为 MultiServerMCPClient 的 Connection。"""
    transport = cfg.transport
    if transport == "stdio":
        # command 可能为 "npx ..." 或 "python /path/server.py"
        cmd = (cfg.command or "").strip()
        if not cmd:
            return {"transport": "stdio", "command": "echo", "args": []}
        parts = cmd.split()
        return {"transport": "stdio", "command": parts[0], "args": parts[1:]}
    if transport in ("http", "sse"):
        return {"transport": transport, "url": cfg.url or ""}
    return {"transport": transport, "url": cfg.url or ""}
