from __future__ import annotations

from collections.abc import Sequence

from langchain_core.messages import BaseMessage
from langgraph.graph import add_messages


def add_messages_delta(
    state: Sequence[BaseMessage],
    writes: Sequence[BaseMessage | Sequence[BaseMessage]],
) -> list[BaseMessage]:
    result: list[BaseMessage] = list(state)  # ty: ignore[invalid-assignment]
    for write in writes:
        if isinstance(write, BaseMessage):
            result = add_messages(result, [write])  # ty: ignore[invalid-argument-type,invalid-assignment]
        elif isinstance(write, (list, tuple)):
            result = add_messages(result, list(write))  # ty: ignore[invalid-argument-type,invalid-assignment]
        elif write is not None:
            result = add_messages(result, [write])  # ty: ignore[invalid-argument-type,invalid-assignment]
    return result
