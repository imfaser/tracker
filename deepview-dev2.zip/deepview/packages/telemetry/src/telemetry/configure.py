from __future__ import annotations

import logging
from typing import ClassVar

from core.schema import TelemetryConfig
from opentelemetry.sdk.trace import TracerProvider

logger = logging.getLogger(__name__)


class Telemetry:
    """链路追踪单例（进程内只配置一次）。"""

    _instance: ClassVar[Telemetry | None] = None

    def __init__(self) -> None:
        self._configured = False
        self._provider: TracerProvider | None = None

    @classmethod
    def instance(cls) -> Telemetry:
        """返回遥测单例；首次访问时创建。"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """清空单例缓存，供测试隔离使用（对称 AppConfig.reset）。"""
        cls._instance = None

    def bootstrap(self, cfg: TelemetryConfig) -> None:
        """按配置启动链路追踪，type 单选。"""
        if self._configured:
            return
        t = getattr(cfg, "type", "none")
        if t == "phoenix":
            from telemetry.backends.phoenix import PhoenixBackend

            b = PhoenixBackend(cfg.phoenix)
            b.bootstrap()
            self._provider = b._provider
        elif t == "openobserve":
            from telemetry.backends.openobserve import OpenObserveBackend

            b = OpenObserveBackend(cfg.openobserve)
            b.bootstrap()
            self._provider = b._provider
        elif t == "none":
            self._provider = None
        else:
            msg = f"unsupported telemetry type: {t!r}"
            raise ValueError(msg)
        self._configured = True

    def teardown(self) -> None:
        """停机已注册的 TracerProvider（刷新导出的 span）。"""
        if self._configured and self._provider is not None:
            self._provider.shutdown()
        self._configured = False
        self._provider = None


def bootstrap_telemetry(cfg: TelemetryConfig) -> None:
    """入口：按配置启动链路追踪。"""
    Telemetry.instance().bootstrap(cfg)


def teardown_telemetry() -> None:
    """入口：停机已注册的 TracerProvider。"""
    Telemetry.instance().teardown()


def reset_telemetry() -> None:
    """入口：重置遥测单例，供测试隔离。"""
    Telemetry.reset()


# 兼容旧名
configure_telemetry = bootstrap_telemetry
shutdown_telemetry = teardown_telemetry
