from __future__ import annotations

import contextlib
import logging
from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI
from pydantic import SecretStr

from llm.base import BaseChatModelProvider
from llm.errors import LlmConfigError

logger = logging.getLogger(__name__)

# 本地无鉴权端点（如 Ollama）要求 api_key 非空时的占位值。
DEFAULT_API_KEY = "placeholder"


class MiMoChatModel(ChatOpenAI):
    """ChatOpenAI + thinking 透传（extra_body）+ 流式 reasoning 捞回。"""

    def __init__(self, *, thinking: bool | None = None, **kwargs: Any) -> None:
        if thinking is not None:
            extra_body = dict(kwargs.get("extra_body") or {})
            extra_body["thinking"] = {"type": "enabled" if thinking else "disabled"}
            kwargs["extra_body"] = extra_body
        super().__init__(**kwargs)

    @staticmethod
    def _strip_reasoning(messages: Any) -> Any:
        if not isinstance(messages, list):
            return messages
        out: list[Any] = []
        for m in messages:
            content = getattr(m, "content", None)
            if isinstance(content, list):
                filtered = [
                    c for c in content if not (isinstance(c, dict) and c.get("type") == "reasoning")
                ]
                if len(filtered) != len(content):
                    with contextlib.suppress(Exception):
                        if not filtered:
                            filtered_content: Any = ""
                        elif all(isinstance(c, str) for c in filtered):
                            filtered_content = "".join(str(c) for c in filtered)
                        else:
                            texts: list[str] = []
                            for c in filtered:
                                if isinstance(c, str):
                                    texts.append(c)
                                elif isinstance(c, dict) and c.get("type") == "text":
                                    t = c.get("text")
                                    if isinstance(t, str):
                                        texts.append(t)
                                elif isinstance(c, dict) and "text" in c:
                                    texts.append(str(c["text"]))
                            filtered_content = "".join(texts) if texts else ""
                            if not filtered_content and filtered:
                                filtered_content = filtered[0] if isinstance(filtered[0], str) else ""
                        m = m.model_copy(update={"content": filtered_content})  # type: ignore[attr-defined]
                out.append(m)
                continue
            out.append(m)
        return out

    def _generate(
        self, messages: Any, stop: Any | None = None, run_manager: Any | None = None, **kwargs: Any
    ) -> Any:
        return super()._generate(
            self._strip_reasoning(messages), stop=stop, run_manager=run_manager, **kwargs
        )  # type: ignore[arg-type]

    async def _agenerate(
        self, messages: Any, stop: Any | None = None, run_manager: Any | None = None, **kwargs: Any
    ) -> Any:
        return await super()._agenerate(
            self._strip_reasoning(messages), stop=stop, run_manager=run_manager, **kwargs
        )  # type: ignore[arg-type]

    async def _astream(
        self, messages: Any, stop: Any | None = None, run_manager: Any | None = None, **kwargs: Any
    ) -> Any:
        async for chunk in super()._astream(
            self._strip_reasoning(messages), stop=stop, run_manager=run_manager, **kwargs
        ):  # type: ignore[arg-type]
            yield chunk

    def _convert_chunk_to_generation_chunk(
        self,
        chunk: dict,
        default_chunk_class: type,
        base_generation_info: dict | None,
    ) -> Any:
        """转换点捞回 reasoning_content（ChatOpenAI 丢弃的官方字段）。"""
        gen = super()._convert_chunk_to_generation_chunk(
            chunk, default_chunk_class, base_generation_info
        )
        if gen is None:
            return None
        choices = chunk.get("choices") or []
        if not choices:
            return gen
        delta = (choices[0] or {}).get("delta") or {}
        reasoning = delta.get("reasoning_content")
        if not reasoning:
            return gen
        message = gen.message
        # content 为 list 时 langchain 的 chunk merge 是拼接 → 完整思考走 content 拿到
        content = list(message.content) if isinstance(message.content, list) else []
        content.append({"type": "reasoning", "reasoning": reasoning})
        additional_kwargs = dict(message.additional_kwargs)
        additional_kwargs["reasoning_content"] = reasoning
        gen.message = message.model_copy(
            update={"content": content, "additional_kwargs": additional_kwargs}
        )
        return gen


class MiMoProvider(BaseChatModelProvider):
    """MiMo provider：OpenAI 兼容端点的 ChatOpenAI 子类构造器。"""

    name = "mimo"

    def build_chat_model(self, *, thinking: bool | None = None) -> BaseChatModel:
        if not self.cfg.base_url:
            raise LlmConfigError("缺少 llm.base_url，请配置模型端点")
        if not self.cfg.model:
            raise LlmConfigError("缺少 llm.model，请指定模型名")
        logger.info(
            "构建 MiMo 模型: model=%s base_url=%s thinking=%s",
            self.cfg.model,
            self.cfg.base_url,
            thinking,
        )
        return MiMoChatModel(
            model=self.cfg.model,
            base_url=self.cfg.base_url,
            api_key=SecretStr(self.cfg.api_key or DEFAULT_API_KEY),
            temperature=self.cfg.temperature,
            thinking=thinking,
        )
