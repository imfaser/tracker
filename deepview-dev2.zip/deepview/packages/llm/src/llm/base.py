from __future__ import annotations

from abc import ABC, abstractmethod

from core.schema import LLMConfig
from langchain_core.language_models import BaseChatModel


class BaseChatModelProvider(ABC):
    """按 LLMConfig 构建 langchain 聊天模型的抽象基类，统一「建造函数」契约。"""

    def __init__(self, cfg: LLMConfig) -> None:
        self.cfg = cfg

    @abstractmethod
    def build_chat_model(self, *, thinking: bool | None = None) -> BaseChatModel:
        """构建聊天模型；thinking=None 表示不注入设置（由模型默认行为决定）。"""
        raise NotImplementedError
