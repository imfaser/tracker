class LlmConfigError(ValueError):
    """LLM provider 配置缺失或非法（AppConfig.llm 段）。"""
