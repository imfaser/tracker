from __future__ import annotations

from typing import Any

from llm.errors import LlmConfigError
from llm.providers.mimo import MiMoProvider


def _resolve_provider_settings(providers: dict[str, Any], provider_id: str) -> dict[str, Any]:
    prov = providers.get(provider_id)
    if prov is None:
        msg = f"unsupported llm provider: {provider_id!r}"
        raise LlmConfigError(msg)
    return (
        prov
        if isinstance(prov, dict)
        else prov.model_dump()
        if hasattr(prov, "model_dump")
        else dict(prov)
    )


def make_chat_model(ref: str, providers: dict[str, Any] | Any, *, thinking: bool | None = None):  # type: ignore[no-untyped-def]
    """按 provider/model#variant 精确筛选。"""
    if not isinstance(ref, str) or "/" not in ref:
        msg = f"invalid model ref: {ref!r}, expected provider/model[#variant]"
        raise LlmConfigError(msg)
    provider_id, rest = ref.split("/", 1)
    model_id = rest.split("#", 1)[0] if "#" in rest else rest

    prov_cfg = providers.get(provider_id) if isinstance(providers, dict) else None
    if prov_cfg is None:
        msg = f"unsupported llm provider: {provider_id!r}"
        raise LlmConfigError(msg)

    # 兼容 Pydantic 模型与原始 dict
    if hasattr(prov_cfg, "models"):
        models = prov_cfg.models or {}
    elif isinstance(prov_cfg, dict):
        models = prov_cfg.get("models") or {}
    else:
        models = {}

    if model_id not in models:
        msg = f"unsupported llm model: {model_id!r} for provider {provider_id!r}"
        raise LlmConfigError(msg)

    # 解析 provider 配置为适配旧 MiMoProvider 的 LLMConfig 形态
    # 兼容新 providers 结构：settings.baseURL/apiKey
    settings: dict[str, Any] = {}
    if hasattr(prov_cfg, "settings") and isinstance(prov_cfg.settings, dict):
        settings = dict(prov_cfg.settings or {})
    elif isinstance(prov_cfg, dict):
        settings = dict(prov_cfg.get("settings") or {})

    base_url = settings.get("baseURL") or settings.get("base_url") or ""
    api_key = settings.get("apiKey") or settings.get("api_key") or ""
    if isinstance(api_key, str) and api_key.startswith("{env:") and api_key.endswith("}"):
        import os

        env_key = api_key[5:-1]
        api_key = os.getenv(env_key, "")
        if not api_key:
            try:
                from core import get_config as _get_cfg

                _cfg = _get_cfg()
                if env_key == "MIMO_API_KEY" and getattr(_cfg, "mimo_api_key", None):
                    api_key = _cfg.mimo_api_key  # type: ignore[assignment]
            except Exception:  # noqa: BLE001, S110
                pass

    from core.schema import LLMConfig as _LLMConfig

    cfg = _LLMConfig(
        type=provider_id,
        base_url=base_url or "",
        api_key=api_key or "",  # type: ignore[arg-type]
        model=model_id,
        temperature=0.7,
    )

    if provider_id == "mimo":
        return MiMoProvider(cfg).build_chat_model(thinking=thinking)
    msg = f"unsupported llm provider: {provider_id!r}"
    raise LlmConfigError(msg)
