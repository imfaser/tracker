# 基础设施常量集中处；环境变量名由 pydantic-settings 推导，不在此定义。

CONFIG_FILENAME = "config.jsonc"  # 默认配置文件名（相对 cwd 解析）
