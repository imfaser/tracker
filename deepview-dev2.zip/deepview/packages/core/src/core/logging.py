from __future__ import annotations

import logging

import structlog
from structlog.dev import ConsoleRenderer
from structlog.stdlib import ProcessorFormatter
from structlog.types import Processor

from core.schema import LoggingConfig


def _structlog_chain(cfg: LoggingConfig) -> list[Processor]:
    return [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        ProcessorFormatter.wrap_for_formatter,
    ]


def _foreign_pre_chain(cfg: LoggingConfig) -> list[Processor]:
    return [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
    ]


def _terminal_renderer(cfg: LoggingConfig) -> Processor:
    if cfg.format == "console":
        return ConsoleRenderer(colors=False)
    return structlog.processors.JSONRenderer()


def _configure_root(cfg: LoggingConfig) -> None:
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    handler = logging.StreamHandler()
    handler.setFormatter(
        ProcessorFormatter(
            processor=_terminal_renderer(cfg),
            foreign_pre_chain=_foreign_pre_chain(cfg),
        )
    )
    root.addHandler(handler)
    root.setLevel(logging.getLevelName(cfg.level.upper()))


def _matches(name: str, target: str) -> bool:
    return name == target or name.startswith(target + ".")


def _silence(target: str) -> None:
    level = logging.CRITICAL + 1
    base = logging.getLogger(target)
    base.setLevel(level)
    base.disabled = True
    base.propagate = False
    base.addFilter(lambda _: False)  # type: ignore[arg-type]
    for logger_name in list(logging.Logger.manager.loggerDict):
        if _matches(logger_name, target):
            lg = logging.getLogger(logger_name)
            lg.setLevel(level)
            lg.disabled = True
            lg.propagate = False
            lg.addFilter(lambda _: False)  # type: ignore[arg-type]


def _reroute(target: str) -> None:
    logging.getLogger(target).handlers = []
    logging.getLogger(target).propagate = True
    for logger_name in list(logging.Logger.manager.loggerDict):
        if _matches(logger_name, target):
            log = logging.getLogger(logger_name)
            log.handlers = []
            log.propagate = True


def _apply_third_party(cfg: LoggingConfig) -> list[str]:
    for name in cfg.third_party.disable:
        _silence(name)
    for name in cfg.third_party.redirect:
        _reroute(name)
    return sorted(set(cfg.third_party.redirect) & set(cfg.third_party.disable))


def configure_logging(cfg: LoggingConfig) -> list[str]:
    """按配置配置结构化日志，返回冲突的库名列表。"""
    # 幂等：已配置过则直接返回空列表，不重复配置。
    if structlog.is_configured():
        return []
    structlog.configure(
        processors=_structlog_chain(cfg),
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    _configure_root(cfg)
    return _apply_third_party(cfg)


def reset_logging() -> None:
    """重置日志配置，供测试隔离。"""
    structlog.reset_defaults()
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
