from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ThirdPartyLoggingConfig(BaseModel):
    """第三方库日志控制配置。"""

    model_config = ConfigDict(extra="forbid")

    redirect: list[str] = Field(default_factory=list)
    disable: list[str] = Field(default_factory=list)


class LoggingConfig(BaseModel):
    """应用日志配置。"""

    model_config = ConfigDict(extra="forbid")

    level: str = Field(default="INFO")
    format: Literal["json", "console"] = Field(default="json")
    third_party: ThirdPartyLoggingConfig = Field(default_factory=ThirdPartyLoggingConfig)


class PhoenixConfig(BaseModel):
    """Phoenix 链路追踪后端配置。"""

    model_config = ConfigDict(extra="forbid")

    project_name: str = Field(default="deepview")
    endpoint: str | None = Field(default=None)
    protocol: Literal["grpc", "http/protobuf"] = Field(default="grpc")
    api_key: str | None = Field(default=None)
    headers: dict[str, str] = Field(default_factory=dict)
    batch: bool = Field(default=True)
    auto_instrument: bool = Field(default=True)

    @field_validator("protocol", mode="before")
    @classmethod
    def _normalize_protocol(cls, v: object) -> object:
        return "http/protobuf" if v == "http" else v


class OpenObserveConfig(BaseModel):
    """OpenObserve 链路追踪后端配置。"""

    model_config = ConfigDict(extra="forbid")

    service_name: str = Field(default="deepview")
    endpoint: str | None = Field(default=None)
    org: str = Field(default="default")
    headers: dict[str, str] = Field(default_factory=dict)
    stream_name: str = Field(default="default")
    protocol: Literal["grpc", "http/protobuf"] = Field(default="http/protobuf")
    batch: bool = Field(default=True)

    @field_validator("protocol", mode="before")
    @classmethod
    def _normalize_protocol(cls, v: object) -> object:
        return "http/protobuf" if v == "http" else v


class TelemetryConfig(BaseModel):
    """应用链路追踪配置。"""

    model_config = ConfigDict(extra="forbid")

    type: Literal["phoenix", "openobserve", "none"] = Field(default="none")
    phoenix: PhoenixConfig = Field(default_factory=PhoenixConfig)
    openobserve: OpenObserveConfig = Field(default_factory=OpenObserveConfig)
    expose_trace_id: bool = Field(default=False)


class MCPServerConfig(BaseModel):
    """MCP 连接配置，仅含连接信息，不含角色或筛选。"""

    model_config = ConfigDict(extra="forbid")

    name: str
    transport: Literal["stdio", "sse", "http"] = Field(default="stdio")
    url: str | None = Field(default=None)
    command: str | None = Field(default=None)
    enabled: bool = Field(default=True)
    timeout: int = Field(default=10)


class BusConfig(BaseModel):
    """NATS 异步总线配置。"""

    model_config = ConfigDict(extra="forbid")

    nats_url: str = Field(...)
    stream_name: str = Field(default="deepview")
    subject_prefix: str = Field(default="chat")
    timeout: int = Field(default=10, ge=1, le=60)


class DatabaseConfig(BaseModel):
    """SQLite 持久化配置。"""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(default="sqlite://data/app.sqlite3")
    sqlite_path: str = Field(default="data/app.sqlite3")
    langgraph_sqlite_path: str = Field(default="data/langgraph.sqlite3")


class HarnessConfig(BaseModel):
    """Harness 配置。"""

    model_config = ConfigDict(extra="forbid")

    description: str | None = Field(default=None)
    model: str = Field(default="")
    system: str = Field(default="")
    steps: int = Field(default=10, ge=1, le=50)
    permissions: list[str] | None = Field(default=None)
    color: str | None = Field(default=None)
    mode: Literal["all", "subagent", "primary"] | None = Field(default=None)

    @field_validator("system", mode="after")
    @classmethod
    def _validate_system(cls, v: str) -> str:
        if v.startswith(("./", "/", "Agents/")):
            p = Path(v)
            if not p.exists():
                msg = f"system file not found: {v!r}"
                raise ValueError(msg)
        return v


class LlmModelLimit(BaseModel):
    """模型上下文限制。"""

    model_config = ConfigDict(extra="allow")

    context: int | None = Field(default=None)
    output: int | None = Field(default=None)


class LlmModelConfig(BaseModel):
    """单模型配置。"""

    model_config = ConfigDict(extra="allow")

    model_id: str | None = Field(default=None, alias="modelID")
    name: str | None = Field(default=None)
    limit: LlmModelLimit | None = Field(default=None)
    variants: dict[str, Any] | None = Field(default=None)


class LlmProviderConfig(BaseModel):
    """LLM 提供商配置。"""

    model_config = ConfigDict(extra="allow")

    package: str | None = Field(default=None)
    settings: dict[str, Any] | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)
    models: dict[str, LlmModelConfig] = Field(default_factory=dict)


class LlmConfig(BaseModel):
    """LLM 顶层配置。"""

    model_config = ConfigDict(extra="forbid")

    providers: dict[str, LlmProviderConfig] = Field(default_factory=dict)
    model: str = Field(default="")


# 兼容旧导入（ radical 迁移期间保留，6.1 后移除 ）
class LLMConfig(BaseModel):
    """旧 LLMConfig 兼容（待 6.1 迁移后移除）。"""

    model_config = ConfigDict(extra="allow")

    type: str = Field(default="mimo")
    api_key: str = Field(default="")
    base_url: str = Field(default="")
    model: str = Field(default="")
    temperature: float = Field(default=0.7)


class AgentConfig(BaseModel):
    """旧 AgentConfig 兼容（待 6.1 迁移后移除）。"""

    model_config = ConfigDict(extra="allow")

    mcp_servers: list[MCPServerConfig] = Field(default_factory=list)
    system_prompt: str = Field(default="You are a helpful assistant.")
    max_steps: int = Field(default=10, ge=1, le=50)
    model: str = Field(default="")
    tool_loop_max_iterations: int | None = Field(default=None, ge=1, le=50)
    max_execution_steps: int | None = Field(default=None, ge=1, le=50)


def __getattr__(name: str) -> Any:
    if name == "AppConfig":
        from core.config import AppConfig as _AppConfig

        return _AppConfig
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
