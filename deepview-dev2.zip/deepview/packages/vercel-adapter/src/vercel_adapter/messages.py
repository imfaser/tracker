"""Vercel AI SDK v7 的 UIMessage 到 LangChain BaseMessage 的转换。"""

from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from pydantic import BaseModel, Field, field_validator


class TextPart(BaseModel):
    type: str
    text: str = ""

    @field_validator("type")
    @classmethod
    def check_type(cls, v: str) -> str:
        if v != "text":
            msg = f"invalid part type: {v!r}"
            raise ValueError(msg)
        return v


class ReasoningPart(BaseModel):
    type: str
    text: str = ""
    reasoning: str = ""

    @field_validator("type")
    @classmethod
    def check_type(cls, v: str) -> str:
        if v != "reasoning":
            msg = f"invalid part type: {v!r}"
            raise ValueError(msg)
        return v


class ToolPart(BaseModel):
    type: str
    toolCallId: str | None = Field(default=None)
    tool_call_id: str | None = Field(default=None)
    toolCallID: str | None = Field(default=None)
    toolName: str | None = Field(default=None)
    name: str | None = Field(default=None)
    tool_name: str | None = Field(default=None)
    input: Any | None = None
    args: Any | None = None
    output: Any | None = None
    text: str | None = None

    @field_validator("type")
    @classmethod
    def check_type(cls, v: str) -> str:
        if not v.startswith("tool"):
            msg = f"invalid part type: {v!r}"
            raise ValueError(msg)
        return v

    def get_call_id(self) -> str:
        return str(self.toolCallId or self.tool_call_id or self.toolCallID or "call_unknown")

    def get_tool_name(self) -> str:
        return str(self.toolName or self.name or self.tool_name or "unknown_tool")

    def get_raw_input(self) -> Any:
        return self.input if self.input is not None else self.args


def _extract_text_from_parts(parts: list[dict[str, Any]]) -> str:
    texts: list[str] = []
    for p in parts:
        if not isinstance(p, dict):
            continue
        t = p.get("type")
        if t == "text":
            txt = p.get("text")
            if isinstance(txt, str):
                texts.append(txt)
    return "\n".join(texts)


def _validate_parts(idx: int, parts: list[Any]) -> None:
    for p in parts:
        if not isinstance(p, dict):
            msg = f"message {idx} part must be an object"
            raise TypeError(msg)
        t = p.get("type")
        if not isinstance(t, str):
            msg = f"message {idx} part missing type"
            raise TypeError(msg)
        if t in ("text", "reasoning", "step-start"):
            continue
        if t.startswith("tool"):
            continue
        msg = f"message {idx} has invalid part type: {t!r}"
        raise ValueError(msg)


def to_base_messages_v7(messages: list[dict[str, Any]]) -> list[Any]:
    """将 V7 的 UIMessage[] 转换为 LangChain BaseMessage 列表。"""
    if not isinstance(messages, list):
        msg = "messages must be a list"
        raise TypeError(msg)
    if len(messages) == 0:
        msg = "messages must not be empty"
        raise ValueError(msg)

    out: list[Any] = []
    for idx, raw in enumerate(messages):
        if not isinstance(raw, dict):
            msg = f"message {idx} must be an object"
            raise TypeError(msg)
        role = raw.get("role")
        if role not in ("user", "assistant", "system", "tool"):
            msg = f"message {idx} has invalid role: {role!r}"
            raise ValueError(msg)

        parts = raw.get("parts")
        content_fallback = raw.get("content")

        if parts is None:
            if isinstance(content_fallback, str):
                parts = [{"type": "text", "text": content_fallback}]
            elif isinstance(content_fallback, list):
                parts = content_fallback
            else:
                msg = f"message {idx} missing parts/content"
                raise ValueError(msg)

        if not isinstance(parts, list):
            msg = f"message {idx} parts must be a list"
            raise TypeError(msg)

        _validate_parts(idx, parts)
        text = _extract_text_from_parts(parts)

        if role == "system":
            out.append(SystemMessage(content=text))
            continue
        if role == "user":
            out.append(HumanMessage(content=text))
            continue
        if role == "tool":
            tool_call_id = raw.get("tool_call_id") or raw.get("toolCallId") or "tool_call_id"
            output = text
            for p in parts:
                if isinstance(p, dict) and "output" in p:
                    output = p["output"]
                    if not isinstance(output, str):
                        output = json.dumps(output, ensure_ascii=False)
                    break
            out.append(ToolMessage(content=output, tool_call_id=str(tool_call_id)))
            continue

        tool_parts = [
            p for p in parts if isinstance(p, dict) and str(p.get("type", "")).startswith("tool")
        ]
        if not tool_parts and not text:
            out.append(AIMessage(content=""))
            continue
        if not tool_parts:
            out.append(AIMessage(content=text))
            continue

        tool_calls: list[dict[str, Any]] = []
        tool_messages: list[ToolMessage] = []
        for p in tool_parts:
            tp = ToolPart.model_validate(p)
            tool_call_id = tp.get_call_id()
            tool_name = tp.get_tool_name()
            raw_input = tp.get_raw_input()
            if raw_input is None and tp.output is None:
                raw_input = p.get("toolInput")
            args: dict[str, Any] = {}
            if isinstance(raw_input, dict):
                args = raw_input
            elif isinstance(raw_input, str):
                try:
                    args = (
                        json.loads(raw_input)
                        if raw_input.strip().startswith("{")
                        else {"input": raw_input}
                    )
                except json.JSONDecodeError, ValueError:
                    args = {"input": raw_input}
            output = p.get("output")
            if output is not None:
                tool_calls.append(
                    {
                        "name": str(tool_name),
                        "args": args,
                        "id": str(tool_call_id),
                        "type": "tool_call",
                    }
                )
                out_str = (
                    output if isinstance(output, str) else json.dumps(output, ensure_ascii=False)
                )
                tool_messages.append(ToolMessage(content=out_str, tool_call_id=str(tool_call_id)))
            else:
                tool_calls.append(
                    {
                        "name": str(tool_name),
                        "args": args,
                        "id": str(tool_call_id),
                        "type": "tool_call",
                    }
                )

        if tool_calls:
            out.append(AIMessage(content=text, tool_calls=tool_calls))
            out.extend(tool_messages)
        else:
            out.append(AIMessage(content=text))

    return out
