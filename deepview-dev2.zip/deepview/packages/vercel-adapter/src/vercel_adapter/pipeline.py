"""Vercel Adapter 函数式管道。"""

from __future__ import annotations

from typing import Any


def validate(payload: dict[str, Any]) -> dict[str, Any]:
    """校验载荷结构。"""
    if not isinstance(payload.get("messages"), list) or not payload["messages"]:
        msg = "messages must not be empty"
        raise ValueError(msg)
    for idx, m in enumerate(payload["messages"]):
        if m.get("role") not in ("user", "assistant", "system", "tool"):
            msg = f"message {idx} has invalid role"
            raise ValueError(msg)
    return payload


def to_base_messages(payload: dict[str, Any]) -> list[Any]:
    """转换为 BaseMessage。"""
    from vercel_adapter.messages import to_base_messages_v7

    return to_base_messages_v7(payload["messages"])


def run_sync_pipeline(payload: dict[str, Any]) -> list[Any]:
    """同步管道：validate -> to_base_messages。"""
    return to_base_messages(validate(payload))
