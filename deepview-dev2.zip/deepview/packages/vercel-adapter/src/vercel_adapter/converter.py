"""Vercel AI SDK v7 的 UI Message Stream 转换与响应。"""

from __future__ import annotations

import uuid
from collections.abc import AsyncIterable, AsyncIterator
from typing import Annotated, Any, Literal

import anyio
from fastapi.responses import StreamingResponse
from langchain_core.messages import AIMessageChunk
from pydantic import BaseModel, Discriminator, Field, RootModel, Tag

try:
    import orjson as _orjson

    def _dumps(obj: Any) -> str:
        return _orjson.dumps(obj).decode()

except ImportError:
    import json as _json

    def _dumps(obj: Any) -> str:
        return _json.dumps(obj, ensure_ascii=False)


class VStart(BaseModel):
    type: Literal["start"]
    messageId: str
    messageMetadata: dict[str, Any] | None = None


class VStartStep(BaseModel):
    type: Literal["start-step"]


class VReasoningStart(BaseModel):
    type: Literal["reasoning-start"]
    id: str


class VReasoningDelta(BaseModel):
    type: Literal["reasoning-delta"]
    id: str
    delta: str


class VReasoningEnd(BaseModel):
    type: Literal["reasoning-end"]
    id: str


class VTextStart(BaseModel):
    type: Literal["text-start"]
    id: str


class VTextDelta(BaseModel):
    type: Literal["text-delta"]
    id: str
    delta: str


class VTextEnd(BaseModel):
    type: Literal["text-end"]
    id: str


class VToolInputStart(BaseModel):
    type: Literal["tool-input-start"]
    toolCallId: str
    toolName: str


class VToolInputDelta(BaseModel):
    type: Literal["tool-input-delta"]
    toolCallId: str
    inputTextDelta: str


class VToolInputAvailable(BaseModel):
    type: Literal["tool-input-available"]
    toolCallId: str
    toolName: str
    input: Any


class VToolOutputAvailable(BaseModel):
    type: Literal["tool-output-available"]
    toolCallId: str
    output: Any


class VFinishStep(BaseModel):
    type: Literal["finish-step"]


class VFinish(BaseModel):
    type: Literal["finish"]
    finishReason: str
    error: str | None = None


class VError(BaseModel):
    type: Literal["error"]
    errorText: str


class VAbort(BaseModel):
    type: Literal["abort"]
    reason: str | None = None


WellKnownVercelChunk = RootModel[
    Annotated[
        Annotated[VStart, Tag("start")]
        | Annotated[VStartStep, Tag("start-step")]
        | Annotated[VReasoningStart, Tag("reasoning-start")]
        | Annotated[VReasoningDelta, Tag("reasoning-delta")]
        | Annotated[VReasoningEnd, Tag("reasoning-end")]
        | Annotated[VTextStart, Tag("text-start")]
        | Annotated[VTextDelta, Tag("text-delta")]
        | Annotated[VTextEnd, Tag("text-end")]
        | Annotated[VToolInputStart, Tag("tool-input-start")]
        | Annotated[VToolInputDelta, Tag("tool-input-delta")]
        | Annotated[VToolInputAvailable, Tag("tool-input-available")]
        | Annotated[VToolOutputAvailable, Tag("tool-output-available")]
        | Annotated[VFinishStep, Tag("finish-step")]
        | Annotated[VFinish, Tag("finish")]
        | Annotated[VError, Tag("error")]
        | Annotated[VAbort, Tag("abort")],
        Field(discriminator=Discriminator("type")),
    ]
]


def _sse_line(payload: dict[str, Any]) -> bytes:
    validated = WellKnownVercelChunk.model_validate(payload).model_dump(exclude_none=True)
    return f"data: {_dumps(validated)}\n\n".encode()


async def to_ui_message_stream_v7(
    chunks: AsyncIterable[AIMessageChunk | dict[str, Any]],
    *,
    message_id: str | None = None,
    expose_trace_id: bool = False,
    trace_id: str | None = None,
) -> AsyncIterator[bytes]:
    """将 LangChain 的 AIMessageChunk 流映射为 V7 UI Message Stream 的 SSE 字节流。"""
    msg_id = message_id or f"msg_{uuid.uuid4().hex[:12]}"
    text_id: str | None = None
    reasoning_id: str | None = None
    text_active = False
    reasoning_active = False
    seen_tool_calls: set[str] = set()

    start_payload: dict[str, Any] = {"type": "start", "messageId": msg_id}
    if expose_trace_id and trace_id:
        start_payload["messageMetadata"] = {"traceId": trace_id}
    yield _sse_line(start_payload)
    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
    yield _sse_line({"type": "start-step"})
    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

    try:
        async for raw in chunks:
            if isinstance(raw, dict):
                yield _sse_line(raw)
                await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
                continue

            chunk: AIMessageChunk = raw  # type: ignore[assignment]

            reasoning_text: str | None = None
            add_kwargs = getattr(chunk, "additional_kwargs", {}) or {}
            if isinstance(add_kwargs, dict) and add_kwargs.get("reasoning_content"):
                reasoning_text = str(add_kwargs["reasoning_content"])
            else:
                content_tmp = getattr(chunk, "content", "")
                if isinstance(content_tmp, list):
                    for block in content_tmp:
                        if isinstance(block, dict) and block.get("type") == "reasoning":
                            txt = str(block.get("reasoning") or block.get("text") or "")
                            if txt:
                                reasoning_text = (reasoning_text or "") + txt
            content = getattr(chunk, "content", "")

            if reasoning_text:
                if not reasoning_active:
                    reasoning_id = f"reasoning_{uuid.uuid4().hex[:8]}"
                    yield _sse_line({"type": "reasoning-start", "id": reasoning_id})
                    reasoning_active = True
                    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
                yield _sse_line(
                    {"type": "reasoning-delta", "id": reasoning_id, "delta": reasoning_text}
                )
                await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

            text_delta: str | None = None
            if isinstance(content, str):
                text_delta = content
            elif isinstance(content, list):
                txt_blocks: list[str] = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        t = block.get("text")
                        if isinstance(t, str):
                            txt_blocks.append(t)
                    elif isinstance(block, str):
                        txt_blocks.append(block)
                if txt_blocks:
                    text_delta = "".join(txt_blocks)

            if text_delta:
                if not text_active:
                    text_id = f"text_{uuid.uuid4().hex[:8]}"
                    yield _sse_line({"type": "text-start", "id": text_id})
                    text_active = True
                    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
                yield _sse_line({"type": "text-delta", "id": text_id, "delta": text_delta})
                await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

            tool_call_chunks = getattr(chunk, "tool_call_chunks", None) or []
            tool_calls = getattr(chunk, "tool_calls", None) or []
            if tool_calls:
                for tc in tool_calls:
                    tc_id = tc.get("id") or tc.get("tool_call_id") or f"call_{uuid.uuid4().hex[:8]}"
                    tc_name = tc.get("name") or "unknown_tool"
                    tc_args = tc.get("args") or {}
                    if tc_id not in seen_tool_calls:
                        yield _sse_line(
                            {"type": "tool-input-start", "toolCallId": tc_id, "toolName": tc_name}
                        )
                        seen_tool_calls.add(tc_id)
                        await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
                    yield _sse_line(
                        {
                            "type": "tool-input-available",
                            "toolCallId": tc_id,
                            "toolName": tc_name,
                            "input": tc_args,
                        }
                    )
                    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
            elif tool_call_chunks:
                for tc in tool_call_chunks:
                    tc_id = tc.get("id") or f"call_{uuid.uuid4().hex[:8]}"
                    tc_name = tc.get("name") or "unknown_tool"
                    if tc_id not in seen_tool_calls and tc_name:
                        yield _sse_line(
                            {"type": "tool-input-start", "toolCallId": tc_id, "toolName": tc_name}
                        )
                        seen_tool_calls.add(tc_id)
                        await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

            await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

    except anyio.get_cancelled_exc_class():  # type: ignore[attr-defined]
        if text_active and text_id:
            yield _sse_line({"type": "text-end", "id": text_id})
        if reasoning_active and reasoning_id:
            yield _sse_line({"type": "reasoning-end", "id": reasoning_id})
        yield _sse_line({"type": "abort", "reason": "cancelled"})
        yield _sse_line({"type": "finish-step"})
        yield _sse_line({"type": "finish", "finishReason": "cancelled"})
        return
    except Exception:  # noqa: BLE001
        if text_active and text_id:
            yield _sse_line({"type": "text-end", "id": text_id})
        if reasoning_active and reasoning_id:
            yield _sse_line({"type": "reasoning-end", "id": reasoning_id})
        yield _sse_line({"type": "error", "errorText": "internal error"})
        yield _sse_line({"type": "finish-step"})
        yield _sse_line({"type": "finish", "finishReason": "error"})
        return

    if reasoning_active and reasoning_id:
        yield _sse_line({"type": "reasoning-end", "id": reasoning_id})
        await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
    if text_active and text_id:
        yield _sse_line({"type": "text-end", "id": text_id})
        await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]

    yield _sse_line({"type": "finish-step"})
    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
    yield _sse_line({"type": "finish", "finishReason": "stop"})
    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]


def create_ui_message_stream_response(
    stream: AsyncIterable[bytes],
    *,
    trace_id: str | None = None,
    thread_id: str | None = None,
) -> StreamingResponse:
    """创建符合 V7 约定的 StreamingResponse。"""
    headers = {
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "x-vercel-ai-ui-message-stream": "v1",
        "Access-Control-Expose-Headers": "X-Trace-Id, X-Thread-Id, traceparent",
    }
    if trace_id:
        headers["X-Trace-Id"] = trace_id
    if thread_id:
        headers["X-Thread-Id"] = thread_id
    return StreamingResponse(stream, media_type="text/event-stream", headers=headers)
