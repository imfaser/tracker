from __future__ import annotations

import pytest
from core.schema import OpenObserveConfig, PhoenixConfig, TelemetryConfig
from opentelemetry.sdk.trace import TracerProvider
from telemetry import bootstrap_telemetry, reset_telemetry, teardown_telemetry
from telemetry.backends.openobserve import OpenObserveBackend
from telemetry.backends.phoenix import PhoenixBackend


class _DummySpanProcessor:
    """桩：仅占位，不启后台线程、不导出，避免打扰真实 provider 生命周期。"""

    def __init__(self, *args, **kwargs) -> None:
        pass

    def shutdown(self, *args, **kwargs) -> None:
        pass


def _mock_bootstraps(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    calls: list[str] = []
    monkeypatch.setattr(PhoenixBackend, "bootstrap", lambda self: calls.append("phoenix"))
    monkeypatch.setattr(OpenObserveBackend, "bootstrap", lambda self: calls.append("openobserve"))
    return calls


def test_empty_config_no_bootstrap(monkeypatch):
    calls = _mock_bootstraps(monkeypatch)
    bootstrap_telemetry(TelemetryConfig(type="none"))
    assert calls == []


def test_single_phoenix_bootstrap(monkeypatch):
    calls = _mock_bootstraps(monkeypatch)
    bootstrap_telemetry(TelemetryConfig(type="phoenix", phoenix=PhoenixConfig()))
    assert calls == ["phoenix"]


def test_only_openobserve_bootstrap(monkeypatch):
    calls = _mock_bootstraps(monkeypatch)
    bootstrap_telemetry(TelemetryConfig(type="openobserve", openobserve=OpenObserveConfig()))
    assert calls == ["openobserve"]


def test_invalid_type_raises():
    import pytest as _pytest

    with _pytest.raises(ValueError):
        bootstrap_telemetry(TelemetryConfig.model_validate({"type": "bad"}))  # ty: ignore[invalid-argument-type]


def test_idempotent_second_call_is_noop(monkeypatch):
    calls = _mock_bootstraps(monkeypatch)
    cfg = TelemetryConfig(type="phoenix", phoenix=PhoenixConfig())
    bootstrap_telemetry(cfg)
    bootstrap_telemetry(cfg)
    assert calls == ["phoenix"]


def test_reset_allows_reconfigure(monkeypatch):
    calls = _mock_bootstraps(monkeypatch)
    cfg = TelemetryConfig(type="phoenix", phoenix=PhoenixConfig())
    bootstrap_telemetry(cfg)
    reset_telemetry()
    bootstrap_telemetry(cfg)
    assert calls == ["phoenix", "phoenix"]


def test_teardown_calls_provider_teardown(monkeypatch):
    shutdown_calls: list[int] = []

    class _TrackedProvider(TracerProvider):
        def shutdown(self):
            shutdown_calls.append(1)
            return super().shutdown()

    def fake_bootstrap(self: OpenObserveBackend) -> None:
        self._provider = _TrackedProvider()

    monkeypatch.setattr(OpenObserveBackend, "bootstrap", fake_bootstrap)
    bootstrap_telemetry(TelemetryConfig(type="openobserve", openobserve=OpenObserveConfig()))
    teardown_telemetry()
    assert shutdown_calls == [1]


def test_openobserve_injects_stream_name_header(monkeypatch):
    captured: dict = {}

    def _fake_exporter(**kwargs):
        captured.update(kwargs)
        return object()

    monkeypatch.setattr("telemetry.backends.openobserve.OTLPSpanExporter", _fake_exporter)
    monkeypatch.setattr("telemetry.backends.openobserve.BatchSpanProcessor", _DummySpanProcessor)
    monkeypatch.setattr("telemetry.backends.openobserve.trace.set_tracer_provider", lambda p: None)

    OpenObserveBackend(OpenObserveConfig(stream_name="deepview-traces")).bootstrap()
    assert captured["headers"]["stream-name"] == "deepview-traces"


def test_openobserve_user_stream_name_header_wins(monkeypatch):
    captured: dict = {}

    def _fake_exporter(**kwargs):
        captured.update(kwargs)
        return object()

    monkeypatch.setattr("telemetry.backends.openobserve.OTLPSpanExporter", _fake_exporter)
    monkeypatch.setattr("telemetry.backends.openobserve.BatchSpanProcessor", _DummySpanProcessor)
    monkeypatch.setattr("telemetry.backends.openobserve.trace.set_tracer_provider", lambda p: None)

    cfg = OpenObserveConfig(stream_name="default", headers={"stream-name": "mine"})
    OpenObserveBackend(cfg).bootstrap()
    assert captured["headers"]["stream-name"] == "mine"
