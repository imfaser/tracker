from core.config import AppConfig


def test_llm_providers_defaults():
    cfg = AppConfig()
    assert isinstance(cfg.providers, dict)
    assert cfg.model == "mimo/mimo-v2.5" or isinstance(cfg.model, str)


def test_app_config_has_providers_field_with_default(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(tmp_path / "config.jsonc"))
    cfg = AppConfig()
    assert isinstance(cfg.providers, dict)


def test_llm_config_env_override(tmp_path, monkeypatch):
    monkeypatch.setenv("CONFIG_FILE", str(tmp_path / "config.jsonc"))
    monkeypatch.setenv("MODEL", "mimo/mimo-v2.5")
    cfg = AppConfig()
    assert "mimo" in cfg.providers or isinstance(cfg.providers, dict)
