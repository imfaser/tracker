import core


def test_core_importable() -> None:
    assert core is not None


def test_fixture_example(example_value: int) -> None:
    assert example_value == 42
