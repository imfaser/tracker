import pytest
from dishka import Provider, Scope, make_async_container, provide
from dishka.integrations.fastapi import setup_dishka
from fastapi.testclient import TestClient
from server.app import create_app
from server.container import AppProvider


class MockHarnessProvider(Provider):
    scope = Scope.APP

    @provide(scope=Scope.APP)
    def mock_supervisor(self) -> str:
        return "mock_supervisor"


@pytest.mark.anyio
async def test_container_mock_override():
    container = make_async_container(AppProvider(), MockHarnessProvider())
    val = await container.get(str)
    assert val == "mock_supervisor"
    await container.close()


def test_create_app_with_mock_container():
    import anyio

    async def _run():
        app = create_app()
        container = make_async_container(AppProvider())
        setup_dishka(container, app)
        with TestClient(app) as client:
            resp = client.get("/health")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok"}
        await container.close()

    anyio.run(_run)


@pytest.mark.anyio
async def test_llm_maker_unknown_raises():
    from llm.errors import LlmConfigError
    from llm.maker import make_chat_model

    with pytest.raises(LlmConfigError):
        make_chat_model("unknown/model", {})
    with pytest.raises(LlmConfigError):
        make_chat_model("mimo/unknown", {"mimo": {"models": {"mimo-v2.5": {}}}})
