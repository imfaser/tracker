from __future__ import annotations

import json

import pytest
from langchain_core.messages import AIMessageChunk, HumanMessage
from server.vercel.converter import create_ui_message_stream_response, to_ui_message_stream_v7
from server.vercel.messages import to_base_messages_v7


async def _collect(stream) -> list[dict]:
    out: list[dict] = []
    async for raw in stream:
        assert raw.startswith(b"data: ")
        line = raw.decode().strip()
        assert line.startswith("data: ")
        payload = line[len("data: ") :]
        if payload == "[DONE]":
            out.append({"type": "[DONE]"})
        else:
            out.append(json.loads(payload))
    return out


def test_to_base_messages_v7_user_text() -> None:
    msgs = [{"role": "user", "parts": [{"type": "text", "text": "hello"}]}]
    out = to_base_messages_v7(msgs)
    assert len(out) == 1
    assert isinstance(out[0], HumanMessage)
    assert out[0].content == "hello"


def test_to_base_messages_v7_system_fallback_content() -> None:
    msgs = [{"role": "system", "content": "you are helpful"}]
    out = to_base_messages_v7(msgs)
    assert out[0].content == "you are helpful"


def test_to_base_messages_v7_assistant_with_tool() -> None:
    msgs = [
        {"role": "user", "parts": [{"type": "text", "text": "calc"}]},
        {
            "role": "assistant",
            "parts": [
                {"type": "text", "text": "thinking"},
                {
                    "type": "tool-input-available",
                    "toolName": "circle_area",
                    "toolCallId": "call_1",
                    "input": {"radius": 2},
                },
            ],
        },
        {
            "role": "assistant",
            "parts": [
                {
                    "type": "tool-input-available",
                    "toolName": "circle_area",
                    "toolCallId": "call_1",
                    "input": {"radius": 2},
                    "output": {"area": 12.5},
                },
            ],
        },
    ]
    out = to_base_messages_v7(msgs)
    # user, AIMessage with tool_calls, AIMessage+ToolMessage for output part → 4
    assert len(out) == 4
    assert out[1].tool_calls[0]["name"] == "circle_area"
    assert out[3].content == json.dumps({"area": 12.5}, ensure_ascii=False)


def test_to_base_messages_v7_invalid_role() -> None:
    with pytest.raises(ValueError, match="invalid role"):
        to_base_messages_v7([{"role": "bad", "parts": []}])


def test_to_base_messages_v7_empty() -> None:
    with pytest.raises(ValueError, match="not be empty"):
        to_base_messages_v7([])


def test_to_base_messages_v7_non_list() -> None:
    with pytest.raises(TypeError):
        to_base_messages_v7("not-a-list")  # type: ignore[arg-type]  # ty: ignore[invalid-argument-type]


def test_to_base_messages_v7_invalid_part_type() -> None:
    with pytest.raises(ValueError, match="invalid part type"):
        to_base_messages_v7([{"role": "user", "parts": [{"type": "bad", "text": "hi"}]}])


def test_to_base_messages_v7_parts_must_be_list() -> None:
    with pytest.raises(TypeError, match="parts must be a list"):
        to_base_messages_v7([{"role": "user", "parts": "not-a-list"}])  # type: ignore[arg-type]


async def test_to_ui_message_stream_v7_text_and_reasoning() -> None:
    async def chunks():
        yield AIMessageChunk(content="Hello ", additional_kwargs={})
        yield AIMessageChunk(content="", additional_kwargs={"reasoning_content": "think"})
        yield AIMessageChunk(content="world")

    events = await _collect(to_ui_message_stream_v7(chunks()))
    types = [e["type"] for e in events]
    assert "start" in types
    assert "start-step" in types
    assert "text-start" in types
    assert "text-delta" in types
    assert "reasoning-start" in types
    assert "reasoning-delta" in types
    assert "finish-step" in types
    assert "finish" in types
    assert types[-1] == "finish"
    assert "[DONE]" not in types
    # text deltas should contain Hello and world
    text_deltas = [e["delta"] for e in events if e.get("type") == "text-delta"]
    assert "".join(text_deltas) == "Hello world"


async def test_to_ui_message_stream_v7_tool() -> None:
    async def chunks():
        yield AIMessageChunk(
            content="",
            tool_calls=[
                {"name": "circle_area", "args": {"radius": 2}, "id": "call_1", "type": "tool_call"}
            ],
        )

    events = await _collect(to_ui_message_stream_v7(chunks()))
    types = [e["type"] for e in events]
    assert "tool-input-start" in types
    assert "tool-input-available" in types
    avail = next(e for e in events if e["type"] == "tool-input-available")
    assert avail["toolCallId"] == "call_1"
    assert avail["toolName"] == "circle_area"


async def test_to_ui_message_stream_v7_expose_trace_id() -> None:
    async def chunks():
        yield AIMessageChunk(content="hi")

    events_false = await _collect(
        to_ui_message_stream_v7(chunks(), trace_id="abc123", expose_trace_id=False)
    )
    start_false = next(e for e in events_false if e["type"] == "start")
    assert "messageMetadata" not in start_false

    events_true = await _collect(
        to_ui_message_stream_v7(chunks(), trace_id="abc123", expose_trace_id=True)
    )
    start_true = next(e for e in events_true if e["type"] == "start")
    assert start_true["messageMetadata"]["traceId"] == "abc123"


async def test_create_ui_message_stream_response_headers() -> None:
    async def empty():
        if False:
            yield b""

    resp = create_ui_message_stream_response(empty(), trace_id="trace123")
    assert resp.media_type == "text/event-stream"
    assert resp.headers["x-vercel-ai-ui-message-stream"] == "v1"
    assert resp.headers["X-Trace-Id"] == "trace123"
    assert "X-Trace-Id" in resp.headers["Access-Control-Expose-Headers"]


async def test_to_ui_message_stream_v7_error_still_finishes() -> None:
    async def bad():
        yield AIMessageChunk(content="ok")
        raise RuntimeError("boom")

    events = await _collect(to_ui_message_stream_v7(bad()))
    types = [e["type"] for e in events]
    assert "error" in types
    assert "finish" in types
    assert types[-1] == "finish"
    assert "[DONE]" not in types
