import logging

import pytest
import structlog
from core.logging import configure_logging, reset_logging
from core.schema import LoggingConfig, ThirdPartyLoggingConfig


@pytest.fixture(autouse=True)
def _reset_logging():
    reset_logging()
    yield
    reset_logging()


def _cfg(level="INFO", format="json", redirect=None, disable=None) -> LoggingConfig:
    return LoggingConfig(
        level=level,
        format=format,
        third_party=ThirdPartyLoggingConfig(redirect=redirect or [], disable=disable or []),
    )


def _captured(capsys) -> str:
    cap = capsys.readouterr()
    return cap.out + cap.err


def test_empty_config_returns_no_conflicts(capsys):
    assert configure_logging(_cfg()) == []
    structlog.get_logger("app").info("hello")
    assert "hello" in _captured(capsys)


def test_idempotent_second_call_returns_empty():
    configure_logging(_cfg())
    assert configure_logging(_cfg()) == []


def test_format_json_selects_json_renderer(capsys):
    configure_logging(_cfg(format="json"))
    structlog.get_logger("app").info("hello", key="value")
    out = _captured(capsys)
    assert '"event"' in out and "hello" in out


def test_format_console_selects_console_renderer(capsys):
    configure_logging(_cfg(format="console"))
    structlog.get_logger("app").info("hello")
    assert "hello" in _captured(capsys)


def test_disable_silences_named_and_descendants(capsys):
    third = logging.getLogger("noisy.lib")
    third.setLevel(logging.DEBUG)
    assert configure_logging(_cfg(disable=["noisy"])) == []
    third.debug("should be silent")
    third.info("should be silent")
    assert "should be silent" not in _captured(capsys)


def test_redirect_reroutes_named_and_descendants():
    rogue = logging.getLogger("rogue.lib")
    rogue.addHandler(logging.StreamHandler())
    rogue.propagate = False
    configure_logging(_cfg(redirect=["rogue"]))
    assert rogue.handlers == []
    assert rogue.propagate is True


def test_conflict_disable_wins_and_reported(capsys):
    # 先实例化被点名的 logger（configure 只能作用于已存在的 logger）
    both = logging.getLogger("both")
    conflicts = configure_logging(_cfg(redirect=["both"], disable=["both"]))
    assert conflicts == ["both"]
    both.info("should be silent")
    out = _captured(capsys)
    assert "should be silent" not in out


def test_reset_logging_allows_reconfigure(capsys):
    configure_logging(_cfg(format="json"))
    reset_logging()
    # 再次 configure 应重新生效（非幂等短路），且切到 console
    assert configure_logging(_cfg(format="console")) == []
    structlog.get_logger("app").info("hello")
    assert "hello" in _captured(capsys)
