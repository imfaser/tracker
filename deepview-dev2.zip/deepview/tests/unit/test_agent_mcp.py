from unittest.mock import AsyncMock, patch

import anyio
from core.schema import MCPServerConfig
from harness.registry import McpDiscovery, ToolStore
from langchain_core.tools import StructuredTool


def _fake_tool(name: str, read_only: bool = True) -> StructuredTool:
    t = StructuredTool.from_function(func=lambda x: x, name=name, description="fake")
    t.metadata = {"readOnlyHint": read_only, "_source": "mcp"}
    return t


def test_configure_mcp_servers_stores_length(mcp_discovery: McpDiscovery):
    mcp_discovery.configure_mcp_servers([MCPServerConfig(name="a"), MCPServerConfig(name="b")])
    assert len(mcp_discovery._mcp_servers) == 2


def test_discover_preserves_annotations_and_filter(
    tool_store: ToolStore, mcp_discovery: McpDiscovery
):
    async def _run():
        mcp_discovery.configure_mcp_servers([MCPServerConfig(name="calc-mcp")])
        fake = _fake_tool("calc_tool", True)
        with patch(
            "langchain_mcp_adapters.client.MultiServerMCPClient.get_tools",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = [fake]
            res = await mcp_discovery.discover()
            assert "calc-mcp" in res
            assert res["calc-mcp"][0].metadata["readOnlyHint"] is True  # ty: ignore[not-subscriptable]
            tool_store.sync_mcp(res)
            assert len(tool_store.list()) == 1
            assert tool_store.list()[0].name == "calc_tool"

    anyio.run(_run)


def test_discover_failure_isolation(mcp_discovery: McpDiscovery):
    async def _run():
        mcp_discovery.configure_mcp_servers([MCPServerConfig(name="a"), MCPServerConfig(name="b")])

        async def side_effect(server_name=None):
            if server_name == "a":
                raise RuntimeError("fail a")
            return [_fake_tool("ok", True)]

        with patch(
            "langchain_mcp_adapters.client.MultiServerMCPClient.get_tools",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.side_effect = side_effect
            res = await mcp_discovery.discover()
            assert res["a"] == []
            assert len(res["b"]) == 1

    anyio.run(_run)


def test_discover_ttl_cache(mcp_discovery: McpDiscovery):
    async def _run():
        mcp_discovery.configure_mcp_servers([MCPServerConfig(name="c")])
        fake = _fake_tool("c_tool", True)
        with patch(
            "langchain_mcp_adapters.client.MultiServerMCPClient.get_tools",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = [fake]
            await mcp_discovery.discover(ttl=10)
            assert mcp_discovery._discover_count == 1
            await mcp_discovery.discover(ttl=10)
            assert mcp_discovery._discover_count == 1
            assert mock_get.call_count == 1
            await mcp_discovery.discover(ttl=10, refresh=True)
            assert mcp_discovery._discover_count == 2
            assert mock_get.call_count == 2

    anyio.run(_run)
