from harness.state import add_messages_delta
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage


def test_add_messages_delta_bulk():
    s = [HumanMessage(content="hi")]
    w = [[AIMessage(content="hello")], HumanMessage(content="next")]
    out = add_messages_delta(s, w)
    assert [m.content for m in out] == ["hi", "hello", "next"]


def test_add_messages_delta_mixed():
    s: list = []
    w = [
        HumanMessage(content="a"),
        [AIMessage(content="b"), ToolMessage(content="c", tool_call_id="x")],
    ]
    out = add_messages_delta(s, w)
    assert len(out) == 3
    assert out[0].content == "a"
    assert out[1].content == "b"
