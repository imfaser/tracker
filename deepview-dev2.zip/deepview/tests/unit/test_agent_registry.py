from harness.registry import ToolStore
from langchain_core.tools import tool


def _tools_for_role(store: ToolStore, role: str):
    return [e.tool for e in store._entries if role in e.roles]


def test_view_initial_empty_and_clear(tool_store: ToolStore):
    assert _tools_for_role(tool_store, "math") == []
    tool_store.clear()
    assert _tools_for_role(tool_store, "math") == []


def test_tool_decorator_registers_and_retains_metadata(tool_store: ToolStore):
    @tool_store.tool(roles=["math"], tags={"geometry"})
    def dummy_tool(x: int) -> int:
        """dummy"""
        return x

    tools = _tools_for_role(tool_store, "math")
    assert len(tools) == 1
    assert tools[0].name == "dummy_tool"
    assert tool_store._entries[0].roles == ["math"]
    assert tool_store._entries[0].tags == {"geometry"}
    assert tool_store._entries[0].source == "builtin"


def test_dual_track_isolation():
    a = ToolStore()
    b = ToolStore()

    @a.tool(roles=["math"])
    def other_tool(y: int) -> int:
        """other"""
        return y

    assert len([e.tool for e in b._entries if "math" in e.roles]) == 0
    assert len([e.tool for e in a._entries if "math" in e.roles]) == 1
    assert next(e.tool for e in a._entries if "math" in e.roles).name == "other_tool"

    @b.tool(roles=["math"])
    def global_tool(z: int) -> int:
        """global"""
        return z

    assert len([e.tool for e in b._entries if "math" in e.roles]) == 1
    assert len([e.tool for e in a._entries if "math" in e.roles]) == 1


def test_same_name_handling(tool_store: ToolStore):
    @tool_store.tool(roles=["math"])
    def same_name(x: int) -> int:
        """first"""
        return x

    from langchain_core.tools import StructuredTool

    dup = StructuredTool.from_function(func=lambda x: x, name="same_name", description="second")
    tool_store.register(dup, roles=["math"])
    tools = _tools_for_role(tool_store, "math")
    assert len(tools) == 2
    assert [t.name for t in tools].count("same_name") == 2


def test_view_filter_by_role(tool_store: ToolStore):
    @tool_store.tool(roles=["math"])
    def math_tool(a: int) -> int:
        """math"""
        return a

    @tool_store.tool(roles=["researcher"])
    def research_tool(b: int) -> int:
        """research"""
        return b

    assert len(_tools_for_role(tool_store, "math")) == 1
    assert len(_tools_for_role(tool_store, "researcher")) == 1
    assert len(_tools_for_role(tool_store, "unknown")) == 0


def test_list_with_source_filter(tool_store: ToolStore):
    @tool_store.tool(roles=["math"])
    def t1(x: int) -> int:
        """t1"""
        return x

    @tool
    def mcp_tool(x: int) -> int:
        """mcp"""
        return x

    tool_store.register(mcp_tool, roles=["math"], source="mcp", annotations={"readOnlyHint": True})
    assert len(tool_store.list(source="builtin")) == 1
    assert len(tool_store.list(source="mcp")) == 1
    assert len(tool_store.list()) == 2
