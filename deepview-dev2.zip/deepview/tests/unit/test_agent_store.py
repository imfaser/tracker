import warnings

import pytest

warnings.filterwarnings("ignore", category=DeprecationWarning)

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

from harness.registry import McpDiscovery, ToolStore


def test_import_side_effect_not_required():
    store = ToolStore()
    assert store.list() == []
    from harness.tools.builtin import register_builtin_tools

    register_builtin_tools(store)
    assert len(store.list()) == 2
    assert len(store.list(source="builtin")) == 2


def test_tool_store_explicit_registration(tool_store: ToolStore):
    assert tool_store.list() == []
    from harness.tools.builtin import register_builtin_tools

    register_builtin_tools(tool_store)
    assert len(tool_store.list()) == 2


def test_discover_via_mcp_discovery_sync(tool_store: ToolStore, mcp_discovery: McpDiscovery):
    from unittest.mock import AsyncMock, patch

    import anyio
    from core.schema import MCPServerConfig
    from langchain_core.tools import StructuredTool

    def _fake(name: str) -> StructuredTool:
        t = StructuredTool.from_function(func=lambda x: x, name=name, description="fake")
        t.metadata = {"readOnlyHint": True, "_source": "mcp"}
        return t

    async def _run():
        mcp_discovery.configure_mcp_servers([MCPServerConfig(name="calc-mcp")])
        fake = _fake("calc_tool")
        with patch(
            "langchain_mcp_adapters.client.MultiServerMCPClient.get_tools",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = [fake]
            res = await mcp_discovery.discover()
            assert "calc-mcp" in res
            tool_store.sync_mcp(res)
            assert len(tool_store.list()) == 1

    anyio.run(_run)


def test_discover_ttl_via_mcp_discovery(mcp_discovery: McpDiscovery):
    from unittest.mock import AsyncMock, patch

    import anyio
    from core.schema import MCPServerConfig
    from langchain_core.tools import StructuredTool

    def _fake(name: str) -> StructuredTool:
        t = StructuredTool.from_function(func=lambda x: x, name=name, description="fake")
        t.metadata = {}
        return t

    async def _run():
        mcp_discovery.configure_mcp_servers([MCPServerConfig(name="c")])
        fake = _fake("c_tool")
        with patch(
            "langchain_mcp_adapters.client.MultiServerMCPClient.get_tools",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = [fake]
            await mcp_discovery.discover(ttl=10)
            assert mcp_discovery._discover_count == 1
            await mcp_discovery.discover(ttl=10)
            assert mcp_discovery._discover_count == 1
            assert mock_get.call_count == 1
            await mcp_discovery.discover(ttl=10, refresh=True)
            assert mcp_discovery._discover_count == 2
            assert mock_get.call_count == 2

    anyio.run(_run)
