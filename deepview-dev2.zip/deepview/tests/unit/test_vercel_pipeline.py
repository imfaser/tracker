from vercel_adapter.pipeline import run_sync_pipeline, validate


def test_pipeline_validate():
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    assert validate(payload) == payload


def test_pipeline_validate_empty():
    import pytest

    with pytest.raises(ValueError):
        validate({"messages": []})


def test_run_sync_pipeline():
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    result = run_sync_pipeline(payload)
    assert isinstance(result, list)
    assert len(result) == 1
