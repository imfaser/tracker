import warnings

import pytest

warnings.filterwarnings("ignore", category=DeprecationWarning)

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

import anyio
from core.schema import HarnessConfig
from harness.agents.context import BaseContext
from harness.agents.math_agent import MathAgent
from harness.agents.supervisor_agent import SupervisorAgent


def test_create_math_subagent_has_tools():
    recipe = MathAgent().to_recipe(context=BaseContext())
    assert recipe["name"] == "math"
    assert len(recipe["tools"]) == 2
    assert {t.name for t in recipe["tools"]} == {"circle_area", "square_area"}


def test_create_supervisor_has_math_subagent_and_budget():
    async def _run():
        sup = SupervisorAgent(config=HarnessConfig(steps=10))
        graph = await sup.get_graph(context=BaseContext())
        assert graph is not None

    anyio.run(_run)


def test_create_supervisor_respects_config_budget():
    async def _run():
        sup = SupervisorAgent(config=HarnessConfig(steps=15))
        graph = await sup.get_graph(context=BaseContext())
        assert graph is not None

    anyio.run(_run)


def test_interrupt_requires_checkpointer():
    async def _run():
        sup = SupervisorAgent(config=HarnessConfig(steps=10))
        graph = await sup.get_graph(context=BaseContext(), interrupt_on={"circle_area": True})
        assert graph is not None

    anyio.run(_run)
