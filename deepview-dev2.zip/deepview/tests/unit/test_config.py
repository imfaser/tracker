from pathlib import Path

import pytest
from core.config import AppConfig, get_config
from core.schema import HarnessConfig, LoggingConfig, TelemetryConfig


def _write_jsonc(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "config.jsonc"
    p.write_text(text, encoding="utf-8")
    return p


def test_instance_with_empty_config_uses_default_level(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    assert AppConfig.instance().logging.level == "INFO"


def test_instance_with_logging_level_env_overrides_file(tmp_path, monkeypatch):
    monkeypatch.setenv(
        "CONFIG_FILE", str(_write_jsonc(tmp_path, '{"logging":{"level":"WARNING"}}'))
    )
    monkeypatch.setenv("LOGGING__LEVEL", "DEBUG")
    assert AppConfig.instance().logging.level == "DEBUG"


def test_instance_parses_jsonc_comments_and_trailing_commas(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    text = """
    {
      // 注释应被社区解析器忽略
      "logging": { "level": "ERROR", },   // 尾逗号
    }
    """
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, text)))
    assert AppConfig.instance().logging.level == "ERROR"


def test_instance_reads_config_file_from_config_env(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv(
        "CONFIG_FILE", str(_write_jsonc(tmp_path, '{"logging":{"level":"CRITICAL"}}'))
    )
    assert AppConfig.instance().logging.level == "CRITICAL"


def test_instance_returns_same_object_and_reset_creates_new(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    first = AppConfig.instance()
    assert AppConfig.instance() is first
    AppConfig.reset()
    assert AppConfig.instance() is not first


def test_get_config_returns_same_instance_and_reset_creates_new(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    AppConfig.reset()
    first = get_config()
    assert get_config() is first
    AppConfig.reset()
    assert get_config() is not first


def test_constructor_injection_isolated_from_singleton(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    cfg = AppConfig(logging=LoggingConfig(level="DEBUG"))
    assert cfg.logging.level == "DEBUG"
    assert AppConfig.instance().logging.level == "INFO"


def test_instance_with_invalid_jsonc_raises(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{ 这不是合法 json")))
    with pytest.raises(ValueError):
        AppConfig.instance()


def test_telemetry_defaults_none(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "TELEMETRY__TYPE", "TELEMETRY__PHOENIX__PROJECT_NAME"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.telemetry.type == "none"


def test_telemetry_nested_env_override_openobserve_org(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("TELEMETRY__OPENOBSERVE__ORG", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("TELEMETRY__OPENOBSERVE__ORG", "acme")
    assert AppConfig().telemetry.openobserve.org == "acme"


def test_telemetry_constructor_injection(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    cfg = AppConfig(telemetry=TelemetryConfig(type="phoenix", phoenix={"project_name": "x"}))
    assert cfg.telemetry.type == "phoenix"
    assert cfg.telemetry.phoenix.project_name == "x"


def test_harness_defaults_empty(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "HARNESS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.harness == {}
    assert cfg.mcp_servers == []


def test_harness_env_override(tmp_path, monkeypatch):
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("HARNESS__SUPERVISOR__STEPS", "12")
    cfg = AppConfig()
    assert cfg.harness["supervisor"].steps == 12


def test_harness_constructor_injection(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    cfg = AppConfig(harness={"supervisor": HarnessConfig(steps=15)})
    assert cfg.harness["supervisor"].steps == 15


def test_harness_steps_validation(tmp_path, monkeypatch):
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        AppConfig(harness={"supervisor": HarnessConfig(steps=0)})
    with pytest.raises(ValidationError):
        AppConfig(harness={"supervisor": HarnessConfig(steps=99)})


def test_harness_system_missing_raises(tmp_path, monkeypatch):
    from pydantic import ValidationError

    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    with pytest.raises(ValidationError):
        AppConfig(harness={"supervisor": HarnessConfig(system="./Agents/missing.md", steps=10)})


def test_bus_defaults(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "BUS__NATS_URL"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.bus.nats_url == "nats://localhost:4222"
    assert cfg.bus.stream_name == "deepview"


def test_bus_env_override(tmp_path, monkeypatch):
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("BUS__NATS_URL", "nats://192.168.16.24:6015")
    monkeypatch.setenv("BUS__STREAM_NAME", "deepview-prod")
    cfg = AppConfig()
    assert cfg.bus.nats_url == "nats://192.168.16.24:6015"
    assert cfg.bus.stream_name == "deepview-prod"


def test_bus_jsonc_override(tmp_path, monkeypatch):
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(
            _write_jsonc(
                tmp_path,
                '{"bus": {"nats_url": "nats://192.168.16.24:6015", "stream_name": "chat"}}',
            )
        ),
    )
    cfg = AppConfig()
    assert cfg.bus.nats_url == "nats://192.168.16.24:6015"
    assert cfg.bus.stream_name == "chat"


def test_extra_forbid(tmp_path, monkeypatch):
    from pydantic import ValidationError

    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    with pytest.raises(ValidationError):
        AppConfig.model_validate({"extra": {}})  # ty: ignore[invalid-argument-type]
