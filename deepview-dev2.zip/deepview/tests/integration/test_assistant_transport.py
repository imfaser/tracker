from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
from langchain_core.messages import AIMessage
from server.app import create_app


def _has_aui_state(body: bytes) -> bool:
    return b"aui-state" in body or b"append-text" in body


async def test_assistant_invalid_json_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/assistant", content=b"not json", headers={"Content-Type": "application/json"}
        )
        assert resp.status_code == 400


async def test_assistant_empty_commands_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/assistant", json={"commands": []})
        assert resp.status_code == 400


async def test_assistant_invalid_command_type_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/assistant",
            json={
                "commands": [
                    {
                        "type": "bad-type",
                        "message": {"role": "user", "parts": [{"type": "text", "text": "hi"}]},
                    }
                ]
            },
        )
        assert resp.status_code == 400


async def test_assistant_hi_returns_datastream_and_trace_headers(monkeypatch) -> None:
    mock_graph = MagicMock()

    async def fake_astream(*args, **kwargs):  # type: ignore[no-untyped-def]
        yield ("", "messages", AIMessage(content="Hello via assistant"))

    mock_graph.astream = fake_astream
    mock_supervisor = MagicMock()
    mock_supervisor.get_graph = AsyncMock(return_value=mock_graph)

    async def fake_get(*args, **kwargs):  # type: ignore[no-untyped-def]
        from harness.agents.supervisor_agent import SupervisorAgent

        if args and args[0] == SupervisorAgent:
            return mock_supervisor
        raise KeyError(args[0])

    monkeypatch.setattr(
        "server.container.make_container", lambda: MagicMock(get=AsyncMock(side_effect=fake_get))
    )

    app = create_app()
    payload = {
        "commands": [
            {
                "type": "add-message",
                "message": {"role": "user", "parts": [{"type": "text", "text": "hi"}]},
            }
        ]
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/assistant", json=payload)
        assert resp.status_code == 200
        assert resp.headers.get("X-Trace-Id") is not None
        assert resp.headers.get("X-Thread-Id") is not None
        assert _has_aui_state(resp.content) or resp.content != b""


async def test_assistant_add_tool_result_roundtrip(monkeypatch) -> None:
    mock_graph = MagicMock()

    async def fake_astream(*args, **kwargs):  # type: ignore[no-untyped-def]
        yield ("", "messages", AIMessage(content="done"))

    mock_graph.astream = fake_astream
    mock_supervisor = MagicMock()
    mock_supervisor.get_graph = AsyncMock(return_value=mock_graph)

    async def fake_get(*args, **kwargs):  # type: ignore[no-untyped-def]
        from harness.agents.supervisor_agent import SupervisorAgent

        if args and args[0] == SupervisorAgent:
            return mock_supervisor
        raise KeyError(args[0])

    monkeypatch.setattr(
        "server.container.make_container", lambda: MagicMock(get=AsyncMock(side_effect=fake_get))
    )

    app = create_app()
    payload = {
        "commands": [
            {
                "type": "add-tool-result",
                "toolCallId": "call_1",
                "toolName": "get_weather",
                "result": {"temp": 20},
            },
        ],
        "tools": {
            "get_weather": {
                "description": "weather",
                "parameters": {"type": "object", "properties": {"location": {"type": "string"}}},
            }
        },
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/assistant", json=payload)
        assert resp.status_code == 200


async def test_assistant_thread_id_persistence(monkeypatch) -> None:
    captured: dict = {}

    mock_graph = MagicMock()

    async def fake_astream(input_state, config=None, **kwargs):  # type: ignore[no-untyped-def]
        captured["thread_id"] = config.get("configurable", {}).get("thread_id") if config else None
        yield ("", "messages", AIMessage(content="ok"))

    mock_graph.astream = fake_astream
    mock_supervisor = MagicMock()
    mock_supervisor.get_graph = AsyncMock(return_value=mock_graph)

    async def fake_get(*args, **kwargs):  # type: ignore[no-untyped-def]
        from harness.agents.supervisor_agent import SupervisorAgent

        if args and args[0] == SupervisorAgent:
            return mock_supervisor
        raise KeyError(args[0])

    monkeypatch.setattr(
        "server.container.make_container",
        lambda: MagicMock(get=AsyncMock(side_effect=fake_get)),
    )

    app = create_app()
    payload = {
        "commands": [
            {
                "type": "add-message",
                "message": {"role": "user", "parts": [{"type": "text", "text": "hi"}]},
            }
        ],
        "threadId": "t-123",
    }
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/assistant", json=payload)
        assert resp.status_code == 200
        assert captured["thread_id"] == "t-123"
