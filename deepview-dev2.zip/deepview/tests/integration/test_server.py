import anyio
import anyio.lowlevel

import server


async def test_server_importable() -> None:
    await anyio.lowlevel.checkpoint()
    assert server is not None
