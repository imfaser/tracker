from __future__ import annotations

import json
from unittest.mock import AsyncMock

import httpx
from core.config import AppConfig
from server.app import create_app


def _parse_sse(body: bytes) -> list[dict]:
    out: list[dict] = []
    for line in body.decode().splitlines():
        if line.startswith("data: "):
            payload = line[len("data: ") :]
            if payload == "[DONE]":
                out.append({"type": "[DONE]"})
            else:
                out.append(json.loads(payload))
    return out


async def test_chat_stream_invalid_json_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/chat/stream", content=b"not json", headers={"Content-Type": "application/json"}
        )
        assert resp.status_code == 400


async def test_chat_stream_empty_messages_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json={"messages": []})
        assert resp.status_code == 400


async def test_chat_stream_invalid_role_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json={"messages": [{"role": "bad", "parts": []}]})
        assert resp.status_code == 400


async def test_chat_stream_fake_stream_headers_and_events(monkeypatch) -> None:
    mock_kiq = AsyncMock(return_value=None)
    mock_broker = AsyncMock()
    mock_broker.startup = AsyncMock(return_value=None)
    mock_broker.shutdown = AsyncMock(return_value=None)
    monkeypatch.setattr("server.bus.nats.get_broker", lambda cfg=None: mock_broker)
    monkeypatch.setattr("server.worker.chat_task.kiq", mock_kiq)
    monkeypatch.setattr("server.routers.chat.chat_task", AsyncMock(kiq=mock_kiq), raising=False)
    for var in ("MODEL", "BUS__NATS_URL"):
        monkeypatch.delenv(var, raising=False)
    AppConfig.reset()
    monkeypatch.setenv("CONFIG_FILE", "/tmp/nonexistent_chat_stream.jsonc")

    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        assert resp.headers["x-vercel-ai-ui-message-stream"] == "v1"
        assert resp.headers["content-type"].startswith("text/event-stream")
        events = _parse_sse(resp.content)
        types = [e["type"] for e in events]
        assert "start" in types
        assert "finish" in types
        assert types[-1] == "finish"


async def test_chat_stream_expose_trace_id_in_stream(monkeypatch) -> None:
    mock_kiq = AsyncMock(return_value=None)
    mock_broker = AsyncMock()
    mock_broker.startup = AsyncMock(return_value=None)
    monkeypatch.setattr("server.bus.nats.get_broker", lambda cfg=None: mock_broker)
    monkeypatch.setattr("server.worker.chat_task.kiq", mock_kiq)
    monkeypatch.setattr("server.routers.chat.chat_task", AsyncMock(kiq=mock_kiq), raising=False)
    monkeypatch.setenv("TELEMETRY__EXPOSE_TRACE_ID", "true")
    AppConfig.reset()
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        events = _parse_sse(resp.content)
        start = next(e for e in events if e["type"] == "start")
        if "messageMetadata" in start:
            assert "traceId" in start["messageMetadata"]
    monkeypatch.delenv("TELEMETRY__EXPOSE_TRACE_ID", raising=False)
    AppConfig.reset()


async def test_chat_stream_repeated_text_id_not_duplicated(monkeypatch) -> None:
    mock_kiq = AsyncMock(return_value=None)
    mock_broker = AsyncMock()
    mock_broker.startup = AsyncMock(return_value=None)
    monkeypatch.setattr("server.bus.nats.get_broker", lambda cfg=None: mock_broker)
    monkeypatch.setattr("server.worker.chat_task.kiq", mock_kiq)
    monkeypatch.setattr("server.routers.chat.chat_task", AsyncMock(kiq=mock_kiq), raising=False)
    AppConfig.reset()
    monkeypatch.setenv("CONFIG_FILE", "/tmp/nonexistent_chat_stream2.jsonc")
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hello"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        events = _parse_sse(resp.content)
        assert any(e["type"] in ("error", "finish") for e in events)


async def test_sync_stream() -> None:
    """同步链路冒烟：新 bus 无 enabled，直接验证 nats_url。"""
    from core.config import AppConfig as _AC

    AppConfig.reset()
    cfg = _AC()
    assert cfg.bus.nats_url == "nats://192.168.16.24:6015"


async def test_bus_stream(monkeypatch) -> None:
    """异步链路冒烟：mock broker 入队。"""
    mock_kiq = AsyncMock(return_value=None)
    mock_broker = AsyncMock()
    mock_broker.startup = AsyncMock(return_value=None)
    monkeypatch.setattr("server.bus.nats.get_broker", lambda cfg=None: mock_broker)
    monkeypatch.setattr("server.worker.chat_task.kiq", mock_kiq)
    monkeypatch.setattr("server.routers.chat.chat_task", AsyncMock(kiq=mock_kiq), raising=False)
    monkeypatch.setenv("BUS__NATS_URL", "nats://192.168.16.24:6015")
    AppConfig.reset()
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
