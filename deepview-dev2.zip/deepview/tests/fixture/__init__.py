import pytest

from .agent import mcp_discovery, tool_store
from .config import config, make_config, reset_config_singleton, reset_telemetry_state

__all__ = [
    "config",
    "example_value",
    "make_config",
    "mcp_discovery",
    "reset_config_singleton",
    "reset_telemetry_state",
    "tool_store",
]


@pytest.fixture
def example_value() -> int:
    return 42
