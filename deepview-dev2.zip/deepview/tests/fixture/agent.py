from collections.abc import Generator

import pytest
from harness.registry import McpDiscovery, ToolStore


@pytest.fixture
def tool_store() -> Generator[ToolStore]:
    store = ToolStore()
    yield store
    store.clear()


@pytest.fixture
def mcp_discovery() -> Generator[McpDiscovery]:
    disc = McpDiscovery()
    yield disc
    disc._mcp_tools_by_server.clear()
    disc._mcp_servers.clear()
    disc._last_discover = None
