from collections.abc import Generator

import pytest
from core.config import AppConfig
from telemetry import reset_telemetry as _reset_telemetry


@pytest.fixture(autouse=True)
def reset_config_singleton() -> Generator[None]:
    """每个测试前后清空配置单例，杜绝跨测试泄漏（配合 filterwarnings=error）。"""
    AppConfig.reset()
    yield
    AppConfig.reset()


@pytest.fixture(autouse=True)
def reset_telemetry_state() -> Generator[None]:
    """每个测试前后重置遥测全局状态，避免 TracerProvider 被重复设置（会触发告警）。"""
    _reset_telemetry()
    yield
    _reset_telemetry()


@pytest.fixture
async def dishka_container():  # type: ignore[no-untyped-def]
    """提供 Dishka 容器的测试夹具，支持 container.override。"""
    from server.container import make_container

    c = make_container()
    yield c
    import contextlib

    with contextlib.suppress(Exception):
        await c.close()


@pytest.fixture
def config() -> Generator[AppConfig]:
    """提供一个干净的 AppConfig 单例，需要配置的测试直接依赖它。"""
    yield AppConfig.instance()


@pytest.fixture
def make_config():
    """构造自定义配置的工厂（走构造入参，最高优先级，不污染单例）。"""

    def _make(**overrides) -> AppConfig:
        AppConfig.reset()
        return AppConfig(**overrides)

    return _make
