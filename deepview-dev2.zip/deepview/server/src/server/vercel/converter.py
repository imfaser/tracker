"""兼容层：转发至 vercel_adapter。"""

from vercel_adapter.converter import create_ui_message_stream_response, to_ui_message_stream_v7

__all__ = ["create_ui_message_stream_response", "to_ui_message_stream_v7"]
