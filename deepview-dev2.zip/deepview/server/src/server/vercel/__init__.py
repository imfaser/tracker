"""兼容层：实际实现已迁移至独立 package `vercel-adapter`。"""

from vercel_adapter import (
    create_ui_message_stream_response,
    to_base_messages_v7,
    to_ui_message_stream_v7,
)

__all__ = ["create_ui_message_stream_response", "to_base_messages_v7", "to_ui_message_stream_v7"]
