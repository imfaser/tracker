"""兼容层：转发至 vercel_adapter。"""

from vercel_adapter.messages import to_base_messages_v7

__all__ = ["to_base_messages_v7"]
