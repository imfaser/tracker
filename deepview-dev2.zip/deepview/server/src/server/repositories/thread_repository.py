from __future__ import annotations

from typing import Protocol

from pydantic import BaseModel


class ThreadDTO(BaseModel):
    id: str
    title: str
    created_at: str | None = None


class ThreadRepository(Protocol):
    async def list(self, limit: int = 100) -> list[ThreadDTO]: ...

    async def get(self, thread_id: str) -> ThreadDTO | None: ...

    async def create(self, thread_id: str, title: str | None = None) -> ThreadDTO: ...

    async def get_or_create(self, thread_id: str, title: str | None = None) -> ThreadDTO: ...

    async def update(self, thread_id: str, title: str | None = None) -> ThreadDTO: ...

    async def delete(self, thread_id: str) -> None: ...


class TortoiseThreadRepository:
    """基于 Tortoise ORM 的持久化实现。"""

    async def list(self, limit: int = 100) -> list[ThreadDTO]:
        from server.db.models import Thread

        rows = await Thread.all().order_by("-created_at").limit(limit)
        return [
            ThreadDTO(
                id=r.id,
                title=r.title,
                created_at=r.created_at.isoformat() if r.created_at else None,
            )
            for r in rows
        ]

    async def get(self, thread_id: str) -> ThreadDTO | None:
        from server.db.models import Thread

        obj = await Thread.get_or_none(id=thread_id)
        return (
            ThreadDTO(
                id=obj.id,
                title=obj.title,
                created_at=obj.created_at.isoformat() if obj.created_at else None,
            )
            if obj
            else None
        )

    async def create(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        from server.db.models import Thread

        obj = await Thread.create(id=thread_id, title=title or "New Thread")
        return ThreadDTO(id=obj.id, title=obj.title)

    async def get_or_create(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        try:
            from server.db.models import Thread

            obj, _ = await Thread.get_or_create(
                id=thread_id, defaults={"title": title or "New Thread"}
            )
            return ThreadDTO(id=obj.id, title=obj.title)
        except Exception:
            # Tortoise 未初始化时回退到内存（测试环境）
            from server.repositories.thread_repository import InMemoryThreadRepository

            return await InMemoryThreadRepository().get_or_create(thread_id, title)

    async def update(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        from server.db.models import Thread

        obj = await Thread.get_or_none(id=thread_id)
        if obj is None:
            obj = await Thread.create(id=thread_id, title=title or "New Thread")
        elif title:
            obj.title = title
            await obj.save()
        return ThreadDTO(id=obj.id, title=obj.title)

    async def delete(self, thread_id: str) -> None:
        from server.db.models import Thread

        await Thread.filter(id=thread_id).delete()


class InMemoryThreadRepository:
    """内存降级实现，仅用于测试或 DB 不可用时。"""

    def __init__(self) -> None:
        self._store: dict[str, ThreadDTO] = {}

    async def list(self, limit: int = 100) -> list[ThreadDTO]:
        return list(self._store.values())[:limit]

    async def get(self, thread_id: str) -> ThreadDTO | None:
        return self._store.get(thread_id)

    async def create(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        dto = ThreadDTO(id=thread_id, title=title or "New Thread")
        self._store[thread_id] = dto
        return dto

    async def get_or_create(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        if thread_id in self._store:
            return self._store[thread_id]
        return await self.create(thread_id, title)

    async def update(self, thread_id: str, title: str | None = None) -> ThreadDTO:
        dto = self._store.get(thread_id)
        if dto is None:
            return await self.create(thread_id, title)
        if title:
            dto.title = title
        self._store[thread_id] = dto
        return dto

    async def delete(self, thread_id: str) -> None:
        self._store.pop(thread_id, None)
