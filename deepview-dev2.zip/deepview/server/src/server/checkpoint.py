from __future__ import annotations

import asyncio
import importlib
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

_sqlite_ctx: Any | None = None
_sqlite_saver: Any | None = None
_pg_ctx: Any | None = None
_pg_saver: Any | None = None
_lock: asyncio.Lock | None = None


def _get_lock() -> asyncio.Lock:
    global _lock
    if _lock is None:
        _lock = asyncio.Lock()
    return _lock


def _sqlite_path() -> Path:
    raw = (
        os.getenv("LANGGRAPH_SQLITE_PATH")
        or os.getenv("SQLITE_PATH")
        or os.getenv("ASSISTANT_SQLITE_PATH")
        or "data/langgraph.sqlite3"
    )
    p = Path(raw)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[3] / p
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


async def _create_sqlite_saver() -> Any | None:
    try:
        mod = importlib.import_module("langgraph.checkpoint.sqlite.aio")
        sqlite_saver = mod.AsyncSqliteSaver  # type: ignore[attr-defined]
        path = _sqlite_path().resolve()
        conn_string = str(path)
        if not conn_string.startswith("sqlite"):
            conn_string = str(path)
        ctx = sqlite_saver.from_conn_string(conn_string)  # type: ignore[attr-defined]
        saver = await ctx.__aenter__()  # type: ignore[attr-defined]
        await saver.setup()  # type: ignore[attr-defined]
        return ctx, saver
    except Exception:
        return None


async def _create_pg_saver() -> Any | None:
    pg_url = os.getenv("LANGGRAPH_POSTGRES_URL") or os.getenv("DATABASE_URL")
    if not pg_url or not pg_url.startswith("postgres"):
        return None
    try:
        mod = importlib.import_module("langgraph.checkpoint.postgres.aio")
        pg_saver = mod.AsyncPostgresSaver  # type: ignore[attr-defined]
        ctx = pg_saver.from_conn_string(pg_url)  # type: ignore[attr-defined]
        saver = await ctx.__aenter__()  # type: ignore[attr-defined]
        await saver.setup()  # type: ignore[attr-defined]
        return ctx, saver
    except Exception:
        return None


async def configure_checkpointer_from_env() -> Any | None:
    global _sqlite_ctx, _sqlite_saver, _pg_ctx, _pg_saver
    async with _get_lock():
        if _pg_saver is not None:
            return _pg_saver
        if _sqlite_saver is not None:
            return _sqlite_saver
        pg = await _create_pg_saver()
        if pg is not None:
            _pg_ctx, _pg_saver = pg
            return _pg_saver
        sq = await _create_sqlite_saver()
        if sq is not None:
            _sqlite_ctx, _sqlite_saver = sq
            return _sqlite_saver
        return None


@asynccontextmanager
async def checkpointer_ctx() -> Any:
    saver = await configure_checkpointer_from_env()
    try:
        yield saver
    finally:
        pass


async def close_checkpointer() -> None:
    global _sqlite_ctx, _sqlite_saver, _pg_ctx, _pg_saver
    import contextlib

    async with _get_lock():
        for ctx in (_sqlite_ctx, _pg_ctx):
            if ctx is not None:
                with contextlib.suppress(Exception):
                    await ctx.__aexit__(None, None, None)  # type: ignore[attr-defined]
        _sqlite_ctx = None
        _sqlite_saver = None
        _pg_ctx = None
        _pg_saver = None


def get_in_memory_checkpointer() -> Any:
    from langgraph.checkpoint.memory import InMemorySaver

    return InMemorySaver()
