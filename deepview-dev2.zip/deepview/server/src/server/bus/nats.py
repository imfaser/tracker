"""NATS 总线与 taskiq broker。"""

from __future__ import annotations

from typing import Any

from core.config import AppConfig

_broker: Any | None = None


def _make_broker(cfg: AppConfig | None = None) -> Any:
    if cfg is None:
        from core import get_config

        cfg = get_config()
    try:
        from taskiq_nats import NatsBroker  # type: ignore

        return NatsBroker(cfg.bus.nats_url)  # type: ignore[call-arg]
    except Exception as e:
        msg = f"nats broker unreachable: {cfg.bus.nats_url}"
        raise ConnectionError(msg) from e


def get_broker(cfg: AppConfig | None = None) -> Any:
    global _broker
    if _broker is None:
        _broker = _make_broker(cfg)
    return _broker


class _DummyBroker:
    def task(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        def decorator(func):  # type: ignore[no-untyped-def]
            return func

        return decorator

    async def kick(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        return None

    async def startup(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        return None

    async def shutdown(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        return None

    # 兼容旧 kiq
    kiq = kick


try:
    broker = get_broker()
except ConnectionError:
    broker = _DummyBroker()


async def ensure_stream(cfg: AppConfig) -> None:
    """确保 JetStream stream 存在（幂等）。"""
    import nats

    try:
        nc = await nats.connect(cfg.bus.nats_url)  # type: ignore[attr-defined]
    except Exception as e:
        msg = f"nats unreachable: {cfg.bus.nats_url}"
        raise ConnectionError(msg) from e
    js = nc.jetstream()
    await js.add_stream(
        name=cfg.bus.stream_name,
        subjects=[
            f"{cfg.bus.subject_prefix}.request.*",
            f"{cfg.bus.subject_prefix}.response.*",
        ],
    )
    await nc.close()
