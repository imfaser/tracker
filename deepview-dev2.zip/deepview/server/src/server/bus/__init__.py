"""异步总线。"""

from __future__ import annotations

from server.bus.nats import broker, get_broker

__all__ = ["broker", "get_broker"]
