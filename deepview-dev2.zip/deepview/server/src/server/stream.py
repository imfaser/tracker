from __future__ import annotations

from typing import Any, Protocol


class StreamController(Protocol):
    state: dict[str, Any]

    def append_text(self, text: str) -> None: ...

    def append_reasoning(self, text: str) -> None: ...
