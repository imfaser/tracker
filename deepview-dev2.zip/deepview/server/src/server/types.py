from __future__ import annotations

from typing import Any, TypedDict, Union

JsonValue = Union[str, int, float, bool, None, list["JsonValue"], dict[str, "JsonValue"]]  # type: ignore[type-arg]


class ToolDefinition(TypedDict, total=False):
    description: str
    parameters: dict[str, Any]
    disabled: bool


class ThreadResponse(TypedDict):
    id: str
    thread_id: str
    title: str
    created_at: str | None


class ThreadsResponse(TypedDict):
    threads: list[ThreadResponse]
