"""taskiq worker：chat_task。"""

from __future__ import annotations

import contextlib
from typing import Any

from dishka.integrations.taskiq import FromDishka, inject, setup_dishka
from harness.agents.supervisor_agent import SupervisorAgent

from server.bus.nats import broker
from server.container import make_container

container = make_container()

with contextlib.suppress(Exception):
    setup_dishka(container, broker)  # type: ignore[arg-type, invalid-argument-type]  # ty: ignore[invalid-argument-type]


@broker.task  # type: ignore[attr-defined]
@inject(patch_module=True)
async def chat_task(
    payload: dict[str, Any],
    thread_id: str,
    supervisor: FromDishka[SupervisorAgent],
) -> dict[str, Any]:
    """消费 chat.request.{thread_id}，经 REQUEST 域隔离执行。"""
    from harness.agents.context import BaseContext

    ctx = BaseContext(thread_id=thread_id, uid=thread_id)
    graph = await supervisor.get_graph(context=ctx)  # type: ignore[union-attr]
    messages = payload.get("messages", [])
    from langchain_core.messages import HumanMessage

    lc_msgs = [
        HumanMessage(content=str(m.get("content", ""))) for m in messages if isinstance(m, dict)
    ]
    result = await graph.ainvoke(
        {"messages": lc_msgs},
        config={"configurable": {"thread_id": thread_id, "uid": thread_id}},
        context=ctx,
    )
    return {"thread_id": thread_id, "result": str(result)}


async def _run_worker() -> None:
    await broker.startup()
    try:
        while True:
            import asyncio

            await asyncio.sleep(3600)
    finally:
        await broker.shutdown()


if __name__ == "__main__":
    import asyncio

    asyncio.run(_run_worker())
