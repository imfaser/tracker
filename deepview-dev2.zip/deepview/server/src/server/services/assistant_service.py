from __future__ import annotations

import contextlib
from typing import Any

from langchain_core.messages import AIMessageChunk, HumanMessage, ToolMessage


class AssistantService:
    """薄服务层：仅组装图与流，不做 HTTP 校验。"""

    def __init__(self, supervisor: Any, checkpointer_factory: Any, app_config: Any) -> None:
        self._supervisor = supervisor
        self._checkpointer_factory = checkpointer_factory
        self._app_config = app_config

    async def stream(
        self,
        thread_id: str,
        input_messages: list[HumanMessage | ToolMessage],
        controller: Any,
        request: Any,
        tools: dict[str, Any] | None = None,
    ) -> None:
        from assistant_stream.modules.langgraph import (
            append_langgraph_event,
            get_tool_call_subgraph_state,
        )
        from harness.agents.context import BaseContext
        from langgraph.types import Command

        checkpointer = None
        with contextlib.suppress(Exception):
            checkpointer = await self._checkpointer_factory()

        graph_kwargs: dict[str, Any] = {}
        if checkpointer is not None:
            graph_kwargs["checkpointer"] = checkpointer

        deepview_ctx = BaseContext(thread_id=thread_id, uid=thread_id)
        with contextlib.suppress(Exception):
            graph_kwargs["context"] = deepview_ctx

        graph = await self._supervisor.get_graph(**graph_kwargs)

        cfg: dict[str, Any] = {
            "configurable": {"thread_id": thread_id, "uid": thread_id},
            "recursion_limit": 10,
        }
        with contextlib.suppress(Exception):
            supervisor_cfg = (
                self._app_config.harness.get("supervisor")
                if isinstance(self._app_config.harness, dict)
                else None
            )
            if supervisor_cfg is not None and hasattr(supervisor_cfg, "steps"):
                cfg["recursion_limit"] = int(supervisor_cfg.steps)  # type: ignore[arg-type]

        input_state: Any = {"messages": input_messages}
        if tools and isinstance(input_state, dict):
            input_state["tools"] = tools

        has_interrupt = False
        resume_value: Any = None
        with contextlib.suppress(Exception):
            state = await graph.aget_state(cfg)  # type: ignore[arg-type]
            if state is not None:
                tasks = getattr(state, "tasks", None)
                if tasks:
                    for task in tasks:
                        intrs = getattr(task, "interrupts", None)
                        if intrs:
                            has_interrupt = True
                            break
                vals = getattr(state, "values", None)
                if not has_interrupt and isinstance(vals, dict) and "__interrupt__" in vals:
                    has_interrupt = bool(vals.get("__interrupt__"))
                if not has_interrupt and hasattr(state, "next") and state.next:
                    with contextlib.suppress(Exception):
                        for nxt in state.next:  # type: ignore[attr-defined]
                            if nxt:
                                has_interrupt = True
                                break

        if has_interrupt:
            for m in reversed(input_messages):
                if isinstance(m, ToolMessage):
                    resume_value = m.content
                    break
            if resume_value is None and input_messages:
                resume_value = getattr(input_messages[-1], "content", "")
            try:
                if isinstance(resume_value, str):
                    with contextlib.suppress(Exception):
                        import json as _j

                        parsed = _j.loads(resume_value)
                        if isinstance(parsed, dict) and "answer" in parsed:
                            resume_value = parsed.get("answer")
                input_state = Command(resume=resume_value if resume_value is not None else "")
            except Exception:  # noqa: BLE001
                input_state = Command(resume=str(resume_value) if resume_value else "")

        seen_reasoning: set[str] = set()

        async for namespace, event_type, chunk in graph.astream(
            input_state,
            config=cfg,
            stream_mode=["messages", "updates"],
            subgraphs=True,
            context=deepview_ctx,
        ):  # type: ignore[arg-type]
            if await request.is_disconnected():
                break
            with contextlib.suppress(Exception):
                if event_type == "messages":
                    msg_chunk = (
                        chunk[0] if isinstance(chunk, (list, tuple)) and len(chunk) >= 1 else chunk
                    )
                    if isinstance(msg_chunk, AIMessageChunk):
                        add_kw = getattr(msg_chunk, "additional_kwargs", {}) or {}
                        reasoning = add_kw.get("reasoning_content")
                        if (
                            isinstance(reasoning, str)
                            and reasoning
                            and reasoning not in seen_reasoning
                        ):
                            with contextlib.suppress(Exception):
                                controller.append_reasoning(reasoning)  # type: ignore[union-attr]
                            seen_reasoning.add(reasoning)
                        content = getattr(msg_chunk, "content", "")
                        if isinstance(content, list):
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "reasoning":
                                    txt = str(block.get("reasoning") or block.get("text") or "")
                                    if txt and txt not in seen_reasoning:
                                        with contextlib.suppress(Exception):
                                            controller.append_reasoning(txt)  # type: ignore[union-attr]
                                        seen_reasoning.add(txt)
                state = get_tool_call_subgraph_state(
                    controller,
                    subgraph_node=["tools", "task"],
                    namespace=namespace,
                    artifact_field_name="subgraph_state",
                    default_state={},
                )
                append_langgraph_event(state, namespace, event_type, chunk)
