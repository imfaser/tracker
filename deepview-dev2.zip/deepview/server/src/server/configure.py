from __future__ import annotations

from core import configure_logging
from core.config import AppConfig
from harness.registry import McpDiscovery, ToolStore, configure_tools
from harness.tools.builtin import register_builtin_tools
from telemetry import bootstrap_telemetry


def bootstrap_app(
    cfg: AppConfig,
    store: ToolStore | None = None,
    discovery: McpDiscovery | None = None,
) -> None:
    configure_logging(cfg.logging)
    effective_store = store
    if effective_store is None:
        effective_store = ToolStore()
        register_builtin_tools(effective_store)
    effective_discovery = discovery or McpDiscovery()
    if cfg.mcp_servers:
        effective_discovery.configure_mcp_servers(cfg.mcp_servers)
    configure_tools(cfg, store=effective_store, discovery=effective_discovery)
    bootstrap_telemetry(cfg.telemetry)


# 兼容旧名
configure_app = bootstrap_app
