"""FastAPI 应用工厂与 lifespan。"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from server.routers.assistant import router as assistant_router
from server.routers.chat import router as chat_router


def create_app() -> FastAPI:
    """创建 FastAPI 应用（纯净，无容器）。"""
    from tortoise.contrib.fastapi import register_tortoise

    from server.db import TORTOISE_ORM

    app = FastAPI()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Trace-Id", "X-Thread-Id", "traceparent"],
    )

    app.include_router(chat_router)
    app.include_router(assistant_router)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/ready")
    async def ready() -> dict[str, str]:
        return {"status": "ready"}

    register_tortoise(
        app,
        config=TORTOISE_ORM,
        generate_schemas=True,
        add_exception_handlers=True,
    )

    return app


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    from core.config import AppConfig
    from harness.registry import McpDiscovery, ToolStore
    from telemetry import teardown_telemetry

    from server.configure import bootstrap_app
    from server.container import make_container

    container = make_container()
    app.state.container = container
    cfg = await container.get(AppConfig)
    store = await container.get(ToolStore)  # type: ignore[assignment]
    discovery = await container.get(McpDiscovery)  # type: ignore[assignment]
    bootstrap_app(cfg, store=store, discovery=discovery)  # type: ignore[arg-type]
    with contextlib.suppress(Exception):
        await discovery.discover()  # type: ignore[union-attr]
    app.state.config = cfg
    app.state.tool_store = store
    app.state.mcp_discovery = discovery
    try:
        yield
    finally:
        with contextlib.suppress(Exception):
            from server.checkpoint import close_checkpointer

            await close_checkpointer()
        with contextlib.suppress(Exception):
            teardown_telemetry()
        with contextlib.suppress(Exception):
            await container.close()


def create_production_app() -> FastAPI:
    """创建生产 FastAPI 应用（带容器与 lifespan）。"""
    from dishka.integrations.fastapi import setup_dishka

    from server.container import make_container

    app = create_app()
    container = make_container()
    setup_dishka(container, app)
    app.state.container = container

    tortoise_lifespan = app.router.lifespan_context  # type: ignore[assignment]

    @asynccontextmanager
    async def prod_lifespan(app: FastAPI) -> AsyncIterator[None]:
        from core.config import AppConfig
        from harness.agents.supervisor_agent import SupervisorAgent
        from harness.registry import McpDiscovery, ToolStore
        from telemetry import teardown_telemetry

        from server.configure import bootstrap_app

        async with tortoise_lifespan(app):  # type: ignore[misc]
            cfg = await container.get(AppConfig)
            store = await container.get(ToolStore)  # type: ignore[assignment]
            discovery = await container.get(McpDiscovery)  # type: ignore[assignment]
            supervisor = await container.get(SupervisorAgent)  # type: ignore[assignment]
            bootstrap_app(cfg, store=store, discovery=discovery)  # type: ignore[arg-type]
            with contextlib.suppress(Exception):
                await discovery.discover()  # type: ignore[union-attr]
            app.state.config = cfg
            app.state.tool_store = store
            app.state.mcp_discovery = discovery
            app.state.supervisor = supervisor
            try:
                yield
            finally:
                with contextlib.suppress(Exception):
                    from server.checkpoint import close_checkpointer

                    await close_checkpointer()
                with contextlib.suppress(Exception):
                    teardown_telemetry()
                with contextlib.suppress(Exception):
                    await container.close()

    app.router.lifespan_context = prod_lifespan  # type: ignore[assignment]
    return app
