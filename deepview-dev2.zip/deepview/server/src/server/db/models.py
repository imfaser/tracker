from __future__ import annotations

from tortoise import fields
from tortoise.models import Model


class Thread(Model):
    """线程记录。"""

    id = fields.CharField(primary_key=True, max_length=128)  # type: ignore[assignment]  # why: tortoise stubs 需要
    title = fields.CharField(max_length=512, default="New Thread")  # type: ignore[assignment]  # why: tortoise stubs 需要
    created_at = fields.DatetimeField(auto_now_add=True)  # type: ignore[assignment]  # why: tortoise stubs 需要
    updated_at = fields.DatetimeField(auto_now=True)  # type: ignore[assignment]  # why: tortoise stubs 需要
    metadata = fields.JSONField(null=True)  # type: ignore[assignment]  # why: 兼容旧数据

    class Meta:
        table = "threads"
