from __future__ import annotations

import os
from pathlib import Path

from tortoise import Tortoise


def _db_url() -> str:
    url = os.getenv("DATABASE_URL") or os.getenv("TORTOISE_ORM_DB_URL")
    if url and url.startswith("sqlite"):
        return url
    raw = os.getenv("SQLITE_PATH") or os.getenv("ASSISTANT_SQLITE_PATH") or "data/app.sqlite3"
    p = Path(raw)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[4] / p
    p.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite://{p}"


TORTOISE_ORM = {
    "connections": {"default": _db_url()},
    "apps": {
        "models": {
            "models": ["server.db.models"],
            "default_connection": "default",
        }
    },
}

TORTOISE_ORM_CONFIG = TORTOISE_ORM


async def init_db() -> None:
    import contextlib

    await Tortoise.init(
        db_url=_db_url(),
        modules={"models": ["server.db.models"]},
    )
    await Tortoise.generate_schemas()
    with contextlib.suppress(Exception):
        conn = Tortoise.get_connection("default")
        await conn.execute_query("PRAGMA journal_mode=DELETE;")
        await conn.execute_query("PRAGMA synchronous=NORMAL;")


async def close_db() -> None:
    import contextlib

    with contextlib.suppress(Exception):
        conn = Tortoise.get_connection("default")
        await conn.execute_query("PRAGMA wal_checkpoint(TRUNCATE);")
    await Tortoise.close_connections()
