from __future__ import annotations

from typing import Any

from core.config import AppConfig
from dishka import Marker, Provider, Scope, activate, provide
from dishka.integrations.taskiq import TaskiqProvider
from harness.agents.supervisor_agent import SupervisorAgent
from harness.registry import McpDiscovery, ToolStore
from langchain_core.language_models import BaseChatModel
from telemetry.backends.openobserve import OpenObserveBackend
from telemetry.backends.phoenix import PhoenixBackend

telemetry_phoenix = Marker("telemetry_phoenix")
telemetry_openobserve = Marker("telemetry_openobserve")


class AppProvider(Provider):
    @provide(scope=Scope.APP)
    def cfg(self) -> AppConfig:
        return AppConfig()


class TelemetryProvider(Provider):
    @provide(scope=Scope.APP, when=telemetry_phoenix)
    def phoenix(self, cfg: AppConfig) -> PhoenixBackend:
        return PhoenixBackend(cfg.telemetry.phoenix)

    @provide(scope=Scope.APP, when=telemetry_openobserve)
    def openobserve(self, cfg: AppConfig) -> OpenObserveBackend:
        return OpenObserveBackend(cfg.telemetry.openobserve)

    @activate(telemetry_phoenix)
    def use_phoenix(self, cfg: AppConfig) -> bool:
        return cfg.telemetry.type == "phoenix"

    @activate(telemetry_openobserve)
    def use_openobserve(self, cfg: AppConfig) -> bool:
        return cfg.telemetry.type == "openobserve"


class BusProvider(Provider):
    @provide(scope=Scope.APP)
    def bus(self, cfg: AppConfig) -> Any:
        from server.bus.nats import get_broker

        return get_broker(cfg)


class LlmProvider(Provider):
    @provide(scope=Scope.APP)
    def chat_model(self, cfg: AppConfig) -> BaseChatModel:
        from llm.maker import make_chat_model

        return make_chat_model(cfg.model, cfg.providers)


class HarnessProvider(Provider):
    @provide(scope=Scope.APP)
    def tool_store(self) -> ToolStore:
        from harness.tools.builtin import register_builtin_tools

        store = ToolStore()
        register_builtin_tools(store)
        return store

    @provide(scope=Scope.APP)
    def mcp_discovery(self, cfg: AppConfig) -> McpDiscovery:
        disc = McpDiscovery()
        if cfg.mcp_servers:
            disc.configure_mcp_servers(cfg.mcp_servers)
        return disc

    @provide(scope=Scope.APP)
    def supervisor(self, cfg: AppConfig, model: BaseChatModel) -> SupervisorAgent:
        harness_cfg = cfg.harness.get("supervisor") if isinstance(cfg.harness, dict) else None
        return SupervisorAgent(config=harness_cfg, model=model)


def make_container():  # type: ignore[no-untyped-def]
    from dishka import make_async_container

    return make_async_container(
        AppProvider(),
        TelemetryProvider(),
        BusProvider(),
        LlmProvider(),
        HarnessProvider(),
        TaskiqProvider(),
    )
