from __future__ import annotations

from fastapi import APIRouter
from server.routers.runs import router as runs_router
from server.routers.threads import router as threads_router
from server.routers.transport import router as transport_router

router = APIRouter(tags=["assistant"])
router.include_router(threads_router)
router.include_router(transport_router)
router.include_router(runs_router)
