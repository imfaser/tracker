from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from server.repositories.thread_repository import TortoiseThreadRepository

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/assistant/threads", tags=["assistant-threads"])


@router.get("", response_model=None)
@router.get("/", response_model=None)
async def list_threads() -> Any:
    try:
        repo = TortoiseThreadRepository()
        rows = await repo.list(limit=100)
        return {"threads": [r.model_dump() for r in rows]}
    except Exception as e:
        logger.warning("list_threads fallback", exc_info=e)
        return {"threads": []}


@router.post("", response_model=None)
@router.post("/", response_model=None)
async def create_thread(request: Request) -> Any:
    try:
        body = await request.json()
    except (ValueError, TypeError) as e:
        logger.warning("create_thread invalid json", exc_info=e)
        body = {}
    thread_id = (
        body.get("threadId")
        or body.get("thread_id")
        or body.get("id")
        or f"thread_{uuid.uuid4().hex[:12]}"
    )
    title = body.get("title") or body.get("name") or "New Thread"
    repo = TortoiseThreadRepository()
    try:
        dto = await repo.get_or_create(thread_id, title)
        return {"id": dto.id, "thread_id": dto.id, "title": dto.title}
    except Exception as e:
        logger.warning("create_thread fallback", exc_info=e)
        return {"id": thread_id, "thread_id": thread_id, "title": title}


@router.get("/{thread_id}", response_model=None)
async def get_thread(thread_id: str) -> Any:
    repo = TortoiseThreadRepository()
    dto = await repo.get(thread_id)
    if dto is None:
        return JSONResponse(status_code=404, content={"detail": "thread not found"})
    return {"id": dto.id, "thread_id": dto.id, "title": dto.title}


@router.delete("/{thread_id}", response_model=None)
async def delete_thread(thread_id: str) -> Any:
    repo = TortoiseThreadRepository()
    await repo.delete(thread_id)
    return {"status": "ok"}


@router.patch("/{thread_id}", response_model=None)
async def update_thread(thread_id: str, request: Request) -> Any:
    try:
        body = await request.json()
    except (ValueError, TypeError) as e:
        logger.warning("update_thread invalid json", exc_info=e)
        body = {}
    title = body.get("title") or body.get("name")
    repo = TortoiseThreadRepository()
    dto = await repo.update(thread_id, title)
    return {"id": dto.id, "thread_id": dto.id, "title": dto.title}
