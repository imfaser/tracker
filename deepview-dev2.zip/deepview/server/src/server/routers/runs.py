from __future__ import annotations

import contextlib
import json
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from langchain_core.messages import HumanMessage, ToolMessage

router = APIRouter(prefix="/assistant/threads/{thread_id}/runs", tags=["assistant-runs"])


def _extract_messages(body: dict[str, Any]) -> list[HumanMessage | ToolMessage]:
    msgs: list[HumanMessage | ToolMessage] = []
    inp = body.get("input") or {}
    raw_list = inp.get("messages") or body.get("messages") or []
    for m in raw_list:
        if not isinstance(m, dict):
            continue
        m_type = m.get("type") or m.get("role")
        content = m.get("content") or ""
        if isinstance(content, list):
            content = " ".join(
                str(p.get("text") or p) if isinstance(p, dict) else str(p) for p in content
            )
        tool_call_id = m.get("tool_call_id") or m.get("toolCallId") or m.get("id") or ""
        tool_name = m.get("name") or m.get("toolName") or ""
        if m_type in ("human", "user") and content:
            msgs.append(HumanMessage(content=str(content), id=m.get("id")))
        elif m_type == "tool" or (m_type == "assistant" and tool_call_id):
            out = content
            if isinstance(m.get("output"), str):
                out = m["output"]
            elif m.get("output") is not None:
                out = json.dumps(m["output"], ensure_ascii=False)
            msgs.append(
                ToolMessage(content=str(out), tool_call_id=str(tool_call_id), name=str(tool_name))
            )
        elif m_type in ("tool", "tool_result"):
            out = content
            msgs.append(
                ToolMessage(content=str(out), tool_call_id=str(tool_call_id), name=str(tool_name))
            )
    if not msgs:
        for m in raw_list:
            if isinstance(m, dict) and m.get("role") == "user":
                txt = ""
                parts = m.get("parts") or []
                if isinstance(parts, list):
                    txt = " ".join(
                        str(p.get("text") or "")
                        for p in parts
                        if isinstance(p, dict) and p.get("type") == "text"
                    )
                if not txt:
                    txt = str(m.get("content") or "")
                if txt:
                    msgs.append(HumanMessage(content=txt))
    return msgs


@router.post("/stream", response_model=None)
@router.post("", response_model=None)
async def runs_stream(thread_id: str, request: Request) -> Any:
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": "invalid json"})

    with contextlib.suppress(Exception):
        from server.repositories.thread_repository import TortoiseThreadRepository

        await TortoiseThreadRepository().get_or_create(thread_id)

    input_messages = _extract_messages(body)
    if not input_messages:
        return JSONResponse(status_code=400, content={"detail": "no messages"})

    try:
        from assistant_stream import create_run
        from assistant_stream.serialization import DataStreamResponse
    except Exception as exc:
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    try:
        from harness.agents.supervisor_agent import SupervisorAgent
        from server.checkpoint import configure_checkpointer_from_env
        from server.container import make_container
        from server.services.assistant_service import AssistantService
    except Exception as exc:
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    container = getattr(request.app.state, "container", None)  # type: ignore[union-attr]
    if container is None:
        try:
            container = make_container()
        except Exception as exc:
            return JSONResponse(status_code=500, content={"detail": str(exc)})

    async def run_callback(controller: Any) -> None:  # type: ignore[no-untyped-def]
        from core.config import AppConfig

        supervisor = await container.get(SupervisorAgent)  # type: ignore[union-attr]
        try:
            app_cfg = await container.get(AppConfig)  # type: ignore[arg-type]
        except Exception:
            app_cfg = AppConfig()
        svc = AssistantService(supervisor, configure_checkpointer_from_env, app_cfg)
        await svc.stream(thread_id, input_messages, controller, request, body.get("tools"))

    stream = create_run(run_callback, state=body.get("state"))
    resp = DataStreamResponse(stream)
    resp.headers["X-Thread-Id"] = thread_id
    resp.headers["X-Trace-Id"] = uuid.uuid4().hex
    return resp
