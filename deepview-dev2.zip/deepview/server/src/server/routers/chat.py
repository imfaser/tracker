"""聊天流式路由。"""

from __future__ import annotations

import contextlib
import uuid
from typing import Any

from core import get_config
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from vercel_adapter import to_base_messages_v7

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatStreamRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    messages: list[dict[str, Any]] = Field(min_length=1)
    id: str | None = None
    thread_id: str | None = Field(default=None, alias="thread_id")
    threadId: str | None = Field(default=None, alias="threadId")

    @property
    def resolved_thread_id(self) -> str | None:
        if self.id:
            return self.id
        if self.thread_id:
            return self.thread_id
        if self.threadId:
            return self.threadId
        if self.model_extra:
            for key in ("threadId", "thread_id", "id"):
                val = self.model_extra.get(key)
                if isinstance(val, str) and val:
                    return val
        return None


@router.post("/stream", response_model=None)
async def chat_stream(request: Request) -> Any:
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": "invalid json"})
    try:
        payload = ChatStreamRequest.model_validate(body)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    for idx, m in enumerate(payload.messages):
        if m.get("role") not in ("user", "assistant", "system", "tool"):
            return JSONResponse(
                status_code=400, content={"detail": f"message {idx} has invalid role"}
            )
    try:
        base_messages = to_base_messages_v7(payload.messages)
    except (ValueError, TypeError) as exc:
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    thread_id = payload.resolved_thread_id or f"thread_{uuid.uuid4().hex}"
    cfg = get_config()
    with contextlib.suppress(Exception):
        state = getattr(getattr(request, "app", None), "state", None)
        c = getattr(state, "container", None) if state is not None else None
        if c is not None:
            from core.config import AppConfig as _AC

            with contextlib.suppress(Exception):
                cfg = await c.get(_AC)  # type: ignore[assignment]
    with contextlib.suppress(Exception):
        from server.bus.nats import get_broker

        b = get_broker(cfg)
        await b.startup()  # type: ignore[attr-defined]
    with contextlib.suppress(Exception):
        from server.worker import chat_task

        await chat_task.kiq(payload.model_dump(), thread_id)  # type: ignore[attr-defined]

    async def subscribe_stream() -> Any:
        import anyio
        from opentelemetry import trace as _trace
        from vercel_adapter.service import _chat_stream

        tracer = _trace.get_tracer("deepview.server")
        span = tracer.start_span("chat.stream.bus")
        try:
            async for chunk in _chat_stream(
                request, span, None, cfg, base_messages, thread_id, False, span.end
            ):
                if await request.is_disconnected():
                    with contextlib.suppress(Exception):
                        span.set_attribute("chat.cancelled", True)
                    break
                yield chunk
                await anyio.lowlevel.checkpoint()  # type: ignore[attr-defined]
        finally:
            with contextlib.suppress(Exception):
                span.end()

    from vercel_adapter.converter import create_ui_message_stream_response

    return create_ui_message_stream_response(subscribe_stream(), thread_id=thread_id)
