from __future__ import annotations

import contextlib
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from langchain_core.messages import HumanMessage, ToolMessage
from pydantic import BaseModel, ConfigDict, Field
from server.repositories.thread_repository import TortoiseThreadRepository

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/assistant", tags=["assistant-transport"])


class MessagePart(BaseModel):
    type: str
    text: str | None = None
    image: str | None = None


class UserMessage(BaseModel):
    role: str = "user"
    parts: list[MessagePart]


from typing import Literal


class AddMessageCommand(BaseModel):
    type: Literal["add-message"] = "add-message"
    message: UserMessage


class AddToolResultCommand(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    type: Literal["add-tool-result"] = "add-tool-result"
    tool_call_id: str = Field(alias="toolCallId")
    tool_name: str | None = Field(default=None, alias="toolName")
    result: Any = None
    is_error: bool | None = Field(default=None, alias="isError")
    artifact: Any | None = None
    model_content: Any | None = Field(default=None, alias="modelContent")


class ChatRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    commands: list[AddMessageCommand | AddToolResultCommand]  # type: ignore[type-arg]
    system: str | None = None
    tools: dict[str, Any] | None = None
    thread_id: str | None = Field(default=None, alias="threadId")
    state: dict[str, Any] | None = None

    @property
    def resolved_thread_id(self) -> str | None:
        if self.thread_id:
            return self.thread_id
        if self.model_extra:
            for k in ("threadId", "thread_id", "id"):
                v = self.model_extra.get(k)  # type: ignore[union-attr]
                if isinstance(v, str) and v:
                    return v
        return None


def _get_thread_id(payload: ChatRequest) -> str:
    return payload.resolved_thread_id or f"anonymous-{uuid.uuid4()}"


@router.post("", response_model=None)
@router.post("/", response_model=None)
async def transport_chat(request: Request) -> Any:
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": "invalid json"})
    try:
        payload = ChatRequest.model_validate(body)
    except Exception as exc:
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    if not payload.commands:
        return JSONResponse(status_code=400, content={"detail": "commands must not be empty"})

    input_messages: list[HumanMessage | ToolMessage] = []
    for cmd in payload.commands:
        if isinstance(cmd, AddMessageCommand):
            text = " ".join(p.text or "" for p in cmd.message.parts if p.type == "text" and p.text)
            if text:
                input_messages.append(HumanMessage(content=text))
        elif isinstance(cmd, AddToolResultCommand):
            content = cmd.model_content if cmd.model_content is not None else cmd.result
            content = (
                content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
            )
            input_messages.append(
                ToolMessage(
                    content=content, tool_call_id=cmd.tool_call_id, name=cmd.tool_name or ""
                )
            )

    if not input_messages:
        return JSONResponse(status_code=400, content={"detail": "no valid messages"})

    thread_id = _get_thread_id(payload)
    try:
        await TortoiseThreadRepository().get_or_create(thread_id)
    except Exception as e:
        logger.warning("ensure thread failed", exc_info=e)

    try:
        from assistant_stream import create_run
        from assistant_stream.serialization import DataStreamResponse
    except Exception as exc:
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    try:
        from harness.agents.supervisor_agent import SupervisorAgent
        from server.checkpoint import configure_checkpointer_from_env
        from server.container import make_container
        from server.services.assistant_service import AssistantService
    except Exception as exc:
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    container = getattr(request.app.state, "container", None)  # type: ignore[union-attr]
    if container is None:
        try:
            container = make_container()
        except Exception as exc:
            return JSONResponse(status_code=500, content={"detail": str(exc)})

    with contextlib.suppress(Exception):
        from opentelemetry import trace as _trace

        tracer = _trace.get_tracer("deepview.server")
        span = tracer.start_span("assistant.transport")
        span.set_attribute("openinference.span.kind", "CHAIN")
        span.set_attribute("session.id", thread_id)

    async def run_callback(controller: Any) -> None:  # type: ignore[no-untyped-def]
        from core.config import AppConfig

        supervisor = await container.get(SupervisorAgent)  # type: ignore[union-attr]
        try:
            app_cfg = await container.get(AppConfig)  # type: ignore[arg-type]
        except Exception:
            app_cfg = AppConfig()
        svc = AssistantService(supervisor, configure_checkpointer_from_env, app_cfg)
        await svc.stream(thread_id, input_messages, controller, request, payload.tools)

    stream = create_run(run_callback, state=payload.state)
    resp = DataStreamResponse(stream)
    resp.headers["X-Thread-Id"] = thread_id
    resp.headers["X-Trace-Id"] = uuid.uuid4().hex
    resp.headers["traceparent"] = f"00-{uuid.uuid4().hex}-0000000000000000-01"
    return resp
