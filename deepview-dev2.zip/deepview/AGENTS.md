# AGENTS.md — DeepView

为 OpenCode 会话准备的精简指引。每一行都应是「没有这些提示，agent 很可能会踩坑」的内容。

## 语言要求（强制）

与用户交流**绝对、绝对**使用**中文**，不得使用英文。所有回复、说明、提问、提交信息描述均用中文。

## 代码注释与文档串规范（强制，经验教训）

曾反复踩坑：在 class/函数/方法**定义顶部**写多行 docstring 解释内部机制（优先级、幂等、配置来源顺序、为什么这样实现、跨模块对应关系等），把「用途」埋没、让扫读变困难。**规则如下**：

- **顶部只写一行用途**：类用 `"""一句话用途。"""`；函数/方法用一行文档串或单行 `#`（私有/内部实现）。**禁止**在顶部展开机制说明。
- **机制 / 非显而易见的「为什么」写到行内**：在真正干活的代码行**上方**写短 `#` 单行注释（纯数据模型则写到对应**字段**旁）。
- 只注释**意图、非显而易见的决策、为什么**；不写重复代码显而易见内容的注释（"这行在做什么"若代码已自明则删掉）。
- 配置项的关键差异（如某后端「一键注册」vs「标准 OTLP 手动对接」）不要塞进类顶部，写到对应字段的 `#` 旁。
- 改注释时**只动注释，不动逻辑/签名/import/行为**；改完跑 `just lint` + `just format` 校验（注释不应影响，但格式化可能微调）。
- 不要为改而改：本就符合「顶部一行 + 行内注释」的文件不动它。

## 导入规范（强制）

- **绝对禁止相对导入**：全仓禁止 `from .` / `from ..`，一律使用绝对导入 `from harness.xxx import yyy` / `from core.xxx import yyy` / `from server.xxx import yyy` / `from llm.xxx import yyy` / `from telemetry.xxx import yyy`。
- `just lint` 已启用 `TID252`（`ruff` 的 `flake8-tidy-imports`）对相对导入直接报错；提交前必须 `just lint` 通过。
- 例外：无。`__init__.py` 的再导出、测试文件、脚本文件同样禁止相对导入。

## 本仓库是什么

一个 Python 3.14 的 **uv workspace**（根目录 `pyproject.toml` 含 `[tool.uv.workspace]`，`members = ["packages/*", "server"]`）。

- `core`（`packages/core`）— 共享库（`import core`）。目前仍是骨架：仅有 `__init__.py`。
- `server`（`server/`）— 应用包，暴露控制台脚本 `server = "server:main"`。目前会 `raise SystemExit("server: no implementation yet (skeleton)")` —— 不要假设已有真实逻辑。
- 根项目依赖 `core` + `server`，并聚合了 `lint`/`typecheck`/`test` 这几个依赖组。

项目处于早期脚手架阶段（仅有骨架、示例测试）。除非你亲自验证过，否则把「真实」行为视为尚未实现。

## 质量门禁（门禁）—— 代码合格前必须达标

代码只有通过全部以下检查才算「好」：**Ruff check + Ruff format + ty + pytest**。目前没有 CI 强制这一门禁，因此你必须自觉执行。推荐顺序（后一步若前一步失败便无意义）：

```
just lint         # ruff check .
just format       # ruff format .   （或 just format-check 仅做校验）
just typecheck    # ty check
just test         # uv run pytest
```

- Ruff：目标 py314，行宽 100，双引号。启用 `I, UP, B, SIM, ASYNC, RUF, C4, W`；忽略 `E501`；`tests/` 与 `__init__.py` 允许 `E402`。
- ty：`python-version = 3.14`。在 `tests/**` 中，未解析的引用仅作 **warn**（不算 error）—— 不要指望靠 ty 在测试里抓出缺失的 import。
- `just lint-fix` 可自动修复；优先用它，之后再重跑 `just typecheck`。

任何 `just` 配方未覆盖的命令都用 `uv run ...`（例如 `uv run pytest tests/unit/test_core.py`）。`just` 配方不转发参数 —— 单文件运行请直接把路径传给 `uv run pytest`。

## 测试 —— 注意点

- pytest 是 **anyio 驱动，而非 pytest-asyncio**：`anyio_mode = "auto"` 且 `-p no:asyncio`。异步测试写成普通 `async def test_...` 并加 `await anyio.lowlevel.checkpoint()` —— 不要用 `@pytest.mark.asyncio`。
- `filterwarnings = ["error"]` —— 警告会让整个测试套件失败。去修掉警告，不要压制它。
- `xfail_strict = true`，且每个测试有 `timeout = "20"` 秒上限。
- `@pytest.mark.network` 标记需要联网的测试；默认运行不会跳过它们。
- 目录结构：`tests/conftest.py` 注册了 `pytest_plugins = ["fixture"]`。`tests/fixture/` 是一个 **pytest 插件包**，用于存放共享夹具（如 `example_value`）—— 新增的共享夹具放在这里，而不是 conftest。测试分别位于 `tests/unit/` 和 `tests/integration/`。
- **配置代码与测试必须同步变更**：改动 `core/config.py`、`core/schema.py`、`core/constant.py` 后，对应的配置测试（`tests/unit/test_config.py`）与共享夹具（`tests/fixture/config.py`）必须同步更新并跑绿 `just test`。新增配置项**务必带默认值或声明为 `Optional`**——若漏掉默认值（`AppConfig()` 全量构造的多个用例会一起报 `ValidationError`），排查信号不聚焦。改了环境变量名 / 默认值时，相关的 env 覆盖、默认值用例按预期失败，那是变更护栏，应同步改测试而非压制。

## 运行与环境

- `just`（任务运行器）会自动加载 `.env`（`set dotenv-load`）；除此之外，应用配置由 `pydantic-settings` 在构造 `AppConfig` 时**自动读取 `.env` 与操作系统环境变量**，不依赖 `just`。所以即使直接 `uv run server` / `uv run pytest`（不经 `just`），`.env` 中的配置项仍会被加载；非配置类环境变量（如 `PYTHONUNBUFFERED`）仍需 `just` 或手动 `export`。
- 嵌套配置的环境变量覆盖使用双下划线约定，例如 `logging.level` 由 `LOGGING__LEVEL` 覆盖。详见 `core/config.py`。
- 在 `just dev` 之前，把 `.env.example` 复制为 `.env` 并填好。
- `just dev` → `uv run server`（启动 server 控制台脚本）。
- `just sync` → `uv sync`（解析 `uv.lock`，创建/更新 `.venv`）。改了依赖后请运行。
- 进程管理通过 **pm2** + `ecosystem.config.js`：`just up|down|logs|del [name]`（默认 `server`）。

## OpenCode 技能 —— 何时查阅

仓库内置了技能，位于 `.opencode/skills/`（slash 命令定义见 `.opencode/commands/opsx-*.md`）。遇到对应场景时直接加载对应技能，不要凭空猜测。

**工具类**
- `just` —— 阅读/编写 `justfile` 配方。
- `uv-package-manager` —— workspace 同步、添加依赖、Python 版本管理。

**OpenSpec（位于 `openspec/` 的规格驱动变更）**
- `openspec-propose` —— 起草一个新变更（设计 + 规格 + 任务）。
- `openspec-explore` —— 在提议前先把想法想清楚。
- `openspec-apply-change` —— 实现某个变更中的任务。
- `openspec-sync-specs` —— 把 delta 规格同步进主规格（不归档）。
- `openspec-update-change` —— 修订某个变更的计划。
- `openspec-archive-change` —— 完成变更后归档收尾。

**Python 工程（编写/改动 Python 前查阅）**
- `python-code-style`、`python-project-structure`、`python-design-patterns`、`python-type-safety`、`python-anti-patterns` —— 规范与常见错误。
- `python-error-handling`、`python-configuration`、`python-resilience`、`python-resource-management`、`python-observability`、`python-background-jobs`、`python-performance-optimization` —— 专项关注点。
- `python-testing-patterns` —— pytest 夹具、mock、标记、覆盖率。`pydantic` —— 模型/校验。`async-python-patterns` —— asyncio/anyio（本仓库使用 anyio）。
- `python-packaging` —— 打包 `core`/`server` 这两个 workspace 包。

## Git 提交规范（Conventional Commits）

提交信息使用中文描述，遵循 Conventional Commits 格式：

```
<type>(<scope>): <描述中文>
```

- **不要**在信息里加分支名前缀（`dev`/`main` 已由当前分支表达）。
- 类型 `type`：`feat` / `fix` / `docs` / `refactor` / `style` / `test` / `perf` / `build` / `ci` / `chore` / `revert`。
- 多个主题拆成多个提交；**一个提交只做一件事**。
- 本仓库的 `AGENTS.md`（及下文的规范说明）同样使用中文描述。

## 不要想当然

- 在此文件之前，仓库没有 `README`、没有 CI 工作流、也没有已有的 `AGENTS.md`/`.cursorrules`/copilot 指令。
- `.opencode` 和 `docs` 被排除在 Ruff 与 ty 之外 —— 其中的配置并不代表应用代码的 lint 规则。
