# Changelog

## Unreleased

### BREAKING — refactor-agent-registry（兼容层已移除，直接重写）

- 移除 `ToolRegistry` 单例与 `get_registry()/reset_registry()/configure_registry()/define_role` 兼容层，全部重写为 `ToolStore` + `McpDiscovery` + `bind_role_to_mcp` + `configure_tools` 显式注入。
- `agent/tools/math.py` 去除 `@get_registry().tool` 装饰器，改为 `register_builtin_tools(store)` 在 `lifespan` 显式注册。
- `agent/__init__.py` 不再顶层副作用导入，`create_agent_for_role` 现要求 `store: ToolStore` 必传，`create_supervisor_agent` 接受 `store` 显式注入。
- `vercel_adapter/service.py` 改为从 `request.app.state.tool_store` 获取显式 `ToolStore`，回退时本地新建并 `register_builtin_tools`。
- `tests/fixture/agent.py` 移除 `clean_registry/fresh_registry`，仅保留 `tool_store` / `mcp_discovery`；全部单测已迁移。
- 移除 `builtins.list/set/dict` 写法，`McpBinding` 与 `ToolFilter` 以 `TypedDict/Callable` 强类型约束。
- `Telemetry` 已收口 `PRIORITY/_REGISTRY` 为模块级常量并加重复注册 `ValueError`，`provider/factory.py` 增加 `ProviderRegistry` 占位。

### Added

- `ToolStore` 纯目录、`McpDiscovery` TTL 发现、`ToolView` 只读视图、`McpBinding/ToolFilter` 类型、`bind_role_to_mcp`、`register_builtin_tools`、`tool_store`/`mcp_discovery` 测试夹具。

### BREAKING — simplify-agent-config-and-async-bus

- `AgentConfig` 瘦为 `mcp_servers/system_prompt/max_steps/model` 四字段，`tool_loop_max_iterations / max_execution_steps` 合并为 `max_steps`（`extra="ignore"` 兼容一版，旧代码需改 `max_steps`）。
- `BaseContext` 瘦为 `thread_id/uid/trace_id/tenant_id/user_id` 五字段，其余 `tools/mcps/skills/run_id/system_prompt/model/max_execution_steps` 移至 `AgentConfig` 或删除。
- 新增 `BusConfig(enabled/nats_url/stream_name/subject_prefix/timeout)`，`nats_url` 默认 `nats://192.168.16.24:6015`（Docker NATS），`BUS__*` 环境变量可覆盖。
- 引入 `dishka`（`Scope.APP`）、`toolz`、`transitions`、`taskiq`、`nats-py`；`server/app.py:lifespan` 改 `AsyncContainer` 托管，`chat_stream` 支持 `bus.enabled` 异步分支 `POST→NATS chat.request.{thread_id}→worker→chat.response.{thread_id}→SSE`。
- 迁移：`AppConfig(agent=AgentConfig(tool_loop_max_iterations=10))` → `AppConfig(agent=AgentConfig(max_steps=10))`；`BaseContext(tools=[...])` → `AgentConfig` 白名单。
