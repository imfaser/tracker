import { useMemo } from 'react';
import { useChatRuntime, AssistantChatTransport } from '@assistant-ui/react-ai-sdk';
import { useConfig } from '@/hooks/useConfig';

const DEFAULT_API_URL = '/api/chat';

function getEnv(name: string): string | undefined {
  return (import.meta as unknown as { env: Record<string, string | undefined> }).env?.[name];
}

export function useAssistantRuntime() {
  const { config } = useConfig();

  const api = useMemo(() => {
    const cfgUrl = config?.backendUrl?.trim();
    if (cfgUrl) {
      return cfgUrl;
    }
    const envUrl = getEnv('VITE_CHAT_API_URL')?.trim();
    if (envUrl) {
      return envUrl;
    }
    return DEFAULT_API_URL;
  }, [config?.backendUrl]);

  const headers = useMemo<Record<string, string>>(() => {
    const h: Record<string, string> = {};
    const uid = config?.userId?.trim();
    const cid = config?.conversationId?.trim();
    if (uid) {
      h['x-user-id'] = uid;
    }
    if (cid) {
      h['x-conversation-id'] = cid;
    }
    return h;
  }, [config?.userId, config?.conversationId]);

  const hasUserId = Boolean(config?.userId?.trim());

  const transport = useMemo(
    () =>
      new AssistantChatTransport({
        api,
        headers,
        fetch: async (input, init) => {
          if (!hasUserId) {
            return new Response(
              JSON.stringify({
                error: 'Missing x-user-id. Please configure userId in /config.',
              }),
              {
                status: 400,
                headers: { 'Content-Type': 'application/json' },
              }
            );
          }
          return fetch(input as RequestInfo, init);
        },
      }),
    [api, headers, hasUserId]
  );

  const runtime = useChatRuntime({ transport });

  return runtime;
}
