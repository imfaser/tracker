'use client';

import { defineToolkit } from '@assistant-ui/react';
import type { ToolCallMessagePartComponent } from '@assistant-ui/react';
import { useState } from 'react';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

// 参考官方文档 Tool UI -> Interactive Tool UIs -> User Input Collection
// https://www.assistant-ui.com/docs/tools/tool-ui#user-input-collection
// Best Practices: https://www.assistant-ui.com/docs/tools/tool-ui#best-practices
// 官方写法：type: "human" + render 中 addResult 恰好调用一次，runtime 会把 tool result 续跑

const askUserParams = z.object({
  prompt: z.string().optional(),
  question: z.string().optional(),
  message: z.string().optional(),
});

type AskUserArgs = z.infer<typeof askUserParams>;
type AskUserResult = string;

// 遵循 Best Practices: 1. 处理所有 status  2. 视觉反馈  3. 可访问性
const AskUserUI: ToolCallMessagePartComponent<AskUserArgs, AskUserResult> = ({
  args,
  result,
  status,
  addResult,
}) => {
  const [value, setValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Best Practice 1: Handle All Status States
  if (status.type === 'running') {
    return (
      <div
        className={cn(
          'flex flex-col gap-2 rounded-lg border bg-card p-3 transition-all duration-300 opacity-60'
        )}
        aria-busy="true"
        aria-label="正在等待工具准备输入"
      >
        <p className="text-sm font-medium">
          {args?.prompt ?? args?.question ?? args?.message ?? '请输入回复'}
        </p>
        <div className="bg-muted h-8 animate-pulse rounded-md" />
        <p className="text-muted-foreground text-xs">工具准备中...</p>
      </div>
    );
  }

  if (status.type === 'incomplete') {
    const reason = status.reason;
    const errorText = status.error
      ? typeof status.error === 'string'
        ? status.error
        : JSON.stringify(status.error)
      : null;
    if (reason === 'cancelled') {
      return <div className="text-muted-foreground rounded-md bg-muted/50 p-3 text-sm">已取消</div>;
    }
    return (
      <div
        className="text-destructive rounded-md border border-destructive/20 bg-destructive/10 p-3 text-sm"
        role="alert"
      >
        <p className="font-medium">输入失败{reason ? `: ${reason}` : ''}</p>
        {errorText && <p className="mt-1 text-xs opacity-80">{errorText}</p>}
      </div>
    );
  }

  // 已有结果：展示结果态（Best Practice 视觉反馈 + 可访问性）
  if (result !== undefined) {
    const text =
      typeof result === 'string'
        ? result
        : String((result as { content?: unknown })?.content ?? JSON.stringify(result));
    return (
      <div
        className={cn('rounded-md bg-muted/50 p-3 text-sm transition-all duration-300 opacity-100')}
        role="status"
        aria-label="已提交的用户输入"
      >
        <span className="text-muted-foreground">已回复：</span>
        <span className="font-medium">{text}</span>
      </div>
    );
  }

  // status.type === 'complete' 但无 result：不渲染（避免闪烁）
  if (status.type === 'complete') {
    return null;
  }

  // requires-action / 默认：展示输入态（human tool 等待用户）
  const prompt = args?.prompt ?? args?.question ?? args?.message ?? '请输入回复';

  const handleSubmit = () => {
    const trimmed = value.trim();
    if (!trimmed) {
      setError('请输入内容');
      return;
    }
    setError(null);
    // 必须恰好调用一次 addResult，官方要求直调 props.addResult 保持 proxy 上下文（勿解构）
    // 本组件通过闭包的 addResult 调用，符合官方示例
    addResult(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div
      className={cn(
        'flex flex-col gap-2 rounded-lg border bg-card p-3 transition-all duration-300',
        status.type === 'requires-action' && 'opacity-100'
      )}
    >
      <p className="text-sm font-medium" id="ask-user-prompt">
        {prompt}
      </p>
      <div className="flex gap-2">
        <Input
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            if (error) {
              setError(null);
            }
          }}
          onKeyDown={handleKeyDown}
          placeholder="请输入..."
          autoFocus
          className="flex-1 h-8 focus-visible:ring-2"
          aria-label="ask_user 输入框"
          aria-describedby="ask-user-prompt"
          aria-invalid={Boolean(error)}
        />
        <Button
          size="sm"
          onClick={handleSubmit}
          aria-label="确认提交输入"
          className="focus-visible:outline-none focus-visible:ring-2 active:scale-[0.98] transition-transform"
        >
          提交
        </Button>
      </div>
      {error && (
        <p className="text-destructive text-xs" role="alert">
          {error}
        </p>
      )}
      <p className="text-muted-foreground text-xs">提交后将以 tool 结果续跑对话</p>
    </div>
  );
};

export const toolkit = defineToolkit({
  ask_user: {
    type: 'human' as const,
    description: 'Ask the user for missing parameter (e.g. radius)',
    parameters: askUserParams,
    render: AskUserUI,
  },
  askUser: {
    type: 'human' as const,
    description: 'Ask the user for missing parameter',
    parameters: askUserParams,
    render: AskUserUI,
  },
});
