import { createFileRoute } from '@tanstack/react-router';
import { useMemo } from 'react';
import { Thread } from '@/components/assistant-ui/thread';
import {
  AssistantRuntimeProvider,
  AuiConfig,
  Tools,
  unstable_createMessageConverter as createMessageConverter,
  useAssistantTransportRuntime,
  type AssistantTransportConnectionMetadata,
} from '@assistant-ui/react';
import { convertLangChainMessages } from '@assistant-ui/react-langgraph';
import { useConfig } from '@/hooks/useConfig';
import { toolkit } from '@/lib/toolkit';

export const Route = createFileRoute('/assistant')({
  component: AssistantPage,
});

function AssistantPage() {
  const { config } = useConfig();

  // 后端：APIRouter(prefix="/assistant")，api 原样用 config.backendUrl，不拼接
  const apiUrl = useMemo(() => {
    const raw = config?.backendUrl?.trim();
    if (raw) return raw;
    return '';
  }, [config?.backendUrl]);

  const headers = useMemo<Record<string, string>>(() => {
    const h: Record<string, string> = {};
    const uid = config?.userId?.trim();
    const cid = config?.conversationId?.trim();
    if (uid) h['x-user-id'] = uid;
    if (cid) h['x-conversation-id'] = cid;
    return h;
  }, [config?.userId, config?.conversationId]);

  // config 未加载前不挂载 runtime，避免 /assistant -> http://.../assistant 切换导致 unstable_state
  if (!apiUrl) {
    return (
      <div className="flex flex-1 items-center justify-center p-8 text-sm text-muted-foreground">
        请先到 配置 页设置 backendUrl（例如 http://192.168.16.8:8000/assistant）
      </div>
    );
  }

  // 官方文档 LangChain：https://www.assistant-ui.com/docs/runtimes/custom/assistant-transport#converting-messages
  // 后端若为 LangGraph，消息含 tool_calls / reasoning，需用 convertLangChainMessages 保留思考与工具调用
  type AgentState = { messages: unknown[] };
  const messageConverter = createMessageConverter(convertLangChainMessages as never);
  const runtime = useAssistantTransportRuntime<AgentState>({
    initialState: { messages: [] },
    api: apiUrl,
    headers,
    converter: (state: AgentState, meta: AssistantTransportConnectionMetadata) => ({
      messages: messageConverter.toThreadMessages((state.messages ?? []) as never),
      isRunning: meta.isSending,
    }),
  });

  // oxlint-disable-next-line new-cap, react/capitalized-calls
  const assistantConfig = useMemo(() => AuiConfig({ tools: Tools({ toolkit }) }), []);

  return (
    <AssistantRuntimeProvider runtime={runtime} config={assistantConfig}>
      <div className="flex flex-1 min-h-0 flex-col overflow-hidden">
        <div className="mx-auto w-full max-w-[44rem] px-4 pt-2">
          <div className="text-muted-foreground flex items-center gap-2 rounded-md border border-dashed bg-muted/20 px-3 py-2 text-xs">
            <span className="font-medium text-foreground">Assistant · /assistant</span>
            <span className="opacity-60">·</span>
            <span className="truncate" title={apiUrl}>
              {apiUrl}
            </span>
          </div>
        </div>
        <Thread />
      </div>
    </AssistantRuntimeProvider>
  );
}
