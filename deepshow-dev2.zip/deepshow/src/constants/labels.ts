export const LABELS = {
  nav: {
    chat: '对话',
    assistant: 'Assistant',
    config: '配置',
    logs: '日志',
  },
  settings: {
    title: '应用配置',
    backendUrl: '后端地址',
    backendUrlPlaceholder: 'https://example.com/api/chat',
    backendUrlHint: 'Vercel AI SDK 后端地址，空值时回退到 VITE_CHAT_API_URL',
    userId: '用户 ID',
    userIdPlaceholder: '必填，例如 u_12345',
    conversationId: '会话 ID',
    conversationIdPlaceholder: '可选，留空则后端自动创建',
    generate: '随机生成',
    save: '保存',
    saved: '配置已保存',
    saveFailed: '配置保存失败',
    required: '必填',
    urlInvalid: 'URL 格式无效',
  },
} as const;
