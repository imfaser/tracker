"""taskiq worker：chat_task。"""

from __future__ import annotations

from typing import Any

from server.bus.nats import broker, get_broker

try:
    _broker = get_broker()
except Exception:  # noqa: BLE001
    _broker = None

if _broker is not None:

    @broker.task  # type: ignore[attr-defined]
    async def chat_task(payload: dict[str, Any], thread_id: str) -> dict[str, Any]:
        """消费 chat.request.{thread_id}，发布 chat.response.{thread_id}。"""
        from core import get_config

        _ = get_config()
        # 复用管道与容器
        try:
            from agent.agents.context import BaseContext

            ctx = BaseContext(thread_id=thread_id, uid=thread_id)
            from agent.agents.supervisor_agent import SupervisorAgent
            from core.di import make_container

            container = make_container()
            supervisor = await container.get(SupervisorAgent)  # type: ignore[assignment]
            graph = await supervisor.get_graph(context=ctx)  # type: ignore[union-attr]
            # 简化：直接 ainvoke，trace_id 经 header 透传（此处省略 header 处理）
            messages = payload.get("messages", [])
            from langchain_core.messages import HumanMessage

            lc_msgs = [
                HumanMessage(content=str(m.get("content", "")))
                for m in messages
                if isinstance(m, dict)
            ]
            result = await graph.ainvoke(
                {"messages": lc_msgs}, config={"configurable": {"thread_id": thread_id}}
            )
            # 发布响应（此处经 broker 结果回传，真实 NATS publish 在外层）
            await container.close()
            return {"thread_id": thread_id, "result": str(result)}
        except Exception as exc:  # noqa: BLE001
            return {"thread_id": thread_id, "error": str(exc)[:200]}

else:

    async def chat_task(payload: dict[str, Any], thread_id: str) -> dict[str, Any]:  # type: ignore[no-redef]
        return {"thread_id": thread_id, "error": "broker not initialized"}
