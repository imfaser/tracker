from __future__ import annotations

from core import get_config

__all__ = ["main"]


def main() -> None:
    import os

    import uvicorn

    from server.app import create_app

    cfg = get_config()
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    app = create_app()
    # 保持 demo.request 的链路自检在 lifespan 内执行，此处仅启动服务
    _ = cfg
    uvicorn.run(app, host=host, port=port)
