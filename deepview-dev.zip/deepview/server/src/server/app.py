"""FastAPI 应用工厂与 lifespan。"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from agent.agents.supervisor_agent import SupervisorAgent
from agent.registry import McpDiscovery, ToolStore
from agent.tools.builtin import register_builtin_tools
from core import get_config
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from telemetry import shutdown_telemetry

from server.configure import configure_app
from server.routers.chat import router as chat_router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    # 初始化配置与工具目录
    cfg = get_config()
    store = ToolStore()
    register_builtin_tools(store)
    # MCP 发现与应用配置
    discovery = McpDiscovery()
    configure_app(cfg, store=store, discovery=discovery)
    # 触发一次 MCP 拉取，失败不阻断启动
    with contextlib.suppress(Exception):
        await discovery.discover()
    # 创建主代理并挂载至应用状态
    supervisor = SupervisorAgent()
    app.state.config = cfg
    app.state.tool_store = store
    app.state.mcp_discovery = discovery
    app.state.supervisor = supervisor
    try:
        yield
    finally:
        # 释放追踪资源
        shutdown_telemetry()


def create_app() -> FastAPI:
    """创建 FastAPI 应用。"""
    app = FastAPI(lifespan=lifespan)

    # 跨域与追踪头暴露
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Trace-Id", "X-Thread-Id", "traceparent"],
    )

    # 注册聊天路由
    app.include_router(chat_router)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    return app
