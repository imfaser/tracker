"""FastAPI 应用工厂与 lifespan。"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from core.config import AppConfig
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from telemetry import shutdown_telemetry

from server.configure import configure_app
from server.routers.chat import router as chat_router


def _make_container():  # type: ignore[no-untyped-def]
    from core.di import AppProvider
    from dishka import make_async_container

    from server.di import ServerProvider

    return make_async_container(AppProvider(), ServerProvider())


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    container = _make_container()
    app.state.container = container
    # 初始化配置与工具目录（经 Dishka 容器）
    cfg = await container.get(AppConfig)
    from agent.registry import McpDiscovery, ToolStore

    store = await container.get(ToolStore)  # type: ignore[assignment]
    discovery = await container.get(McpDiscovery)  # type: ignore[assignment]
    from agent.agents.supervisor_agent import SupervisorAgent

    supervisor = await container.get(SupervisorAgent)  # type: ignore[assignment]
    configure_app(cfg, store=store, discovery=discovery)  # type: ignore[arg-type]
    # 触发一次 MCP 拉取，失败不阻断启动
    with contextlib.suppress(Exception):
        await discovery.discover()  # type: ignore[union-attr]
    app.state.config = cfg
    app.state.tool_store = store
    app.state.mcp_discovery = discovery
    app.state.supervisor = supervisor
    try:
        yield
    finally:
        # 释放追踪与容器资源
        with contextlib.suppress(Exception):
            shutdown_telemetry()
        with contextlib.suppress(Exception):
            await container.close()


def create_app() -> FastAPI:
    """创建 FastAPI 应用。"""
    app = FastAPI(lifespan=lifespan)

    # 跨域与追踪头暴露
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Trace-Id", "X-Thread-Id", "traceparent"],
    )

    # 注册聊天路由
    app.include_router(chat_router)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    return app
