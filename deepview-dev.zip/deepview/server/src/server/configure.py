from __future__ import annotations

from agent.registry import McpDiscovery, ToolStore, configure_tools
from agent.tools.builtin import register_builtin_tools
from core import configure_logging
from core.config import AppConfig
from telemetry import configure_telemetry


def configure_app(
    cfg: AppConfig,
    store: ToolStore | None = None,
    discovery: McpDiscovery | None = None,
) -> list[str]:
    configure_logging(cfg.logging)
    effective_store = store
    if effective_store is None:
        effective_store = ToolStore()
        register_builtin_tools(effective_store)
    effective_discovery = discovery or McpDiscovery()
    configure_tools(cfg.agent, store=effective_store, discovery=effective_discovery)
    return configure_telemetry(cfg.telemetry)
