"""聊天流式路由。"""

from __future__ import annotations

import uuid
from typing import Any

from core import get_config
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from vercel_adapter import to_base_messages_v7
from vercel_adapter.service import create_chat_stream_response

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatStreamRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    messages: list[dict[str, Any]] = Field(min_length=1)
    id: str | None = None
    thread_id: str | None = Field(default=None, alias="thread_id")
    threadId: str | None = Field(default=None, alias="threadId")

    @property
    def resolved_thread_id(self) -> str | None:
        if self.id:
            return self.id
        if self.thread_id:
            return self.thread_id
        if self.threadId:
            return self.threadId
        if self.model_extra:
            for key in ("threadId", "thread_id", "id"):
                val = self.model_extra.get(key)
                if isinstance(val, str) and val:
                    return val
        return None


@router.post("/stream", response_model=None)
async def chat_stream(request: Request) -> Any:
    # 1. 解析 JSON
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": "invalid json"})
    # 2. 校验载荷结构
    try:
        payload = ChatStreamRequest.model_validate(body)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    # 3. 校验每条消息的角色
    for idx, m in enumerate(payload.messages):
        if m.get("role") not in ("user", "assistant", "system", "tool"):
            return JSONResponse(
                status_code=400, content={"detail": f"message {idx} has invalid role"}
            )
    # 4. 转换为 LangChain 消息
    try:
        base_messages = to_base_messages_v7(payload.messages)
    except (ValueError, TypeError) as exc:
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    # 5. 取 thread_id，前端创 id 优先，后端仅兜底；兼容 id/thread_id/threadId 三种写法
    thread_id = payload.resolved_thread_id or f"thread_{uuid.uuid4().hex}"
    # 优先从 Dishka 容器取配置，回退 get_config()
    cfg = get_config()
    import contextlib

    with contextlib.suppress(Exception):
        state = getattr(getattr(request, "app", None), "state", None)
        c = getattr(state, "container", None) if state is not None else None
        if c is not None:
            from core.config import AppConfig as _AC

            with contextlib.suppress(Exception):
                cfg = await c.get(_AC)  # type: ignore[assignment]
    # 6. 异步分支：bus.enabled 时入队后订阅回推，否则同步直调
    if getattr(getattr(cfg, "bus", None), "enabled", False):
        import contextlib

        try:
            from server.bus.nats import get_broker

            b = get_broker(cfg)
            if b is not None:
                with contextlib.suppress(Exception):
                    await b.kiq("chat_task", payload.model_dump(), thread_id)  # type: ignore[attr-defined]

            # NATS → queue → SSE 桥接（此处简化为订阅占位，实际 JetStream 订阅在 worker）
            async def subscribe_stream() -> Any:
                import anyio
                from opentelemetry import trace as _trace

                # 简化：直接复用同步流，但经 NATS header 透传 trace
                from vercel_adapter.service import _chat_stream

                tracer = _trace.get_tracer("deepview.server")
                span = tracer.start_span("chat.stream.bus")
                try:
                    async for chunk in _chat_stream(
                        request, span, None, cfg, base_messages, thread_id, False, span.end
                    ):
                        if await request.is_disconnected():
                            with contextlib.suppress(Exception):
                                span.set_attribute("chat.cancelled", True)
                            break
                        yield chunk
                        await anyio.lowlevel.checkpoint()  # type: ignore[attr-defined]
                finally:
                    with contextlib.suppress(Exception):
                        span.end()

            from vercel_adapter.converter import create_ui_message_stream_response

            return create_ui_message_stream_response(subscribe_stream(), thread_id=thread_id)
        except Exception:  # noqa: BLE001, S110
            pass
    return create_chat_stream_response(request, base_messages, thread_id, cfg)
