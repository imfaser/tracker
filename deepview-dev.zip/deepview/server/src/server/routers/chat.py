"""聊天流式路由。"""

from __future__ import annotations

import uuid
from typing import Any

from core import get_config
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from vercel_adapter import to_base_messages_v7
from vercel_adapter.service import create_chat_stream_response

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatStreamRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    messages: list[dict[str, Any]] = Field(min_length=1)
    id: str | None = None
    thread_id: str | None = Field(default=None, alias="thread_id")
    threadId: str | None = Field(default=None, alias="threadId")

    @property
    def resolved_thread_id(self) -> str | None:
        if self.id:
            return self.id
        if self.thread_id:
            return self.thread_id
        if self.threadId:
            return self.threadId
        if self.model_extra:
            for key in ("threadId", "thread_id", "id"):
                val = self.model_extra.get(key)
                if isinstance(val, str) and val:
                    return val
        return None


@router.post("/stream", response_model=None)
async def chat_stream(request: Request) -> Any:
    # 1. 解析 JSON
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": "invalid json"})
    # 2. 校验载荷结构
    try:
        payload = ChatStreamRequest.model_validate(body)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    # 3. 校验每条消息的角色
    for idx, m in enumerate(payload.messages):
        if m.get("role") not in ("user", "assistant", "system", "tool"):
            return JSONResponse(
                status_code=400, content={"detail": f"message {idx} has invalid role"}
            )
    # 4. 转换为 LangChain 消息
    try:
        base_messages = to_base_messages_v7(payload.messages)
    except (ValueError, TypeError) as exc:
        return JSONResponse(status_code=400, content={"detail": str(exc)})
    # 5. 取 thread_id，前端创 id 优先，后端仅兜底；兼容 id/thread_id/threadId 三种写法
    thread_id = payload.resolved_thread_id or f"thread_{uuid.uuid4().hex}"
    cfg = get_config()
    # 6. 调流式响应（X-Thread-Id 原样回显该 tid）
    return create_chat_stream_response(request, base_messages, thread_id, cfg)
