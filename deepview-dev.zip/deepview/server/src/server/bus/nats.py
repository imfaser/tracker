"""NATS 总线与 taskiq broker。"""

from __future__ import annotations

import contextlib
from typing import Any

from core.config import AppConfig

try:
    from taskiq import InMemoryBroker

    _has_inmemory = True
except Exception:  # noqa: BLE001
    _has_inmemory = False

_broker: Any | None = None


def _make_broker(cfg: AppConfig | None = None) -> Any:
    if cfg is None:
        try:
            from core import get_config

            cfg = get_config()
        except Exception:  # noqa: BLE001
            cfg = AppConfig()
    # bus.enabled=false 时用内存占位，保证同步链路零依赖
    if not cfg.bus.enabled:
        if _has_inmemory:
            return InMemoryBroker()
        return None
    # 尝试 NatsBroker，失败回退 InMemory
    try:
        # taskiq-nats 插件可选，未安装则回退
        from taskiq_nats import NatsBroker  # type: ignore

        return NatsBroker(cfg.bus.nats_url)  # type: ignore[call-arg]
    except Exception:  # noqa: BLE001
        try:
            from nats.aio.client import Client  # type: ignore

            _ = Client()
        except Exception:  # noqa: BLE001, S110
            pass
        if _has_inmemory:
            return InMemoryBroker()
        return None


def get_broker(cfg: AppConfig | None = None) -> Any:
    global _broker
    if _broker is None:
        _broker = _make_broker(cfg)
    return _broker


broker = get_broker()


async def ensure_stream(cfg: AppConfig) -> None:
    """确保 JetStream stream 存在（幂等）。"""
    if not cfg.bus.enabled:
        return
    try:
        import nats

        nc = await nats.connect(cfg.bus.nats_url)  # type: ignore[attr-defined]
        js = nc.jetstream()
        with contextlib.suppress(Exception):
            await js.add_stream(
                name=cfg.bus.stream_name,
                subjects=[
                    f"{cfg.bus.subject_prefix}.request.*",
                    f"{cfg.bus.subject_prefix}.response.*",
                ],
            )
        await nc.close()
    except Exception:  # noqa: BLE001, S110
        pass
