"""Server Dishka Provider."""

from __future__ import annotations

from agent.agents.supervisor_agent import SupervisorAgent
from agent.registry import McpDiscovery, ToolStore
from core.config import AppConfig
from dishka import Provider, Scope, provide


class ServerProvider(Provider):
    scope = Scope.APP

    @provide(scope=Scope.APP)
    def provide_tool_store(self, cfg: AppConfig) -> ToolStore:
        from agent.tools.builtin import register_builtin_tools

        store = ToolStore()
        register_builtin_tools(store)
        return store

    @provide(scope=Scope.APP)
    def provide_mcp_discovery(self, cfg: AppConfig) -> McpDiscovery:
        disc = McpDiscovery()
        if cfg.agent.mcp_servers:
            disc.configure_mcp_servers(cfg.agent.mcp_servers)
        return disc

    @provide(scope=Scope.APP)
    def provide_supervisor(self, cfg: AppConfig) -> SupervisorAgent:
        return SupervisorAgent()
