"""Dishka 依赖注入容器。"""

from __future__ import annotations

from dishka import Provider, Scope, provide

from core.config import AppConfig
from core.schema import BusConfig


class AppProvider(Provider):
    """应用级 Provider，Scope.APP。"""

    scope = Scope.APP

    def __init__(self) -> None:
        super().__init__()

    @provide(scope=Scope.APP)
    def provide_config(self) -> AppConfig:
        return AppConfig()

    @provide(scope=Scope.APP)
    def provide_bus_config(self, cfg: AppConfig) -> BusConfig:
        return cfg.bus

def make_container():  # type: ignore[no-untyped-def]
    from dishka import make_async_container

    return make_async_container(AppProvider())
