from __future__ import annotations

import os
from importlib.resources.abc import Traversable
from pathlib import Path
from typing import Any, ClassVar

import json5
from pydantic import Field, field_validator
from pydantic_settings import (
    BaseSettings,
    JsonConfigSettingsSource,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

from core.constant import CONFIG_FILENAME
from core.schema import AgentConfig, BusConfig, LLMConfig, LoggingConfig, TelemetryConfig


def _resolve_config_path() -> Path:
    """解析配置文件路径：CONFIG_FILE 环境变量优先，空串当未设置，否则回退默认文件名（相对 cwd）。"""
    # CONFIG_FILE 是真实环境变量（非本仓库常量），改名会影响 .env 加载
    return Path(os.environ.get("CONFIG_FILE") or CONFIG_FILENAME)


class JsoncConfigSettingsSource(JsonConfigSettingsSource):
    """读取 JSONC 配置文件的 pydantic settings source。"""

    def _read_file(self, file_path: Path | Traversable) -> dict[str, Any]:
        p = Path(str(file_path))
        if not p.exists() or not p.read_text(encoding="utf-8").strip():
            return {}
        # 用 json5 而非标准 json，容忍 // 注释与尾逗号
        return json5.loads(p.read_text(encoding="utf-8"))


class AppConfig(BaseSettings):
    """应用配置模型：从 jsonc 配置文件与环境变量加载。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore",
        env_ignore_empty=True,
    )

    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    telemetry: TelemetryConfig = Field(default_factory=TelemetryConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    bus: BusConfig = Field(default_factory=BusConfig)

    @field_validator("agent", mode="before")
    @classmethod
    def _coerce_agent(cls, v: object) -> object:
        if v in (1, "1"):
            return {}
        if isinstance(v, str) and v.strip() == "1":
            return {}
        return v

    _instance: ClassVar[AppConfig | None] = None

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """编排 pydantic 配置来源的组合。"""
        # 优先级：构造入参 > 环境变量 > .env > jsonc 文件；文件缺失则跳过该 source 回落默认值
        cfg_path = _resolve_config_path()
        sources: list[PydanticBaseSettingsSource] = [env_settings, dotenv_settings]
        if cfg_path.exists():
            sources.append(JsoncConfigSettingsSource(settings_cls, json_file=str(cfg_path)))
        return (init_settings, *sources)

    @classmethod
    def instance(cls) -> AppConfig:
        """返回配置单例；首次访问时自动加载。"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """清空单例缓存，供测试隔离使用。"""
        cls._instance = None


def get_config() -> AppConfig:
    """公开访问器：返回应用配置单例，收敛配置读取入口。"""
    return AppConfig.instance()
