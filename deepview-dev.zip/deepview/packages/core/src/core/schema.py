from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class ThirdPartyLoggingConfig(BaseModel):
    """第三方库日志控制配置。"""

    redirect: list[str] = Field(default_factory=list)
    disable: list[str] = Field(default_factory=list)


class LoggingConfig(BaseModel):
    """应用日志配置。"""

    level: str = Field(default="INFO")
    format: Literal["json", "console"] = Field(default="json")
    third_party: ThirdPartyLoggingConfig = Field(default_factory=ThirdPartyLoggingConfig)


class PhoenixConfig(BaseModel):
    """Phoenix 链路追踪后端配置。"""

    # 启用后由 arize-phoenix-otel 的 register() 一键初始化（含自动打桩）
    enabled: bool = Field(default=False)
    project_name: str = Field(default="deepview")
    endpoint: str | None = Field(default=None)
    protocol: Literal["grpc", "http/protobuf"] = Field(default="grpc")
    api_key: str | None = Field(default=None)
    headers: dict[str, str] = Field(default_factory=dict)
    batch: bool = Field(default=True)
    auto_instrument: bool = Field(default=True)

    @field_validator("protocol", mode="before")
    @classmethod
    def _normalize_protocol(cls, v: object) -> object:
        # 接受常见的 http 简写，归一为 OTLP 标准 http/protobuf
        return "http/protobuf" if v == "http" else v


class OpenObserveConfig(BaseModel):
    """OpenObserve 链路追踪后端配置。"""

    # 启用后按标准 OTLP 手动对接 OpenObserve（不依赖 openobserve-telemetry-sdk）
    enabled: bool = Field(default=False)
    service_name: str = Field(default="deepview")
    endpoint: str | None = Field(default=None)
    org: str = Field(default="default")
    headers: dict[str, str] = Field(default_factory=dict)
    # 落入库的流名：OpenObserve 用 stream-name 请求头决定 trace 进哪个流（默认 default）
    stream_name: str = Field(default="default")
    protocol: Literal["grpc", "http/protobuf"] = Field(default="http/protobuf")
    batch: bool = Field(default=True)

    @field_validator("protocol", mode="before")
    @classmethod
    def _normalize_protocol(cls, v: object) -> object:
        # 接受常见的 http 简写，归一为 OTLP 标准 http/protobuf
        return "http/protobuf" if v == "http" else v


class LLMConfig(BaseModel):
    """LLM provider 配置：type 决定 provider，其余为连接与默认采样参数。"""

    # 目前唯一外部 provider；未知值由 provider 工厂（match）抛错
    type: str = Field(default="mimo")
    api_key: str = Field(default="")  # 密钥；本地无鉴权端点时由 provider 填空占位符
    base_url: str = Field(default="")  # OpenAI 兼容端点，如 http://host:port/v1
    model: str = Field(default="")  # 模型名（build 时必填校验）
    temperature: float = Field(default=0.7)  # 默认采样温度，build_chat_model 从 cfg 读


class TelemetryConfig(BaseModel):
    """应用链路追踪配置。"""

    phoenix: PhoenixConfig = Field(default_factory=PhoenixConfig)
    openobserve: OpenObserveConfig = Field(default_factory=OpenObserveConfig)
    expose_trace_id: bool = Field(default=False)


class MCPServerConfig(BaseModel):
    """MCP 连接配置，仅含连接信息，不含角色或筛选。"""

    name: str
    transport: Literal["stdio", "sse", "http"] = Field(default="stdio")
    url: str | None = Field(default=None)
    command: str | None = Field(default=None)
    enabled: bool = Field(default=True)
    timeout: int = Field(default=10)


class AgentConfig(BaseModel):
    """Agent 公共库配置。"""

    mcp_servers: list[MCPServerConfig] = Field(default_factory=list)
    tool_loop_max_iterations: int = Field(default=10, ge=1, le=50)
