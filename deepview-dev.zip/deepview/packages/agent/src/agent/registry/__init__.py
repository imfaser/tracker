from __future__ import annotations

import logging

from core.schema import AgentConfig

from agent.registry.discovery import McpDiscovery
from agent.registry.store import ToolStore
from agent.registry.types import McpBinding, ToolFilter

logger = logging.getLogger(__name__)

__all__ = [
    "McpBinding",
    "McpDiscovery",
    "ToolFilter",
    "ToolStore",
    "configure_tools",
]


def configure_tools(
    cfg: AgentConfig,
    store: ToolStore,
    discovery: McpDiscovery,
) -> None:
    try:
        servers = getattr(cfg, "mcp_servers", None)
        if servers:
            discovery.configure_mcp_servers(servers)
            store.sync_mcp(discovery.snapshot())
    except Exception as exc:
        logger.warning("configure_tools failed: %s", exc)
        raise RuntimeError(f"tool registry 未配置: {exc}") from exc
    if not store.list() and not getattr(cfg, "mcp_servers", None):
        logger.info("tool registry 已配置但无可用工具: %s", cfg)
