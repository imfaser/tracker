from __future__ import annotations

from dataclasses import dataclass, field
from typing import List  # noqa: UP035

from langchain_core.tools import BaseTool


@dataclass
class _Entry:
    tool: BaseTool
    roles: list[str] = field(default_factory=list)
    tags: set[str] = field(default_factory=set)
    source: str = "builtin"
    annotations: dict = field(default_factory=dict)


class ToolStore:
    """纯工具目录，不持有网络或 TTL。"""

    def __init__(self) -> None:
        self._entries: list[_Entry] = []
        self._mcp_tools_by_server: dict[str, list[BaseTool]] = {}

    def tool(self, *, roles: List[str] | None = None, tags: set[str] | None = None):  # noqa: UP006
        def _deco(fn):  # type: ignore[no-untyped-def]
            from langchain_core.tools import tool as _tool

            wrapped = _tool(fn)
            self.register(wrapped, roles=roles, tags=tags, source="builtin")
            return wrapped

        return _deco

    def register(
        self,
        tool: BaseTool,
        *,
        roles: List[str] | None = None,  # noqa: UP006
        tags: set[str] | None = None,
        source: str = "builtin",
        annotations: dict | None = None,
    ) -> None:
        self._entries.append(
            _Entry(
                tool=tool,
                roles=list(roles or []),
                tags=set(tags or set()),
                source=source,
                annotations=dict(annotations or {}),
            )
        )

    def clear(self) -> None:
        self._entries.clear()
        self._mcp_tools_by_server.clear()

    def sync_mcp(self, snapshot: dict[str, List[BaseTool]]) -> None:  # noqa: UP006
        self._mcp_tools_by_server = dict(snapshot)

    def list(self, *, source: str | None = None) -> List[BaseTool]:  # noqa: UP006
        if source is None:
            all_tools: List[BaseTool] = [e.tool for e in self._entries]  # noqa: UP006
            for tools in self._mcp_tools_by_server.values():
                all_tools.extend(tools)
            return all_tools
        if source == "builtin":
            return [e.tool for e in self._entries if e.source == "builtin"]
        if source == "mcp":
            all_mcp: List[BaseTool] = [e.tool for e in self._entries if e.source == "mcp"]  # noqa: UP006
            for tools in self._mcp_tools_by_server.values():
                all_mcp.extend(tools)
            return all_mcp
        return [e.tool for e in self._entries if e.source == source]
