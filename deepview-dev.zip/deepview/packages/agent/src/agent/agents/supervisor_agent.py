from __future__ import annotations

import contextlib
from typing import Any

from langchain_core.tools import tool as _tool
from langgraph.types import interrupt

from agent.agents.base import BaseAgent
from agent.agents.context import BaseContext
from agent.agents.math_agent import MathAgent
from agent.middleware.mcp_bridge import mcp_context_bridge

_SUPERVISOR_PROMPT = (
    "你是 DeepView 的调度员，负责将任务委派给子代理。"
    "所有数学计算必须委派给 math 子代理，并明确指示其调用 circle_area 或 square_area 工具，禁止手动计算或估算。"
    "当 math 子代理返回工具结果后，你再用自然语言总结公式、代入过程和结论。"
    "若缺少关键参数（如半径/边长），调用 ask_user 提问获取，禁止猜测。"
)

_SUBAGENT_DISABLED_TOOLS = frozenset(
    {"ask_user", "ask_user_question", "present_artifacts", "install_skill"}
)


@_tool
def ask_user(question: str) -> str:
    """向用户发起自由文本提问并等待回答。"""
    if not isinstance(question, str) or not question.strip():
        raise ValueError("question 不能为空")
    payload = {"question": question.strip(), "source": "ask_user"}
    answer = interrupt(payload)
    if isinstance(answer, dict):
        return str(answer.get("answer") or answer.get("question") or "")
    return str(answer)


class SupervisorAgent(BaseAgent):
    name = "supervisor"
    description = "调度员，主代理"
    context_schema = BaseContext

    def __init__(self, *, checkpointer: Any | None = None, **kwargs: Any) -> None:
        super().__init__(checkpointer=checkpointer, **kwargs)

    async def get_graph(self, **kwargs: Any):  # type: ignore[override]
        context = kwargs.get("context")
        if context is None:
            context = BaseContext()
        if isinstance(context, dict):
            tmp = BaseContext()
            tmp.update_from_dict(context)
            context = tmp
        from deepagents import create_deep_agent

        checkpointer = await self._get_checkpointer()
        math_agent = MathAgent(checkpointer=checkpointer)
        math_recipe = math_agent.to_recipe(context)
        limit = getattr(context, "max_execution_steps", None)
        if limit is None:
            limit = getattr(context, "tool_loop_max_iterations", 10)
        if not isinstance(limit, int) or limit <= 0:
            limit = 10
        model = kwargs.get("model")
        if model is None:
            try:
                from core import get_config
                from provider import build_chat_model

                cfg = get_config()
                model = build_chat_model(cfg.llm)
            except Exception:  # noqa: BLE001
                model = None
        interrupt_on = kwargs.get("interrupt_on")
        if interrupt_on and checkpointer is None:
            msg = "interrupt_on requires checkpointer"
            raise ValueError(msg)
        kwargs.pop("context", None)
        kwargs.pop("model", None)
        kwargs.pop("checkpointer", None)
        graph = create_deep_agent(
            model=model,
            tools=[ask_user],
            subagents=[math_recipe],  # ty: ignore[invalid-argument-type]
            system_prompt=_SUPERVISOR_PROMPT,
            context_schema=BaseContext,
            checkpointer=checkpointer,
            middleware=[mcp_context_bridge],  # ty: ignore[invalid-argument-type]
            **kwargs,
        )
        with contextlib.suppress(Exception):
            object.__setattr__(graph, "_tool_loop_max_iterations", limit)  # type: ignore[attr-defined]
        return graph
