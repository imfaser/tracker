"""可配置上下文，后端生成 thread_id 并落库。"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass(kw_only=True)
class BaseContext:
    """可配置上下文，后端生成 thread_id 并落库。"""

    thread_id: str = field(
        default_factory=lambda: str(uuid.uuid4()),
        metadata={"kind": "thread", "configurable": False},
    )  # 会话隔离键，由后端生成落库
    uid: str = field(
        default_factory=lambda: str(uuid.uuid4()), metadata={"kind": "uid", "configurable": False}
    )  # 用户会话标识，与 thread_id 一起组成 configurable
    run_id: str | None = field(
        default=None, metadata={"kind": "run", "configurable": False}
    )  # 单次运行标识
    user_id: str = field(default="", metadata={"kind": "user", "configurable": True})  # 业务用户
    tenant_id: str = field(
        default="", metadata={"kind": "tenant", "configurable": True}
    )  # 租户隔离
    trace_id: str | None = field(
        default=None, metadata={"kind": "trace", "configurable": False}
    )  # 追踪关联
    system_prompt: str = field(
        default="You are a helpful assistant.", metadata={"kind": "prompt", "configurable": True}
    )  # 系统提示词
    model: str = field(default="", metadata={"kind": "llm", "configurable": True})  # 模型名
    tools: list[str] | None = field(
        default=None, metadata={"kind": "tools", "configurable": True}
    )  # 允许工具白名单
    mcps: list[str] | None = field(
        default=None, metadata={"kind": "mcps", "configurable": True}
    )  # 允许 MCP 列表
    skills: list[str] | None = field(
        default=None, metadata={"kind": "skills", "configurable": True}
    )  # 允许技能列表
    max_execution_steps: int = field(
        default=10, metadata={"kind": "limit", "configurable": True}
    )  # 递归/步数上限
    tool_loop_max_iterations: int = field(
        default=10, metadata={"kind": "limit", "configurable": True}
    )  # 兼容旧限流字段，与 max_execution_steps 同义

    def update_from_dict(self, data: dict[str, Any]) -> None:
        for k, v in (data or {}).items():
            if hasattr(self, k):
                setattr(self, k, v)


def build_agent_input_context(
    agent_config: dict | None, *, thread_id: str, uid: str, **kwargs: Any
) -> dict[str, Any]:
    ctx = dict(agent_config or {})
    ctx.update({"thread_id": thread_id, "uid": uid})
    ctx.update(kwargs)
    return ctx


def normalize_agent_context_config(
    context: dict | None,
    *,
    available_tools: list[str] | None = None,
    available_mcps: list[str] | None = None,
) -> dict[str, Any]:
    ctx = dict(context or {})
    if available_tools is not None:
        allowed = set(available_tools)
        cur = ctx.get("tools")
        if cur is None:
            ctx["tools"] = list(allowed)
        elif isinstance(cur, list):
            ctx["tools"] = [x for x in cur if x in allowed]
    if available_mcps is not None:
        allowed = set(available_mcps)
        cur = ctx.get("mcps")
        if cur is None:
            ctx["mcps"] = list(allowed)
        elif isinstance(cur, list):
            ctx["mcps"] = [x for x in cur if x in allowed]
    return ctx


async def prepare_agent_runtime_context(context: BaseContext, **kwargs: Any) -> BaseContext:
    return context
