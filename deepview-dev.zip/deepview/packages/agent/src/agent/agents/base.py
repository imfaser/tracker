"""基础代理，托管 checkpointer 与 thread_id 持久化。"""

from __future__ import annotations

import uuid
from abc import abstractmethod
from typing import Any, ClassVar

from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command

from agent.agents.context import BaseContext


class BaseAgent:
    """基础代理，托管 checkpointer 与 thread_id 持久化。"""

    name = "base_agent"
    description = "base_agent"
    capabilities: ClassVar[list[str]] = []
    context_schema: Any = BaseContext

    def __init__(self, *, checkpointer: Any | None = None, **kwargs: Any) -> None:
        self._checkpointer = checkpointer
        self.graph: CompiledStateGraph | None = None
        self._extra_kwargs = kwargs

    async def _get_checkpointer(self) -> Any:
        if self._checkpointer is not None:
            return self._checkpointer
        try:
            from langgraph.checkpoint.memory import InMemorySaver

            self._checkpointer = InMemorySaver()
            return self._checkpointer
        except Exception:  # noqa: BLE001
            return None

    @abstractmethod
    async def get_graph(self, **kwargs: Any) -> CompiledStateGraph:
        raise NotImplementedError

    def _build_context(self, input_context: dict | None) -> BaseContext:
        # 显式构造上下文，避免 setattr 魔法
        if isinstance(input_context, dict):
            ctx = BaseContext()
            ctx.update_from_dict(input_context)
            return ctx
        if isinstance(input_context, BaseContext):
            return input_context
        return BaseContext() if not callable(self.context_schema) else self.context_schema()

    def _build_config(self, context: BaseContext, **kwargs: Any) -> dict[str, Any]:
        # thread_id/uid 显式透传至 configurable，供 checkpointer 隔离会话
        thread_id = context.thread_id or str(uuid.uuid4())
        uid = context.uid or str(uuid.uuid4())
        # 单一限流来源，避免双名偷读
        limit = context.max_execution_steps
        if not isinstance(limit, int) or limit <= 0:
            limit = 10
        config: dict[str, Any] = {
            "configurable": {"thread_id": thread_id, "uid": uid},
            "recursion_limit": limit,
        }
        if callbacks := kwargs.get("callbacks"):
            config["callbacks"] = list(callbacks)
        if metadata := kwargs.get("metadata"):
            config["metadata"] = dict(metadata)
        return config

    async def stream_messages(
        self, messages: list[Any], input_context: dict | None = None, **kwargs: Any
    ) -> Any:
        context = self._build_context(input_context)
        graph = await self.get_graph(context=context)
        config = self._build_config(context, **kwargs)
        async for msg, metadata in graph.astream(
            {"messages": messages},
            stream_mode="messages",
            context=context,
            config=config,
        ):
            yield msg, metadata

    async def stream_resume(
        self, resume: Any, input_context: dict | None = None, **kwargs: Any
    ) -> Any:
        context = self._build_context(input_context)
        graph = await self.get_graph(context=context)
        config = self._build_config(context, **kwargs)
        if isinstance(resume, Command):
            resume_input = resume
        elif isinstance(resume, dict) and "resume" in resume:
            resume_input = Command(resume=resume["resume"])
        else:
            resume_input = Command(resume=resume)
        async for msg, metadata in graph.astream(
            resume_input,
            stream_mode="messages",
            context=context,
            config=config,
        ):
            yield msg, metadata

    async def get_history(self, uid: str, thread_id: str) -> list[dict]:
        try:
            graph = await self.get_graph()
            if not hasattr(graph, "checkpointer") or graph.checkpointer is None:
                return []
            config = {"configurable": {"thread_id": thread_id, "uid": uid}}
            state = await graph.aget_state(config)
            result: list[dict] = []
            if state:
                messages = state.values.get("messages", [])
                for msg in messages:
                    if hasattr(msg, "model_dump"):
                        result.append(msg.model_dump())
                    elif hasattr(msg, "__dict__"):
                        result.append({"content": str(msg)})
                    else:
                        result.append({"content": str(msg)})
            return result
        except Exception:  # noqa: BLE001
            return []

    def reload_graph(self) -> None:
        self.graph = None
