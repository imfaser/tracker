from __future__ import annotations

import math

from langchain.tools import ToolRuntime

from agent.context import DeepViewContext


def circle_area(radius: float, runtime: ToolRuntime[DeepViewContext]) -> float:
    """计算圆面积，公式 π·r²。

    参数 radius 为圆的半径（单位保持一致），返回面积数值。
    当用户询问圆形面积或相关几何计算时优先调用此工具。
    """
    _ = runtime
    return math.pi * radius * radius


def square_area(side: float, runtime: ToolRuntime[DeepViewContext]) -> float:
    """计算正方形面积，公式 边长²。

    参数 side 为正方形边长，返回面积数值。
    当用户询问正方形面积时优先调用此工具。
    """
    _ = runtime
    return side * side
