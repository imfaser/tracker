from __future__ import annotations

from telemetry.base import TelemetryBackend
from telemetry.configure import Telemetry


def register_backend(name: str):
    """把后端子类登记进 Telemetry 单例的注册表。"""

    def _wrap(cls: type[TelemetryBackend]) -> type[TelemetryBackend]:
        if name in Telemetry._REGISTRY:
            msg = f"telemetry backend {name!r} already registered"
            raise ValueError(msg)
        Telemetry._REGISTRY[name] = cls
        return cls

    return _wrap
