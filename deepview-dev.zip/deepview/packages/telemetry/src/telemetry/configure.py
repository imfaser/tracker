from __future__ import annotations

import logging
from typing import ClassVar

from core.schema import TelemetryConfig
from opentelemetry.sdk.trace import TracerProvider

from telemetry.base import TelemetryBackend

logger = logging.getLogger(__name__)

# 优先级收口为模块级常量，Telemetry 类内保留别名以兼容
PRIORITY: list[str] = ["phoenix", "openobserve"]
_REGISTRY: dict[str, type[TelemetryBackend]] = {}


class Telemetry:
    """链路追踪单例（进程内只配置一次）。"""

    _instance: ClassVar[Telemetry | None] = None
    _REGISTRY: ClassVar[dict[str, type[TelemetryBackend]]] = _REGISTRY
    _PRIORITY: ClassVar[list[str]] = PRIORITY

    def __init__(self) -> None:
        self._configured = False
        self._provider: TracerProvider | None = None

    @classmethod
    def instance(cls) -> Telemetry:
        """返回遥测单例；首次访问时创建。"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """清空单例缓存，供测试隔离使用（对称 AppConfig.reset）。"""
        cls._instance = None

    def configure(self, cfg: TelemetryConfig) -> list[str]:
        """按配置启动链路追踪，返回冲突的后端名单。"""
        if self._configured:
            return []

        want = [name for name in self._PRIORITY if getattr(cfg, name).enabled]
        conflicts = want[1:]
        owner = want[0] if want else None

        if owner is not None:
            backend = self._REGISTRY[owner](getattr(cfg, owner))
            backend.setup()
            self._provider = backend._provider
            if conflicts:
                logger.warning("遥测后端冲突: 仅启用 %s, 其余被忽略: %s", owner, conflicts)

        self._configured = True
        return conflicts

    def shutdown(self) -> None:
        """停机已注册的 TracerProvider（刷新导出的 span）。"""
        if self._configured and self._provider is not None:
            self._provider.shutdown()
        self._configured = False
        self._provider = None


def configure_telemetry(cfg: TelemetryConfig) -> list[str]:
    """入口：按配置启动链路追踪，返回冲突的后端名单。"""
    return Telemetry.instance().configure(cfg)


def shutdown_telemetry() -> None:
    """入口：停机已注册的 TracerProvider。"""
    Telemetry.instance().shutdown()


def reset_telemetry() -> None:
    """入口：重置遥测单例，供测试隔离。"""
    Telemetry.reset()
