from __future__ import annotations

from core.schema import PhoenixConfig
from phoenix.otel import register

from telemetry.base import TelemetryBackend
from telemetry.registry import register_backend


@register_backend("phoenix")
class PhoenixBackend(TelemetryBackend[PhoenixConfig]):
    """Phoenix 后端（arize-phoenix-otel 一键初始化，保留自动打桩）。"""

    name = "phoenix"

    def setup(self) -> None:
        # 注入 api_key 时统一走 Authorization: Bearer
        headers = dict(self.config.headers)
        if self.config.api_key is not None:
            headers.setdefault("Authorization", f"Bearer {self.config.api_key}")

        kwargs: dict = {
            "project_name": self.config.project_name,
            "protocol": self.config.protocol,
            "headers": headers,
            "batch": self.config.batch,
            "auto_instrument": self.config.auto_instrument,
        }
        if self.config.endpoint is not None:
            kwargs["endpoint"] = self.config.endpoint

        self._provider = register(**kwargs)

    def shutdown(self) -> None:
        if self._provider is not None:
            self._provider.shutdown()
