from __future__ import annotations

from core.schema import OpenObserveConfig
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from telemetry.base import TelemetryBackend
from telemetry.registry import register_backend


def _resolve_endpoint(cfg: OpenObserveConfig) -> str:
    """endpoint 未显式给出时按 org 拼出 OpenObserve 默认 traces 路径。"""
    if cfg.endpoint:
        return cfg.endpoint
    return f"http://localhost:5080/api/{cfg.org}/v1/traces"


@register_backend("openobserve")
class OpenObserveBackend(TelemetryBackend[OpenObserveConfig]):
    """OpenObserve 后端（标准 OTLP 手动对接，不依赖 openobserve-telemetry-sdk）。"""

    name = "openobserve"

    def setup(self) -> None:
        resource = Resource(attributes={SERVICE_NAME: self.config.service_name})
        provider = TracerProvider(resource=resource)
        headers = dict(self.config.headers)
        # OpenObserve 用 stream-name 头决定 trace 落入哪个流；用户未在 headers 显式指定时取配置
        headers.setdefault("stream-name", self.config.stream_name)
        exporter = OTLPSpanExporter(
            endpoint=_resolve_endpoint(self.config),
            headers=headers,
        )
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        self._provider = provider

    def shutdown(self) -> None:
        if self._provider is not None:
            self._provider.shutdown()
