from __future__ import annotations

from abc import ABC, abstractmethod

from opentelemetry.sdk.trace import TracerProvider


class TelemetryBackend[C](ABC):
    """链路追踪后端抽象基类。"""

    # 抽象只到「组装并注册 provider」「停机」两类动作；配置由各后端自带独立类型
    name: str

    def __init__(self, config: C) -> None:
        self.config = config
        self._provider: TracerProvider | None = None

    @abstractmethod
    def setup(self) -> None:
        """组装并注册该后端的 TracerProvider。"""
        raise NotImplementedError

    @abstractmethod
    def shutdown(self) -> None:
        """停机/刷新该后端的导出管道。"""
        raise NotImplementedError
