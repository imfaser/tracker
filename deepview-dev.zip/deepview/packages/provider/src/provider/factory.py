from __future__ import annotations

from core.schema import LLMConfig
from langchain_core.language_models import BaseChatModel

from provider.errors import LlmConfigError
from provider.providers.mimo import MiMoProvider

# ProviderRegistry 占位：后续多 provider 时可引入映射
# PROVIDERS: dict[str, type[BaseChatModelProvider]] = {"mimo": MiMoProvider}


def build_chat_model(cfg: LLMConfig, *, thinking: bool | None = None) -> BaseChatModel:
    """配置 → match type → provider 实例 → build_chat_model。"""
    match cfg.type:
        case "mimo":
            return MiMoProvider(cfg).build_chat_model(thinking=thinking)
        case _:
            raise LlmConfigError(f"unsupported llm type: {cfg.type!r}")
