"""Vercel Adapter 函数式管道。"""

from __future__ import annotations

from typing import Any

from toolz import curry, pipe


def validate(payload: dict[str, Any]) -> dict[str, Any]:
    """校验载荷结构。"""
    if not isinstance(payload.get("messages"), list) or not payload["messages"]:
        msg = "messages must not be empty"
        raise ValueError(msg)
    for idx, m in enumerate(payload["messages"]):
        if m.get("role") not in ("user", "assistant", "system", "tool"):
            msg = f"message {idx} has invalid role"
            raise ValueError(msg)
    return payload


def to_base_messages(payload: dict[str, Any]) -> list[Any]:
    """转换为 BaseMessage。"""
    from vercel_adapter.messages import to_base_messages_v7

    return to_base_messages_v7(payload["messages"])


def build_context(thread_id: str, base_messages: list[Any]) -> dict[str, Any]:
    """构建上下文。"""
    return {"thread_id": thread_id, "messages": base_messages}


def trace_context(context: dict[str, Any], trace_id: str | None = None) -> dict[str, Any]:
    """注入 trace。"""
    if trace_id:
        context["trace_id"] = trace_id
    return context


def to_sse(context: dict[str, Any]) -> dict[str, Any]:
    """占位：转 SSE。"""
    return context


@curry
def validate_curried(payload: dict[str, Any]) -> dict[str, Any]:
    return validate(payload)


async def async_pipe(data: Any, *funcs: Any) -> Any:
    """异步管道。"""
    result = data
    for fn in funcs:
        if hasattr(result, "__aiter__"):
            result = fn(result)
        else:
            result = fn(result)
            if hasattr(result, "__await__"):
                result = await result
    return result


def run_sync_pipeline(payload: dict[str, Any]) -> list[Any]:
    """同步管道：validate -> to_base_messages。"""
    return pipe(payload, validate, to_base_messages)  # type: ignore[arg-type]
