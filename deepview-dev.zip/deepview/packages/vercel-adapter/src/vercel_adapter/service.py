"""Vercel AI SDK v7 的 Chat Stream 服务与追踪。"""

from __future__ import annotations

import contextlib
import uuid
from typing import Any

import anyio
import structlog
from core.config import AppConfig
from fastapi import Request
from opentelemetry import trace

from vercel_adapter.converter import create_ui_message_stream_response, to_ui_message_stream_v7

_tracer = trace.get_tracer("deepview.server")
_log = structlog.get_logger(__name__)


def _get_trace_id(span: Any) -> str | None:
    ctx = span.get_span_context()
    if not ctx.is_valid or ctx.trace_id == 0:
        return None
    return f"{ctx.trace_id:032x}"


def _get_supervisor(request: Request | None) -> Any | None:
    if request is not None:
        state = getattr(getattr(request, "app", None), "state", None)
        if state is not None:
            sup = getattr(state, "supervisor", None)
            if sup is not None:
                return sup
    return None


async def _chat_stream(
    request: Request,
    outer_span: Any,
    outer_trace_id: str | None,
    cfg: AppConfig,
    base_messages: list[Any],
    thread_id: str,
    expose: bool,
    end_span: Any,
) -> Any:
    with trace.use_span(outer_span, end_on_exit=False):  # type: ignore[attr-defined]
        try:
            if not cfg.llm.model or not cfg.llm.base_url:

                async def err_stream() -> Any:
                    yield {"type": "error", "errorText": "llm config error"}

                async for b in to_ui_message_stream_v7(
                    err_stream(), expose_trace_id=expose, trace_id=outer_trace_id
                ):
                    if await request.is_disconnected():
                        break
                    yield b
                return

            supervisor = _get_supervisor(request)
            if supervisor is None:

                async def _missing_supervisor() -> Any:
                    yield {"type": "error", "errorText": "supervisor not initialized"}

                async for b in to_ui_message_stream_v7(
                    _missing_supervisor(), expose_trace_id=expose, trace_id=outer_trace_id
                ):
                    yield b
                return

            messages: list[Any] = list(base_messages)
            from agent.agents.context import BaseContext

            deepview_ctx = BaseContext(thread_id=thread_id, uid=thread_id)
            # system_prompt 已在 AgentConfig，BaseContext 不再承载
            _ = getattr(cfg.agent, "system_prompt", None)
            output_buf: list[str] = []
            reasoning_buf: list[str] = []

            async def _collect_stream() -> Any:
                from langchain_core.messages import AIMessageChunk, ToolMessage
                from langgraph.types import Command

                tool_messages = [m for m in messages if isinstance(m, ToolMessage)]
                use_resume = False
                resume_value: Any = None
                if tool_messages:
                    last_tool = tool_messages[-1]
                    resume_value = getattr(last_tool, "content", "")
                    use_resume = True
                try:
                    if hasattr(supervisor, "get_graph"):
                        graph = await supervisor.get_graph(context=deepview_ctx)
                    else:
                        graph = supervisor
                    limit = getattr(cfg.agent, "max_steps", None) or getattr(
                        cfg.agent, "tool_loop_max_iterations", 10
                    )
                    if use_resume:
                        result = await graph.ainvoke(
                            Command(resume=resume_value),
                            config={
                                "configurable": {"thread_id": thread_id, "uid": thread_id},
                                "recursion_limit": limit,
                            },
                            context=deepview_ctx,
                        )
                    else:
                        result = await graph.ainvoke(
                            {"messages": messages},
                            config={
                                "configurable": {"thread_id": thread_id, "uid": thread_id},
                                "recursion_limit": limit,
                            },
                            context=deepview_ctx,
                        )
                except Exception as exc:  # noqa: BLE001
                    yield {"type": "error", "errorText": str(exc)[:200]}
                    return
                if isinstance(result, dict) and "__interrupt__" in result:
                    inters = result["__interrupt__"]
                    if inters:
                        first = inters[0] if isinstance(inters, list) else inters
                        val = getattr(first, "value", first)
                        if isinstance(val, dict) and "question" in val:
                            q = val["question"]
                        else:
                            q = str(val)
                        yield AIMessageChunk(
                            content="",
                            tool_calls=[
                                {
                                    "id": f"call_ask_{thread_id[:4]}",
                                    "name": "ask_user",
                                    "args": {"question": q},
                                }
                            ],  # type: ignore[arg-type]
                        )
                        return
                    return
                msgs = result.get("messages", []) if isinstance(result, dict) else []
                for msg in msgs:
                    if msg.__class__.__name__ == "HumanMessage":
                        continue
                    content = getattr(msg, "content", "")
                    if isinstance(content, str) and content:
                        output_buf.append(content)
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                t = block.get("text")
                                if isinstance(t, str):
                                    output_buf.append(t)
                            elif isinstance(block, str):
                                output_buf.append(block)
                    add_kwargs = getattr(msg, "additional_kwargs", {}) or {}
                    if isinstance(add_kwargs, dict) and add_kwargs.get("reasoning_content"):
                        reasoning_buf.append(str(add_kwargs["reasoning_content"]))
                    if hasattr(msg, "tool_calls"):
                        yield AIMessageChunk(
                            content=content if isinstance(content, str) else "",
                            additional_kwargs=add_kwargs,
                            tool_calls=getattr(msg, "tool_calls", []),  # type: ignore[arg-type]
                        )
                    else:
                        yield AIMessageChunk(
                            content=content if isinstance(content, str) else "",
                            additional_kwargs=add_kwargs,
                        )
                    await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
                _ = deepview_ctx

            async for b in to_ui_message_stream_v7(
                _collect_stream(), expose_trace_id=expose, trace_id=outer_trace_id
            ):
                if await request.is_disconnected():
                    outer_span.set_attribute("chat.cancelled", True)
                    break
                yield b
                await anyio.lowlevel.checkpoint()  # ty: ignore[unresolved-attribute]
            with contextlib.suppress(Exception):
                import json as _json

                outer_span.set_attribute(
                    "output.value",
                    _json.dumps(
                        {"reasoning": "".join(reasoning_buf), "content": "".join(output_buf)},
                        ensure_ascii=False,
                    )[:4000],
                )
                outer_span.set_attribute("output.mime_type", "application/json")
        except anyio.get_cancelled_exc_class():  # type: ignore[attr-defined]
            outer_span.set_attribute("chat.cancelled", True)
            raise
        except Exception as exc:
            outer_span.record_exception(exc)
            raise
        finally:
            end_span()


def create_chat_stream_response(
    request: Request,
    base_messages: list[Any],
    thread_id: str | None = None,
    cfg: AppConfig | None = None,
) -> Any:
    from core import get_config

    cfg = cfg or get_config()
    tid = thread_id or f"thread_{uuid.uuid4().hex}"
    expose = bool(cfg.telemetry.expose_trace_id)

    outer_span: Any = _tracer.start_span("chat.stream")
    outer_trace_id = _get_trace_id(outer_span)
    if outer_trace_id:
        outer_span.set_attribute("chat.thread_id", tid)
        outer_span.set_attribute("chat.message_count", len(base_messages))
    import json as _json

    try:
        outer_span.set_attribute(
            "input.value",
            _json.dumps(
                [m.model_dump() if hasattr(m, "model_dump") else str(m) for m in base_messages],
                ensure_ascii=False,
            )[:4000],
        )
    except Exception:  # noqa: BLE001
        outer_span.set_attribute("input.value", str(base_messages)[:4000])
    outer_span.set_attribute("input.mime_type", "application/json")
    outer_span.set_attribute("session.id", tid)
    outer_span.set_attribute("openinference.span.kind", "CHAIN")

    ended = False

    def _end_span() -> None:
        nonlocal ended
        if not ended:
            ended = True
            with contextlib.suppress(Exception):
                outer_span.end()

    stream = _chat_stream(
        request, outer_span, outer_trace_id, cfg, base_messages, tid, expose, _end_span
    )
    return create_ui_message_stream_response(stream, trace_id=outer_trace_id, thread_id=tid)


class ChatStreamService:
    def __init__(self, cfg: AppConfig | None = None) -> None:
        from core import get_config

        self.cfg = cfg or get_config()

    def create_response(self, request: Request, base_messages: list[Any], thread_id: str) -> Any:
        return create_chat_stream_response(request, base_messages, thread_id, self.cfg)
