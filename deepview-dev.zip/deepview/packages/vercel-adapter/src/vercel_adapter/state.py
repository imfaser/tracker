"""聊天流状态机。"""

from __future__ import annotations

from typing import Any, ClassVar

from transitions import Machine


class ChatStreamStateMachine:
    """流式状态机：idle → streaming → interrupted → resuming → done/error/cancelled。"""

    states: ClassVar[list[str]] = [
        "idle",
        "streaming",
        "interrupted",
        "resuming",
        "done",
        "error",
        "cancelled",
    ]

    def __init__(self) -> None:
        self.machine = Machine(
            model=self,
            states=ChatStreamStateMachine.states,
            initial="idle",
            ignore_invalid_triggers=True,
        )
        self.machine.add_transition("start", "idle", "streaming")
        self.machine.add_transition("interrupt", "streaming", "interrupted")
        self.machine.add_transition("resume", "interrupted", "resuming")
        self.machine.add_transition("stream", "resuming", "streaming")
        self.machine.add_transition("finish", ["streaming", "resuming"], "done")
        self.machine.add_transition(
            "fail", ["idle", "streaming", "resuming", "interrupted"], "error"
        )
        self.machine.add_transition(
            "cancel", ["idle", "streaming", "resuming", "interrupted"], "cancelled"
        )
        self._text_active = False
        self._reasoning_active = False
        self._seen_tool_calls: set[str] = set()

    def on_enter_streaming(self, **kwargs: Any) -> None:
        self._text_active = False
        self._reasoning_active = False

    def on_enter_text(self, **kwargs: Any) -> None:
        self._text_active = True

    def on_exit_text(self, **kwargs: Any) -> None:
        self._text_active = False

    def on_enter_reasoning(self, **kwargs: Any) -> None:
        self._reasoning_active = True

    def on_exit_reasoning(self, **kwargs: Any) -> None:
        self._reasoning_active = False

    def mark_tool_seen(self, tool_id: str) -> bool:
        if tool_id in self._seen_tool_calls:
            return False
        self._seen_tool_calls.add(tool_id)
        return True

    @property
    def text_active(self) -> bool:
        return self._text_active

    @property
    def reasoning_active(self) -> bool:
        return self._reasoning_active
