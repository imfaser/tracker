module.exports = {
  apps: [
    {
      name: "server",
      interpreter: "none",
      script: "uv",
      args: "run server",
      cwd: __dirname,
      autorestart: false,
      watch: false,
      env: {
        PYTHONUNBUFFERED: "1",
      },
    },
    {
      name: "worker",
      interpreter: "none",
      script: "uv",
      args: "run python -m server.worker",
      cwd: __dirname,
      autorestart: false,
      watch: false,
      env: {
        PYTHONUNBUFFERED: "1",
      },
    },
    {
      name: "nats",
      interpreter: "none",
      script: "docker",
      args: "run --rm -p 6015:4222 -p 8222:8222 nats:alpine -js",
      cwd: __dirname,
      autorestart: false,
      watch: false,
    },
  ],
};
