module.exports = {
  apps: [
    {
      name: "server",
      // Run the server through uv so it uses the workspace virtual environment.
      interpreter: "none",
      script: "uv",
      args: "run server",
      cwd: __dirname,
      autorestart: false,
      watch: false,
      env: {
        PYTHONUNBUFFERED: "1",
      },
    },
  ],
};
