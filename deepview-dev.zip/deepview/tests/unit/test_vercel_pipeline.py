from vercel_adapter.pipeline import validate
from vercel_adapter.state import ChatStreamStateMachine


def test_pipeline_validate():
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    assert validate(payload) == payload


def test_pipeline_validate_empty():
    import pytest

    with pytest.raises(ValueError):
        validate({"messages": []})


def test_state_machine_transitions():
    m = ChatStreamStateMachine()
    assert m.state == "idle"
    m.start()
    assert m.state == "streaming"
    m.interrupt()
    assert m.state == "interrupted"
    m.resume()
    assert m.state == "resuming"
    m.stream()
    assert m.state == "streaming"
    m.finish()
    assert m.state == "done"


def test_state_machine_cancel():
    m = ChatStreamStateMachine()
    m.start()
    m.cancel()
    assert m.state == "cancelled"
