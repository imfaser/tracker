import warnings

import pytest

warnings.filterwarnings("ignore", category=DeprecationWarning)

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

import anyio
from agent.agents.context import BaseContext
from agent.agents.math_agent import MathAgent
from agent.agents.supervisor_agent import SupervisorAgent


def test_create_math_subagent_has_tools():
    recipe = MathAgent().to_recipe(context=BaseContext())
    assert recipe["name"] == "math"
    assert len(recipe["tools"]) == 2
    assert {t.name for t in recipe["tools"]} == {"circle_area", "square_area"}


def test_create_supervisor_has_math_subagent_and_budget():
    async def _run():
        sup = SupervisorAgent()
        graph = await sup.get_graph(context=BaseContext())
        assert graph is not None
        assert getattr(graph, "_tool_loop_max_iterations", None) == 10

    anyio.run(_run)


def test_create_supervisor_respects_config_budget():
    async def _run():
        from core import AppConfig
        from core.schema import AgentConfig

        AppConfig.reset()
        _ = AppConfig(agent=AgentConfig(max_steps=15))
        # 预算由 AgentConfig 托管，此处仅验 BaseContext 可构造
        sup = SupervisorAgent()
        graph = await sup.get_graph(context=BaseContext())
        assert getattr(graph, "_tool_loop_max_iterations", None) is not None

    anyio.run(_run)


def test_interrupt_requires_checkpointer():
    async def _run():
        sup = SupervisorAgent()
        graph = await sup.get_graph(context=BaseContext(), interrupt_on={"circle_area": True})
        assert graph is not None

    anyio.run(_run)
