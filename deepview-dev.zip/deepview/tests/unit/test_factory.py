import pytest
from core.schema import LLMConfig
from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI
from provider import LlmConfigError, build_chat_model
from provider.providers.mimo import MiMoProvider
from pydantic import SecretStr


def test_build_chat_model_dispatches_to_mimo(monkeypatch):
    captured = {}

    def _fake_build(self, *, thinking=None):
        captured["thinking"] = thinking
        # 返回真实 MiMoChatModel 验证工厂分发与返回类型（构造不触网）
        return ChatOpenAI(model="m", base_url="http://x/v1", api_key=SecretStr("k"))

    monkeypatch.setattr(MiMoProvider, "build_chat_model", _fake_build)
    cfg = LLMConfig(type="mimo", base_url="http://x/v1", model="MiMo-V2.5")
    model = build_chat_model(cfg, thinking=True)
    assert isinstance(model, BaseChatModel)
    assert captured["thinking"] is True


def test_build_chat_model_unknown_type_raises(monkeypatch):
    # 保证即便以后新增 provider，未知 type 也由 match 兜底报错
    cfg = LLMConfig(type="unknown", base_url="http://x/v1", model="m")
    with pytest.raises(LlmConfigError):
        build_chat_model(cfg)
