from __future__ import annotations

import logging

import pytest
from core.schema import OpenObserveConfig, PhoenixConfig, TelemetryConfig
from opentelemetry.sdk.trace import TracerProvider
from telemetry import configure_telemetry, reset_telemetry, shutdown_telemetry
from telemetry.backends.openobserve import OpenObserveBackend
from telemetry.backends.phoenix import PhoenixBackend


class _DummySpanProcessor:
    """桩：仅占位，不启后台线程、不导出，避免打扰真实 provider 生命周期。"""

    def __init__(self, *args, **kwargs) -> None:
        pass

    def shutdown(self, *args, **kwargs) -> None:
        pass


def _mock_setups(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    """把两个后端的 setup 替换成只记录调用的桩。"""
    # 不碰真实 TracerProvider：幂等由单例 _configured 守卫判定，避开 OTel 一次限制
    calls: list[str] = []
    monkeypatch.setattr(PhoenixBackend, "setup", lambda self: calls.append("phoenix"))
    monkeypatch.setattr(OpenObserveBackend, "setup", lambda self: calls.append("openobserve"))
    return calls


def test_empty_config_returns_no_conflicts(monkeypatch):
    calls = _mock_setups(monkeypatch)
    assert configure_telemetry(TelemetryConfig()) == []
    assert calls == []


def test_single_backend_no_conflict(monkeypatch):
    calls = _mock_setups(monkeypatch)
    assert configure_telemetry(TelemetryConfig(phoenix=PhoenixConfig(enabled=True))) == []
    assert calls == ["phoenix"]


def test_only_openobserve_backend(monkeypatch):
    calls = _mock_setups(monkeypatch)
    assert configure_telemetry(TelemetryConfig(openobserve=OpenObserveConfig(enabled=True))) == []
    assert calls == ["openobserve"]


def test_multiple_backends_logs_conflict_and_returns(monkeypatch, caplog):
    calls = _mock_setups(monkeypatch)
    cfg = TelemetryConfig(
        phoenix=PhoenixConfig(enabled=True),
        openobserve=OpenObserveConfig(enabled=True),
    )
    with caplog.at_level(logging.WARNING, logger="telemetry.configure"):
        conflicts = configure_telemetry(cfg)
    # 仅优先级最高的 phoenix 被启动，openobserve 作为冲突返回
    assert conflicts == ["openobserve"]
    assert calls == ["phoenix"]
    assert any("遥测后端冲突" in record.message for record in caplog.records)


def test_idempotent_second_call_is_noop(monkeypatch):
    calls = _mock_setups(monkeypatch)
    cfg = TelemetryConfig(phoenix=PhoenixConfig(enabled=True))
    configure_telemetry(cfg)
    assert configure_telemetry(cfg) == []
    assert calls == ["phoenix"]


def test_reset_allows_reconfigure(monkeypatch):
    calls = _mock_setups(monkeypatch)
    cfg = TelemetryConfig(phoenix=PhoenixConfig(enabled=True))
    configure_telemetry(cfg)
    reset_telemetry()
    configure_telemetry(cfg)
    assert calls == ["phoenix", "phoenix"]


def test_shutdown_calls_provider_shutdown(monkeypatch):
    """shutdown 应触发被配置 provider 的 shutdown（验证停机语义）。"""
    shutdown_calls: list[int] = []

    class _TrackedProvider(TracerProvider):
        def shutdown(self):
            shutdown_calls.append(1)
            return super().shutdown()

    def fake_setup(self: OpenObserveBackend) -> None:
        self._provider = _TrackedProvider()

    monkeypatch.setattr(OpenObserveBackend, "setup", fake_setup)
    configure_telemetry(TelemetryConfig(openobserve=OpenObserveConfig(enabled=True)))
    shutdown_telemetry()
    assert shutdown_calls == [1]


def test_openobserve_injects_stream_name_header(monkeypatch):
    """OpenObserve 后端应把 stream_name 注入为 stream-name 请求头。"""
    captured: dict = {}

    def _fake_exporter(**kwargs):
        captured.update(kwargs)
        return object()

    # 桩掉真实导出器/处理器，只验证传给 OTLPSpanExporter 的 headers
    monkeypatch.setattr("telemetry.backends.openobserve.OTLPSpanExporter", _fake_exporter)
    monkeypatch.setattr("telemetry.backends.openobserve.BatchSpanProcessor", _DummySpanProcessor)
    monkeypatch.setattr("telemetry.backends.openobserve.trace.set_tracer_provider", lambda p: None)

    OpenObserveBackend(OpenObserveConfig(enabled=True, stream_name="deepview-traces")).setup()
    assert captured["headers"]["stream-name"] == "deepview-traces"


def test_openobserve_user_stream_name_header_wins(monkeypatch):
    """用户在 headers 里显式写 stream-name 时，应优先于配置值。"""
    captured: dict = {}

    def _fake_exporter(**kwargs):
        captured.update(kwargs)
        return object()

    monkeypatch.setattr("telemetry.backends.openobserve.OTLPSpanExporter", _fake_exporter)
    monkeypatch.setattr("telemetry.backends.openobserve.BatchSpanProcessor", _DummySpanProcessor)
    monkeypatch.setattr("telemetry.backends.openobserve.trace.set_tracer_provider", lambda p: None)

    cfg = OpenObserveConfig(enabled=True, stream_name="default", headers={"stream-name": "mine"})
    OpenObserveBackend(cfg).setup()
    assert captured["headers"]["stream-name"] == "mine"
