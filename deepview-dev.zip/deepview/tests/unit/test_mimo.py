import pytest
from core.schema import LLMConfig
from langchain_openai import ChatOpenAI
from provider import LlmConfigError
from provider.providers.mimo import DEFAULT_API_KEY, MiMoChatModel, MiMoProvider
from pydantic import SecretStr


def _provider(base_url: str = "http://x/v1", model: str = "MiMo-V2.5") -> MiMoProvider:
    return MiMoProvider(LLMConfig(type="mimo", base_url=base_url, model=model, api_key=""))


def test_mimo_requires_base_url():
    with pytest.raises(LlmConfigError):
        _provider(base_url="").build_chat_model()


def test_mimo_requires_model():
    with pytest.raises(LlmConfigError):
        _provider(model="").build_chat_model()


def test_mimo_builds_chat_model_with_placeholder_key():
    model = _provider().build_chat_model()
    assert isinstance(model, MiMoChatModel)
    key = model.openai_api_key
    assert isinstance(key, SecretStr)
    assert key.get_secret_value() == DEFAULT_API_KEY


def test_mimo_passes_real_api_key():
    model = _provider().build_chat_model()
    assert isinstance(model, MiMoChatModel)


def test_thinking_enabled_passthrough_to_extra_body():
    model = MiMoChatModel(model="m", base_url="http://x/v1", api_key=SecretStr("k"), thinking=True)
    extra = model.extra_body
    assert isinstance(extra, dict)
    assert extra["thinking"] == {"type": "enabled"}


def test_thinking_disabled_passthrough_to_extra_body():
    model = MiMoChatModel(model="m", base_url="http://x/v1", api_key=SecretStr("k"), thinking=False)
    extra = model.extra_body
    assert isinstance(extra, dict)
    assert extra["thinking"] == {"type": "disabled"}


def test_reasoning_content_recovered(monkeypatch):
    # 桩掉父类转换（避免依赖 langchain 内部 chunk 解析），只验证我们的捞回逻辑
    class _Gen:
        def __init__(self, message):
            self.message = message

    class _Msg:
        def __init__(self, content, additional_kwargs):
            self.content = content
            self.additional_kwargs = additional_kwargs

        def model_copy(self, *, update):
            return _Msg(update["content"], update["additional_kwargs"])

    fake_gen = _Gen(_Msg(content="hi", additional_kwargs={}))
    monkeypatch.setattr(
        ChatOpenAI,
        "_convert_chunk_to_generation_chunk",
        lambda self, chunk, default_chunk_class, base_generation_info: fake_gen,
    )
    model = MiMoChatModel(model="m", base_url="http://x/v1", api_key=SecretStr("k"))
    out = model._convert_chunk_to_generation_chunk(
        {"choices": [{"delta": {"reasoning_content": "让我想想"}}]},
        object,
        None,
    )
    assert out.message.additional_kwargs["reasoning_content"] == "让我想想"
    assert out.message.content[-1] == {"type": "reasoning", "reasoning": "让我想想"}
