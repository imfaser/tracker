from pathlib import Path

import pytest
from core.config import AppConfig, get_config
from core.schema import AgentConfig, LoggingConfig, MCPServerConfig, TelemetryConfig


def _write_jsonc(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "config.jsonc"
    p.write_text(text, encoding="utf-8")
    return p


def test_instance_with_empty_config_uses_default_level(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    assert AppConfig.instance().logging.level == "INFO"


def test_instance_with_logging_level_env_overrides_file(tmp_path, monkeypatch):
    monkeypatch.setenv(
        "CONFIG_FILE", str(_write_jsonc(tmp_path, '{"logging":{"level":"WARNING"}}'))
    )
    monkeypatch.setenv("LOGGING__LEVEL", "DEBUG")
    assert AppConfig.instance().logging.level == "DEBUG"


def test_instance_parses_jsonc_comments_and_trailing_commas(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    text = """
    {
      // 注释应被社区解析器忽略
      "logging": { "level": "ERROR", },   // 尾逗号
    }
    """
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, text)))
    assert AppConfig.instance().logging.level == "ERROR"


def test_instance_reads_config_file_from_config_env(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv(
        "CONFIG_FILE", str(_write_jsonc(tmp_path, '{"logging":{"level":"CRITICAL"}}'))
    )
    assert AppConfig.instance().logging.level == "CRITICAL"


def test_instance_returns_same_object_and_reset_creates_new(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    first = AppConfig.instance()
    assert AppConfig.instance() is first
    AppConfig.reset()
    assert AppConfig.instance() is not first


def test_get_config_returns_same_instance_and_reset_creates_new(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    AppConfig.reset()
    first = get_config()
    assert get_config() is first
    AppConfig.reset()
    assert get_config() is not first


def test_constructor_injection_isolated_from_singleton(monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    cfg = AppConfig(logging=LoggingConfig(level="DEBUG"))
    assert cfg.logging.level == "DEBUG"
    # 单例不受影响，回落默认值
    assert AppConfig.instance().logging.level == "INFO"


def test_instance_with_invalid_jsonc_raises(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGGING__LEVEL", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{ 这不是合法 json")))
    with pytest.raises(ValueError):
        AppConfig.instance()


def test_telemetry_defaults_disabled(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "TELEMETRY__PHOENIX__ENABLED", "TELEMETRY__OPENOBSERVE__ENABLED"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.telemetry.phoenix.enabled is False
    assert cfg.telemetry.openobserve.enabled is False


def test_telemetry_nested_env_override_openobserve_org(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("TELEMETRY__OPENOBSERVE__ORG", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("TELEMETRY__OPENOBSERVE__ORG", "acme")
    assert AppConfig().telemetry.openobserve.org == "acme"


def test_telemetry_constructor_injection(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("TELEMETRY__PHOENIX__ENABLED", raising=False)
    cfg = AppConfig(telemetry=TelemetryConfig(phoenix={"enabled": True, "project_name": "x"}))
    assert cfg.telemetry.phoenix.enabled is True
    assert cfg.telemetry.phoenix.project_name == "x"


def test_agent_defaults_empty(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "AGENT", "AGENT__MCP_SERVERS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.agent.mcp_servers == []


def test_agent_env_override_name(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "AGENT", "AGENT__MCP_SERVERS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("AGENT__MCP_SERVERS", '[{"name": "calc-mcp"}]')
    cfg = AppConfig()
    assert len(cfg.agent.mcp_servers) == 1
    assert cfg.agent.mcp_servers[0].name == "calc-mcp"


def test_agent_constructor_injection(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    for var in ("AGENT", "AGENT__MCP_SERVERS"):
        monkeypatch.delenv(var, raising=False)
    cfg = AppConfig(agent=AgentConfig(mcp_servers=[MCPServerConfig(name="x")]))
    assert cfg.agent.mcp_servers[0].name == "x"
    assert AppConfig().agent.mcp_servers == []


def test_agent_tool_loop_defaults(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "AGENT", "AGENT__TOOL_LOOP_MAX_ITERATIONS", "AGENT__MAX_STEPS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.agent.max_steps == 10


def test_agent_tool_loop_env_override(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "AGENT", "AGENT__TOOL_LOOP_MAX_ITERATIONS", "AGENT__MAX_STEPS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("AGENT__MAX_STEPS", "12")
    assert AppConfig().agent.max_steps == 12


def test_agent_tool_loop_jsonc_override(tmp_path, monkeypatch):
    for var in ("AGENT", "AGENT__TOOL_LOOP_MAX_ITERATIONS", "AGENT__MAX_STEPS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(_write_jsonc(tmp_path, '{"agent":{"max_steps":15}}')),
    )
    assert AppConfig().agent.max_steps == 15


def test_agent_tool_loop_validation(tmp_path, monkeypatch):
    from pydantic import ValidationError

    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.delenv("AGENT", raising=False)
    monkeypatch.delenv("AGENT__TOOL_LOOP_MAX_ITERATIONS", raising=False)
    monkeypatch.delenv("AGENT__MAX_STEPS", raising=False)
    with pytest.raises(ValidationError):
        AppConfig(agent=AgentConfig(max_steps=0))
    with pytest.raises(ValidationError):
        AppConfig(agent=AgentConfig(max_steps=99))


def test_agent_max_steps_legacy_compat(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "AGENT__MAX_STEPS", "AGENT__TOOL_LOOP_MAX_ITERATIONS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig(agent=AgentConfig(tool_loop_max_iterations=15))
    assert cfg.agent.max_steps == 15
    cfg2 = AppConfig(agent=AgentConfig(max_execution_steps=12))
    assert cfg2.agent.max_steps == 12


def test_bus_defaults(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "BUS__ENABLED", "BUS__NATS_URL"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    cfg = AppConfig()
    assert cfg.bus.enabled is False
    assert cfg.bus.nats_url == "nats://192.168.16.24:6015"
    assert cfg.bus.stream_name == "deepview"


def test_bus_env_override(tmp_path, monkeypatch):
    for var in ("CONFIG_FILE", "BUS__NATS_URL", "BUS__ENABLED", "BUS__STREAM_NAME"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(_write_jsonc(tmp_path, "{}")))
    monkeypatch.setenv("BUS__NATS_URL", "nats://192.168.16.24:6015")
    monkeypatch.setenv("BUS__ENABLED", "true")
    monkeypatch.setenv("BUS__STREAM_NAME", "deepview-prod")
    cfg = AppConfig()
    assert cfg.bus.nats_url == "nats://192.168.16.24:6015"
    assert cfg.bus.enabled is True
    assert cfg.bus.stream_name == "deepview-prod"


def test_bus_jsonc_override(tmp_path, monkeypatch):
    for var in ("BUS__ENABLED", "BUS__NATS_URL"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv(
        "CONFIG_FILE",
        str(_write_jsonc(tmp_path, '{"bus": {"enabled": true, "stream_name": "chat"}}')),
    )
    cfg = AppConfig()
    assert cfg.bus.enabled is True
    assert cfg.bus.stream_name == "chat"
