from core import LLMConfig
from core.config import AppConfig
from core.schema import LLMConfig as SchemaLLMConfig


def test_llm_config_defaults():
    cfg = LLMConfig()
    assert cfg.type == "mimo"
    assert cfg.api_key == ""
    assert cfg.base_url == ""
    assert cfg.model == ""
    assert cfg.temperature == 0.7


def test_app_config_has_llm_field_with_default(tmp_path, monkeypatch):
    monkeypatch.delenv("CONFIG_FILE", raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(tmp_path / "config.jsonc"))
    cfg = AppConfig()
    assert isinstance(cfg.llm, LLMConfig)
    assert cfg.llm.type == "mimo"


def test_llm_config_env_override(tmp_path, monkeypatch):
    monkeypatch.setenv("CONFIG_FILE", str(tmp_path / "config.jsonc"))
    monkeypatch.setenv("LLM__TYPE", "mimo")
    monkeypatch.setenv("LLM__BASE_URL", "http://x/v1")
    monkeypatch.setenv("LLM__MODEL", "MiMo-V2.5")
    monkeypatch.setenv("LLM__TEMPERATURE", "0.3")
    cfg = AppConfig()
    assert cfg.llm.type == "mimo"
    assert cfg.llm.base_url == "http://x/v1"
    assert cfg.llm.model == "MiMo-V2.5"
    assert cfg.llm.temperature == 0.3


def test_llm_config_used_via_schema_import():
    # 公共类型同时出现在 core.schema 与 core 顶层导出
    assert SchemaLLMConfig is LLMConfig
