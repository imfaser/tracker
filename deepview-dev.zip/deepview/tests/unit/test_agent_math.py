import math
import warnings
from unittest.mock import MagicMock

import pytest

warnings.filterwarnings("ignore", category=DeprecationWarning)

pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")

from agent.agents.context import BaseContext
from agent.agents.math_agent import MathAgent
from agent.agents.supervisor_agent import SupervisorAgent
from agent.context import DeepViewContext
from agent.registry import ToolStore
from agent.tools.builtin import register_builtin_tools
from langchain.tools import ToolRuntime
from langgraph.runtime import Runtime  # noqa: F401


def test_math_tools_registered(tool_store: ToolStore):
    register_builtin_tools(tool_store)
    tools = tool_store.list()
    assert len(tools) == 2
    names = {t.name for t in tools}
    assert "circle_area" in names
    assert "square_area" in names


def test_math_tools_direct_calculation():
    from agent.tools.math import circle_area, square_area

    ctx = DeepViewContext(user_id="u1", tenant_id="t1", trace_id="tid")
    rt = MagicMock(spec=ToolRuntime)
    rt.context = ctx
    assert circle_area(radius=3, runtime=rt) == pytest.approx(math.pi * 9)
    assert square_area(side=4, runtime=rt) == pytest.approx(16)


def test_math_tools_via_store_invoke(tool_store: ToolStore):
    register_builtin_tools(tool_store)
    tools = {t.name: t for t in tool_store.list()}
    assert "circle_area" in tools
    assert "square_area" in tools
    assert tools["circle_area"].description.startswith("计算圆面积")


def test_math_agent_factory_creates(tool_store: ToolStore):
    register_builtin_tools(tool_store)
    import anyio

    async def _run():
        agent = MathAgent()
        graph = await agent.get_graph(context=BaseContext())
        assert graph is not None

    anyio.run(_run)
    recipe = MathAgent().to_recipe()
    assert recipe["name"] == "math"
    assert len(recipe["tools"]) == 2


def test_supervisor_delegation(tool_store: ToolStore):
    import anyio

    async def _run():
        sup = SupervisorAgent()
        graph = await sup.get_graph(context=BaseContext())
        assert graph is not None
        assert getattr(graph, "_tool_loop_max_iterations", None) == 10

    anyio.run(_run)
