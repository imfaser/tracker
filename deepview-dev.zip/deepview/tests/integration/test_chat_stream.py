from __future__ import annotations

import json

import httpx
from core.config import AppConfig
from server.app import create_app


def _parse_sse(body: bytes) -> list[dict]:
    out: list[dict] = []
    for line in body.decode().splitlines():
        if line.startswith("data: "):
            payload = line[len("data: ") :]
            if payload == "[DONE]":
                out.append({"type": "[DONE]"})
            else:
                out.append(json.loads(payload))
    return out


async def test_chat_stream_invalid_json_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/chat/stream", content=b"not json", headers={"Content-Type": "application/json"}
        )
        assert resp.status_code == 400


async def test_chat_stream_empty_messages_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json={"messages": []})
        assert resp.status_code == 400


async def test_chat_stream_invalid_role_returns_400() -> None:
    app = create_app()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json={"messages": [{"role": "bad", "parts": []}]})
        assert resp.status_code == 400


async def test_chat_stream_fake_stream_headers_and_events(monkeypatch) -> None:
    # 确保无 llm 配置走错误流
    for var in ("LLM__MODEL", "LLM__BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    AppConfig.reset()
    monkeypatch.setenv("CONFIG_FILE", "/tmp/nonexistent_chat_stream.jsonc")

    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        assert resp.headers["x-vercel-ai-ui-message-stream"] == "v1"
        assert (
            "X-Trace-Id" in resp.headers or resp.headers.get("X-Trace-Id", "") == ""
        )  # 无追踪时可能为空
        assert resp.headers["content-type"].startswith("text/event-stream")
        events = _parse_sse(resp.content)
        types = [e["type"] for e in events]
        assert "start" in types
        assert "error" in types
        assert "finish" in types
        assert types[-1] == "finish"
        assert "[DONE]" not in types


async def test_chat_stream_expose_trace_id_in_stream(monkeypatch) -> None:
    monkeypatch.setenv("TELEMETRY__EXPOSE_TRACE_ID", "true")
    AppConfig.reset()
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        events = _parse_sse(resp.content)
        start = next(e for e in events if e["type"] == "start")
        # 有追踪时 messageMetadata.traceId 存在；无追踪时不强制
        if "messageMetadata" in start:
            assert "traceId" in start["messageMetadata"]
    monkeypatch.delenv("TELEMETRY__EXPOSE_TRACE_ID", raising=False)
    AppConfig.reset()


async def test_chat_stream_repeated_text_id_not_duplicated(monkeypatch) -> None:
    for var in ("LLM__MODEL", "LLM__BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    AppConfig.reset()
    monkeypatch.setenv("CONFIG_FILE", "/tmp/nonexistent_chat_stream2.jsonc")
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hello"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        events = _parse_sse(resp.content)
        assert any(e["type"] == "error" for e in events)


async def test_sync_stream() -> None:
    """同步链路冒烟：bus.enabled=false 时走同步。"""
    from core.config import AppConfig as _AC

    AppConfig.reset()
    cfg = _AC(bus={"enabled": False})
    assert cfg.bus.enabled is False


async def test_bus_stream(monkeypatch) -> None:
    """异步链路冒烟：bus.enabled=true 时入队（network 标记）。"""
    import pytest

    pytest.skip("need nats")
    monkeypatch.setenv("BUS__ENABLED", "true")
    monkeypatch.setenv("BUS__NATS_URL", "nats://192.168.16.24:6015")
    AppConfig.reset()
    app = create_app()
    payload = {"messages": [{"role": "user", "parts": [{"type": "text", "text": "hi"}]}]}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/chat/stream", json=payload)
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
