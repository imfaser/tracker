# Changelog

## Unreleased

### BREAKING — refactor-agent-registry（兼容层已移除，直接重写）

- 移除 `ToolRegistry` 单例与 `get_registry()/reset_registry()/configure_registry()/define_role` 兼容层，全部重写为 `ToolStore` + `McpDiscovery` + `bind_role_to_mcp` + `configure_tools` 显式注入。
- `agent/tools/math.py` 去除 `@get_registry().tool` 装饰器，改为 `register_builtin_tools(store)` 在 `lifespan` 显式注册。
- `agent/__init__.py` 不再顶层副作用导入，`create_agent_for_role` 现要求 `store: ToolStore` 必传，`create_supervisor_agent` 接受 `store` 显式注入。
- `vercel_adapter/service.py` 改为从 `request.app.state.tool_store` 获取显式 `ToolStore`，回退时本地新建并 `register_builtin_tools`。
- `tests/fixture/agent.py` 移除 `clean_registry/fresh_registry`，仅保留 `tool_store` / `mcp_discovery`；全部单测已迁移。
- 移除 `builtins.list/set/dict` 写法，`McpBinding` 与 `ToolFilter` 以 `TypedDict/Callable` 强类型约束。
- `Telemetry` 已收口 `PRIORITY/_REGISTRY` 为模块级常量并加重复注册 `ValueError`，`provider/factory.py` 增加 `ProviderRegistry` 占位。

### Added

- `ToolStore` 纯目录、`McpDiscovery` TTL 发现、`ToolView` 只读视图、`McpBinding/ToolFilter` 类型、`bind_role_to_mcp`、`register_builtin_tools`、`tool_store`/`mcp_discovery` 测试夹具。
