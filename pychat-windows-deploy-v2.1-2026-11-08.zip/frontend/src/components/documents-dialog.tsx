import { useQuery } from '@tanstack/react-query'
import { FileSpreadsheetIcon, FileTextIcon, Loader2Icon, RotateCcwIcon, Trash2Icon, UploadIcon } from 'lucide-react'
import { useRef, useState } from 'react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useUserId } from '@/hooks/useUserId'
import {
  deleteDocument,
  fetchDocuments,
  formatSize,
  reconvertDocument,
  uploadDocument,
  type DocumentEntry,
} from '@/lib/api'

const ACCEPT = '.xlsx,.xlsm,.xls,.csv,.docx,.doc,.pdf,.pptx,.md,.html,.htm,.txt'

function DocumentIcon({ kind }: { kind: string }) {
  return kind === 'excel' ? (
    <FileSpreadsheetIcon className="size-4 shrink-0 text-emerald-600" />
  ) : (
    <FileTextIcon className="size-4 shrink-0 text-sky-600" />
  )
}

/**
 * Upload and inspect the documents the agent may read.
 *
 * This is the one feature pychat adds on top of the upstream chat UI: the
 * backend converts uploads with Docling and serves the derived JSON/Markdown to
 * the sandbox, so the panel only drives `/api/documents`.
 */
export function DocumentsDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const userId = useUserId()
  const { data, error, isPending, refetch } = useQuery({
    queryKey: ['documents', userId],
    queryFn: fetchDocuments,
    enabled: open,
  })
  const [busy, setBusy] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const documents = data?.documents ?? []

  async function handleFiles(files: FileList | null) {
    if (!files?.length) return
    for (const file of Array.from(files)) {
      setBusy(`正在上传 ${file.name}…`)
      try {
        const entry = await uploadDocument(file)
        if (entry.status === 'failed') {
          toast.error(`${entry.filename} 解析失败`, { description: entry.error ?? '未知错误' })
        } else {
          toast.success(`${entry.filename} 已就绪`)
        }
      } catch (cause) {
        toast.error('上传失败', {
          description: cause instanceof Error ? cause.message : String(cause),
        })
      } finally {
        await refetch()
        setBusy(null)
      }
    }
    if (inputRef.current) inputRef.current.value = ''
  }

  async function handleDelete(entry: DocumentEntry) {
    try {
      await deleteDocument(entry.id)
      toast.success(`已删除 ${entry.filename}`)
    } catch (cause) {
      toast.error('删除失败', {
        description: cause instanceof Error ? cause.message : String(cause),
      })
    } finally {
      await refetch()
    }
  }

  async function handleRetry(entry: DocumentEntry) {
    setBusy(`正在重试 ${entry.filename}…`)
    try {
      const updated = await reconvertDocument(entry.id)
      if (updated.status === 'failed') {
        toast.error(`${updated.filename} 仍然失败`, { description: updated.error ?? '未知错误' })
      }
    } catch (cause) {
      toast.error('重试失败', {
        description: cause instanceof Error ? cause.message : String(cause),
      })
    } finally {
      await refetch()
      setBusy(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[80svh] flex-col sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>文档</DialogTitle>
          <DialogDescription>上传 Excel / Word / PDF，问答时由模型读取转换后的内容。</DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => {
              inputRef.current?.click()
            }}
            disabled={busy !== null}
          >
            {busy ? <Loader2Icon className="animate-spin" /> : <UploadIcon />}
            {busy ?? '上传文档'}
          </Button>
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPT}
            multiple
            hidden
            onChange={(event) => void handleFiles(event.target.files)}
          />
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto rounded-md border">
          {isPending && <p className="text-muted-foreground px-3 py-4 text-sm">加载中…</p>}
          {error && (
            <p className="text-destructive px-3 py-4 text-sm">
              文档列表加载失败：{error instanceof Error ? error.message : String(error)}
            </p>
          )}
          {!isPending && !error && documents.length === 0 && (
            <p className="text-muted-foreground px-3 py-4 text-sm">还没有文档。上传后即可提问。</p>
          )}
          <ul className="divide-y">
            {documents.map((entry) => (
              <li key={entry.id} className="flex items-start gap-2 px-3 py-2.5">
                <DocumentIcon kind={entry.kind} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm" title={entry.filename}>
                    {entry.filename}
                  </p>
                  <p className="text-muted-foreground mt-0.5 flex items-center gap-1.5 text-xs">
                    <span
                      className={
                        entry.status === 'ready'
                          ? 'size-1.5 rounded-full bg-emerald-500'
                          : 'bg-destructive size-1.5 rounded-full'
                      }
                    />
                    {entry.status === 'ready' ? '已就绪' : '解析失败'} · {formatSize(entry.size)}
                  </p>
                  {entry.error && (
                    <p className="text-destructive mt-1 line-clamp-2 text-xs" title={entry.error}>
                      {entry.error}
                    </p>
                  )}
                </div>
                <div className="flex shrink-0 gap-0.5">
                  {entry.status === 'failed' && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-7"
                      title="重试解析"
                      aria-label="重试解析"
                      disabled={busy !== null}
                      onClick={() => void handleRetry(entry)}
                    >
                      <RotateCcwIcon className="size-3.5" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7"
                    title="删除"
                    aria-label="删除"
                    onClick={() => void handleDelete(entry)}
                  >
                    <Trash2Icon className="size-3.5" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  )
}
