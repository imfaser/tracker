import { useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { withBasePath } from '@/lib/base-path'
import { DEFAULT_USER, getUserId, isValidUserId, setUserId } from '@/lib/identity'

/**
 * Test-only identity switch.
 *
 * Production takes the user from the gateway header; this box exists so two
 * people (or two tabs) can be simulated without one. Switching sends the new
 * id with every later request, and starts a new conversation because message
 * histories still live in this browser and are not partitioned by user yet.
 */
export function UserSwitcher() {
  const [value, setValue] = useState(getUserId)
  const queryClient = useQueryClient()

  const apply = () => {
    if (!isValidUserId(value)) {
      toast.error('用户 ID 只能包含字母、数字、下划线和连字符（1–64 个字符）')
      return
    }
    const id = setUserId(value)
    setValue(id)
    // The sidebar reads a per-user database, so it must re-read now.
    window.dispatchEvent(new Event('conversations-changed'))
    void queryClient.invalidateQueries()
    window.history.replaceState({}, '', withBasePath('/'))
    window.dispatchEvent(new Event('history-state-changed'))
    toast.success(`当前用户：${id}`)
  }

  return (
    <div className="px-2 pb-2 group-data-[state=collapsed]:hidden">
      <label htmlFor="pychat-user" className="text-muted-foreground text-xs">
        当前用户（测试）
      </label>
      <div className="mt-1 flex gap-1">
        <Input
          id="pychat-user"
          className="h-7 text-xs"
          value={value}
          placeholder={DEFAULT_USER}
          onChange={(event) => {
            setValue(event.target.value)
          }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault()
              apply()
            }
          }}
        />
        <Button type="button" size="sm" variant="outline" className="h-7 px-2 text-xs" onClick={apply}>
          切换
        </Button>
      </div>
    </div>
  )
}
