import type { UIMessage } from "ai";

import type { BuiltinTool, ModelConfig } from "@/types";

import { startupConfig } from "@/lib/config";
import { identityHeaders } from "@/lib/identity";

export type DocumentEntry = {
  id: string;
  filename: string;
  size: number;
  kind: string;
  status: "ready" | "failed";
  uploaded_at: string;
  json_file: string | null;
  md_file: string | null;
  error: string | null;
};

type DocumentList = { documents: DocumentEntry[] };

/** The shape the chat UI already understands; see `/api/models`. */
export interface RemoteConfig {
  models: ModelConfig[];
  builtinTools: BuiltinTool[];
}

export interface Identity {
  user_id: string;
}

export interface RemoteConversation {
  id: string;
  messages: UIMessage[];
}

export interface RemoteConversationSummary {
  id: string;
  title: string | null;
  message_count: number;
  updated_at: string;
}

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

/**
 * Every backend call goes through here, so the base path and the identity
 * header are decided in one place instead of at each call site.
 */
function apiUrl(path: string): string {
  return `${startupConfig.apiPath}${path.replace(/^\//, "")}`;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(apiUrl(path), {
    ...init,
    headers: {
      ...identityHeaders(),
      ...(init.headers as Record<string, string> | undefined),
    },
  });
  if (!response.ok) {
    const text = await response.text();
    let detail = text;
    try {
      const parsed = JSON.parse(text) as { detail?: string };
      detail = parsed.detail ?? text;
    } catch {
      // Not JSON: keep the raw body.
    }
    throw new ApiError(detail || `HTTP ${response.status}`, response.status);
  }
  return (await response.json()) as T;
}

export const fetchDocuments = (): Promise<DocumentList> => request<DocumentList>("documents");

export async function uploadDocument(file: File): Promise<DocumentEntry> {
  const body = new FormData();
  body.append("file", file);
  return request<DocumentEntry>("documents", { method: "POST", body });
}

export async function deleteDocument(id: string): Promise<void> {
  await request<{ ok: boolean }>(`documents/${encodeURIComponent(id)}`, { method: "DELETE" });
}

export async function reconvertDocument(id: string): Promise<DocumentEntry> {
  return request<DocumentEntry>(`documents/${encodeURIComponent(id)}/reconvert`, { method: "POST" });
}

export const fetchConfig = (): Promise<RemoteConfig> => request<RemoteConfig>("models");

export const fetchIdentity = (): Promise<Identity> => request<Identity>("me");

/** Restore a conversation persisted on the server (newer than this browser). */
export const fetchConversation = (id: string): Promise<RemoteConversation> =>
  request<RemoteConversation>(`conversations/${encodeURIComponent(id.replace(/^\//, ""))}`);

export const fetchConversations = (): Promise<{ conversations: RemoteConversationSummary[] }> =>
  request<{ conversations: RemoteConversationSummary[] }>("conversations");

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MiB`;
}
