/**
 * The user this browser acts as.
 *
 * Production puts a gateway in front and forwards the asserted id in a header;
 * for testing there is no gateway, so the id is chosen here and sent with every
 * request. It lives in localStorage rather than React state because it is
 * environment, not render data.
 */

const STORAGE_KEY = "pychat-user";
const VALID_ID = /^[A-Za-z0-9_-]{1,64}$/;

export const DEFAULT_USER = "local";

export function isValidUserId(value: string): boolean {
  return VALID_ID.test(value.trim());
}

export function getUserId(): string {
  if (typeof window === "undefined") return DEFAULT_USER;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY) ?? "";
    return isValidUserId(stored) ? stored.trim() : DEFAULT_USER;
  } catch {
    return DEFAULT_USER;
  }
}

/** Persist a valid id, tell the rest of the app, and echo back what was stored. */
export function setUserId(value: string): string {
  const id = isValidUserId(value) ? value.trim() : DEFAULT_USER;
  window.localStorage.setItem(STORAGE_KEY, id);
  window.dispatchEvent(new Event("identity-changed"));
  return id;
}

export function identityHeaders(): Record<string, string> {
  return { "X-User-Id": getUserId() };
}
