import { useSyncExternalStore } from 'react'

import { fetchConversations, type RemoteConversationSummary } from '@/lib/api'
import { getConversations, hiddenConversationIds } from '@/lib/chat-db'
import { getUserId } from '@/lib/identity'
import type { ConversationEntry } from '@/types'

// Conversations live in two places: the local cache (fast, offline) and the
// server (authoritative, shared across devices). The sidebar shows the union;
// a local entry wins on fields a person edits, the server fills in the rest.
export interface ConversationsState {
  conversations: ConversationEntry[]
  /**
   * Whether the local store has been read at least once. Before that, an empty
   * list means "not read yet", not "no conversations" — a caller that cannot
   * tell the two apart renders its not-found state over every reload.
   */
  loaded: boolean
  /**
   * Whether the local store has never been read successfully and the last
   * attempt failed. A server failure alone is not `failed`: the cached list is
   * still worth showing.
   */
  failed: boolean
}

let local: ConversationEntry[] = []
let remote: ConversationEntry[] = []
let loaded = false
let failed = false

let state: ConversationsState = { conversations: [], loaded: false, failed: false }
const listeners = new Set<() => void>()

// Reads triggered by two writes in quick succession can resolve out of order;
// only the newest is allowed to win, so a deleted conversation cannot reappear
// from an older in-flight snapshot.
let latestLocal = 0
let latestRemote = 0

function toEntry(item: RemoteConversationSummary): ConversationEntry {
  const timestamp = Date.parse(item.updated_at) || Date.now()
  return { id: item.id, firstMessage: item.title ?? undefined, timestamp, createdAt: timestamp }
}

function publish(): void {
  const hidden = new Set(hiddenConversationIds())
  const byId = new Map<string, ConversationEntry>()
  for (const entry of local) byId.set(entry.id, entry)
  for (const entry of remote) {
    if (hidden.has(entry.id)) continue
    const current = byId.get(entry.id)
    if (current) {
      byId.set(entry.id, {
        ...current,
        firstMessage: current.firstMessage ?? entry.firstMessage,
        timestamp: Math.max(current.timestamp, entry.timestamp),
      })
    } else {
      byId.set(entry.id, entry)
    }
  }
  state = {
    conversations: [...byId.values()].sort(
      (a, b) => Number(b.pinned ?? false) - Number(a.pinned ?? false) || b.timestamp - a.timestamp,
    ),
    loaded,
    failed,
  }
  for (const listener of listeners) listener()
}

function refreshLocal(): void {
  const request = ++latestLocal
  getConversations()
    .then((conversations) => {
      if (request !== latestLocal) return
      local = conversations
      loaded = true
      failed = false
      publish()
    })
    .catch((err: unknown) => {
      console.error('Failed to load conversations:', err)
      // A failure after a good read keeps that list: emptying the sidebar and
      // blanking the header title is the worse outcome, and the next write
      // event reads again.
      if (request !== latestLocal || loaded) return
      failed = true
      loaded = true
      publish()
    })
}

function refreshRemote(): void {
  const user = getUserId()
  const request = ++latestRemote
  fetchConversations()
    .then(({ conversations }) => {
      if (request !== latestRemote || user !== getUserId()) return
      remote = conversations.map(toEntry)
      publish()
    })
    .catch((err: unknown) => {
      // The cache is still usable; a server outage must not empty the sidebar.
      console.error('Failed to load server conversations:', err)
    })
}

/**
 * Read the local store again after a failed read; see `ConversationsState.failed`.
 */
export function retryConversations(): void {
  refreshLocal()
  refreshRemote()
}

function onIdentityChanged(): void {
  remote = []
  latestRemote += 1
  refreshLocal()
  refreshRemote()
}

function subscribe(listener: () => void): () => void {
  // With nobody subscribed there is no `conversations-changed` listener, so any
  // write in that window is missed. Re-read whenever the first subscriber
  // arrives.
  const reconnecting = listeners.size === 0
  if (reconnecting) {
    window.addEventListener('conversations-changed', refreshLocal)
    window.addEventListener('identity-changed', onIdentityChanged)
    refreshRemote()
  }
  listeners.add(listener)
  if (reconnecting || !loaded) refreshLocal()

  return () => {
    listeners.delete(listener)
    if (listeners.size === 0) {
      window.removeEventListener('conversations-changed', refreshLocal)
      window.removeEventListener('identity-changed', onIdentityChanged)
    }
  }
}

function getSnapshot(): ConversationsState {
  return state
}

export function useConversationsState(): ConversationsState {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
}

/** The list alone, for callers that have nothing to show while it loads. */
export function useConversations(): ConversationEntry[] {
  return useConversationsState().conversations
}
