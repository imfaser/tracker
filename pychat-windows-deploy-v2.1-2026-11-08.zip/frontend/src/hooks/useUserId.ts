import { useEffect, useState } from "react";

import { getUserId } from "@/lib/identity";

/**
 * The current test user, kept in sync with `identity-changed`.
 *
 * Query keys include this value, so switching users refetches by construction
 * rather than relying on a caller to remember an invalidation.
 */
export function useUserId(): string {
  const [userId, setUserId] = useState(getUserId);

  useEffect(() => {
    const update = () => {
      setUserId(getUserId());
    };
    window.addEventListener("identity-changed", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("identity-changed", update);
      window.removeEventListener("storage", update);
    };
  }, []);

  return userId;
}
