# 前端改造：从演示壳到可演进的界面

> 结论：**不重写 UI，先减法再做一层薄封装。** 真正的重复不在组件里，在三处：HTTP 调用各写各的、模型列表写死在代码里、身份根本不存在。把这三处收拢，页面代码几乎不动，但后面每加一个功能都少改五个文件。

- 日期：2026-11-08
- 范围：v2 MVP 的前端改造（多用户、动态模型、测试切换用户）
- 依据：当前 `frontend/src` 的实际代码
- 配套：`docs/14-multiuser-persistence.md`（身份、API、配置、资源）

## 0. TL;DR

1. **不引入新框架。** 不加路由库、不加状态库、不重写 `components/ui` 与 `components/ai-elements`。这份代码的问题不是"框架不够新"，是"同一件事做了三遍"。
2. **一个 HTTP 层**：所有请求走 `lib/api.ts` 的 `request()`，统一 base path、身份头、错误解析、类型。
3. **一个身份源**：`lib/identity.ts` 持有 `userId`，API 层与聊天 transport 都从它取，不再各读各的。
4. **模型从后端来**：删掉 `config.ts` 里的写死列表，`GET /api/models` 返回目录；上架模型不再发前端。
5. **测试用用户切换器**：侧边栏一个输入框，切换后文档列表与问答上下文一起变。
6. **会话持久化走服务端**：`StepPersistence` + PostgreSQL，IndexedDB 只做缓存；跨设备打开已知会话 id 时从服务端还原。

## 1. 现状评估

### 1.1 已经不错的部分（不要动）

| 项 | 现状 | 判断 |
|---|---|---|
| 构建 | Vite 8 + React 19 + TS 7 strict | 保持 |
| 样式 | Tailwind v4 CSS-first + shadcn | 保持 |
| 服务端状态 | `@tanstack/react-query` 已在用（文档、模型） | 保持并扩大 |
| 组件 | 上游 `ai-chat-ui` 的会话/工具/思考卡片 | 一行不碰 |
| 路由 | 路径即会话 id，`pushState` + `popstate` | 够用，不换 |
| Lint/格式化 | oxlint + oxfmt | 保持 |

### 1.2 真正的问题（按影响排序）

**P1 · API 调用绕过 base path。** `lib/api.ts` 把 `/api/documents` 写死，而聊天用的是 `startupConfig.apiPath`（`Chat.tsx:64`）。一旦按 `PYDANTIC_AI_CHAT_CONFIG.basePath` 部署到子路径，文档功能全挂，聊天却正常——这种"一半好一半坏"最难查。

**P2 · 模型列表写死在前端。** `lib/config.ts:88` 的 `LOCAL_CONFIG` 固定 `mimo-v2.6-pro`；`fetchConfig()` 不请求后端，直接返回常量。后果：换模型、加模型、下架模型，都要改 TS、重新构建、重新部署。这正是"配置很重要"那条在代码里的反面教材。

**P3 · 上游配置机制成了死代码。** `RemoteConfig`、`parseRemoteConfig`、`builtinTools` 都是为上游的 `/api/configure` 准备的，本项目没有这个端点。它们不是错，但让读者以为后端应该有个配置服务，实际没有。

**P4 · 没有身份。** 所有请求不带用户标识；后端也就无法按用户隔离。测试多用户只能靠改代码。

**P5 · 查询键不带身份。** 文档列表是 `['documents']`（`documents-dialog.tsx:36`），切换用户后缓存不会失效，会看到上一个人的列表——测试时最容易误判成"隔离没生效"。

**P6 · 组件常驻导致空转请求。** `DocumentsDialog` 在侧边栏里始终挂载（`app-sidebar.tsx:248`），`useQuery` 在对话框关闭时也会请求。小问题，但会掩盖"切换用户后重新拉取"的因果。

**P7 · 前端零测试。** 没有 vitest 配置。组件的复杂度来自上游，不值得补；但 API 层与模型解析是纯函数，是真正值得测的缝。

**P8 · 类型手写，容易漂。** `DocumentEntry` 在前后端各写一份。v2 先用同一份字段约定 + 一个解析函数，v3 再考虑从 OpenAPI 生成。

## 2. 目标形状

```text
组件（几乎不动）
   │  只依赖 hooks / api
   ▼
lib/api.ts          唯一 HTTP 层：base path + 身份头 + 错误 + 类型
   │
   ├─ lib/identity.ts   userId 的唯一来源（localStorage + 事件）
   └─ lib/config.ts     只保留启动配置（basePath / apiPath）
```

三条规则：

1. **组件里不出现 `fetch`。** 出现即视为需要下沉到 `api.ts`。
2. **组件里不出现字符串路径。** `api.ts` 负责拼 `/api/...` 与 base path。
3. **身份只从 `identity.ts` 读。** 不在组件里读 `localStorage`。

## 3. 逐文件改造

### 3.1 新增 `lib/identity.ts`

```ts
const KEY = "pychat-user";
export const DEFAULT_USER = "local";

export function getUserId(): string;
export function setUserId(value: string): string;   // 规范化 + 持久化 + 广播
export function identityHeaders(): Record<string, string>; // { "X-User-Id": ... }
```

- 取值规则与后端一致：`^[A-Za-z0-9_-]{1,64}$`，空值回落 `local`。
- 切换时 `window.dispatchEvent(new Event("identity-changed"))`，供查询键与界面同步。
- 不放在 React context 里：它不是渲染状态，是环境状态；多一个 provider 只会多一层。

### 3.2 重写 `lib/api.ts`

```ts
import { startupConfig } from "@/lib/config";
import { identityHeaders } from "@/lib/identity";

function apiUrl(path: string): string {
  return `${startupConfig.apiPath}${path.replace(/^\//, "")}`;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(apiUrl(path), {
    ...init,
    headers: { ...identityHeaders(), ...(init.headers ?? {}) },
  });
  // 错误解析只写一次：detail 优先，其次 HTTP 状态
  ...
}

export const fetchDocuments = () => request<DocumentList>("documents");
export const uploadDocument = (file: File) => { ... };
export const deleteDocument = (id: string) => ...;
export const reconvertDocument = (id: string) => ...;
export const fetchModels = () => request<RemoteConfig>("models");
export const fetchMe = () => request<Identity>("me");
```

注意：`startupConfig.apiPath` 已经是 `/api/`（带尾斜杠），不要重复拼。

### 3.3 收缩 `lib/config.ts`

保留：`StartupConfig`、`ResolvedStartupConfig`、`resolveStartupConfig`、`startupConfig`。
删除：`LOCAL_CONFIG`、`fetchConfig`、`parseRemoteConfig`、`RemoteConfig`（移到 `types.ts` 或 `api.ts` 的响应类型）。
理由：这些是"后端有配置服务"的假设；v2 的配置端点是 `/api/models`，形状更简单。

### 3.4 `Chat.tsx` 两处

1. `fetchConfig` 改从 `@/lib/api` 导入；查询键改成 `['models', userId]`，用户切换后自动重取。
2. transport 加身份头（transport 只建一次，头必须是函数）：

```ts
new DefaultChatTransport({
  api: `${startupConfig.apiPath}chat`,
  headers: () => identityHeaders(),
  body: () => ({ model: modelRef.current, builtinTools: enabledToolsRef.current, effort: effortRef.current }),
})
```

### 3.5 新增 `components/user-switcher.tsx`

放在侧边栏底部、"文档"上方；折叠态隐藏。

```text
当前用户  [ alice        ] [切换]
```

行为：

1. `setUserId(value)` → 写入 localStorage 并广播。
2. `queryClient.invalidateQueries()`（或让查询键带 userId，二选一，推荐后者）。
3. 导航回 `/`（新会话），避免把上一个人的消息留在屏幕上。
4. toast 提示"当前用户：alice"。

**为什么必须回 `/`：** 服务端历史已按用户隔离，但侧边栏仍读本地缓存。为了让测试结果可信，本地 IndexedDB 也按用户分区（数据库名 `chat-storage:<user>`），切换用户后侧边栏读的是另一份列表，不会出现"上一页的会话还在"。

### 3.6 `documents-dialog.tsx`

- 查询键：`['documents', userId]`。
- `fetchDocuments` 不再接收 URL（路径由 `api.ts` 拼）。
- 可选：加 `enabled: open`，避免对话框关闭时空转请求。

### 3.7 `types.ts`

- `ModelConfig` 增加可选 `available?: boolean`、`reason?: string`、`efforts?: string[]`；v2 后端只返回 `id/name/builtinTools`，字段可选，不破坏现有组件。

### 3.7 侧边栏合并服务端列表

`useConversations` 原来是纯 IndexedDB 的 `useSyncExternalStore`；现在同时读本地与服务端：

- 本地优先：同 id 的标题/置顶以本地为准，服务端补空字段。
- 服务端只在首次订阅与 `identity-changed` 时拉一次，不在每次流式写盘时拉，避免把列表查询打成高频请求。
- 服务端没有删除接口，所以本地删除时把 id 记进 `pychat-hidden:<user>`，合并时过滤掉；服务端数据仍在，换设备会再出现（已知边界）。
- 老会话没有标题时，用服务端从快照里提取的第一条用户消息补上。

## 4. 后端配套（v2 必做）

| 端点 | 返回 | 用途 |
|---|---|---|
| `GET /api/models` | `{ models: [{id, name, builtinTools: []}], builtinTools: [] }` | 替换写死的模型列表，形状与现有 `RemoteConfig` 兼容 |
| `GET /api/me` | `{ user_id }` | 前端可校验身份，测试时显示"你是谁" |
| `GET /api/conversations` | `[{ id, title, message_count, updated_at }]` | 侧边栏合并服务端会话 |
| `GET /api/conversations/{id}` | `{ id, messages }` | 本地没有时从服务端还原历史 |
| 既有 `/api/documents*` | 按 `X-User-Id` 隔离 | 切换用户后列表变化 |
| 既有 `/api/chat` | 按 `X-User-Id` 选 Agent | 问答范围与文档范围一致 |

`/api/models` 的形状刻意与上游 `RemoteConfig` 一致，这样 `Chat.tsx` 的模型选择、内置工具、`resolveSelectedModel` 全都不用改。

## 5. 动态模型契约

```json
{
  "models": [
    { "id": "mimo-v2.6-pro", "name": "mimo-v2.6-pro", "builtinTools": [] }
  ],
  "builtinTools": []
}
```

- 目录来源是 `server/config/pychat.toml`：`[agent.model]` 是默认，`[[agent.catalog]]` 是可选模型（v2 有 `mimo-v2.6-pro` 与 `mimo-v2.6-flash`）。
- 客户端只能发 `model` 字段；服务端在目录里校验，未知模型返回 400。
- 后续加模型时，`[[agent.catalog]]` 多一项即可；`resolveSelectedModel` 已处理"当前选中项消失"的情况（`lib/models.ts`）。
- 不下发 `api_key`、`base_url`，也不接受客户端传入。

## 6. 测试策略

**不引测试框架，先把可测的缝做成纯函数。** 如果后面要加 vitest，只测这三处：

1. `apiUrl()`：basePath 为 `/` 与 `/pychat/` 两种部署。
2. `identity` 规范化：空值、非法字符、超长。
3. `resolveSelectedModel()`：模型下架后的回落。

组件与 SSE 流程继续用人工验收（第 7 节），因为它们的价值在集成行为，不在单测。

## 7. 验收清单（手工）

在浏览器里：

1. 打开页面，侧边栏显示"当前用户 local"。
2. 上传一份 xlsx，文档列表出现。
3. 输入 `alice` → 切换。文档列表**变为空**。
4. 用 alice 上传另一份文件 → 列表只有这一份。
5. 切回 `local` → 只看到第一份。
6. 用 `local` 提问第一份文件里的数字 → 答对；用 `alice` 问同一个问题 → 模型说没有这份文档。
7. 刷新页面：当前用户仍是 `alice`（localStorage）。
8. `GET /api/health` 正常；容器日志无异常。

命令行（不打开浏览器也能验）：

```bash
curl -s -H "X-User-Id: alice" http://127.0.0.1:8000/api/documents
curl -s -H "X-User-Id: bob"   http://127.0.0.1:8000/api/documents
```

## 8. 明确不做（v2）

- 不重写上游组件，不换 UI 套件
- 不引入路由库、状态库、表单库
- 不做用户管理界面（增删改用户属于网关）
- 不做 OpenAPI 代码生成（v3 再评估）

## 9. 风险

| 风险 | 表现 | 处理 |
|---|---|---|
| 切换用户后旧会话仍可见 | 本地会话列表未按用户分区 | 切换即回 `/`；服务端历史按用户隔离 |
| 查询键漏带 userId | 切换后看到旧列表 | 统一用 `queryKey: ['documents', userId]` |
| transport 头不刷新 | 切换后仍用旧用户 | headers 用函数，不用对象 |
| 子路径部署 | 文档请求 404 | `apiUrl()` 统一拼 `startupConfig.apiPath` |
| 模型端点失败 | 选择器空、无法发送 | 保留 `ConfigErrorBanner` 与重试 |
