# Windows 部署指南（v2）

本文覆盖三种在 Windows 上使用 pychat 的方式，按需要选一种：

| 方式 | 适合 | 需要 |
|---|---|---|
| A. 本机直接跑 | 开发、调试、单机使用 | Python 3.14、uv、Node 24 |
| B. Docker Desktop | 本机跑与 NAS 相同的镜像 | Docker Desktop（WSL2） |
| C. 从 Windows 发布到 NAS | 当前生产环境 | OpenSSH 客户端、NAS 上的 Docker 与目录 |

v2 相比 v1 多了三件事：**网关身份头**、**按用户隔离的文档/Agent**、**PostgreSQL 里的会话历史**。数据库只存消息，不存文件。

> 机器上没有 Docker、需要把服务装成 Windows 服务/开机自启？见 [17-windows-native-deploy.md](./17-windows-native-deploy.md)。

所有命令都在 Windows PowerShell 5.1 及以上验证；推荐 PowerShell 7（`pwsh`）。PowerShell 里 `curl` 是 `Invoke-WebRequest` 的别名，本文一律写 `curl.exe`。

## 1. 前置条件

- Windows 10 21H2+ / Windows 11，x64。
- [uv](https://docs.astral.sh/uv/) 0.12+（`uv sync` 会自动下载 Python 3.14）。
- Node.js 24 + npm（只在前端开发或构建时需要；生产镜像里会构建）。
- 可选：Docker Desktop 4.x，使用 WSL2 backend。
- 可选：PostgreSQL 14+（NAS 上已有 `pgvector` 容器，端口 `6027`）。
- 网络可达：
  - docling-serve：`http://192.168.16.24:6029`
  - 模型接口：`https://token-plan-cn.xiaomimimo.com/v1`
  - 可选：Phoenix：`http://192.168.16.24:6013`
  - 可选：PostgreSQL：`192.168.16.24:6027`

解压后的目录结构：

```text
pychat\
  server\        FastAPI + Pydantic AI
  frontend\      Vite + React（界面来自 pydantic/ai-chat-ui）
  docs\          设计与运维文档
  README.md
```

## 2. 密钥与配置

### 2.1 模型 key

`server\config\pychat.toml` 里只写占位符：

```toml
[agent.model]
api_key = "{$MIMO_API_KEY}"

[[agent.catalog]]
api_key = "{$MIMO_API_KEY}"
```

真正的值有两种给法，任选一种：

**方式一：`server\.env`（推荐给本机长期使用）**

```powershell
Copy-Item server\.env.example server\.env
notepad server\.env
```

填入：

```text
MIMO_API_KEY=你的key
```

保存为 UTF-8 **无 BOM**（Windows 11 记事本默认就是）。`server\.env` 已在 `.gitignore` 里，不要提交。

**方式二：环境变量（推荐给一次性命令）**

```powershell
$env:MIMO_API_KEY = "你的key"
# 或写入当前用户的环境变量（新开的窗口生效）
[Environment]::SetEnvironmentVariable("MIMO_API_KEY", "你的key", "User")
```

`python-dotenv` 不会覆盖已经存在的环境变量，所以环境变量优先级更高。

不打印密钥地确认键名存在：

```powershell
(Get-Content server\.env) -match '^MIMO_API_KEY='
```

### 2.2 会话历史（可选但推荐）

不配置时历史在进程内存里，重启即丢；配置后写 PostgreSQL。数据库只存消息，文档和文件永远在磁盘上。

```text
PYCHAT_DATABASE_URL=postgresql://pychat:你的密码@192.168.16.24:6027/pychat
```

本机临时验证：

```powershell
$env:PYCHAT_DATABASE_URL = "postgresql://pychat:你的密码@192.168.16.24:6027/pychat"
```

Docker 用 `--env-file` 读取同一个变量。`config/pychat.toml` 的 `[database] dsn` 留空即可，环境变量会覆盖。

### 2.3 身份

应用不登录，只读网关给的 `X-User-Id`：

- 缺省 `local`（适合本机、单用户、测试）。
- 设置 `PYCHAT_REQUIRE_IDENTITY=1` 后，缺头直接 401（生产有网关时应打开）。
- 前端侧边栏的「当前用户（测试）」输入框只是为了模拟不同用户；生产由网关注入。

## 3. 方式 A：本机直接跑

后端：

```powershell
cd server
uv sync
uv run python -m pychat
```

打开 `http://127.0.0.1:8000`。前端 `dist` 不存在时只提供 API，属正常。

前端开发态（热更新，`/api` 代理到 8000）：

```powershell
cd frontend
npm install
npm run dev
```

打开 `http://127.0.0.1:5173`。

生产态（由 FastAPI 直接服务构建产物）：

```powershell
cd frontend
npm run typecheck
npm run build
```

然后重启后端，`http://127.0.0.1:8000` 就是完整界面。

没有模型 key 时用离线配置验证管道：

```powershell
cd server
$env:PYCHAT_CONFIG = "config/pychat.test.toml"
uv run python -m pychat
```

检查：

```powershell
curl.exe -s http://127.0.0.1:8000/api/health
```

期望包含：

```json
{"ok":true,"model":"mimo-v2.6-pro","docling":true,"tracing":true,"documents":0,"history":"postgres"}
```

`history` 是 `memory` 表示没配数据库（可用，但重启丢历史）。

> 首次运行时 Windows 会弹出防火墙提示，勾选“专用网络”，否则同网段的其他机器访问不到 8000。

## 4. 方式 B：Docker Desktop

在仓库根目录执行（构建上下文是仓库根目录）：

```powershell
docker build -t pychat:latest -f server/Dockerfile .
```

```powershell
docker run -d --name pychat --restart unless-stopped `
  -p 6032:8000 `
  --env-file server/.env `
  -v "${PWD}/data:/app/data" `
  pychat:latest
```

```powershell
curl.exe -s http://127.0.0.1:6032/api/health
```

说明：

- Docker Desktop 的 File sharing 必须允许项目所在的盘符。
- 容器内以 uid 10001 运行。如果 bind mount 报权限错误，改用命名卷：
  ```powershell
  docker run -d --name pychat --restart unless-stopped -p 6032:8000 `
    --env-file server/.env -v pychat-data:/app/data pychat:latest
  ```
- 镜像里已包含前端构建产物；本机不需要装 Node 也能跑 Docker。
- npm 依赖走 `frontend/.npmrc` 里的 npmmirror；基础镜像拉不下来时见第 7 节。

## 5. 方式 C：从 Windows 发布到 NAS（当前生产）

前提：`ssh 192.168.16.24` 可免密登录（或每次输入密码），NAS 已装 Docker，源码目录是 `/vol2/1000/app/pychat/src`。

### 5.1 首次准备（只需一次）

**数据库**：NAS 上已有 `pgvector` 容器（端口 `6027`）。只建角色和库，**不写表结构**——应用里的 `PostgresStepStore` 第一次读写时会自己建表。

```powershell
ssh 192.168.16.24
```

```sh
docker exec -it pgvector psql -U postgres -c \
  "CREATE ROLE pychat LOGIN PASSWORD '换成你的密码'"
docker exec -it pgvector createdb -U postgres -O pychat pychat
exit
```

验证（在 NAS 上）：

```sh
docker exec -e PGPASSWORD='换成你的密码' pgvector \
  psql -h 127.0.0.1 -U pychat -d pychat -c "select 1"
```

**密钥与数据目录**：

```sh
umask 077
printf 'MIMO_API_KEY=%s\n' '你的key' > /vol2/1000/app/pychat/.env
printf 'PYCHAT_DATABASE_URL=%s\n' \
  'postgresql://pychat:你的密码@192.168.16.24:6027/pychat' \
  >> /vol2/1000/app/pychat/.env
chmod 600 /vol2/1000/app/pychat/.env
mkdir -p /vol2/1000/app/pychat/data
chown -R 10001:10001 /vol2/1000/app/pychat/data
```

用 `printf` 写、不要用会加 BOM 的编辑器：`--env-file` 对 BOM/CRLF 的容忍度不值得赌。

### 5.2 同步源码

只传构建需要的文件，不要把 `node_modules`、`.venv`、`data`、`.env` 带上去：

```powershell
$dst = "192.168.16.24:/vol2/1000/app/pychat/src"
ssh 192.168.16.24 "mkdir -p /vol2/1000/app/pychat/src/server /vol2/1000/app/pychat/src/frontend"

scp -r server/src server/config server/prompts server/tests "${dst}/server/"
scp server/pyproject.toml server/uv.lock server/Dockerfile "${dst}/server/"

scp -r frontend/src frontend/public "${dst}/frontend/"
scp frontend/package.json frontend/package-lock.json frontend/.npmrc `
    frontend/index.html frontend/components.json frontend/tsconfig.json `
    frontend/vite.config.ts "${dst}/frontend/"
```

### 5.3 构建镜像

构建可能超过 SSH 的交互超时，放到后台并写日志：

```powershell
ssh -n 192.168.16.24 "cd /vol2/1000/app/pychat/src && setsid nohup docker build --progress=plain -t pychat:latest -f server/Dockerfile . > /tmp/pychat-build.log 2>&1 < /dev/null & echo ok"
```

进度与结果：

```powershell
ssh 192.168.16.24 "tail -5 /tmp/pychat-build.log; docker images pychat --format '{{.CreatedAt}}'"
```

正常情况下 45 秒到 2 分钟。超过 5 分钟先查第 7 节的 PyPI 镜像。

### 5.4 替换容器

密钥、数据库地址和数据都在 NAS 上，不随代码同步：

```powershell
ssh 192.168.16.24 "docker rm -f pychat >/dev/null 2>&1; docker run -d --name pychat --restart unless-stopped -p 6032:8000 --env-file /vol2/1000/app/pychat/.env -v /vol2/1000/app/pychat/data:/app/data pychat:latest"
```

```powershell
curl.exe -s http://192.168.16.24:6032/api/health
```

期望返回：

```json
{"ok":true,"model":"mimo-v2.6-pro","docling":true,"tracing":true,"documents":1,"history":"postgres"}
```

## 6. 验证清单

### 6.1 静态检查

```powershell
cd server
uv run ruff check .
uv run pytest -q        # v2 为 26 passed

cd ..\frontend
npm run typecheck
npm run lint
npm run build
```

### 6.2 接口

```powershell
# 健康：history 必须是 postgres
curl.exe -s http://192.168.16.24:6032/api/health

# 模型目录：应有两个
curl.exe -s http://192.168.16.24:6032/api/models

# 身份
curl.exe -s -H "X-User-Id: alice" http://192.168.16.24:6032/api/me

# 文档按用户隔离：alice 与 bob 应不同
curl.exe -s -H "X-User-Id: alice" http://192.168.16.24:6032/api/documents
curl.exe -s -H "X-User-Id: bob"   http://192.168.16.24:6032/api/documents

# 会话列表：alice 应有自己的会话
curl.exe -s -H "X-User-Id: alice" http://192.168.16.24:6032/api/conversations

# 别人的会话：404
curl.exe -s -o NUL -w "%{http_code}" -H "X-User-Id: bob" `
  http://192.168.16.24:6032/api/conversations/<某个 alice 的 id>
```

### 6.3 页面

1. 打开 `http://192.168.16.24:6032/`，**强制刷新**（旧 bundle 会缓存）。
2. 侧边栏顶部选 `alice`，会话列表应来自服务端；换成 `bob` 应为空。
3. 上传一份 xlsx，状态变成“已就绪”；切到另一个用户，列表为空。
4. 提问并展开工具活动，应看到 `run_code` 卡片和思考过程。
5. 模型下拉应有 `mimo-v2.6-pro` 与 `mimo-v2.6-flash`；选 flash 发一轮。
6. Phoenix（可选）：应出现 `chat mimo-v2.6-flash` span。
7. 刷新页面或换浏览器：`alice` 的会话仍在列表里；点开能还原消息。
8. `docker restart pychat` 后，列表与消息仍在。

## 7. 网络与镜像源（大陆环境）

- **npm**：`frontend/.npmrc` 已配置 `registry=https://registry.npmmirror.com/`；`Dockerfile` 在 `npm ci` 之前复制它。
- **PyPI**：`server/Dockerfile` 默认 `UV_DEFAULT_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple`。换源用 `docker build --build-arg UV_DEFAULT_INDEX=...`；本机可用 `$env:UV_DEFAULT_INDEX`。**不配镜像时 NAS 上拉依赖可能要十分钟以上。**
- **Docker Hub**：NAS 的 `docker.fnnas.com` 偶尔对 `node:24-alpine` 返回 401。先走备用镜像再打成本地名，Dockerfile 本身不写死镜像源：

  ```powershell
  ssh 192.168.16.24 "docker pull 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine; docker tag 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine node:24-alpine"
  ```

- **GitHub Releases**：直连 `github.com/.../releases/download/...` 可能 504。给 URL 加代理前缀：

  ```powershell
  curl.exe -L -o tool.zip "https://ghproxy.net/https://github.com/<owner>/<repo>/releases/download/<tag>/<asset>"
  ```

## 8. 常见问题

| 现象 | 处理 |
|---|---|
| `curl` 报参数错误 | PowerShell 的 `curl` 是别名，改用 `curl.exe` |
| POST 中文 JSON 报 `json_invalid` | PowerShell 5 的 `Out-File -Encoding utf8` 会写 BOM；改用 `[System.IO.File]::WriteAllText($path, $body, (New-Object System.Text.UTF8Encoding($false)))` |
| 8000 端口被占用 | `Get-NetTCPConnection -LocalPort 8000 -State Listen` 找到 PID 后 `Stop-Process -Id <pid>` |
| 健康检查 `history:"memory"` | 没配 `PYCHAT_DATABASE_URL`；历史只在进程内存 |
| 健康检查 `history:"postgres"` 但列表为空 | 用户对不上：切换/传入的 `X-User-Id` 与创建会话时不一致 |
| `401 missing user identity` | 设了 `PYCHAT_REQUIRE_IDENTITY=1` 但请求没带 `X-User-Id` |
| `400 invalid user identity` | id 只能包含字母、数字、`_`、`-`，1–64 字符 |
| 数据库连不上 | 在 NAS 上 `docker exec -e PGPASSWORD=... pgvector psql -h 127.0.0.1 -U pychat -d pychat -c "select 1"`；确认端口 `6027`、角色、库名 |
| 上传一直失败，`docling:false` | docling-serve 不可达；`curl.exe http://192.168.16.24:6029/health` 应返回 `{"status":"ok"}` |
| 上传成功但模型说找不到文件 | 看 `data/users/<user>/work/manifest.json` 的 `status` / `error`，再 `docker logs pychat` |
| 模型下拉为空 | `/api/models` 失败；检查 `server/config/pychat.toml` 的 `[agent.model]` / `[[agent.catalog]]` 与 key |
| 选了 flash 但看起来没变 | 看 Phoenix 的 span 名：`chat mimo-v2.6-flash` 才是真的走了 flash |
| 换浏览器后列表为空 | 确认后端 `history:"postgres"`、当前用户与创建者一致；旧本地库已按用户分库，不会再显示 |
| 删除的会话又出现 | 服务端没有删除接口；本地删除只写隐藏标记，换设备会重新出现（已知边界） |
| Phoenix 没有 trace | `[observability] enabled=true`，健康检查 `tracing:true` |
| Docker 构建很慢/超时 | 先确认第 7 节的 PyPI 镜像；再处理基础镜像与 GitHub 访问 |

## 9. 安全与边界

- 不要把 `server/.env`、NAS 的 `/vol2/1000/app/pychat/.env` 提交或打包。
- 应用**不做认证**：只信任网关给的 `X-User-Id`。直接暴露到公网前必须加反向代理和认证，并把 `PYCHAT_REQUIRE_IDENTITY=1` 打开。
- 数据库只存会话历史；文档原文件、派生 JSON/Markdown 永远在文件系统。
- 上传上限 64 MiB（`MAX_UPLOAD_BYTES`）。
- 会话 id 按用户命名空间隔离；猜 id 也读不到别人的历史（服务端校验）。
- 服务端没有删除会话的接口；本地删除只做隐藏。
- 怀疑 key 泄漏时，在服务商后台轮换，并更新 NAS 与本机的值。

## 10. 用 gitleaks 自查

```powershell
# 安装（大陆网络下 winget 可能下载失败，可改用第 7 节的代理方式下载 release zip）
winget install --id Gitleaks.Gitleaks -e

# 只扫源码：复制一份排除依赖与数据的目录，再扫
$src = (Get-Location).Path
$stage = "$env:TEMP\pychat-scan"
robocopy $src $stage /MIR /XD .git .codegraph .openchamber node_modules .venv __pycache__ dist data /XF .env server\.env
gitleaks dir $stage --redact --no-banner
```

- `gitleaks dir .` 会把 `node_modules` / `.venv` 一起扫，量大且多为库里的假阳性。
- 真实密钥应只在未纳入版本管理的 `server/.env`、NAS `.env` 或系统环境变量里。
- 本仓库的 `.gitignore` 已排除 `.env`、`data/`、`node_modules/`、`.venv/`、`dist/`、`.codegraph/`、`.openchamber/`。
