# Windows 原生部署（不用 Docker）

适用：一台内网 Windows 10/11 或 Windows Server 2019+，直接跑 Python 服务，**不安装 Docker**。

```text
浏览器 ──▶ FastAPI (uvicorn, :8000)
             ├─ docling-serve（远程或本机，可选）
             ├─ 模型接口（MiMo）
             └─ PostgreSQL（可选；只存会话历史）
```

没有 Docker 时，需要自己解决三件事：**开机自启**、**崩溃重启**、**日志落盘**。第 8 节给两种做法。

## 1. 前置条件

| 项 | 要求 |
|---|---|
| 系统 | Windows 10 21H2+ / Windows 11 / Server 2019+，x64 |
| Python | 3.14（uv 可以代管，不必单独安装） |
| uv | 0.12+ |
| Node.js | 24 + npm（只在构建前端时需要） |
| PostgreSQL | 14+，可选；也可以直接用 NAS 上的 `pgvector` |
| 目录 | 建议 `C:\pychat`（不要放在 OneDrive 同步目录） |
| 端口 | 默认 8000 |
| 网络 | 能访问 docling-serve、模型接口；可选 PostgreSQL |

## 2. 放置代码

把交付包解压到 `C:\pychat`，确认目录结构：

```text
C:\pychat\
  server\        FastAPI + Pydantic AI
  frontend\      Vite + React
  docs\          文档
  README.md
```

路径里有空格也能跑，但服务脚本里要加引号；建议就用 `C:\pychat`。

## 3. 配置

### 3.1 `server\.env`

```powershell
Copy-Item C:\pychat\server\.env.example C:\pychat\server\.env
notepad C:\pychat\server\.env
```

内容示例（**UTF-8 无 BOM**）：

```text
MIMO_API_KEY=你的key

# 可选：会话历史。留空则历史在进程内存里，重启即丢。
PYCHAT_DATABASE_URL=postgresql://pychat:你的密码@127.0.0.1:5432/pychat

# 只有前面确实有网关时才打开；本机/内网测试不要开。
# PYCHAT_REQUIRE_IDENTITY=1
```

`server\.env` 已被 `.gitignore` 排除，不要提交或打包。

### 3.2 `server\config\pychat.toml`

至少确认三处：

```toml
[server]
bind = "0.0.0.0:8000"        # 只给本机用就改成 127.0.0.1:8000
data_dir = "./data"

[docling]
service_url = "http://192.168.16.24:6029"

[agent.model]
name = "mimo-v2.6-pro"
api_key = "{$MIMO_API_KEY}"

[[agent.catalog]]
name = "mimo-v2.6-flash"
api_key = "{$MIMO_API_KEY}"
```

`{$MIMO_API_KEY}` 在启动时从环境变量或 `server\.env` 替换；缺了会直接启动失败，不会静默用错 key。

## 4. 数据库（可选）

不配数据库也能跑：`/api/health` 会返回 `"history":"memory"`，重启后会话历史丢失。要持久化就选一种。

### 4.1 用 NAS 上现成的 PostgreSQL（推荐）

NAS 上的 `pgvector` 容器已经把 5432 发布到 `6027`。只需建角色和库，**不要写表结构**——应用里的 `PostgresStepStore` 第一次读写时会自己建表。

在能 SSH 到 NAS 的机器上：

```sh
docker exec -it pgvector psql -U postgres -c \
  "CREATE ROLE pychat LOGIN PASSWORD '换成你的密码'"
docker exec -it pgvector createdb -U postgres -O pychat pychat
```

然后 `server\.env` 里写：

```text
PYCHAT_DATABASE_URL=postgresql://pychat:你的密码@192.168.16.24:6027/pychat
```

### 4.2 本机安装 PostgreSQL

1. 用 EDB 安装包安装 PostgreSQL 17/18（安装时记住超级用户密码）。
2. 打开“SQL Shell (psql)”或以 `postgres` 用户执行：

   ```sql
   CREATE ROLE pychat LOGIN PASSWORD '换成你的密码';
   CREATE DATABASE pychat OWNER pychat;
   ```

3. `server\.env`：

   ```text
   PYCHAT_DATABASE_URL=postgresql://pychat:你的密码@127.0.0.1:5432/pychat
   ```

4. 验证：

   ```powershell
   & "C:\Program Files\PostgreSQL\17\bin\psql.exe" `
     "postgresql://pychat:你的密码@127.0.0.1:5432/pychat" -c "select 1"
   ```

数据库**只存会话历史**；文档原文件、派生 JSON/Markdown 永远在 `data\` 目录里。

## 5. 安装后端依赖

```powershell
cd C:\pychat\server
uv sync --frozen --no-dev
```

- `--no-dev` 不装 pytest/ruff，生产机器不需要。
- 国内网络先设镜像：

  ```powershell
  $env:UV_DEFAULT_INDEX = "https://pypi.tuna.tsinghua.edu.cn/simple"
  uv sync --frozen --no-dev
  ```

## 6. 构建前端

FastAPI 直接服务 `frontend\dist`，所以要先构建一次：

```powershell
cd C:\pychat\frontend
npm ci
npm run typecheck
npm run build
```

- `.npmrc` 已配置 npmmirror；`npm ci` 失败时先检查它。
- 构建产物在 `C:\pychat\frontend\dist`，后端默认就从这里读，不需要额外配置。
- 没有 Node 的机器可以把构建好的 `dist` 一起拷过去，但升级时要重新构建。

## 7. 试运行

```powershell
cd C:\pychat\server
.\.venv\Scripts\python.exe -m pychat
```

打开 `http://127.0.0.1:8000`，检查：

```powershell
curl.exe -s http://127.0.0.1:8000/api/health
```

期望：

```json
{"ok":true,"model":"mimo-v2.6-pro","docling":true,"tracing":true,"documents":0,"history":"postgres"}
```

`history` 是 `memory` 说明数据库没接上；`docling:false` 说明 docling-serve 不可达。Ctrl+C 停止。

## 8. 开机自启与崩溃重启

### 8.1 方案 A：NSSM（推荐，自带崩溃重启）

1. 下载 NSSM 2.24（`nssm-2.24.zip`），解压出 `win64\nssm.exe`，放到 `C:\pychat\tools\nssm.exe`。GitHub 直连慢时用第 12 节的代理。
2. 以管理员身份打开 PowerShell：

   ```powershell
   New-Item -ItemType Directory -Force C:\pychat\logs | Out-Null

   C:\pychat\tools\nssm.exe install pychat `
     "C:\pychat\server\.venv\Scripts\python.exe" "-m pychat"
   C:\pychat\tools\nssm.exe set pychat AppDirectory "C:\pychat\server"
   C:\pychat\tools\nssm.exe set pychat AppStdout "C:\pychat\logs\pychat.log"
   C:\pychat\tools\nssm.exe set pychat AppStderr "C:\pychat\logs\pychat.err.log"
   C:\pychat\tools\nssm.exe set pychat AppRotateFiles 1
   C:\pychat\tools\nssm.exe set pychat AppRotateOnline 1
   C:\pychat\tools\nssm.exe set pychat AppRotateBytes 10485760
   C:\pychat\tools\nssm.exe set pychat AppEnvironmentExtra PYTHONUNBUFFERED=1 PYTHONIOENCODING=utf-8
   C:\pychat\tools\nssm.exe set pychat Start SERVICE_AUTO_START
   C:\pychat\tools\nssm.exe start pychat
   ```

3. 查看状态与日志：

   ```powershell
   C:\pychat\tools\nssm.exe status pychat
   Get-Content C:\pychat\logs\pychat.log -Tail 20
   ```

4. 升级后重启：`nssm restart pychat`；彻底移除：`nssm stop pychat; nssm remove pychat confirm`。

### 8.2 方案 B：任务计划程序（不装额外工具）

1. 创建 `C:\pychat\start-pychat.cmd`：

   ```bat
   @echo off
   cd /d C:\pychat\server
   if not exist C:\pychat\logs mkdir C:\pychat\logs
   set PYTHONUNBUFFERED=1
   set PYTHONIOENCODING=utf-8
   ".venv\Scripts\python.exe" -m pychat >> C:\pychat\logs\pychat.log 2>&1
   ```

2. 以管理员身份注册开机任务：

   ```powershell
   schtasks /Create /TN "pychat" /TR "C:\pychat\start-pychat.cmd" `
     /SC ONSTART /RU "SYSTEM" /RL HIGHEST /F
   schtasks /Run /TN "pychat"
   ```

3. 停止/删除：

   ```powershell
   schtasks /End /TN "pychat"
   schtasks /Delete /TN "pychat" /F
   ```

任务计划程序**不会在进程崩溃后自动重启**。要这个能力就用 NSSM；或者再建一个每 5 分钟检查端口的任务（注意服务启动瞬间会误判）：

```powershell
# C:\pychat\watchdog.ps1
if (-not (Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue)) {
  Start-Process -FilePath "C:\pychat\start-pychat.cmd" -WindowStyle Hidden
}
```

## 9. 防火墙与局域网访问

只在专用网络开放 8000：

```powershell
New-NetFirewallRule -DisplayName "pychat 8000" `
  -Direction Inbound -Protocol TCP -LocalPort 8000 `
  -Action Allow -Profile Private
```

然后从同网段另一台机器访问 `http://<这台机器的IP>:8000`。

- `bind = "127.0.0.1:8000"` 时只有本机能访问；要让局域网访问必须是 `0.0.0.0:8000`。
- 服务账号（SYSTEM 或专用用户）必须对 `C:\pychat\data`、`C:\pychat\logs` 有写权限。

## 10. 反向代理与身份（重要）

应用**不做认证**，只信任网关给的 `X-User-Id`：

- 纯内网、无网关：保持 `PYCHAT_REQUIRE_IDENTITY` 不设，缺头按 `local` 处理；侧边栏的“当前用户”只是测试开关，**任何人改它都能看到别人的会话**（同一台机器上）。
- 有网关/反向代理（IIS ARR、nginx、Caddy）：把用户身份作为 `X-User-Id` 注入，设置 `PYCHAT_REQUIRE_IDENTITY=1`，并让 8000 只监听 `127.0.0.1`，只允许代理访问。
- 暴露到公网前必须加 HTTPS 和认证；否则不要暴露。

## 11. 升级与回滚

1. 停止服务：`nssm stop pychat`（或 `schtasks /End /TN "pychat"`）。
2. 备份：`C:\pychat\server\.env`、`C:\pychat\data`、数据库（见第 12 节）。
3. 覆盖 `server\src`、`server\config`、`server\pyproject.toml`、`server\uv.lock`、`frontend\src`。
4. 安装与构建：

   ```powershell
   cd C:\pychat\server
   uv sync --frozen --no-dev
   cd C:\pychat\frontend
   npm ci
   npm run build
   ```

5. 启动并验证 `/api/health`、页面强制刷新。
6. 回滚：保留上一版整个 `C:\pychat` 目录的副本，出问题时切回并重启服务。

## 12. 网络与镜像源

```powershell
# PyPI
$env:UV_DEFAULT_INDEX = "https://pypi.tuna.tsinghua.edu.cn/simple"

# npm 已在 frontend\.npmrc；临时覆盖：
npm config set registry https://registry.npmmirror.com/
```

- **Docker 不存在不影响本指南**；NSSM 只是下载一个 exe。
- GitHub Releases 直连 504 时：

  ```powershell
  curl.exe -L -o nssm.zip "https://ghproxy.net/https://github.com/kirillkovalenko/nssm/releases/download/v2.24/nssm-2.24.zip"
  ```

## 13. 备份

```powershell
# 文件
robocopy C:\pychat\data D:\backup\pychat-data /MIR

# 本机 PostgreSQL
& "C:\Program Files\PostgreSQL\17\bin\pg_dump.exe" `
  "postgresql://pychat:你的密码@127.0.0.1:5432/pychat" `
  -Fc -f "D:\backup\pychat-$(Get-Date -Format yyyyMMdd).dump"

# 如果库在 NAS 的 pgvector 里
ssh 192.168.16.24 "docker exec pgvector pg_dump -U pychat -Fc pychat" > D:\backup\pychat.dump
```

- 备份要成对：`data` 与数据库尽量在同一时间窗。
- `.env` 单独保存（不要放进共享目录）。

## 14. 常见问题

| 现象 | 处理 |
|---|---|
| 服务启动即退出 | 用同一个账号在命令行跑 `.venv\Scripts\python.exe -m pychat` 看报错；多半是 `.env` 缺 key 或配置校验失败 |
| `history:"memory"` | `PYCHAT_DATABASE_URL` 没加载：确认 `server\.env` 存在、无 BOM、变量名拼写正确 |
| 数据库连接失败 | 用 `psql "postgresql://..." -c "select 1"` 验证；检查端口、角色、库、防火墙 |
| `401 missing user identity` | 设了 `PYCHAT_REQUIRE_IDENTITY=1` 但请求没带 `X-User-Id` |
| `400 invalid user identity` | id 只能包含字母、数字、`_`、`-`，1–64 字符 |
| 页面 404 / 还是旧界面 | `frontend\dist` 不存在或没重建；`npm run build` 后强制刷新 |
| 端口被占用 | `Get-NetTCPConnection -LocalPort 8000 -State Listen` 找 PID，`Stop-Process -Id <pid>` |
| 局域网访问不到 | 检查 `bind`、防火墙规则、网络配置文件是否为“专用” |
| 中文日志乱码 | 服务环境加 `PYTHONIOENCODING=utf-8` |
| 日志文件不更新 | NSSM 的 `AppStdout` 路径；任务计划方案看 cmd 是否加了重定向 |
| 模型下拉为空 | `/api/models` 失败：检查 `[agent.model]` / `[[agent.catalog]]` 和 key |
| 换浏览器会话为空 | 当前用户与创建者不一致，或数据库没接上 |
| `uv sync` 很慢 | 设 `UV_DEFAULT_INDEX`（第 12 节） |

## 15. 验收清单

```powershell
curl.exe -s http://127.0.0.1:8000/api/health
curl.exe -s http://127.0.0.1:8000/api/models
curl.exe -s -H "X-User-Id: alice" http://127.0.0.1:8000/api/me
curl.exe -s -H "X-User-Id: alice" http://127.0.0.1:8000/api/conversations
```

页面：

1. 上传文档 → 状态“已就绪”。
2. 切到另一个用户 → 文档列表为空。
3. 发一轮对话 → 会话出现在侧边栏；换浏览器/刷新后仍在。
4. 模型下拉有 pro / flash；选 flash 后 Phoenix 出现 `chat mimo-v2.6-flash`。
5. 重启服务（`nssm restart pychat`）→ 会话列表与消息仍在。
6. 从同网段另一台机器打开 `http://<IP>:8000`。
