# 多用户与持久化：现状、缺口与路线

> 结论先行：**缺的不是数据库，是两个东西——身份契约，和一层能改行为而不发版的配置。** 没有前者，换 Postgres 只是把共享数据搬进更贵的柜子；没有后者，上架一个模型、调一次限额、关一个功能，都要重新构建镜像。

- 日期：2026-11-08
- 范围：从当前单用户 MVP 演进到"多用户 + 服务端持久化"需要补什么
- 依据：本仓库代码 + Pydantic AI 2.66.0 / Harness 0.66.0 实际安装的行为
- 本文不是实施方案，是**契约 + 缺口清单 + 路线建议 + 待拍板项**

## 0. TL;DR

1. **不做认证，但必须做身份契约与归属校验。** 登录、token、MFA 是网关的事；"这条记录是不是这个人的"只有我们能做，而且它发生在我们的响应体里——出事算我们的。
2. **配置不是运维细节，是产品的控制面。** 模型目录、思考档位、限额、开关全在这里；它决定了"改行为要不要发版"。
3. **最容易被低估的是文档与沙箱隔离**，不是会话存储。当前 `manifest.json`、`uploads/`、`/work` 挂载都是全局的，模型在 A 的会话里能直接读到 B 的文档。
4. **会话持久化是最便宜的一块。** `dispatch_request` 已内建 `message_history=` / `manage_message_history='server'` / `on_complete=`，前端一行不用改；一张 `jsonb` 表就够"还原一个对话"。
5. **前端 IndexedDB 必须从"真相源"降级为"缓存"**，而不是简单删掉。服务端持有历史之后，客户端历史才能被视为不可信输入。
6. **多副本之前先去掉进程内状态**（`DocumentStore._entries`、`asyncio.Lock`、`app.state.agent` 单例），否则扩容只是产生两个各写各的数据集。
7. 粗估：P0–P3（身份 + 配置 + 会话 + 隔离）约 **6–10 人天**；完整生产形态约 **12–20 人天**。估算前提是熟悉本仓库，不含对接网关本身的工时。

## 1. 现状盘点（可逐条核对）

| 能力 | 现状 | 位置 |
|---|---|---|
| 身份 | **无。** 所有路由没有用户概念，没有 session、没有 token 校验 | `server/src/pychat/main.py:84-146` |
| 归属 | **无。** `GET /api/documents` 返回全部文档；`GET /api/documents/{id}/raw` 只要 id 是字母数字就返回文件 | `main.py:104-146`、`documents.py:97-103` |
| 会话历史 | 浏览器 IndexedDB，服务端完全无状态 | `frontend/src/lib/chat-db.ts`、`Chat.tsx:47-110` |
| 客户端历史信任 | 客户端发全量历史，服务端按 `manage_message_history='client'` 当作会话；Pydantic AI 只做 sanitize | `main.py:96-101`、pydantic 文档 "Trust model" |
| 配置 | 单份 TOML；模型名与 `max_tokens` 写死；前端模型列表写死在 `config.ts` | `config/pychat.toml`、`frontend/src/lib/config.ts` |
| 文档索引 | 单个 `data/work/manifest.json`，进程内 `dict` 缓存 + `asyncio.Lock` | `documents.py:57-91` |
| 文档文件 | 全局 `data/uploads/<12hex>.<ext>`，文件名即所有权 | `documents.py:115-116` |
| 模型可见范围 | `MountDir("/work", work_dir, read-only)`，**全局唯一**，在 lifespan 里构建一次 | `agent.py:54`、`main.py:45-50` |
| 系统提示词里的清单 | `{manifest}` 占位符每次 run 注入**全局** manifest | `agent.py:43-46`、`prompts/chat.md` |
| Agent 实例 | `app.state.agent` 单例，全进程共用 | `main.py:45-50` |
| 转换 | 上传请求内同步等待 docling-serve，最长 600s | `documents.py:105-138`、`docling.py` |
| 观测 | Phoenix 单项目，span 里没有 user 维度 | `observability.py`、`config/pychat.toml` |
| 部署 | 单容器 + NAS bind mount，uid 10001 | `server/Dockerfile`、`docs/13-windows-deploy.md` |

## 2. 为什么"前端存储"在生产上不可接受

**（a）它让服务端失去对历史的权威。** 当前 `POST /api/chat` 把浏览器发来的整段历史当作会话。Pydantic AI 的适配器默认只保证"协议能往返"，不保证"历史是真的"——官方原话是 *UI adapter endpoints aren't authentication boundaries*，并且 *anything in `message_history` ... is under the caller's control*。改一段前端 JS 就能让模型"以为"自己之前答应过某事。

**（b）它让审计与计费不可能。** 会话不在服务端，就没有"这个用户这个月用了多少 token"的可靠来源；`Conversation.usage` 也就没地方累计。

**（c）它让保留策略无法执行。** 用户注销、数据删除、监管要求，都只能寄希望于用户自己清浏览器。

**（d）它让跨设备、团队协作、分享链接这类产品功能在结构上无法实现。**

分清楚：**不可接受的是"客户端是真相源"，不是"客户端有缓存"。** 正确形态是服务端权威、IndexedDB 缓存：读时本地命中先用、后台校验，写时只写服务端。

## 3. 缺口清单

### 3.1 身份契约与归属（不做认证）

#### 边界：我们做什么、不做什么

| 事项 | 谁的活 | 出事谁背 |
|---|---|---|
| 登录、发 token、MFA、账号生命周期 | 网关 / 统一认证 | 他们 |
| 网络准入、只在内网暴露、端口策略 | 运维 / 基础设施 | 他们 |
| 身份头格式、字段语义、失效时谁通知谁 | 双方，写进接口约定 | 共同，但有条文可依 |
| **这条记录是不是这个人的** | **我们** | **我们** |
| **请求日志里留下收到的是谁** | **我们** | **我们** |

中间那行是关键：**接口约定要写成纸。** 一页，三句话——头叫什么、`user_id` 保证唯一且不可变、网络保证只有网关能到。这张纸的作用不是技术，是出事时能指着它说"我按约定消费的，身份不是我发的"。

#### 身份头

只走 Header，**不接受 body 或 query**：

```text
X-User-Id:    u_8f3a2c        # 不透明字符串，1..128，仅 [A-Za-z0-9_-]
X-Tenant-Id:  t_001           # 可选，现在不用，列先留
X-Request-Id: 01J...          # 可选，链路追踪
```

信任靠哪一道，由网关/运维定，我们只记录选择：

| 做法 | 谁的活 | 挡得住什么 |
|---|---|---|
| 网络隔离：容器不 publish 端口，只在内网 | 运维 | LAN 上的随手伪造 |
| 网关签名：`X-Identity-Signature = HMAC(secret, user_id\|ts)` | 网关 | 内网被横向移动后的伪造 |

**部署前提**：如果容器仍然 `-p 6032:8000` 直接发布到 LAN，那么"网关在前面"这句话不成立，任何人都能 `curl -H "X-User-Id: 别人"`。这不是我们加代码能解决的，是要在部署清单里写明的前置条件。

#### 三条实现规则

1. **失败即拒绝。** `trusted-header` 模式下缺头就是 401，绝不回落成匿名用户。回落是这类设计最常见的洞。
2. **不建 `users` 表。** 业务表存 `owner_id text`，列表与配额都按它过滤。没有外键完整性，上游删用户的残留靠定期清理任务。身份是别人给的，我们只记下来。
3. **别人的资源返回 404，不是 403。** 403 等于确认"存在但你没权限"，可以拿来枚举。

开发环境留 `mode = "single-user"` + 固定 id，本地跑不用起网关。

#### 不做的事（明确排除）

- 应用内注册、登录、找回密码、MFA
- 自建用户表与角色表
- 细粒度 RBAC（资源级 ACL）
- 校验身份头签名的业务逻辑（如果网关提供，我们只做"有就验、没有就记日志"）

**工作量**：0.5–1 天（依赖注入 + 所有查询加 `owner_id` + 日志）。

### 3.2 租户隔离：文档与沙箱（最容易被低估）

**现状**：这是当前最实际的越权面，且不是理论问题。

- `manifest.json` 全局，`instructions()` 每次 run 把它拼进系统提示词 → **A 的模型能看到 B 上传的文件名**。
- `/work` 全局只读挂载 → 模型可以 `json.load("/work/<任意id>.json")` 读到别人的文档内容。
- `uploads/` 全局，文件名就是 12 位 hex → `raw` 端点猜中即可下载。
- `app.state.agent` 单例，`MountDir` 在 lifespan 里构建一次 → 现在根本没有按用户切换目录的位置。

**最小方案**：

```text
data/users/<user_id>/
  uploads/
  work/
    manifest.json
```

- `DocumentStore` 从"全局实例"变成"按 `owner_id` 解析"（或所有方法收 `owner_id`）。
- Agent 不能再在 lifespan 里调一次。粒度是 **(模型, 工具集)**，不是用户；用户相关信息走 run 依赖。挂载目录按 `owner_id` 解析（详见 §6）。
- `manifest_text()` 变成 `manifest_text(owner_id)`。
- 迁移：历史数据归入 `legacy`，或直接清空（当前只有 1 份测试文档）。

**代价**：Agent 缓存要设上限，否则用户数 × capability 状态会吃内存；注意 CodeMode 沙箱默认 30s / 256 MiB / 100 次调用。

**工作量**：2–3 天。

### 3.3 会话持久化：StepPersistence + PostgresStepStore

**现状**：IndexedDB，服务端无状态。

**决定**：用 Harness 自带的 `StepPersistence` + `PostgresStepStore`，**不写 SQL、不写迁移**。

- 表由存储在第一次读写时自己创建（`CREATE ... IF NOT EXISTS` + advisory lock），表前缀 `pychat`。
- 能力挂在 Agent 上：`StepPersistence(store=..., agent_name="pychat", metadata={"user_id": user})`。
- 会话 id 加用户前缀（`user:chat_id`），猜到一个 id 也读不到别人的历史。
- **数据库只存消息历史，永远不存文件。**

**读写都不经过手写 SQL**：

```python
# 读：最新的 complete 快照就是下一轮的起点
runs = await store.list_runs(conversation_id=f"{user}:{chat_id}")
for run in reversed(runs):
    snapshot = await store.latest_snapshot(run_id=run.run_id)
    if snapshot is not None:
        history = snapshot.messages
        break

# 写：能力在 settled 边界和 run 结束时自动快照，调用方不写库
adapter = await VercelAIAdapter.from_request(
    request, agent=agent, sdk_version=7, manage_message_history="server",
)
return adapter.streaming_response(
    adapter.run_stream(message_history=history, conversation_id=f"{user}:{chat_id}")
)
```

**接口**：

| 方法 | 路径 | 行为 |
|---|---|---|
| POST | `/api/chat` | 按 `conversation_id` 读最新快照，跑完由能力保存 |
| GET | `/api/conversations` | `list_runs()` + metadata 过滤，返回当前用户的会话摘要 |
| GET | `/api/conversations/{id}` | 读快照 → `VercelAIAdapter.dump_messages(sdk_version=7)` 返回 UI 消息 |

**边界，必须写清楚**：

1. **只存 messages，不存 usage。** 跨轮的 token 预算每轮从零开始；需要累计用量时再另存。
2. **会话列表用框架 API 拼。** `StepStore` 只能按 `conversation_id` 查，所以列表走 `list_runs()` + `RunRecord.metadata["user_id"]` 过滤，再按用户前缀去重；不写 SQL。规模变大时再加索引或专门的会话头存储。
3. **快照默认不裁剪。** 长对话会持续增长；后续用 `max_snapshots_per_run` 设上限。
4. **Harness 仍是 0.x。** 钉 `0.66.0`；升级时先看 release notes。
5. **id 规范化。** 前端会话 id 带前导 `/`，存储前统一去掉；否则同一会话会有两条记录。

**为什么不是 A（`Conversation` + `jsonb`）或 B（自实现 `ConversationStore`）**：A、B 都要自己定义表、写 SQL、写迁移，正是这次明确否掉的做法。C 的代价是概念多、只有消息没有 usage，但换来"零 SQL"和崩溃/分叉能力。

### 3.4 文档存储：文件永远不进数据库

**铁律**：PostgreSQL 只存会话历史，**文档原文件与派生 JSON/Markdown 一律留在文件系统**。数据库存文件会让备份、WAL、恢复全部被大文件拖垮，也不是 blob store 该干的事。

**v2 现状**：每个用户一份目录 + 一份 `manifest.json`：

```text
data/users/<user_id>/
  uploads/<id>.<ext>
  work/<id>.json
  work/<id>.md
  work/manifest.json
```

- 默认用户沿用旧的 `data/` 布局，老数据零迁移。
- `manifest.json` 只是给沙箱看的投影；模型仍按 `/work/manifest.json` 发现文档。
- 删除时三者一起删：DB 没有文档行，所以只有文件与 manifest，顺序简单。

**什么时候需要变化**：多副本或共享存储时，把 `data/` 换成对象存储（S3/MinIO），路径按 `user_id/<sha256>` 分；仍然不放进 PostgreSQL。文档元数据表可以以后再加，但它只存指针与状态，不存字节。

### 3.5 并发、幂等、多副本

**现状**：所有状态在进程内。`_lock` 与 `_entries` 只在一个进程里有效；Agent 单例；上传/转换/聊天都假设单副本。

**缺什么**：

- 真相源移到 Postgres 后，滚动更新才安全。
- 上传重试幂等（同一文件重复提交会得到两个 doc_id）。
- 每用户并发 run 限制（否则一个人能打满配额，也会让同一对话并发写冲突）。
- 多副本 SSE：上负载均衡后需要粘性会话或共享事件通道。

**工作量**：1–2 天（不含多副本 SSE）。

### 3.6 转换异步化与背压

**现状**：`ingest()` 在请求里 `await` docling-serve，最长 600 秒。

**缺什么**：上传立即返回 `status=converting`，后台推进状态，前端轮询或订阅。再进一步是任务表 + worker，但那是量起来之后的事。

**工作量**：1–2 天。

### 3.7 配额与成本

**现状**：无。上传 64 MiB 是全局常量；没有按用户的文档数、存储量、token 预算。

**缺什么**：按 `owner_id` 的计数与用量。Harness 的 `Spend` capability 有 Postgres 后端，可做 per-tenant 预算，属可选加速项。

**工作量**：1–2 天。

### 3.8 可观测性

**现状**：Phoenix 单项目，`gen_ai.conversation.id` 有，但没有 user 维度。

**缺什么**：`owner_id` 放进 run metadata / span 属性，才能按租户排障与计费核对。**不要把用户输入的大段文本塞进 metadata**（会进 trace）。

**工作量**：0.5 天。

### 3.9 运维：迁移、备份、密钥、保留

- **迁移**：`asyncpg` + 手写 SQL + `schema_version` 表；除非预期复杂查询，不引入 ORM。
- **备份**：DB 与文件要能对到同一个时间点；先 DB 后文件（或反之）都有一致性窗口，要明确接受哪一种。
- **密钥**：`.env` 单份仍可行（模型 key 是服务级），但文档内容从此是"用户数据"，需要保留期与删除承诺。
- **磁盘**：`uploads/` 随用户增长，NAS 容量要有告警。

**工作量**：1–2 天 + 长期运维。

## 4. API 契约

### 4.1 原则

1. **归属是第一等公民。** 每个读写都带 `owner_id` 约束；列表只返回自己的。
2. **不提供登录相关端点。** 没有 `/login`、`/token`、`/session`、`/password`。
3. **流式端点与 CRUD 分开。** 聊天保留 AI SDK 协议，身份在服务端解析，不进 body。
4. **路径版本化暂缓。** v2 沿用 `/api`，新增端点不改名；第一次破坏性变更时再起 `/api/v1`，避免现在就维护两套 URL。
5. **失败可说清。** 统一 `{code, message, request_id}`，`code` 稳定、可被前端分支。

### 4.2 端点

| 方法 | 路径 | 用途 | 归属 |
|---|---|---|---|
| GET | `/api/me` | 我是谁、能用哪些模型、剩余配额 | 自身 |
| GET | `/api/models` | 对当前用户可见的模型目录 | 按权限过滤 |
| GET | `/api/conversations` | 我的会话列表（游标分页） | `owner_id` |
| POST | `/api/conversations` | 新建会话 | `owner_id = 我` |
| GET | `/api/conversations/{id}` | 读取历史 | 校验归属 |
| PATCH | `/api/conversations/{id}` | 改名 / 归档 | 校验归属 |
| DELETE | `/api/conversations/{id}` | 删除 | 校验归属 |
| POST | `/api/chat` | 流式一轮对话 | 校验会话归属 |
| GET | `/api/documents` | 我的文档 | `owner_id` |
| POST | `/api/documents` | 上传 | `owner_id = 我` |
| DELETE | `/api/documents/{id}` | 删除文档及产物 | 校验归属 |
| GET | `/api/documents/{id}/raw` | 下载原件 | 校验归属 |
| GET / PUT | `/api/preferences` | 默认模型、默认思考强度 | `owner_id` |
| GET | `/api/health` · `/api/ready` | 存活 / 依赖就绪 | 无需 |
| — | `/api/login` 等 | **不存在，刻意不做** | — |

### 4.3 响应形状

`GET /api/me`：

```json
{
  "user_id": "u_8f3a2c",
  "display_name": "张三",
  "default_model": "mimo-v2.6-pro",
  "default_effort": "medium",
  "limits": { "documents": 200, "concurrent_runs": 1 },
  "config_version": "2026-11-08.3"
}
```

`GET /api/models`：

```json
{
  "models": [
    {
      "id": "mimo-v2.6-pro",
      "label": "MiMo v2.6 Pro",
      "efforts": ["low", "medium", "high"],
      "default_effort": "medium",
      "available": true
    },
    {
      "id": "other-model",
      "label": "Other",
      "available": false,
      "reason": "no key configured"
    }
  ]
}
```

**关键**：`available: false` + `reason`，而不是让前端拿到一个点不动的选项。前端所有"该不该显示"的判断都来自这里，不再散落在客户端常量里。

### 4.4 状态码约定

| 码 | 场景 |
|---|---|
| 400 | 参数不合法；请求的模型不在允许集合（响应带 `allowed` 列表） |
| 401 | 缺身份头 / 身份无效 |
| 404 | 资源不存在**或不属于你**（不区分） |
| 409 | 会话 revision 冲突（编辑/重生成并发） |
| 413 | 上传超限 |
| 415 | content-type 不是 `application/json`（适配器默认行为，保留） |
| 429 | 每用户并发 run 超限，带 `Retry-After` |
| 503 | 模型或 DB 未就绪 |

### 4.5 幂等与流式

- `POST /documents`、`POST /conversations` 接受 `Idempotency-Key`，24 小时内同键返回同一结果。
- 聊天端点：`text/event-stream`；客户端断开即取消 run（`on_cancel` 里按需要保存）。
- 分页一律游标（`?cursor=...&limit=...`），不用 offset——会话会随时新增。

## 5. 配置设计

### 5.1 为什么配置是这套系统里最该认真对待的东西

1. **它是唯一能"不发版改行为"的地方。** 模型上下架、限额、开关、提示词版本都在这里。没有它，上架一个模型要改前端常量、重新 `npm run build`、重建镜像、重启容器。
2. **它是事故时的刹车。** 出问题第一反应是关功能，不是回滚代码——回滚要构建和重启，热加载是秒级。
3. **配置错了是静默故障。** 代码错会 500；配置错会"正常返回错误的结果"：模型指向测试环境、`max_tokens` 少十倍、某个用户不在白名单。没人会发现，直到账单或投诉。
4. **它是跨团队的接口。** 产品要上模型、运维要给配额、安全要看谁能用，三方都读它。所以它必须有 schema、有版本、有校验、有审计。
5. **它直接等于钱。** 模型单价、`max_tokens`、并发数，每一个都是账单上的一行。

现状只有第 1 层（部署配置），第 2、3 层完全不存在——这是"有没有完整配置"的答案：**没有**。

### 5.2 三层配置

| 层 | 内容 | 存储 | 生效 | 谁能改 | 出错的影响 |
|---|---|---|---|---|---|
| **部署配置** | DB DSN、docling 地址、监听、数据目录、网关密钥 | TOML + 环境变量 | 重启 | 运维 | 起不来（可见） |
| **产品配置** | 模型目录、思考档位、限额、开关 | TOML（起步）/ DB（有管理界面后） | 热加载 | 产品 / 管理员 | 静默错误（不可见） |
| **用户偏好** | 默认模型、默认强度 | DB | 即时 | 用户自己 | 影响单人 |

建议起步：**产品配置也用 TOML**，配文件监听或 `SIGHUP` 热加载；等到需要"管理员在网页上改"时再迁 DB。先上 DB 会多一套 CRUD 和审计，收益不成正比。

### 5.3 优先级：后面的只能收窄，不能扩张

```text
部署默认  →  产品目录（允许集合）  →  用户偏好  →  请求参数
                                              └─ 必须落在前三者的交集内
```

具体规则：

- 客户端只能发 `model_id` 和 `effort`，**永远不接受 `base_url` / `api_key`**。一个能指定 base_url 的接口，等于允许别人把你的 key 发到他的服务器。
- 服务端算 `可用 = 目录 ∩ 用户权限`；不在集合里返回 400，并带上 `allowed` 列表。
- 用户偏好失效时（模型下架）自动回落默认，并在 `/api/me` 里标 `source: "fallback"`，不要让前端自己猜。
- 思考强度是枚举（`low/medium/high`）映射到服务端预算，不是客户端传任意 token 数——一个前端 bug 就能把账单放大十倍。

### 5.4 配置文件长什么样

```toml
# ---- 部署配置（改了要重启） ----
[server]
bind = "0.0.0.0:8000"
data_dir = "./data"

[identity]
mode = "trusted-header"        # trusted-header | single-user
header = "X-User-Id"
single_user_id = "local"       # 仅 mode = single-user 时使用

[database]
dsn = "{$PYCHAT_DATABASE_URL}"
pool_min = 2
pool_max = 10

[docling]
service_url = "http://192.168.16.24:6029"
timeout_s = 600

[observability]
enabled = true
endpoint = "http://192.168.16.24:6013"
project_name = "pychat"

# ---- 产品配置（可热加载） ----
[limits]
max_upload_bytes = 67108864
max_documents_per_user = 200
concurrent_runs_per_user = 1
max_tokens_ceiling = 16384

[[models]]
id = "mimo-v2.6-pro"
label = "MiMo v2.6 Pro"
provider = "openai-compatible"
base_url = "https://token-plan-cn.xiaomimimo.com/v1"
api_key = "{$MIMO_API_KEY}"
default = true
max_tokens = 8192
efforts = ["low", "medium", "high"]

[[models]]
id = "backup-model"
label = "Backup"
provider = "openai-compatible"
base_url = "https://example/v1"
api_key = "{$BACKUP_API_KEY}"
enabled = false
disabled_reason = "quota not approved"
```

字段要点：

- `api_key` 只写 `{$ENV}` 引用，**永不进 API 响应、永不进日志**。
- `efforts` 是允许的档位；具体数值映射留在服务端代码里，配置只暴露枚举。
- `enabled = false` + `disabled_reason` 让"下架但不删"成为一等操作。
- `default = true` 全局唯一；多个为真时启动报错。

### 5.5 校验与失败策略

- Pydantic 模型 + `extra="forbid"`：拼错的键必须在启动时报错，而不是被静默忽略。
- 生产环境 **fail fast**：模型目录为空、默认模型不存在、`default` 多于一个 → 启动失败。
- 开发环境 **warn**：允许跑起来，但 `/api/ready` 标 `config_warnings`。
- 热加载失败 → 保留上一份可用配置，日志报错，`/api/ready` 返回 `config_stale: true`。**永远不要因为新配置坏了就把服务打挂。**
- 提供 `python -m pychat --check-config`：打印生效配置（密钥打码）、校验结果、退出码。上线前跑一次，比看日志快。

### 5.6 配置的可观测性

- 启动日志只打 **配置哈希 + 版本 + 模型数量**，不打值。
- `/api/ready` 返回 `config_version`、`models_available`、`config_stale`。
- `/api/me` 返回生效的模型与 `source`（`default` / `user` / `fallback`）——出问题时能一眼看出"是配置错还是用户选错"。

## 6. 全局资源管理（Dishka）

> v2 先用一个等价的显式实现落地同样的三层生命周期：`build_model()` 在进程内只调一次，`AgentPool` 按用户缓存 Agent，连接池由模型持有。Dishka 迁移只替换装配方式，不改变这套职责划分。

### 6.1 泄漏从哪来

一条链：模型实例 → provider → SDK 客户端 → **HTTP 连接池**。连接只在 `aclose()` 时释放。

Pydantic AI 的 provider 实现了引用计数的 `__aenter__` / `__aexit__`：**最后一个借用者退出时，它关闭"它自己创建的"客户端**；如果你把自己的 client 注入进去，它不会关，由你负责。

于是三种写法，只有一种是对的：

| 写法 | 结果 |
|---|---|
| ❌ 每请求 `build_model()`，从不关闭 | socket / FD 泄漏，随轮次线性增长，最后 `Too many open files` |
| ⚠️ 每请求创建 + `async with provider` | 不漏，但计数归零即关池：每轮重新 TLS 握手，延迟与 CPU 白花 |
| ✅ 进程级连接池 + 模型级句柄 + 请求级借用 | 连接复用，生命周期可控 |

注意第二种：**能"关"不等于该"每请求关"**。这正是"换模型"看起来和连接管理对立的原因——把开关频率搞错了。

### 6.2 作用域映射

Dishka 1.x 的标准作用域是 `APP → REQUEST`（`RUNTIME` 与 `SESSION` 默认跳过）。映射到本项目：

| 作用域 | 对象 | 创建时机 | 销毁时机 |
|---|---|---|---|
| `Scope.APP` | 配置、`httpx2.AsyncClient`、DB 池、docling 客户端、追踪 provider、`ModelRegistry` | 首次被请求 | `container.close()` |
| `Scope.REQUEST` | `Identity`、`ConversationStore`、按请求的 deps | 每个请求 | 响应结束（含 SSE 全流） |
| `Scope.STEP` | 可选：单次 run 的沙箱租约 | 每次 run | run 结束 |

**一句话：身份不产生资源。** `owner_id` 只是过滤键；它不该触发新建 Agent、新建连接、新建沙箱。

**关键事实（已核对 Dishka 源码）**：`ContainerMiddleware` 把整个 ASGI 调用包在 `async with` 里，而 `StreamingResponse` 是在这个调用内部把 body 逐块发完的。所以 **REQUEST 作用域会一直活到 SSE 最后一个 chunk**，流式端点里注入的依赖不会在中途被关掉。

### 6.3 为什么模型不是 provider，而是注册表

Dishka 按**类型**解析依赖。`model_id` 是运行时的键，不是类型——把它做成 provider 只有两种结局：

- provider 参数里带 `model_id` → 每次请求一个新的 model/provider → 正好踩回 §6.1 的泄漏；
- 为每个模型写一个 `NewType` 或子类 → 上架模型要改代码，和 §5 的"配置驱动"直接冲突。

所以分工是：**Dishka 管生命周期，注册表管键值。**

```python
class ModelRegistry:
    """APP 作用域。按 model_id 懒创建，句柄本身不持有连接。"""

    def __init__(self, catalog: list[ModelEntry], http: httpx2.AsyncClient) -> None:
        self.catalog = {entry.id: entry for entry in catalog}
        self._http = http          # 共享连接池，provider 不拥有它
        self._models: dict[str, OpenAIChatModel] = {}

    def get(self, model_id: str) -> OpenAIChatModel:
        entry = self.catalog[model_id]
        model = self._models.get(model_id)
        if model is None:
            provider = OpenAIProvider(
                base_url=entry.base_url,
                api_key=resolve(entry.api_key),
                http_client=self._http,   # 注入：provider 不负责关闭
            )
            model = OpenAIChatModel(entry.id, provider=provider)
            self._models[model_id] = model
        return model
```

- 一个 `httpx2.AsyncClient` 服务所有上游；它内部按 host 分池，天然复用。
- 模型句柄只是壳，不持有连接 → **丢弃不需要排空**，热加载可以直接换字典。
- 温度、`max_tokens`、思考强度是 **run 级设置**，不产生新句柄。

### 6.4 装配

```python
from collections.abc import AsyncIterator

from dishka import Provider, Scope, make_async_container, provide
from dishka.integrations.fastapi import FastapiProvider, FromDishka, inject, setup_dishka


class AppProvider(Provider):
    scope = Scope.APP

    @provide
    def config(self) -> AppConfig:
        return load_config()

    @provide
    async def http(self) -> AsyncIterator[httpx2.AsyncClient]:
        client = httpx2.AsyncClient(timeout=60)
        yield client
        await client.aclose()

    @provide
    async def db(self, config: AppConfig) -> AsyncIterator[Pool]:
        pool = await asyncpg.create_pool(config.database.dsn)
        yield pool
        await pool.close()

    @provide
    def models(self, config: AppConfig, http: httpx2.AsyncClient) -> ModelRegistry:
        return ModelRegistry(config.models, http)


class RequestProvider(Provider):
    scope = Scope.REQUEST

    @provide
    def identity(self, request: Request, config: AppConfig) -> Identity:
        raw = request.headers.get(config.identity.header)
        if not raw:
            raise HTTPException(status_code=401, detail="missing identity")
        return Identity(user_id=raw)

    @provide
    def conversations(self, db: Pool, identity: Identity) -> ConversationStore:
        return ConversationStore(db, owner=identity.user_id)


container = make_async_container(AppProvider(), RequestProvider(), FastapiProvider())
setup_dishka(container=container, app=app)


# lifespan 里：结束时必须关
async def lifespan(app: FastAPI):
    yield
    await app.state.dishka_container.close()
```

处理器只声明"我需要什么"，不关心它从哪来、何时关：

```python
@router.post("/api/chat")
@inject
async def chat(
    request: Request,
    identity: FromDishka[Identity],
    registry: FromDishka[ModelRegistry],
    conversations: FromDishka[ConversationStore],
) -> Response:
    adapter = await VercelAIAdapter.from_request(request, agent=agent, sdk_version=7)
    model_id = pick_allowed(adapter, identity, registry.catalog)   # §5.3 的收窄规则
    history = await conversations.load(adapter.conversation_id)

    async def save(result: AgentRunResult) -> None:
        await conversations.save(adapter.conversation_id, result)

    return adapter.streaming_response(
        adapter.run_stream(
            model=registry.get(model_id),
            message_history=history,
            conversation_id=adapter.conversation_id,
            manage_message_history="server",
            on_complete=save,
        )
    )
```

**DI 管生命周期，不管数据流。** 会话 id、解析后的 body、加载出来的历史，都是处理器里的局部变量；不要把它们做成 provider，否则依赖图会退化成请求解析器。

### 6.5 换模型、换强度

- **换模型** = `registry.get(new_id)`，一次字典查找；连接池不动。
- **换强度** = `model_settings`，连字典都不用查。
- **热加载** = 替换 `registry.catalog` 和句柄字典；在跑的请求持有旧对象引用，不受影响。因为句柄不持有连接，不需要等待排空。

### 6.6 关停顺序

```text
停止接收新请求 → 等在跑的 run 结束（有超时）→ 关 DB 池 / docling 客户端 / HTTP 池 → flush 追踪
```

Dishka 的 `container.close()` 按作用域逆序执行 finalizer，天然满足这个顺序；不要再自己维护第二套 `AsyncExitStack`。

### 6.7 Agent 与沙箱的粒度

- **Agent 粒度是 (模型, 工具集)**，不是用户。用户相关的东西（名字、权限、文档目录）走 run 依赖。否则用户一多，就有一堆 Agent 各自握着一个沙箱。
- 沙箱是隔离边界，建议**按 run**（`Scope.STEP`）而不是按进程；如果只能按 Agent，就必须给缓存设硬上限。
- 注意：`MountDir` 在 pychat 里是按用户的 `work/` 目录，这一维度和"按模型"正交。Dishka 解决不了它，需要 CodeMode 支持 run 级挂载，或接受一个有上限的 `(model, owner)` 缓存。

### 6.8 踩坑清单

1. **别把 model / provider 放进 `Scope.REQUEST`**——这是泄漏的唯一来源。
2. **别每请求 `async with provider`**——计数归零即关池，连接复用全丢。
3. **后台任务不要从请求容器取对象**：转换 worker 这类比响应活得久的任务，开自己的作用域，或只依赖 APP 服务。
4. **`await container.close()` 必须写在 lifespan 里**，漏了就泄漏到进程退出。
5. **DI 不解析请求数据**：provider 只拿 `Request` 这类框架上下文，不拿业务 payload。
6. **版本**：Dishka 1.10.x（Python ≥ 3.10）。`dishka.integrations.fastapi` 在 2.0 计划迁到独立包，先钉版本。

### 6.9 监控什么

- 进程打开的文件描述符数（泄漏的第一信号）
- `httpx2` 连接池使用率与等待时间
- 活跃模型句柄数、命中率（是否频繁建了又关）
- 每用户并发 run 数

## 7. 建议的改造顺序

每个阶段独立可上线、可回滚。

| 阶段 | 内容 | 验收标准 | 回滚方式 |
|---|---|---|---|
| **P0** | 身份契约 + `current_user` + 所有路由 `owner_id` 校验 | 缺头 401；A 拿不到 B 的文档 | 切 `single-user` 模式 |
| **P1** | 配置分层 + `/api/me` + `/api/models`（模型目录从代码搬到配置） | 上架模型只改配置，不发前端 | 回落写死的单模型 |
| **P2** | 会话持久化（`Conversation` jsonb）+ 前端缓存化 | 换浏览器仍有历史；服务端有 usage | 关开关，回落浏览器历史 |
| **P3** | 文档与沙箱隔离 + 文档元数据进 DB | A 的模型读不到 B 的 `/work` | 保留旧全局目录只读 |
| **P4** | 上传异步化（`converting` 状态） | 大文件立即返回 | 切回同步转换 |
| **P5**（可选） | 配额、审计日志、`ConversationStore` / `StepPersistence` | 按需 | — |

**P0 + P1 可以先上**：它们合起来把"任何人在 API 上看见全部数据"和"换个模型要发版"两件事同时解决，而且都不碰数据模型。

## 8. 存储选型对比（会话）

| | A. jsonb | B. `ConversationStore` | C. `StepPersistence` |
|---|---|---|---|
| 还原对话 | ✅ | ✅ | ✅（快照可能被裁剪） |
| 跨设备 | ✅ | ✅ | ✅ |
| 并发写安全 | 需自己做 `revision` CAS | ✅ 内建 | ✅ |
| 编辑/重生成分叉 | 覆盖式，丢旧轮次 | ✅ branch/fork | ✅ |
| 崩溃恢复 | ❌ | ❌ | ✅ |
| 工具副作用审计 | ❌ | ❌ | ✅ |
| 依赖 | 无 | 核心 ABC，自己实现 | Harness 0.x |
| 推荐时机 | 现在 | 需要分叉 / 多人同改 | 需要"run 中断续跑" |

## 9. 需要拍板的决策

| # | 决策 | 选项 | 影响 |
|---|---|---|---|
| 1 | 身份来源 | 网关 header / 网关签名 / 内网直连 | 决定 P0 的信任模型 |
| 2 | 产品配置存哪 | TOML + 热加载 / DB + 管理界面 | 决定 P1 的实现量 |
| 3 | 依赖注入 | Dishka / 手写注册表 | 决定全局资源的生命周期写法 |
| 4 | 隔离粒度 | 单库多租户 / 每租户 schema | 后者运维成本高，通常不需要 |
| 5 | 文件存储 | 本地卷（NAS）/ S3 兼容 | 备份与水平扩展 |
| 6 | 会话深度 | A / B / C | 见 §8 |
| 7 | 前端缓存 | 保留为缓存 / 直接去掉 | 首屏与离线体验 |
| 8 | 数据访问层 | `asyncpg` + SQL / ORM | 后续所有表 |
| 9 | 转换是否异步 | 是 / 先不做 | 上传体验与并发上限 |

**v2 已定**：身份用网关 header；会话用 C（`StepPersistence`，零 SQL）；依赖注入先用 `AgentPool`，Dishka 作为后续迁移；文档留在文件系统，数据库不存文件；应用不手写 SQL，`asyncpg` 只作为框架的连接池。

## 10. 明确不做

- 应用内登录、注册、找回密码、MFA
- 自建用户表 / 角色表 / 细粒度 RBAC
- 企业级 SSO / SCIM / 目录同步
- 每用户独立数据库或独立部署
- 多区域、读写分离
- 向量检索 / RAG（与本次目标无关）

## 11. v2 实施状态（2026-11-08）

| 项 | 状态 | 落点 |
|---|---|---|
| 身份头 + 形状校验 | 完成 | `server/src/pychat/identity.py`、`main.py` |
| 按用户文档目录 | 完成 | `documents.py::DocumentStores` |
| 按用户 Agent、共享模型连接池 | 完成（等价最小实现） | `agent.py::AgentPool` |
| `GET /api/me` / `GET /api/models` | 完成 | `main.py` |
| 前端统一 HTTP 层 | 完成 | `frontend/src/lib/api.ts` |
| 前端身份与切换器 | 完成 | `lib/identity.ts`、`components/user-switcher.tsx` |
| 模型目录动态化 | 完成 | `Chat.tsx` 读 `/api/models` |
| 服务端会话历史 | 完成（StepPersistence + PostgresStepStore，零 SQL） | `persistence.py`、`main.py` |
| 会话恢复接口 | 完成 | `GET /api/conversations/{id}` |
| PG 文档元数据 | **不做**：文件与索引留在文件系统（铁律） | §3.4 |
| Dishka 装配 | 未做，先用 `AgentPool` 达到同样的三层生命周期 | 迁移时行为不变，见 §6 |
| 按用户列会话 | 完成（`list_runs()` + metadata 过滤，不写 SQL） | `persistence.py::list_conversations` |
| 前端自动化测试 | 未做，只有类型检查 + 手工验收 | 见 `docs/15` §6 |

验收方式：`uv run pytest -q`（26 passed）；`npm run typecheck`、`npm run lint`、`npm run build`；两个 `X-User-Id` 的文档列表互不可见；同一会话 id 用另一个用户读返回 404；`/api/models` 返回目录，选择 flash 后 Phoenix 出现 `chat mimo-v2.6-flash`；`/api/conversations` 在新浏览器里能列出会话；重启进程后历史仍在（PostgreSQL）。

## 12. 参考

**本仓库**

- `server/src/pychat/main.py` — 路由与生命周期
- `server/src/pychat/documents.py` — 按用户的 store 与上传
- `server/src/pychat/agent.py` — 共享模型与 `AgentPool`
- `server/src/pychat/persistence.py` — 会话快照的读取与用户前缀
- `server/src/pychat/config.py` — 部署配置（含 `[database]`）
- `server/src/pychat/identity.py` — `X-User-Id` 的读取与形状校验
- `frontend/src/lib/api.ts` — 唯一 HTTP 层
- `frontend/src/lib/identity.ts` — 测试用用户切换
- `frontend/src/lib/chat-db.ts` — IndexedDB 缓存
- `docs/15-frontend-refactor.md` — 前端改造的逐文件说明
- `docs/16-lessons.md` — 经验教训
- `docs/13-windows-deploy.md` — 当前部署形态

**上游文档**

- [Persistence](https://pydantic.dev/docs/ai/core-concepts/persistence/) — `Conversation` / `ConversationStore` / `StepPersistence` 的分工
- [Step Persistence](https://pydantic.dev/docs/ai/harness/step-persistence/) — `PostgresStepStore` 与表结构
- [UI Event Streams](https://pydantic.dev/docs/ai/integrations/ui/overview/) — "Keeping the history on the server" 与信任模型
- [Message History](https://pydantic.dev/docs/ai/core-concepts/message-history/) — 序列化边界与不可信历史
- [Dependencies](https://pydantic.dev/docs/ai/core-concepts/dependencies/) — 按用户注入运行依赖
- [Dishka](https://dishka.readthedocs.io/) — 作用域（APP / REQUEST）与 FastAPI 集成
