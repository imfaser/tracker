from __future__ import annotations

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from pychat import identity


def _request(**headers: str) -> Request:
    raw = [(name.lower().encode(), value.encode()) for name, value in headers.items()]
    return Request({"type": "http", "headers": raw})


def test_missing_header_falls_back_to_local(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PYCHAT_REQUIRE_IDENTITY", raising=False)
    assert identity.current_user(_request()) == identity.DEFAULT_USER


def test_missing_header_fails_closed_when_required(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYCHAT_REQUIRE_IDENTITY", "1")
    with pytest.raises(HTTPException) as excinfo:
        identity.current_user(_request())
    assert excinfo.value.status_code == 401


def test_valid_id_is_returned() -> None:
    assert identity.current_user(_request(**{"X-User-Id": "alice-01"})) == "alice-01"


@pytest.mark.parametrize("value", ["../etc", "a/b", "a b", "x" * 65, "用户"])
def test_invalid_id_is_rejected(value: str) -> None:
    with pytest.raises(HTTPException) as excinfo:
        identity.current_user(_request(**{"X-User-Id": value}))
    assert excinfo.value.status_code == 400
