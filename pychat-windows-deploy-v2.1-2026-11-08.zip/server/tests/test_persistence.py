from __future__ import annotations

from pychat.persistence import normalize_chat_id, scoped_conversation_id


def test_chat_ids_are_normalized_and_scoped_to_the_user() -> None:
    assert normalize_chat_id("/abc") == "abc"
    assert normalize_chat_id("abc") == "abc"
    assert scoped_conversation_id("alice", "/abc") == "alice:abc"
    assert scoped_conversation_id("bob", "abc") == "bob:abc"
