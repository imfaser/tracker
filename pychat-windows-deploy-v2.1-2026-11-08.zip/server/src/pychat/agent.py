"""Agent assembly: one model, one Code Mode capability, no tool zoo."""

from __future__ import annotations

from collections import OrderedDict
from collections.abc import Callable
from pathlib import Path

from pydantic_ai import Agent
from pydantic_ai.capabilities import Instrumentation
from pydantic_ai.models.instrumented import InstrumentationSettings
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.models.test import TestModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings
from pydantic_ai_harness import CodeMode, StepPersistence
from pydantic_monty import MountDir

from pychat.config import AgentConfig, ModelConfig
from pychat.documents import DocumentStore


def build_model(config: ModelConfig) -> OpenAIChatModel | TestModel:
    """Create the chat model. ``name = "test"`` enables the offline TestModel."""
    if config.name == "test":
        return TestModel()
    if not config.base_url or not config.api_key:
        raise RuntimeError('agent.model needs both base_url and api_key (or name = "test")')
    return OpenAIChatModel(
        config.name,
        provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
    )


def build_agent(
    config: AgentConfig,
    store: DocumentStore,
    work_dir: Path,
    *,
    model: OpenAIChatModel | TestModel | None = None,
    persistence: StepPersistence | None = None,
    instrument: bool = False,
) -> Agent:
    """Assemble the chat agent around a single read-only sandbox mount.

    ``model`` is shared across users: it owns the provider and its HTTP
    connection pool, so rebuilding it per user would leak a pool each time.
    """
    prompt = config.instructions_file.read_text(encoding="utf-8")

    def instructions() -> str:
        # The manifest is re-read per run so freshly uploaded files are visible
        # without restarting the process.
        return prompt.replace("{manifest}", store.manifest_text())

    model = model or build_model(config.model)
    settings = ModelSettings(
        temperature=config.model.temperature,
        max_tokens=config.model.max_tokens,
        timeout=config.model.timeout_s,
    )
    mount = MountDir(virtual_path="/work", host_path=str(work_dir), mode="read-only")
    capabilities = [CodeMode(mount=mount)]
    if instrument:
        capabilities.insert(0, Instrumentation(InstrumentationSettings(version=2)))
    if persistence is not None:
        capabilities.append(persistence)
    return Agent(
        model,
        model_settings=settings,
        instructions=instructions,
        capabilities=capabilities,
    )


class AgentPool:
    """One agent per user, sharing a single model.

    The model owns the connection pool, so it must not be rebuilt per user.
    The agent itself is cheap: instructions plus a sandbox mount. The bound
    keeps a long-lived process from accumulating one per visitor.
    """

    def __init__(self, build: Callable[[str], Agent], capacity: int = 16) -> None:
        self._build = build
        self._capacity = capacity
        self._agents: OrderedDict[str, Agent] = OrderedDict()

    def for_user(self, user: str) -> Agent:
        """Return the agent for ``user``, building it on first use."""
        agent = self._agents.get(user)
        if agent is not None:
            self._agents.move_to_end(user)
            return agent
        agent = self._build(user)
        self._agents[user] = agent
        if len(self._agents) > self._capacity:
            self._agents.popitem(last=False)
        return agent


class ModelRegistry:
    """Models from the catalog, built once and sharing providers.

    A provider owns an HTTP connection pool, so one is kept per (base_url,
    api_key) rather than per model: switching models reuses the same sockets.
    """

    def __init__(self, config: AgentConfig) -> None:
        self._default = config.model
        self._entries = {entry.name: entry for entry in config.all_models()}
        self._providers: dict[tuple[str, str], OpenAIProvider] = {}
        self._models: dict[str, OpenAIChatModel | TestModel] = {}

    @property
    def default_id(self) -> str:
        """The model used when a request does not name one."""
        return self._default.name

    def has(self, model_id: str | None) -> bool:
        """Whether ``model_id`` is in the catalog."""
        return bool(model_id) and model_id in self._entries

    def get(self, model_id: str | None) -> OpenAIChatModel | TestModel:
        """Return the model for ``model_id``, falling back to the default."""
        entry = self._entries.get(model_id or "") or self._default
        cached = self._models.get(entry.name)
        if cached is not None:
            return cached
        if entry.name == "test":
            model: OpenAIChatModel | TestModel = TestModel()
        else:
            if not entry.base_url or not entry.api_key:
                raise RuntimeError(
                    f'model "{entry.name}" needs both base_url and api_key (or name = "test")'
                )
            key = (entry.base_url, entry.api_key)
            provider = self._providers.get(key)
            if provider is None:
                provider = OpenAIProvider(base_url=entry.base_url, api_key=entry.api_key)
                self._providers[key] = provider
            model = OpenAIChatModel(entry.name, provider=provider)
        self._models[entry.name] = model
        return model

    def settings(self, model_id: str | None) -> ModelSettings:
        """Run settings for ``model_id``: its limits, not the default's."""
        entry = self._entries.get(model_id or "") or self._default
        return ModelSettings(
            temperature=entry.temperature,
            max_tokens=entry.max_tokens,
            timeout=entry.timeout_s,
        )
