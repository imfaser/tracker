"""Trusted identity asserted by the gateway.

This service does not authenticate anyone: the gateway in front of it does, and
passes the user along in a header. The value is only validated for shape here,
because it becomes both a directory name and a row key.

Set ``PYCHAT_REQUIRE_IDENTITY=1`` when a gateway is guaranteed to be in front,
so a missing header fails closed instead of falling back to the local user.
"""

from __future__ import annotations

import os
import re

from fastapi import HTTPException, Request, status

IDENTITY_HEADER = "X-User-Id"
DEFAULT_USER = "local"

# Hex-ish ids from the gateway, and simple names while testing. No slashes, no
# dots: the value is used as a path segment.
_USER_ID = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def require_identity() -> bool:
    """Whether a missing header is an error.

    Read at call time, not import time: ``server/.env`` is loaded by ``main``
    after this module is imported, and a native (no-Docker) deployment relies
    on that file for ``PYCHAT_REQUIRE_IDENTITY``.
    """
    return os.environ.get("PYCHAT_REQUIRE_IDENTITY", "").lower() in {"1", "true", "yes"}


def current_user(request: Request) -> str:
    """Return the asserted user id, or :data:`DEFAULT_USER` when absent.

    Raises:
        HTTPException: 401 when identity is required and missing, 400 when the
            value cannot be used safely as a key.
    """
    raw = request.headers.get(IDENTITY_HEADER, "").strip()
    if not raw:
        if require_identity():
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing user identity")
        return DEFAULT_USER
    if not _USER_ID.fullmatch(raw):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "invalid user identity")
    return raw
