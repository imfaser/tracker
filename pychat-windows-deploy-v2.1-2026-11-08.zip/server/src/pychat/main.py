"""FastAPI entry point: chat stream, document upload, and the built SPA."""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

import asyncpg
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic_ai import Agent
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from pydantic_ai_harness import StepPersistence
from pydantic_ai_harness.step_persistence import InMemoryStepStore, PostgresStepStore
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import Request
from starlette.responses import Response

from pychat.agent import AgentPool, ModelRegistry, build_agent
from pychat.config import ROOT, load_config
from pychat.docling import DoclingConverter
from pychat.documents import DocumentStores
from pychat.identity import DEFAULT_USER, current_user
from pychat.observability import setup_observability, shutdown_observability
from pychat.persistence import (
    list_conversations,
    load_history,
    normalize_chat_id,
    scoped_conversation_id,
)

load_dotenv(ROOT / ".env")

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("pychat")

config = load_config()
stores = DocumentStores(config.server.data_dir, DEFAULT_USER)
converter = DoclingConverter(config.docling)

FRONTEND_DIST = Path(os.environ.get("PYCHAT_FRONTEND_DIST", ROOT.parent / "frontend" / "dist"))


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Own tracing, the model, and the conversation store for the process."""
    provider = setup_observability(config.observability)
    app.state.observability = provider

    # Conversation history only. Documents stay on disk; the database never
    # holds file bytes. PostgresStepStore creates its own schema on first use.
    if config.database.dsn:
        pool = await asyncpg.create_pool(
            dsn=config.database.dsn,
            min_size=config.database.pool_min,
            max_size=config.database.pool_max,
        )
        step_store = PostgresStepStore(pool, table="pychat")
        await step_store.list_runs(conversation_id="startup-probe")
        log.info("conversation history: postgres")
    else:
        pool = None
        step_store = InMemoryStepStore()
        log.info("conversation history: in-memory (no database.dsn)")

    app.state.pool = pool
    app.state.step_store = step_store

    # One model per catalog entry, sharing a provider per endpoint. Both the
    # models and their connection pools outlive requests.
    registry = ModelRegistry(config.agent)
    app.state.models = registry
    model = registry.get(registry.default_id)

    def build_for_user(user: str) -> Agent:
        user_store = stores.for_user(user)
        persistence = StepPersistence(
            store=step_store,
            agent_name="pychat",
            metadata={"user_id": user},
        )
        return build_agent(
            config.agent,
            user_store,
            user_store.work_dir,
            model=model,
            persistence=persistence,
            instrument=config.observability.enabled,
        )

    app.state.agents = AgentPool(build_for_user)
    await converter.start()
    try:
        yield
    finally:
        await converter.stop()
        if pool is not None:
            await pool.close()
        shutdown_observability(provider)


app = FastAPI(
    title="pychat",
    lifespan=lifespan,
    # FastAPI 0.162 instruments requests with the global OTel provider by
    # default. That would nest every agent/tool span under a POST /api/chat
    # request span and add operation spans Phoenix does not need, so the only
    # spans we emit are the ones Pydantic AI creates.
    telemetry={
        "tracing": False,
        "metrics": False,
        "logs": False,
        "operation_spans": False,
        "auto_configure": False,
    },
)

if config.server.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.server.cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )


@app.get("/api/health")
async def health() -> dict:
    """Liveness plus the two facts that explain most broken deployments."""
    return {
        "ok": True,
        "model": config.agent.model.name,
        "docling": converter.ready,
        "tracing": config.observability.enabled,
        "documents": len(stores.for_user(DEFAULT_USER).list()),
        "history": "postgres" if config.database.dsn else "memory",
    }


@app.post("/api/chat")
async def chat(request: Request, user: str = Depends(current_user)) -> Response:
    """Stream one turn, continuing the history stored for this user."""
    if request.headers.get("content-type", "").split(";")[0].strip().lower() != "application/json":
        raise HTTPException(status_code=415, detail="expected application/json")

    body = await request.body()
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="invalid json") from exc
    model_id = payload.get("model") if isinstance(payload, dict) else None
    registry = request.app.state.models
    if model_id and not registry.has(model_id):
        raise HTTPException(status_code=400, detail="unknown model")

    adapter = VercelAIAdapter(
        request.app.state.agents.for_user(user),
        VercelAIAdapter.build_run_input(body),
        accept=request.headers.get("accept") or "text/event-stream",
        sdk_version=7,
        manage_message_history="server",
    )
    chat_id = adapter.conversation_id
    conversation_id = scoped_conversation_id(user, chat_id) if chat_id else None
    history = (
        await load_history(request.app.state.step_store, conversation_id)
        if conversation_id
        else None
    )
    return adapter.streaming_response(
        adapter.run_stream(
            message_history=history,
            conversation_id=conversation_id,
            model=registry.get(model_id),
            model_settings=registry.settings(model_id),
        )
    )


@app.get("/api/conversations")
async def conversation_list(request: Request, user: str = Depends(current_user)) -> dict:
    """The caller's conversations, newest first."""
    return {"conversations": await list_conversations(request.app.state.step_store, user)}


@app.get("/api/conversations/{chat_id}")
async def get_conversation(
    chat_id: str,
    request: Request,
    user: str = Depends(current_user),
) -> dict:
    """Return a stored conversation as UI messages, scoped to the caller."""
    history = await load_history(
        request.app.state.step_store,
        scoped_conversation_id(user, chat_id),
    )
    if not history:
        raise HTTPException(status_code=404, detail="unknown conversation")
    return {
        "id": normalize_chat_id(chat_id),
        "messages": VercelAIAdapter.dump_messages(history, sdk_version=7),
    }


@app.get("/api/me")
async def me(user: str = Depends(current_user)) -> dict:
    """The identity this request runs as, as asserted by the gateway."""
    return {"user_id": user, "default_model": config.agent.model.name}


@app.get("/api/models")
async def list_models() -> dict:
    """The model catalog, in the shape the frontend already understands.

    Kept compatible with the upstream ``RemoteConfig`` contract: the UI picks a
    model id from here and never learns the endpoint, key, or base URL.
    """
    return {
        "models": [
            {"id": entry.name, "name": entry.name, "builtinTools": []}
            for entry in config.agent.all_models()
        ],
        "builtinTools": [],
    }


@app.get("/api/documents")
async def list_documents(user: str = Depends(current_user)) -> dict:
    """List the caller's documents, newest first."""
    return {"documents": [entry.model_dump() for entry in stores.for_user(user).list()]}


@app.post("/api/documents")
async def upload_document(
    file: Annotated[UploadFile, File()],
    user: str = Depends(current_user),
) -> dict:
    """Store an upload and convert it through docling-serve."""
    try:
        entry = await stores.for_user(user).ingest(file, converter)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return entry.model_dump()


@app.post("/api/documents/{doc_id}/reconvert")
async def reconvert_document(doc_id: str, user: str = Depends(current_user)) -> dict:
    """Retry a failed conversion without re-uploading the file."""
    try:
        entry = await stores.for_user(user).reconvert(doc_id, converter)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="unknown document") from exc
    return entry.model_dump()


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str, user: str = Depends(current_user)) -> dict:
    """Delete the registry entry and every derived file."""
    try:
        await stores.for_user(user).delete(doc_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="unknown document") from exc
    return {"ok": True}


@app.get("/api/documents/{doc_id}/raw")
async def raw_document(doc_id: str, user: str = Depends(current_user)) -> FileResponse:
    """Download the original upload."""
    path = stores.for_user(user).raw_path(doc_id)
    if path is None:
        raise HTTPException(status_code=404, detail="unknown document")
    return FileResponse(path, filename=path.name)


class SPAStaticFiles(StaticFiles):
    """Static files with an SPA fallback, so client routes survive a refresh."""

    async def get_response(self, path: str, scope) -> Response:  # noqa: ANN001
        """Serve the file, or ``index.html`` for unmatched client-side routes."""
        try:
            return await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            if exc.status_code != 404:
                raise
            return await super().get_response("index.html", scope)


@app.middleware("http")
async def cache_headers(request: Request, call_next) -> Response:  # noqa: ANN001
    """Long-cache hashed assets, never cache the HTML shell."""
    response = await call_next(request)
    if request.url.path.startswith("/assets/"):
        response.headers["cache-control"] = "public, max-age=31536000, immutable"
    elif response.headers.get("content-type", "").startswith("text/html"):
        response.headers["cache-control"] = "no-cache"
    return response


if FRONTEND_DIST.is_dir():
    app.mount("/", SPAStaticFiles(directory=str(FRONTEND_DIST), html=True), name="spa")
else:
    log.warning("frontend dist not found at %s; serving API only", FRONTEND_DIST)
