"""Conversation history, stored by the harness's own step store.

No schema is defined here on purpose: ``PostgresStepStore`` creates its tables
on first use. Documents never enter the database; only message history does.
"""

from __future__ import annotations

from collections.abc import Sequence

from pydantic_ai.messages import ModelMessage, UserPromptPart
from pydantic_ai_harness.step_persistence import StepStore

SEPARATOR = ":"


def normalize_chat_id(value: str) -> str:
    """The frontend keeps a leading slash on the chat id; storage does not."""
    return value.lstrip("/")


def scoped_conversation_id(user: str, conversation_id: str) -> str:
    """Namespace a chat id by user so a guessed id cannot read another history."""
    return f"{user}{SEPARATOR}{normalize_chat_id(conversation_id)}"


async def load_history(store: StepStore, conversation_id: str) -> list[ModelMessage] | None:
    """Return the newest complete snapshot's messages, or ``None``.

    Runs are ordered oldest first; the newest snapshot that reached a settled
    boundary is what the next turn continues from.
    """
    runs = await store.list_runs(conversation_id=conversation_id)
    for run in reversed(runs):
        snapshot = await store.latest_snapshot(run_id=run.run_id)
        if snapshot is not None:
            return snapshot.messages
    return None


def conversation_title(messages: Sequence[ModelMessage]) -> str | None:
    """The first user prompt, flattened to one line; enough for a sidebar."""
    for message in messages:
        for part in message.parts:
            if isinstance(part, UserPromptPart):
                content = part.content
                text = (
                    content if isinstance(content, str) else " ".join(str(item) for item in content)
                )
                text = " ".join(text.split())
                if text:
                    return text[:60]
    return None


async def list_conversations(
    store: StepStore,
    user: str,
    *,
    limit: int = 50,
) -> list[dict[str, object]]:
    """Summarise this user's conversations, newest first.

    ``StepStore`` can only filter by ``conversation_id``, so this reads the run
    records and filters on the user metadata the capability records. Fine at
    v2 scale; a dedicated index is the next step when the table grows.
    """
    runs = await store.list_runs()
    mine = [run for run in runs if (run.metadata or {}).get("user_id") == user]
    mine.sort(key=lambda run: run.started_at, reverse=True)

    prefix = f"{user}{SEPARATOR}"
    seen: set[str] = set()
    items: list[dict[str, object]] = []
    for run in mine:
        scoped = run.conversation_id or ""
        if not scoped.startswith(prefix):
            continue
        chat_id = scoped[len(prefix) :]
        if not chat_id or chat_id in seen:
            continue
        seen.add(chat_id)
        snapshot = await store.latest_snapshot(run_id=run.run_id)
        messages = snapshot.messages if snapshot is not None else []
        items.append(
            {
                "id": chat_id,
                "title": conversation_title(messages),
                "message_count": len(messages),
                "updated_at": run.started_at.isoformat(),
            }
        )
        if len(items) >= limit:
            break
    return items
