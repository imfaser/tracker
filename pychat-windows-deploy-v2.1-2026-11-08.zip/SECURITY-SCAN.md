# 敏感信息扫描报告（v2.1）

- 日期：2026-11-08
- 工具：gitleaks 8.30.1（`gitleaks dir`，默认规则集）
- 源码树：约 1.33 MB，排除 `.git`、`.codegraph`、`.openchamber`、`node_modules`、`.venv`、`data`、`dist`、缓存目录
- 结果：**0 条命中**

## 补充扫描

对整个 `server/` 目录（含 `.venv`，约 76 MB）扫描命中 2 条，均为第三方库里的占位字符串，不是项目密钥：

- `server/.venv/Lib/site-packages/google/protobuf/descriptor_pb2.py`
- `server/.venv/Lib/site-packages/openai/_client.py`

## 凭据核对

- `server/.env` 未打包；当前内容为空的 `MIMO_API_KEY=`。
- NAS 的 `/vol2/1000/app/pychat/.env`（权限 600）不在本包内。
- 数据库连接串只存在于 NAS `.env`；源码、文档和本压缩包中均无。
- 对源码副本和 Git 跟踪文件做了明文核对，未发现数据库密码。

## 包内排除

`.env`、`data/`、`node_modules/`、`.venv/`、`dist/`、`.git/`、`.codegraph/`、`.openchamber/`、`__pycache__`、`.pytest_cache`、`.ruff_cache`。

## 建议

数据库密码与模型 key 都曾在聊天/终端里出现过。建议：

1. 在模型服务商后台轮换 `MIMO_API_KEY`。
2. 轮换 PostgreSQL 角色密码。
3. 更新 NAS 的 `/vol2/1000/app/pychat/.env` 后 `docker restart pychat`。

## 复现

```powershell
$stage = "$env:TEMP\pychat-scan"
robocopy . $stage /MIR /XD .git .codegraph .openchamber node_modules .venv __pycache__ .pytest_cache .ruff_cache dist data /XF .env server\.env
gitleaks dir $stage --redact --no-banner
```
