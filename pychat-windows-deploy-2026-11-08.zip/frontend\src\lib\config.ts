import { z } from 'zod'

import type { BuiltinTool, ModelConfig } from '@/types'

export interface StartupConfig {
  basePath?: string
  apiPath?: string
}

export interface ResolvedStartupConfig {
  readonly basePath: string
  readonly apiPath: string
}

export interface RemoteConfig {
  models: ModelConfig[]
  builtinTools: BuiltinTool[]
}

const PATH_ORIGIN = 'https://pydantic-ai-chat.invalid'

/** Normalize a same-origin directory path for safe suffix concatenation. */
export function normalizeDirectoryPath(path: string, name: string): string {
  const url = new URL(path, PATH_ORIGIN)
  if (url.origin !== PATH_ORIGIN || url.search || url.hash) {
    throw new TypeError(`${name} must be a same-origin path without a query or fragment`)
  }
  return url.pathname.endsWith('/') ? url.pathname : `${url.pathname}/`
}

function defaultBasePath(viteBase: string): string {
  const url = new URL(viteBase || '/', PATH_ORIGIN)
  return url.origin === PATH_ORIGIN ? normalizeDirectoryPath(url.pathname, 'Vite base') : '/'
}

const startupConfigSchema = z
  .object(
    {
      basePath: z.string({ error: 'PYDANTIC_AI_CHAT_CONFIG.basePath must be a string' }).optional(),
      apiPath: z.string({ error: 'PYDANTIC_AI_CHAT_CONFIG.apiPath must be a string' }).optional(),
    },
    { error: 'PYDANTIC_AI_CHAT_CONFIG must be an object' },
  )
  .optional()

export function resolveStartupConfig(
  config: unknown = typeof window === 'undefined' ? undefined : window.PYDANTIC_AI_CHAT_CONFIG,
  viteBase: string = import.meta.env.BASE_URL,
): ResolvedStartupConfig {
  const parsedConfig = startupConfigSchema.safeParse(config)
  if (!parsedConfig.success) {
    throw new TypeError(parsedConfig.error.issues[0].message)
  }
  const { basePath, apiPath } = parsedConfig.data ?? {}
  return Object.freeze({
    basePath: basePath === undefined ? defaultBasePath(viteBase) : normalizeDirectoryPath(basePath, 'basePath'),
    apiPath: apiPath === undefined ? '/api/' : normalizeDirectoryPath(apiPath, 'apiPath'),
  })
}

export const startupConfig = resolveStartupConfig()

const remoteConfigSchema = z.looseObject({
  models: z.array(
    z.looseObject({
      id: z.string(),
      name: z.string(),
      builtinTools: z.array(z.string()),
    }),
  ),
  builtinTools: z.array(z.looseObject({ id: z.string(), name: z.string() })),
})

export function parseRemoteConfig(value: unknown): RemoteConfig {
  const parsedConfig = remoteConfigSchema.safeParse(value)
  if (!parsedConfig.success) {
    throw new Error('Configuration response did not contain models and builtin tools')
  }
  return parsedConfig.data
}

/**
 * The models this deployment offers.
 *
 * pychat runs one configured model behind `/api/chat`, and the server exposes
 * no `/api/configure` endpoint, so the list is fixed here instead of fetched.
 * The id is informational: the server decides which model to run.
 */
const LOCAL_CONFIG: RemoteConfig = {
  models: [{ id: 'mimo-v2.6-pro', name: 'mimo-v2.6-pro', builtinTools: [] }],
  builtinTools: [],
}

export async function fetchConfig(): Promise<RemoteConfig> {
  return LOCAL_CONFIG
}
