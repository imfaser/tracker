"""Agent assembly: one model, one Code Mode capability, no tool zoo."""

from __future__ import annotations

from pathlib import Path

from pydantic_ai import Agent
from pydantic_ai.capabilities import Instrumentation
from pydantic_ai.models.instrumented import InstrumentationSettings
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.models.test import TestModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings
from pydantic_ai_harness import CodeMode
from pydantic_monty import MountDir

from pychat.config import AgentConfig, ModelConfig
from pychat.documents import DocumentStore


def build_model(config: ModelConfig) -> OpenAIChatModel | TestModel:
    """Create the chat model. ``name = "test"`` enables the offline TestModel."""
    if config.name == "test":
        return TestModel()
    if not config.base_url or not config.api_key:
        raise RuntimeError('agent.model needs both base_url and api_key (or name = "test")')
    return OpenAIChatModel(
        config.name,
        provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
    )


def build_agent(
    config: AgentConfig,
    store: DocumentStore,
    work_dir: Path,
    *,
    instrument: bool = False,
) -> Agent:
    """Assemble the chat agent around a single read-only sandbox mount."""
    prompt = config.instructions_file.read_text(encoding="utf-8")

    def instructions() -> str:
        # The manifest is re-read per run so freshly uploaded files are visible
        # without restarting the process.
        return prompt.replace("{manifest}", store.manifest_text())

    model = build_model(config.model)
    settings = ModelSettings(
        temperature=config.model.temperature,
        max_tokens=config.model.max_tokens,
        timeout=config.model.timeout_s,
    )
    mount = MountDir(virtual_path="/work", host_path=str(work_dir), mode="read-only")
    capabilities = [CodeMode(mount=mount)]
    if instrument:
        capabilities.insert(0, Instrumentation(InstrumentationSettings(version=2)))
    return Agent(
        model,
        model_settings=settings,
        instructions=instructions,
        capabilities=capabilities,
    )
