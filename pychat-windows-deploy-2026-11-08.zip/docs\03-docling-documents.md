# 03 · Docling：Excel / Word 解析

**这一篇是全项目最需要被审查的部分**，因为"解析 Excel"听起来简单，实际有三个不同的问题被混在一起：读版面、读数据、读公式。

## 1. 线上实例的真实配置

对着 `http://192.168.16.24:6029` 实测（不是文档抄的）：

```json
{"docling-serve":"1.38.1","docling":"2.142.1","docling-jobkit":"3.9.1",
 "docling-core":"2.104.0","docling-ibm-models":"4.0.4","docling-parse":"7.23.0",
 "python":"cpython-312 (3.12.15)"}
```

`GET /v1/capabilities` 的关键项：

| 项 | 值 | 说明 |
|---|---|---|
| `features.api_key_required` | `false` | 内网裸奔，无鉴权 |
| `limits.max_document_timeout` | `604800` | 7 天，够 |
| `limits.max_sources_per_request` | `3` | 批量最多 3 个源 |
| `limits.max_file_size` | `null` | **未限制**，上传层要自己兜底 |
| `limits.max_num_pages` | `null` | 同上 |
| `targets.default` | `inbody` | 结果直接返回 JSON body（不是给下载链接） |
| `output_formats` | `md, json, yaml, html, html_split_page, text, doctags, vtt, doclang, dclx, chunks, latex` | |

### 端点

| 端点 | 用途 |
|---|---|
| `POST /v1/convert/file` · `/async` | 上传文件（multipart） |
| `POST /v1/convert/source` · `/async` | 按 URL / 对象存储地址转 |
| `POST /v1/convert/source/batch` | 批量（≤3） |
| `GET /v1/status/poll/{task_id}` | 轮询 `task_status` |
| `GET /v1/result/{task_id}` | 取结果 |
| `POST /v1/chunk/{hybrid,hierarchical}/{file,source}` | 分块（同步/异步） |
| `GET /v1/health` `ready` `version` `capabilities` | 探活 |

`/v1/result/{task_id}` 的响应结构（实测）：

```
{ document: { filename, md_content, json_content, html_content,
              text_content, doctags_content, doclang_content },
  status, errors, processing_time, timings, confidence }
```

注意：`timings` 在这个版本是空对象，别指望它做性能分析。

### 输入格式（`from_formats` 默认全集）

`docx, doc, rtf, pptx, ppt, html, mhtml, image, pdf, asciidoc, md, csv, xlsx, xls,
odt, ods, odp, xml_uspto, xml_jats, xml_xbrl, xml_doclang, dclx, mets_gbs,
json_docling, audio, video, vtt, latex, email, epub, boxnote, iwork_pages,
iwork_keynote, iwork_numbers, ebcdic, afp`

对我们有用的：**`docx` / `xlsx` 原生支持**；`doc` / `xls` / `rtf` 属于"legacy binary Office"，官方支持格式页写的是 **requires LibreOffice**——这个 `docling-serve-cpu` 镜像里有没有装 LibreOffice，**没有验证过**（见第 8 节验证清单）。

## 2. Excel 实测（重点）

我造了一个 5.9 KB 的测试文件：3 个区（标题合并单元格 A1:E1、表头、3 行数据、1 行注释），2 个 sheet（`汇总` / `明细`），且 `合计` 列是 `=SUM(...)` 公式。

请求：`to_formats=["md","json"]`, `do_ocr=false`, `table_mode=accurate`。
**耗时 0.75 秒**，`status: success`。

### markdown 输出（原文照抄）

```markdown
2026 年差旅预算执行表

| 部门   |     Q1 |     Q2 |     Q3 | 合计   |
|--------|--------|--------|--------|--------|
| 销售   | 120000 |  98000 | 143000 |        |
| 研发   |  45000 |  52000 |  61000 |        |
| 市场   |  88000 | 132000 |  76000 |        |

| 注：Q3 含 9 月临时差旅追加 20%。   |
|------------------------------------|

| 日期       | 项目           |   金额 | 备注     |
|------------|----------------|--------|----------|
| 2026-07-03 | 上海-北京 高铁 | 1253.5 | 客户拜访 |
| 2026-08-11 | 深圳 酒店 3 晚 |   2880 |          |
| 2026-09-02 | 成都 机票      |   1980 | 临时追加 |
```

### 结论（四条，都很硬）

1. **sheet 名在 markdown 里丢失**。`汇总` 和 `明细` 糊成一张连续文档，没有任何分隔标记。多 sheet 的表格一旦被这样喂给模型，模型无法回答"A 表里的 X"这类问题。
2. **公式丢失**。`合计` 列是空的。注意：我的测试文件是 openpyxl 写的、不带缓存值，所以**这不能证明 Docling 忽略 Excel 的 cached value**——真实 Excel 存的文件带缓存结果，需要拿真实业务文件复测。
3. **合并单元格的标题保留成了标题**（`2026 年差旅预算执行表`），这点是好的。
4. **单行注释被识别成 1 列 1 行的表**，脏数据。对 LLM 来说这是噪声。

### JSON 输出（同一个响应）

```json
"groups": [
  {"name":"汇总","label":"sheet","children":[{"$ref":"#/texts/0"},{"$ref":"#/tables/0"},{"$ref":"#/tables/1"}]},
  {"name":"明细","label":"sheet","children":[{"$ref":"#/tables/2"}]}
]
"tables": [ { "data": { "table_cells": [
   {"text":"部门","column_header":true,"start_row_offset_idx":0,"end_row_offset_idx":1,
    "start_col_offset_idx":0,"end_col_offset_idx":1,"row_span":1,"col_span":1}, ... ] } } ]
```

**这是关键发现：sheet 结构在 `json` 里是完整的**——`groups[].name` 就是 sheet 名，`label: "sheet"`；每个 sheet 的 `children` 指向它自己的 table。`table_cells` 甚至带了 `row_span` / `col_span` / 行列索引。

### 所以正确的 Excel 姿势

```
上传 xlsx
  ├─ 数值问答（"Q3 多少"）      → openpyxl 直读（sheet 名 + 公式缓存值都在）
  ├─ 版面/结构（"这表长什么样"） → Docling MCP → markdown
  └─ 需要 sheet 分组的结构化数据 → 只有 json 里有（groups[].name）
                                  走 MCP 拿不到，见下
```

⚠️ **一个必须知道的落差**：`json_content` 只在直连 REST（`to_formats=["json"]`）或用 `save_docling_document` 落盘时才拿得到。docling-mcp 暴露的是 `export_docling_document_to_markdown` 和 anchor 级读取，**没有"导出 json"这个工具**。而 anchor 视角是扁平的：

```
[anchor:#/texts/0] text
[anchor:#/tables/0] table
[anchor:#/tables/1] table
[anchor:#/tables/2] table
```

—— 没有 sheet 名。这就是为什么 Excel 的数值问答不该走 Docling：不是它慢，是这条路本来就不带那个信息。

## 3. Excel：不写解析器，给模型"传输 + 沙箱"

**分场景，别一刀切。**

| 用户想干什么 | 走哪条 | 理由 |
|---|---|---|
| "这张表里 Q3 差旅多少" | Docling 的 **JSON**（传输工具递进沙箱，模型自己读） | sheet 名、合并区域、cell 矩阵都在 JSON 里；不写任何格式分支 |
| "把这个 Excel 转成一份报告/网页" | Docling `md` | 版面和表格结构已经做好了 |
| "这是扫描件/PDF 里的表格" | Docling + `table_mode=accurate` | 只有它能做版面分析 |

### 3.1 先把两个事实钉死

**事实一：Docling 的 JSON 里有 sheet 名。** 同一个文件转 `json`，`groups` 是：

```
name=汇总 label=sheet
name=明细 label=sheet
```

`tables[0].data.table_cells` 还带 `start_row_offset_idx` / `start_col_offset_idx` / `row_span` / `col_span` 和每个 cell 的 `text`。**这是 markdown 里丢掉的、而我们唯一需要的东西。**

**事实二：Monty 沙箱不能 import 第三方库，也没有 `zipfile`。**

官方允许的 stdlib 只有：`sys, typing, asyncio, math, json, re, unicodedata, datetime, time, random, os, pathlib, collections, itertools, functools, dataclasses, copy, base64, binascii, bisect, csv, decimal, hashlib, os.path, tomllib`。

xlsx 是个 zip 包着的 XML。没有 `zipfile`、没有 `openpyxl`，模型**自己打不开它**。

所以"完全不给代码"只在这两种情况下成立：

1. 我们只处理 docx/pdf（Docling 的 markdown 够用）；
2. 或者把 docling-mcp 的 `_cache`（`save_docling_document` 会把 JSON 写进去）挂进沙箱——实测这个目录在 `site-packages/_cache`，**跟着版本走**，在容器里路径不稳定。

这两条都不够好。所以收敛成第三条：**一条 12 行的传输工具，不做任何格式判断。**

### 3.2 唯一的自写代码：把 JSON 递进去

```python
# src/pychat/tools.py
import json
from pathlib import Path

import httpx


async def document_structure(path: str) -> dict:
    """Return Docling's structured JSON for a document.

    No format branching: Docling decides how to parse xlsx/docx/pdf/pptx.
    For spreadsheets, sheet names are in ``groups`` where ``label == "sheet"``.

    Args:
        path: File on this server, e.g. ``/data/uploads/9f3a1c.xlsx``.

    Returns:
        The DoclingDocument as a dict.
    """
    async with httpx.AsyncClient(base_url=DOCLING_URL, timeout=600) as client:
        with open(path, "rb") as fh:
            resp = await client.post(
                "/v1/convert/file",
                files={"files": (Path(path).name, fh)},
                data={"to_formats": "json"},
            )
        resp.raise_for_status()
        return json.loads(resp.json()["document"]["json_content"])
```

注意它**没有**任何 `if suffix == ".xlsx"`。它不知道也不关心文件是什么格式——Docling 知道。

模型在 `run_code` 里：

```python
doc = await document_structure('/data/uploads/9f3a1c.xlsx')

sheets = {g['name']: g for g in doc['groups'] if g['label'] == 'sheet'}
summary = sheets['汇总']
# summary['children'] 里挑 table，再按 row/col 索引取数
{'sheets': list(sheets), 'tables': len(doc['tables'])}
```

**这才是"让模型自己调用"的正确形态**：我们不告诉它"Excel 有几张表、表头在哪、公式怎么算"，只把结构化数据交给它，它用 `json`/`pathlib`/`decimal` 自己探索。

### 3.3 所以删掉了什么

| 删掉 | 为什么 |
|---|---|
| `ingest/excel.py` 那 80 行 | 一个扩展名枚举 + 两个 openpyxl 分支，只覆盖我能想到的情况 |
| `openpyxl` 依赖 | 不再需要：格式解析归 Docling |
| `list_sheets` / `read_sheet` / `list_uploaded_files` 三个工具 | 粒度是设计者定的，不是模型定的 |
| `ingest/dispatch.py` 的格式分派 | 路由只剩"保存文件"，四行 |

现在"上传"这件事的全部服务端逻辑是：

```python
@app.post("/api/files")
async def upload(file: UploadFile) -> dict:
    doc_id = uuid4().hex[:12]
    dest = settings.data_dir / "uploads" / f"{doc_id}{Path(file.filename or '').suffix}"
    dest.write_bytes(await file.read())
    return {"document_id": doc_id, "path": str(dest), "name": file.filename}
```

十几行，没有格式知识。**能穷举的只有这件事；格式的无穷可能交给 Docling + 模型。**

### 3.4 代价

| 代价 | 说明 |
|---|---|
| 大文档的 JSON 可能几十 MB | 它进的是沙箱，不是上下文（`run_code` 只 `return` 需要的片段），但内存要留够 |
| `/v1/convert/file` 是同步接口 | 超大 PDF 会占住连接；给 600s 超时，必要时换 async + 轮询 |
| 模型要学会读 DoclingDocument | 所以 `pychat-dev` skill 里要写清 `groups` / `tables` 的结构（见 10 §3） |

这比"我写 80 行解析器"的代价低：解析器只覆盖我想到的格式，而模型 + Docling 覆盖的是 Docling 支持的全集（PDF、DOCX、XLSX、PPTX、HTML、图片、音频……）。


## 4. Word（docx）

docx 是 Docling 的舒适区，直接 `md` 就很好。要注意的只有三件：

1. **表格**：`table_mode=accurate`（默认）用 TableFormer；复杂表格建议加 `table_structure_preset=tableformer_v2`。
2. **图片**：`include_images=true`（默认）但 `image_export_mode=placeholder` 只留 `<!-- image -->` 占位。要真图就设 `embedded`（base64，会让响应体暴涨）或 `referenced`。
3. **页眉页脚/注释**：会作为 furniture 处理，markdown 里一般看不到——如果需要，读 `json` 的 `furniture` 字段。

## 5. 扫描件与中文 OCR

`/v1/capabilities` 里可选的 OCR preset：`auto`（默认）、`easyocr`、`rapidocr`、`tesserocr`、`tesseract`、`ocrmac`、`nemotron-ocr`、`kserve_v2_ocr`。

中文场景建议：

```python
form["ocr_preset"] = "rapidocr"          # 对中文/表格更稳，CPU 友好
form["ocr_lang"] = ["iso:zh", "iso:en"]  # iso: 前缀是 docling 自己的语言码，跨引擎通用
```

`iso:` 前缀是 docling ≥2.127 的写法，比直接给 `chi_sim`/`en` 更安全（后者是引擎特定的）。这个实例是 2.142，支持。

## 6. 给 RAG 用的分块

Docling 自带两种分块：

| 端点 | 策略 |
|---|---|
| `/v1/chunk/hybrid/file` | 混合（结构感知 + 定长），最常用 |
| `/v1/chunk/hierarchical/file` | 按标题层级 |

**现在不做。** 我们没有向量库，也不打算在 MVP 引入。真到"文档多到装不进上下文"那天，再走这条路：

```
上传 → docling 转 md → chunk(hybrid) → embedding → 向量库
问答 → 检索 top-k → 只把命中的 chunk 塞进 prompt
```

在那之前，`CodeMode` + `mount` 已经够用：模型自己按需读 CSV / 按 anchor 取片段，不依赖检索。

## 7. docling-mcp：钉 3.3.0 的理由，以及它现在装在哪

### 装在哪

- **开发期（已装）**：`D:\workspace\dev\pychat\opencode.jsonc` 的 `mcp.servers.docling`，我这边已经能调 21 个 `docling` 工具。它跟产品运行时无关，纯给 agent 查资料/转网页用。
- **产品运行时（待接）**：**只有一种**——`MCPToolset` 挂给 agent，再用 `CodeMode` 包起来。不要写 REST 客户端，理由和三种调用方式见 [02 §4](./02-backend-pydantic-ai.md#4-mcpdocling-只有这一条入口)。

### 为什么钉 3.3.0 而不是最新 3.5.0

PyPI 上 `docling-mcp` 已经是 3.5.0，但你给的配置是 3.3.0，我保持了原样并写进注释。理由：

- 3.0+ 要求 **MCP Python SDK v2**（`mcp>=2.0.0`），3.3.0 正好跨过这个断点；
- 3.3.0 的 21 个工具是"conversion / generation / manipulation"三组，接口稳定；
- 升级 3.4/3.5 前先看 `MIGRATION.md`，它们动过工具签名。

**真要升的时候**：改 `uvx --from=docling-mcp==3.5.0` 一行，然后重跑一次 `convert_document_into_docling_document` 冒烟。

### 21 个工具里真正有用的只有 6 个

`convert_document_into_docling_document`、`export_docling_document_to_markdown`、
`get_overview_of_document_anchors`、`search_for_text_in_document_anchors`、
`get_text_of_document_item_at_anchor`、`list_cached_documents`。

剩下 8 个是"往缓存文档里加段落/标题/列表/表格"的**编辑型**工具，对我们没用。如果产品里要挂 MCP，一定用 `--tools conversion` 只加载转换组，否则 21 个工具白占上下文。

## 8. 验证清单（部署前必须打勾）

```bash
# 1. 服务活着
curl -s http://192.168.16.24:6029/health

# 2. legacy Office 到底能不能转（关键！）
#    拿一个 .doc 和一个 .xls 上传，看 status 是否 success
#    失败且 errors 里提到 libreoffice/soffice => 镜像没装，需要在
#    docling-serve 侧加装，或产品里直接拒绝 legacy 格式

# 3. 真实业务 Excel 的公式缓存值
#    Excel 另存的 xlsx（带公式结果）→ 转 json → 看 "合计" 那个 cell 的 text 是否为空

# 4. 中文扫描件 OCR
#    一张中文发票/合同扫描图，ocr_preset=rapidocr, ocr_lang=["iso:zh","iso:en"]

# 5. 大文件
#    10MB 的 PDF，测实际耗时；同时确认上传层有没有自己的体积上限

# 6. 并发
#    同时打 3 个转换请求，看 GPU/CPU 队列会不会把彼此拖死
#    （docling-serve-cpu，24 核，但模型推理是单实例的）
```

第 2 条和第 3 条会直接影响产品能不能宣称"支持 Word/Excel 全格式"，别跳过。

## 9. 还没确认的事

| 问题 | 影响 | 怎么确认 |
|---|---|---|
| `docling-serve-cpu` 镜像是否含 LibreOffice | `.doc`/`.xls`/`.rtf` 能不能转 | 上传一个 `.doc` 试 |
| Excel 公式是否有 cached value 可读 | 能不能回答"合计是多少" | 用真实 Excel 复测 |
| 并发上限 | 多人同时上传会排队还是崩 | 压测 3–10 并发 |
| `docling-serve` 有没有内置的持久化/清理 | 内存/磁盘会不会涨 | 看 `/v1/memory/stats`、`/v1/clear/results` |
| 6090 之外的 GPU | 大 PDF 慢 | 先测 10MB 样本 |
