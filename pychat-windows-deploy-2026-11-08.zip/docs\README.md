# pychat 调研与方案（2026-11）

> **历史文档。** 当前可运行的实现与使用方式见仓库根目录的 [`../README.md`](../README.md)。
> 本文档集保留决策过程与实测数据；与代码冲突时以代码和根 README 为准。

一个 **Python 后端（Pydantic AI）+ React 前端（assistant-ui）** 的 AI 文档助手：
上传 Excel / Word，解析成结构化文本，然后在聊天里问答。

本目录是**调研结论 + MVP 技术方案**，供评审。不是最终实现，代码片段是骨架级。

## 阅读顺序

| 文档 | 内容 | 优先级 |
|---|---|---|
| [01-architecture.md](./01-architecture.md) | 端到端数据流、为什么选这套协议、模块边界 | 必读 |
| [02-backend-pydantic-ai.md](./02-backend-pydantic-ai.md) | Pydantic AI 2.66 + Vercel AI 适配器 + uv 工程结构 | 必读 |
| [03-docling-documents.md](./03-docling-documents.md) | Docling 实测数据、Excel/Word 解析策略、坑 | 必读（核心功能） |
| [04-frontend-stack.md](./04-frontend-stack.md) | TypeScript 7 / Vite 8 / oxlint / React Compiler / TanStack Router / SWR / shadcn / assistant-ui | 必读 |
| [05-deployment.md](./05-deployment.md) | 192.168.16.24 现状勘查、端口分配、compose | 必读 |
| [06-ai-ecosystem-trends.md](./06-ai-ecosystem-trends.md) | GitHub Trending 实测、Agent Skills 生态、可复用的东西 | 选读 |
| [07-roadmap-risks.md](./07-roadmap-risks.md) | MVP 边界、验收标准、风险清单、待决问题 | 必读（决策用） |
| [08-python-engineering.md](./08-python-engineering.md) | uv / ruff / ty / pytest：工程化子集 | 必读（动手前） |
| [09-configuration.md](./09-configuration.md) | 配置：一份 TOML，每个 agent 一份 model | 必读 |
| [10-dev-experience.md](./10-dev-experience.md) | 版本策略、Skills、浏览器调试 | 必读（动手前） |
| [11-code-standards.md](./11-code-standards.md) | Commit（Conventional Commits）、Docstring（Google）、注释标准 | 必读（写第一行前） |

## 三句话结论

1. **协议层不要自己发明**。后端用 `pydantic_ai.ui.vercel_ai.VercelAIAdapter` 输出 Vercel AI Data Stream（SSE），前端用 assistant-ui 的 `useDataStreamRuntime` 直接吃，中间不需要 Node BFF，也不需要 AI SDK 运行时。
2. **Docling 能覆盖 Word，但 Excel 只适合"读版面"，不适合"读数据"**。`xlsx` 走 Docling 的 markdown 会丢 sheet 名，公式列是空的（我实测过，见 03）。所以上传时用 `openpyxl` 把每个 sheet 摊平成 CSV，模型在 `CodeMode` 的 `mount` 里自己读——**不给它写工具**。
3. **前端新栈很能打，但有两个真实陷阱**：TypeScript 7 没有编译器 API（typescript-eslint 要别名回 6.0）；Vite 8 的 `@vitejs/plugin-react` v6 拆掉了 Babel，React Compiler 必须换成 `@rolldown/plugin-babel` + `reactCompilerPreset()`（见 04）。

## 版本矩阵（2026-11-08 实测，非记忆）

版本号来自 npm registry / PyPI / 目标机 `docker ps` 的实时查询。

### 后端

| 组件 | 版本 | 备注 |
|---|---|---|
| Python | **3.14**（本机 3.14.3） | 全线统一 3.14，不再迁就 3.13 |
| uv | **0.13.7**（本机 0.12.24，待升） | 包管理 + 运行 + 容器内安装 |
| pydantic | 2.14.3 | |
| pydantic-ai | 2.66.0 | 含 `ui.vercel_ai`、`mcp.MCPToolset`、Harness |
| pydantic-ai-harness | 0.66.0 | 提供 `CodeMode`（Monty 沙箱）；**0.x，钉精确版本** |
| ruff | 0.17.4 | lint + format，CI 卡门禁 |
| ty | 0.0.99 | 类型检查；**0.x，只做本地提示，不进 CI** |
| pytest / pytest-asyncio / pytest-timeout | 9.2.0 / 1.4.1 / 2.4.0 | 单测 + 异步 + 超时 |
| httpx | 0.28.1 | |
| FastAPI / uvicorn | 0.162.2 / 0.54.0 | 只用到 Starlette 的 Request/Response |
| docling | 2.142.1 | 跑在 NAS 上的 docling-serve |
| docling-serve | 1.38.1 | `http://192.168.16.24:6029` |
| docling-mcp | 3.3.0（钉住） | PyPI 最新 3.5.0，故意不跟（见 03） |

### 前端

| 组件 | 版本 | 备注 |
|---|---|---|
| Node / npm | 24.13.0 / 11.17.0 | |
| react / react-dom | 19.3.1 | |
| @types/react / @types/react-dom | 19.3.0 | |
| TypeScript | **7.0.2** | Go 原生移植，无 API，需 `@typescript/typescript6` 兜 typescript-eslint |
| Vite | 8.3.6 | |
| @vitejs/plugin-react | 6.2.1 | **已移除 Babel**，改用 oxc |
| babel-plugin-react-compiler | 1.0.0 | React Compiler 1.0 stable |
| oxlint | 1.92.0 | |
| oxfmt | **0.77.0** | 还是 0.x，格式细节仍会变 |
| @tanstack/react-router | 1.170.46 | |
| @tanstack/react-start | 1.169.5 | 若要做 SSR |
| swr | 2.5.1 | 非流式数据 |
| shadcn（CLI） | 4.23.0 | registry 机制 |
| tailwindcss | 4.3.5 | |
| ai / @ai-sdk/react | 7.0.165 / 4.0.169 | 只在需要前端工具调用时引入 |
| @assistant-ui/react | 0.15.33 | 仍是 0.x，务必钉精确版本 |
| @assistant-ui/react-data-stream | 0.12.41 | 推荐入口（不依赖 `ai`） |
| @assistant-ui/react-ai-sdk | 1.4.22 | 备选，peer `ai@^7.0.101` |
| @assistant-ui/react-markdown | 0.14.25 | markdown 渲染 |
| @assistant-ui/react-devtools | 1.2.27 | 开发期看 runtime 状态 |
| vitest | 5.1.0 | 前端单测 |
| @playwright/test | 1.65.0 | E2E |

### 开发期 MCP

| 包 | 版本 | 用途 |
|---|---|---|
| chrome-devtools-mcp | 1.12.0 | 真 Chrome 的 console / network |
| @playwright/mcp | 0.0.84 | agent 驱动浏览器 |
| docling-mcp | 3.3.0 | 项目级已装（见下） |

### 基础设施

| 项 | 值 |
|---|---|
| Docker 主机 | `nas` / 192.168.16.24，Linux 6.18.18，x86_64 |
| Docker | 28.5.2 |
| 资源 | 24 核 / 23 GiB 内存 / 105 GiB 可用 |
| 已占端口 | 6001–6003, 6005–6007, 6010–6016, 6018–6019, 6027–6031 |
| 建议新端口 | **6032**（Web）、6033（可选 API 直连） |

## 本次已落地的改动

除了这些文档，还给**本项目**装了 Docling MCP：

- 新增 `D:\workspace\dev\pychat\opencode.jsonc`
- 形状是 OpenCode V2 的 `mcp.servers.docling`（你给的片段是 V1 的 `enabled`，V2 用 `disabled`）
- 配置保存后被热加载，本会话里已经能直接调 21 个 `docling` 工具
- 已验证：`https://ai-sdk.dev/docs/ai-sdk-ui/stream-protocol`、GitHub Trending、TypeScript 7 公告页、Docling 支持格式页都能转成干净 markdown

这条链路顺带解决了"Web Fetch 抓不干净"的问题：JS 渲染的文档站（ai-sdk.dev、github.com/trending）用裸 fetch 只能拿到壳，走 Docling 能拿到正文。

**2. `server/` 下有一份骨架，已冻结，且已过时**

按旧方案先落了最小后端（`pyproject.toml` / `main.py` / `agents.py` / `tools.py` / `config.py`）。它跑不起来（`uv sync` 没完成），**而且内容已经被这轮评审推翻**：

- 它还带着 `list_uploaded_files` / `list_sheets` / `read_sheet` 三个工具 —— 文档里已删，改用 `CodeMode(mount=...)`；
- 它写的是 `requires-python >=3.11` —— 文档已定 3.14；
- 它没有配置层 —— 文档 09 已给出 TOML + `pydantic.BaseModel` 的方案。

**以文档为准，代码等你看完再重写。** 留在那里只是让你看到"曾经这么想过"，不是可运行的实现。

`docs` 里的所有结论都优先于这份代码——如果评审改了方案，代码跟着改，不是反过来。

