"""FastAPI entry point: chat stream, document upload, and the built SPA."""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import Request
from starlette.responses import Response

from pychat.agent import build_agent
from pychat.config import ROOT, load_config
from pychat.docling import DoclingConverter
from pychat.documents import DocumentStore
from pychat.observability import setup_observability, shutdown_observability

load_dotenv(ROOT / ".env")

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("pychat")

config = load_config()
store = DocumentStore(config.server.data_dir)
converter = DoclingConverter(config.docling)

FRONTEND_DIST = Path(os.environ.get("PYCHAT_FRONTEND_DIST", ROOT.parent / "frontend" / "dist"))


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Own tracing and the docling-serve client for the whole process lifetime."""
    provider = setup_observability(config.observability)
    app.state.observability = provider
    app.state.agent = build_agent(
        config.agent,
        store,
        store.work_dir,
        instrument=config.observability.enabled,
    )
    await converter.start()
    try:
        yield
    finally:
        await converter.stop()
        shutdown_observability(provider)


app = FastAPI(
    title="pychat",
    lifespan=lifespan,
    # FastAPI 0.162 instruments requests with the global OTel provider by
    # default. That would nest every agent/tool span under a POST /api/chat
    # request span and add operation spans Phoenix does not need, so the only
    # spans we emit are the ones Pydantic AI creates.
    telemetry={
        "tracing": False,
        "metrics": False,
        "logs": False,
        "operation_spans": False,
        "auto_configure": False,
    },
)

if config.server.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.server.cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )


@app.get("/api/health")
async def health() -> dict:
    """Liveness plus the two facts that explain most broken deployments."""
    return {
        "ok": True,
        "model": config.agent.model.name,
        "docling": converter.ready,
        "tracing": config.observability.enabled,
        "documents": len(store.list()),
    }


@app.post("/api/chat")
async def chat(request: Request) -> Response:
    """Stream one turn using the Vercel AI SDK v7 UI message protocol."""
    return await VercelAIAdapter.dispatch_request(
        request, agent=request.app.state.agent, sdk_version=7
    )


@app.get("/api/documents")
async def list_documents() -> dict:
    """List registered documents, newest first."""
    return {"documents": [entry.model_dump() for entry in store.list()]}


@app.post("/api/documents")
async def upload_document(file: Annotated[UploadFile, File()]) -> dict:
    """Store an upload and convert it through docling-serve."""
    try:
        entry = await store.ingest(file, converter)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return entry.model_dump()


@app.post("/api/documents/{doc_id}/reconvert")
async def reconvert_document(doc_id: str) -> dict:
    """Retry a failed conversion without re-uploading the file."""
    try:
        entry = await store.reconvert(doc_id, converter)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="unknown document") from exc
    return entry.model_dump()


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str) -> dict:
    """Delete the registry entry and every derived file."""
    try:
        await store.delete(doc_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="unknown document") from exc
    return {"ok": True}


@app.get("/api/documents/{doc_id}/raw")
async def raw_document(doc_id: str) -> FileResponse:
    """Download the original upload."""
    path = store.raw_path(doc_id)
    if path is None:
        raise HTTPException(status_code=404, detail="unknown document")
    return FileResponse(path, filename=path.name)


class SPAStaticFiles(StaticFiles):
    """Static files with an SPA fallback, so client routes survive a refresh."""

    async def get_response(self, path: str, scope) -> Response:  # noqa: ANN001
        """Serve the file, or ``index.html`` for unmatched client-side routes."""
        try:
            return await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            if exc.status_code != 404:
                raise
            return await super().get_response("index.html", scope)


@app.middleware("http")
async def cache_headers(request: Request, call_next) -> Response:  # noqa: ANN001
    """Long-cache hashed assets, never cache the HTML shell."""
    response = await call_next(request)
    if request.url.path.startswith("/assets/"):
        response.headers["cache-control"] = "public, max-age=31536000, immutable"
    elif response.headers.get("content-type", "").startswith("text/html"):
        response.headers["cache-control"] = "no-cache"
    return response


if FRONTEND_DIST.is_dir():
    app.mount("/", SPAStaticFiles(directory=str(FRONTEND_DIST), html=True), name="spa")
else:
    log.warning("frontend dist not found at %s; serving API only", FRONTEND_DIST)
