# 04 · 前端：React + assistant-ui 的新栈

## 1. 选型结论

| 层 | 选 | 不选 | 理由 |
|---|---|---|---|
| 框架 | **Vite 8 + React 19** | Next.js / TanStack Start | 不需要 SSR / RSC；SSE 用原生 fetch 就够，多一层 Node 运行时纯亏 |
| 语言 | **TypeScript 7.0.2** | TS 6 | 类型检查快一个数量级；代价见第 5 节 |
| 路由 | **@tanstack/react-router 1.170** | react-router / 手写 | 类型安全的 path/search params，`Link` 的 `to` 写错直接编译报错 |
| 聊天 UI | **assistant-ui 0.15 + react-data-stream** | 自己写消息列表 | primitive 化，工具调用/分支/附件/停止都现成 |
| 协议 | Vercel AI Data Stream | 自定 WS | 后端 Pydantic AI 原生就吐这个 |
| 数据 | **SWR 2.5** | React Query | 只做"取一次 + 轮询"，SWR 更薄 |
| 样式 | **Tailwind 4 + shadcn CLI 4** | CSS-in-JS | shadcn 是 registry（复制源码），没有运行时依赖 |
| Lint | **oxlint 1.92** | ESLint | 快 10–50x，规则集够用 |
| Format | oxfmt 0.77（**可选**） | Prettier | 快，但还在 0.x，格式细节会变 |
| 编译优化 | React Compiler 1.0（**二期**） | — | 自动 memo，但 Vite 8 上的接法变了（第 6 节） |

## 2. 依赖清单

```jsonc
{
  "dependencies": {
    "react": "^19",
    "react-dom": "^19",
    "@assistant-ui/react": "^0.15.33",
    "@assistant-ui/react-data-stream": "^0.12.41",
    "@assistant-ui/react-markdown": "^0.14.24",
    "@tanstack/react-router": "^1.170.46",
    "swr": "^2.5.1"
  },
  "devDependencies": {
    "vite": "^8.3.6",
    "@vitejs/plugin-react": "^6.2.1",
    "typescript": "^7.0.2",
    "oxlint": "^1.92.0",
    "tailwindcss": "^4.3.5",
    "@tailwindcss/vite": "^4.3.5"
  }
}
```

**注意这里没有 `ai` / `@ai-sdk/react`。** `react-data-stream` 直接说协议，不依赖 AI SDK 运行时。只有当你要"前端工具调用 / 工具审批卡片"时，才换成 `@assistant-ui/react-ai-sdk`——它的 peer 是 `ai@^7.0.101`，会把你绑到 AI SDK 的版本节奏上。MVP 不需要。

## 3. 最小装配

### 3.1 runtime（全部协议复杂度都在这 3 行）

```tsx
// src/lib/runtime.ts
import { useDataStreamRuntime } from '@assistant-ui/react-data-stream'

export function useChatRuntime() {
  return useDataStreamRuntime({ api: '/api/chat' })
}
```

参数（文档确认过，`UseDataStreamRuntimeOptions`）：

| 参数 | 说明 |
|---|---|
| `api` | 必填，POST 端点 |
| `protocol` | 默认先看响应头，再按 `"ui-message-stream"` 解析 |
| `body` | 额外请求体，可以是 `(opts) => object`（拿得到 thread id） |
| `headers` / `credentials` | 认证 |
| `onData` / `onFinish` / `onError` / `onCancel` | 钩子 |
| `maxStreamEventLength` | 单事件上限，默认 16 MiB |

### 3.2 Provider + Thread

```tsx
// src/App.tsx
import { AssistantRuntimeProvider, ThreadPrimitive } from '@assistant-ui/react'
import { useChatRuntime } from './lib/runtime'

export function App() {
  const runtime = useChatRuntime()
  return (
    <AssistantRuntimeProvider runtime={runtime}>
      <ThreadPrimitive.Root className="mx-auto flex h-dvh max-w-3xl flex-col">
        <ThreadPrimitive.Viewport className="flex-1 overflow-y-auto p-4">
          <ThreadPrimitive.Messages />
          <ThreadPrimitive.ViewportFooter />
        </ThreadPrimitive.Viewport>
        <ThreadPrimitive.Composer />
      </ThreadPrimitive.Root>
    </AssistantRuntimeProvider>
  )
}
```

`ThreadPrimitive.Composer` / `.Messages` 是**默认实现**，样式很素但能跑。要好看，用官方 registry 拉一份定制版（第 7 节），别自己从 primitive 拼——0.x 的 primitive 组合方式还在变。

### 3.3 路由（代码式，不用代码生成）

```tsx
// src/router.tsx
import { createRootRoute, createRoute, createRouter } from '@tanstack/react-router'
import { App } from './App'

const rootRoute = createRootRoute()
const indexRoute = createRoute({ getParentRoute: () => rootRoute, path: '/', component: App })
const routeTree = rootRoute.addChildren([indexRoute])

export const router = createRouter({ routeTree })

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}
```

```tsx
// src/main.tsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider } from '@tanstack/react-router'
import { router } from './router'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
```

**为什么用代码式而不是文件式**：文件式要 `@tanstack/router-plugin` 做代码生成，多一个构建步骤和一份 `routeTree.gen.ts`。MVP 一个页面，不值得。等真有了 `/threads/$id` 这种，再换文件路由。

### 3.4 SWR 用在哪

聊天流由 assistant-ui 管，SWR 只管**非流式**的东西：

```tsx
import useSWR from 'swr'

const { data: files } = useSWR<{ document_id: string; filename: string; size: number }[]>(
  '/api/files',
  (url: string) => fetch(url).then((r) => r.json()),
  { refreshInterval: 5000 },
)
```

上行同理：上传用原生 `fetch` + `FormData`，别往 SWR 里塞 mutation 逻辑。

## 4. Vite 配置（含 SSE 开发代理）

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
})
```

⚠️ Vite 的 proxy 默认会把 SSE 缓冲住。如果流"一次性全出来"，加：

```ts
proxy: {
  '/api': {
    target: 'http://127.0.0.1:8000',
    changeOrigin: true,
    // 关掉压缩与缓冲
    configure: (proxy) => {
      proxy.on('proxyRes', (proxyRes) => {
        proxyRes.headers['cache-control'] = 'no-cache, no-transform'
      })
    },
  },
},
```

同样的坑在生产 nginx 上也有（`proxy_buffering off`），见 [05](./05-deployment.md)。

## 5. TypeScript 7 的两个真实代价

TS 7.0.2 是 **Go 原生移植**，官方数据：vscode 125.7s → 10.6s（11.9x），内存还降 18%。但有两件事必须知道：

### 5.1 它没有编译器 API

官方原话：

> TypeScript 7.0 **does not ship with an API**。我们期望 7.1 带一套新的（且不同的）API。

而 `typescript-eslint` 这类工具是 `import type ... from 'typescript'` 的。解法是官方给的双别名：

```jsonc
{
  "devDependencies": {
    "typescript": "npm:@typescript/typescript6@^6.0.2",
    "@typescript/native": "npm:typescript@^7.0.2"
  }
}
```

这样 `npx tsc` 走 7，工具链走 6 的 API。**如果你用 oxlint（Rust 实现，不依赖 TS API），这条根本不用管**——这也是我推荐 oxlint 而不是 typescript-eslint 的原因之一。

### 5.2 tsconfig 默认值变了，且有一批选项变成硬错误

默认值：

| 项 | TS7 默认 | 影响 |
|---|---|---|
| `types` | `[]` | **必须显式列出**，否则 `vite/client`、`node` 的全局声明全丢 |
| `rootDir` | `./` | tsconfig 不在 `src` 同级会打乱输出目录 |
| `target` | esnext 之前那个稳定版 | |
| `noUncheckedSideEffectImports` | `true` | `import './x.css'` 可能报错 |
| `stableTypeOrdering` | `true`，不可关 | |

变更即报错（no-op）：`target: es5`、`downlevelIteration`、`moduleResolution: node/node10/classic`、`module: amd/umd/systemjs/none`、`baseUrl`、`esModuleInterop: false`、`allowSyntheticDefaultImports: false`。

新项目的 `tsconfig.json`：

```jsonc
{
  "compilerOptions": {
    "target": "esnext",
    "lib": ["esnext", "dom", "dom.iterable"],
    "module": "preserve",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noEmit": true,
    "skipLibCheck": true,
    "types": ["vite/client"]
  },
  "include": ["src"]
}
```

## 6. React Compiler 在 Vite 8 上的正确接法

**这是最容易踩的一个坑**，因为网上 90% 的教程还是旧写法。

- React Compiler 1.0 在 2025-10 转正，`babel-plugin-react-compiler@1.0.0`。
- 但 `@vitejs/plugin-react@6` **把内部 Babel 换成了 oxc**（JSX 变换和 Fast Refresh 跑到 Rust 里了）。
- 结果：`react({ babel: { plugins: [...] } })` **在 Vite 8 上不再生效**，而且不报错，只是编译器没跑。

正确写法（这是 `D:\code\tauri\run-deck` 里跑通的形态，`vite.config.ts:17-31`）：

```bash
npm i -D @rolldown/plugin-babel babel-plugin-react-compiler
```

```ts
import babel from '@rolldown/plugin-babel'
import react, { reactCompilerPreset } from '@vitejs/plugin-react'

plugins: [
  react(),
  babel({
    presets: [
      reactCompilerPreset({
        logger: {
          logEvent(filename, event) {
            if (event.kind === 'CompileError') {
              console.error(`[Compiler] Skipped: ${filename}`, event.detail.reason)
            }
          },
        },
      }),
    ],
  }),
]
```

三个细节，都不是可选的：

1. `reactCompilerPreset()` 由 `@vitejs/plugin-react` 导出，内部已打包 `babel-plugin-react-compiler`。
2. **一定要接 `logger`**。编译器对"不符合规则"的组件是**静默跳过**的（比如用了某些 hook 模式），没有这个 logger，你会以为它开了，其实某个文件根本没编译。
3. 插件顺序在 run-deck 里是 `react()` 在前、`babel()` 在后；也有文章写 `babel` 必须在前。两说都有，**以你项目里 `CompileSuccess` 日志为准**——先跑一次，看是不是每个组件都编译了。

**MVP 阶段建议先不上编译器**（多一个 Babel 环节，构建慢、升级面大）。等 UI 稳定、真出现不必要的重渲染再开。

## 7. shadcn (CLI 4.23)

shadcn 不是组件库，是**registry**：`npx shadcn add button` 把源码复制进你的仓库。所以没有版本冲突，也没有运行时依赖。

初始化后 `components.json` 里加 assistant-ui 的 registry，一句话拉官方定制版聊天组件：

```jsonc
{
  "registries": {
    "@assistant-ui": "https://r.assistant-ui.com/styles/{style}/{name}.json"
  }
}
```

```bash
npx shadcn@latest add @assistant-ui/thread @assistant-ui/thread-list
```

> `{style}` 由 `components.json` 的 style 决定：`base-*` 开头的 style 拿到 Base UI 风味，其它拿到 Radix 风味。`npx shadcn init` 现在默认 Base UI。

## 8. oxlint / oxfmt 的现状（别当成"已经成熟"）

| | 版本 | 状态 | 建议 |
|---|---|---|---|
| oxlint | 1.92.0 | 已 1.x，规则覆盖 React / TS / import / jsx-a11y | **直接用**，替代 ESLint |
| oxfmt | 0.77.0 | **还是 0.x** | 可以先跑，但别接进 CI 卡门禁 |

oxfmt 的卖点：Prettier 兼容 + 内置 import 排序 + Tailwind class 排序，速度是 Prettier 的几十倍。但 0.x 意味着格式化结果还会变，一旦进 CI，某次升级就会产生几百行无意义 diff。团队没共识之前，保持 Prettier 或干脆不格式化。

配置：

```jsonc
// .oxlintrc.json
{
  "categories": { "correctness": "error", "suspicious": "warn", "perf": "warn" },
  "plugins": ["react", "react-hooks", "typescript", "import"],
  "env": { "browser": true, "es2024": true }
}
```

```jsonc
// package.json
{ "scripts": { "lint": "oxlint --deny-warnings src" } }
```

## 9. 不该现在引入的东西

| 想引入 | 为什么先别 |
|---|---|
| Next.js | 只为 SSE 付一个 Node 运行时 + RSC 心智负担；后端已经会说协议了 |
| TanStack Start (SSR) | 首屏是登录墙后面，SEO 无价值；loader 的价值在数据预取，聊天没有 |
| React Query | SWR 够了，两套缓存模型反而分裂 |
| `@assistant-ui/react-ai-sdk` | 引入 `ai@7` 的运行时耦合；等要前端工具调用时再说 |
| 文件路由 + 插件 | 一个页面，代码式路由足够 |
| Zustand / Redux | 聊天状态在 assistant-ui runtime 里，业务状态在 SWR 里，没有第三处 |

## 10. 验收（能被肉眼验证的 4 条）

1. `npm run dev` 起来，页面上能输入、能收到流式回复（后端 `PYCHAT_MODEL=test` 也应当有输出）。
2. 流是**逐字**出现的，不是一次性刷出来（否则看第 4 节的 proxy 缓冲）。
3. 回答里的 markdown 表格能正常渲染（靠 `@assistant-ui/react-markdown`）。
4. 上传一个 xlsx 后，问"这个表有几个 sheet"，回答正确——这条同时验证了预处理产物、`mount` 和工具调用链路。

## 11. 附：`run-deck` 的可借鉴清单

`D:\code\tauri\run-deck` 是同一套栈（Vite 8 + TS 7 + TanStack Router + SWR + Tailwind 4 + oxlint/oxfmt + React Compiler）的实战项目。但它是个 **Tauri 桌面应用**，而且有些地方是"缺治理"而不是"做了选择"，照抄会踩。

### 直接借

| 做法 | 出处 | 为什么 |
|---|---|---|
| `presets: [reactCompilerPreset({ logger })]` + 只打 `CompileError` | `vite.config.ts:17-31` | 编译器静默跳过组件，没有这个日志你不会发现 |
| 服务层做运行时校验：拿到的数据先过 schema 再进组件 | `src/services/cmds.ts:78-81` | 我们把 `invoke` 换成 `fetch`，`zod.parse` 保留 |
| Tailwind v4 的 CSS-first 写法：`@theme inline` + oklch 变量 + `@custom-variant dark` | `src/index.css:1-133` | 零 JS 配置，和 shadcn 变量天然对齐 |
| oxlint + oxfmt，不引 ESLint / Prettier | `.oxlintrc.json` / `.oxfmtrc.json` | 少一整条插件矩阵 |
| `cn()` = clsx + twMerge，变体用 `cva` | `src/lib/utils.ts:4-6`、`src/components/ui/button.tsx:6-41` | 与 assistant-ui / shadcn 生态同构 |
| `minify: 'oxc'` | `vite.config.ts:62` | Vite 8 下免费的性能收益 |
| 首帧前把主题 class 打上 | `src/main.tsx:19-29` | 消除闪白/闪黑 |

### 借之前要改

| 它的做法 | 我们要改成 | 原因 |
|---|---|---|
| 用 **hash history** | `createBrowserHistory`（默认） | 桌面壳需要 hash 规避自定义协议；我们是网页 |
| `components.json` 的 `style: base-nova`（Base UI） | 默认 style（Radix） | assistant-ui 的 registry 组件按默认 style 生成，混用会出现两套 primitives |
| `shadcn` 放在 `dependencies` | 放 `devDependencies` | 它只是构建期被 `@import 'shadcn/tailwind.css'` 引用 |
| 没有 `proxy` 配置 | 必须配 `/api` → 后端，并处理 SSE 缓冲 | 它走 Tauri `invoke`，没有 HTTP 层（见第 4 节） |

### 不要借

| 它的做法 | 问题 |
|---|---|
| 三份 `tsconfig` 里**都没有 `strict`** | 聊天应用到处是可选的消息 part，隐式 any 兜不住；我们必须 `strict: true` |
| 质量命令只写在 `justfile`，`package.json` 无 `lint`/`test`/`typecheck` | 换台机器没装 `just` 就失效，CI 也调不动；命令必须进 `package.json` |
| `routeTree.gen.ts` 既提交又没进 lint/format 的 ignore | 每次启动被重写 → 格式化噪音；我们代码式路由，没有这个文件 |
| 死代码与死依赖（`services/query-client.ts` 无人 import，`dexie`/`rxjs`/`mitt` 装了不用） | 新项目从零开始，装了不用比不装更糟 |
| 中文文案集中在一个巨型 `constants/labels.ts` | 聊天文案随迭代变，会变成 merge conflict 热点 |
| React Compiler + `ahooks` 的 `useMemoizedFn` 双轨 | 两套记忆化心智模型；先只靠 Compiler |

