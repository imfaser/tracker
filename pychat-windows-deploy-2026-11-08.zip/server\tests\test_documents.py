from __future__ import annotations

import io
from pathlib import Path

import pytest
from starlette.datastructures import UploadFile

from pychat.documents import DocumentStore


class FakeConverter:
    """Stand-in for the docling converter; writes the two derived files directly."""

    def __init__(self, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[Path] = []

    async def convert(self, source: Path, work_dir: Path, doc_id: str) -> dict[str, str]:
        self.calls.append(source)
        if self.fail:
            raise RuntimeError("docling exploded")
        (work_dir / f"{doc_id}.json").write_text('{"doc": true}', encoding="utf-8")
        (work_dir / f"{doc_id}.md").write_text("# hello", encoding="utf-8")
        return {"json_file": f"{doc_id}.json", "md_file": f"{doc_id}.md"}


def upload(name: str, payload: bytes = b"x") -> UploadFile:
    file = UploadFile(file=io.BytesIO(payload), filename=name)  # type: ignore[arg-type]
    return file


async def test_ingest_writes_manifest_and_derived_files(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    entry = await store.ingest(upload("预算.xlsx"), FakeConverter())

    assert entry.status == "ready"
    assert (store.work_dir / f"{entry.id}.json").is_file()
    assert (store.work_dir / f"{entry.id}.md").is_file()
    assert "预算.xlsx" in store.manifest_text()

    reloaded = DocumentStore(tmp_path)
    assert reloaded.get(entry.id) is not None


async def test_conversion_failure_is_recorded_not_raised(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    entry = await store.ingest(upload("broken.docx"), FakeConverter(fail=True))

    assert entry.status == "failed"
    assert "docling exploded" in (entry.error or "")
    assert entry.json_file is None


async def test_unsupported_type_is_rejected(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    with pytest.raises(ValueError, match="不支持"):
        await store.ingest(upload("virus.exe"), FakeConverter())


async def test_delete_removes_entry_and_files(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    entry = await store.ingest(upload("a.xlsx"), FakeConverter())
    await store.delete(entry.id)

    assert store.get(entry.id) is None
    assert not (store.work_dir / f"{entry.id}.json").exists()
    assert store.raw_path(entry.id) is None


def test_raw_path_rejects_traversal(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    assert store.raw_path("../../etc/passwd") is None


async def test_manifest_is_compact_for_the_agent(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    entry = await store.ingest(upload("a.xlsx"), FakeConverter())
    text = store.manifest_text()
    assert f"id={entry.id}" in text
    assert "/work/" in text
    assert text.count("\n") <= 1


def test_empty_manifest_text(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    assert "暂无" in store.manifest_text()


async def test_reconvert_retries_after_failure(tmp_path: Path) -> None:
    store = DocumentStore(tmp_path)
    entry = await store.ingest(upload("a.pdf"), FakeConverter(fail=True))
    assert entry.status == "failed"

    retried = await store.reconvert(entry.id, FakeConverter())
    assert retried.status == "ready"


def test_upload_size_limit_is_documented() -> None:
    from pychat.documents import MAX_UPLOAD_BYTES

    assert MAX_UPLOAD_BYTES >= 1024 * 1024
