"""Docling access: one HTTP call to docling-serve per upload.

The service returns the DoclingDocument JSON and the Markdown export inline.
Both are written into the sandbox work directory, where the model reads them
through CodeMode. No Docling parser is implemented here: this module only moves
one request and two files.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import httpx2

from pychat.config import DoclingConfig

log = logging.getLogger(__name__)


class DoclingConverter:
    """Thin client for docling-serve, shared by every upload.

    docling-serve queues and runs conversions itself, so calls are not
    serialized here: two uploads can be in flight at once.
    """

    def __init__(self, config: DoclingConfig) -> None:
        self._config = config
        self._client = httpx2.AsyncClient(
            base_url=config.service_url.rstrip("/"),
            timeout=httpx2.Timeout(timeout=config.timeout_s, connect=10.0),
        )
        self.ready = False

    async def start(self) -> None:
        """Probe the service once. Failure is logged, not fatal: chat still works."""
        try:
            response = await self._client.get("/health")
            response.raise_for_status()
            self.ready = True
            log.info("docling-serve ready (%s)", self._config.service_url)
        except Exception:
            log.exception("docling-serve unavailable; uploads will fail until restart")

    async def stop(self) -> None:
        """Close the HTTP client."""
        try:
            await self._client.aclose()
        except Exception:
            log.warning("error while closing the docling client", exc_info=True)

    async def convert(self, source: Path, work_dir: Path, doc_id: str) -> dict[str, str]:
        """Convert ``source`` and write the JSON/Markdown exports into ``work_dir``.

        Args:
            source: Absolute path of the uploaded file.
            work_dir: Directory mounted into the model sandbox as ``/work``.
            doc_id: Stable document id, also used as the derived file stem.

        Returns:
            Mapping with ``json_file`` and ``md_file`` names relative to ``work_dir``.

        Raises:
            RuntimeError: The service is unreachable, rejected the file, or
                returned a payload without a usable document.
        """
        if not self.ready:
            raise RuntimeError("docling-serve is not reachable")

        # Pass bytes, not an open handle: httpx2's async client rejects a sync
        # file object ("Attempted to send a sync request with an AsyncClient").
        # Uploads are capped at 64 MiB, so this stays bounded.
        payload = source.read_bytes()
        response = await self._client.post(
            "/v1/convert/file",
            files={"files": (source.name, payload)},
            data={"to_formats": ["json", "md"]},
        )
        if response.status_code != 200:
            raise RuntimeError(
                f"docling-serve returned {response.status_code}: {response.text[:300]}"
            )

        body = response.json()
        if body.get("status") != "success":
            raise RuntimeError(f"docling-serve conversion failed: {body.get('errors') or body}")

        document = body.get("document") or {}
        json_content = document.get("json_content")
        # docling-serve already decodes json_content to an object; loading it
        # again raises, and a string here means the response shape changed.
        if not isinstance(json_content, dict):
            raise RuntimeError("docling-serve returned json_content in an unexpected shape")

        json_path = work_dir / f"{doc_id}.json"
        md_path = work_dir / f"{doc_id}.md"
        json_path.write_text(json.dumps(json_content, ensure_ascii=False), encoding="utf-8")
        md_path.write_text(document.get("md_content") or "", encoding="utf-8")
        return {"json_file": json_path.name, "md_file": md_path.name}
