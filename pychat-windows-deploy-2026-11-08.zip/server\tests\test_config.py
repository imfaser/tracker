from __future__ import annotations

import tomllib
from pathlib import Path

import pytest
from pydantic import ValidationError

from pychat.config import AppConfig, _substitute


def _config_dict(tmp_path: Path) -> dict:
    return {
        "server": {"data_dir": str(tmp_path / "data"), "cors_origins": []},
        "agent": {
            "instructions_file": str(tmp_path / "prompt.md"),
            "model": {"name": "test"},
        },
    }


def test_config_rejects_unknown_keys(tmp_path: Path) -> None:
    raw = _config_dict(tmp_path)
    raw["agent"]["model"]["typo"] = True
    with pytest.raises(ValidationError):
        AppConfig.model_validate(raw)


def test_config_resolves_relative_paths_against_project_root(tmp_path: Path) -> None:
    raw = _config_dict(tmp_path)
    raw["server"]["data_dir"] = "./data"
    config = AppConfig.model_validate(raw)
    assert config.server.data_dir.is_absolute()


def test_ensure_dirs_creates_uploads_and_work(tmp_path: Path) -> None:
    config = AppConfig.model_validate(_config_dict(tmp_path))
    config.ensure_dirs()
    assert (config.server.data_dir / "uploads").is_dir()
    assert (config.server.data_dir / "work").is_dir()


def test_secret_substitution_reads_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYCHAT_TEST_KEY", "s3cret")
    assert _substitute({"api_key": "{$PYCHAT_TEST_KEY}"}) == {"api_key": "s3cret"}


def test_missing_secret_fails_loudly(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PYCHAT_MISSING_KEY", raising=False)
    with pytest.raises(RuntimeError, match="PYCHAT_MISSING_KEY"):
        _substitute({"api_key": "{$PYCHAT_MISSING_KEY}"})


def test_toml_file_round_trip(tmp_path: Path) -> None:
    config_file = tmp_path / "pychat.toml"
    config_file.write_text(
        f"""
[server]
data_dir = "{(tmp_path / "data").as_posix()}"

[agent]
instructions_file = "{(tmp_path / "prompt.md").as_posix()}"

[agent.model]
name = "test"
""",
        encoding="utf-8",
    )
    with config_file.open("rb") as handle:
        parsed = tomllib.load(handle)
    assert parsed["agent"]["model"]["name"] == "test"
    assert Path(parsed["server"]["data_dir"]).parent == tmp_path
