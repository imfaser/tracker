# pychat

AI 文档助手：上传 Excel / Word / PDF，在聊天里问答。后端 Python（Pydantic AI + docling-serve + Code Mode）+ 前端 React（Pydantic AI Chat UI），部署在内网 Docker。

## 现状

MVP 已实现并通过端到端验证：上传 → docling-serve 转换 → 沙箱内由模型读 JSON/Markdown → 流式回答；前端 `npm run build` 的产物由 FastAPI 直接服务。

- **`README.md` 与代码是当前事实。** `docs/01–12` 是设计与评审记录；其中 `docs/12-review-claims.md` 记录了已发现但未全部回填历史文档的问题。
- 会话历史在浏览器（client 模式），服务端无状态。
- 没有 PostgreSQL / Redis / 向量库。

## 目录

```text
server/        FastAPI + Pydantic AI + docling-serve(HTTP)
  config/      pychat.toml（唯一配置）
  prompts/     chat.md（系统提示词）
frontend/      Vite + React + @ai-sdk/react（界面来自 pydantic/ai-chat-ui）
docs/          方案与调研（历史）
server/Dockerfile  单容器镜像（前端构建产物 + 后端）
```

## 命令

```bash
# 后端（server/）
uv sync
uv run python -m pychat
uv run ruff format . && uv run ruff check .
uv run pytest

# 前端（frontend/）
npm install
npm run dev
npm run lint && npm run typecheck && npm run build
```

## 不能忘的常量

| 位置 | 值 | 原因 |
|---|---|---|
| `VercelAIAdapter.dispatch_request` | `sdk_version=7` | 默认 5 会吞掉工具审批态，**且不报错** |
| 前端聊天 | `@ai-sdk/react` 的 `useChat` + `Chat` 会话 | 界面照搬 `pydantic/ai-chat-ui`，不自写工具/思考卡片 |
| 前端 transport | `DefaultChatTransport({ api: "/api/chat" })` | 只发标准 AI SDK body |
| 前端模型列表 | `frontend/src/lib/config.ts` 写死当前模型名 | 后端没有 `/api/configure`，列表只用于展示和选择 |
| 模型配置 | 每个 agent 一份完整 `model`，不做回落 | |
| CodeMode 挂载 | `/work` 只读 | 可写是安全边界，不由配置决定 |
| 文档来源 | 只有 `data/work/*.json` / `*.md` + `manifest.json` | agent 没有 list/read 工具 |
| 会话历史 | 浏览器持有，服务端无状态 | |
| 数据库 / Redis / 向量库 | **不用** | |

## 代码规范

- **Commit**：Conventional Commits 1.0.0。`<type>(<scope>): <subject>`，subject 英文祈使句、小写、≤72、不加句号；body 可中文。
- `.githooks/commit-msg` 已提供；clone 后执行 `git config core.hooksPath .githooks`（不随 clone 传播）。
- **Docstring**：Google 风格。公开 API / 非平凡 / 逻辑不直观才写；有类型注解就不重复类型。
- **注释只写"为什么"**，不复述代码。
- 细节见 `docs/11-code-standards.md`。

## 已知坑（实测）

| 坑 | 事实 |
|---|---|
| Docling 的 `xlsx` → markdown | 丢 sheet 名；sheet 结构只在 **JSON** 的 `groups[].name`（`label=sheet`） |
| Docling 读公式 | 后端 `data_only=True`，读缓存值；`=SUM(...)` 文本永远拿不到 |
| `json_content` | REST 返回里已是对象，不要再 `json.loads` |
| Monty 沙箱 | 无第三方库、无 `zipfile`；默认 30s / 256 MiB / 100 次嵌套调用 |
| `httpx2` multipart | `data` 传 `dict[str, list]`（重复字段）；传 `list[tuple]` 会退化成同步流，AsyncClient 直接报 "Attempted to send a sync request" |
| docling-serve 探活 | 是 `/health`，没有 `/v1/health` |
| `RunCancelled` | 没有 `.conversation`，只有 `all_messages()` / `usage` / `conversation_id` |
| Vite 8 + `@vitejs/plugin-react@6` | 内部 Babel 已换成 oxc |
| TypeScript 7 | 不提供编译器 API |
| ruff | `task-tags` 写在 `[tool.ruff.lint]` 下，没有 `flake8-todos` 子表 |
| uv 镜像 | 只有 `python3.14-trixie-slim`，没有 bookworm |
| Docker Hub 镜像 | `docker.fnnas.com` 偶发对 `node:24-alpine` 回 401；用 `6xbrkv9mhdnp8e.xuanyuan.run/library/<image>` 拉取后 `docker tag` 成本地名，Dockerfile 不写死镜像源 |
| Dockerfile frontend | 不写 `# syntax=docker/dockerfile:1`：BuildKit 内置 frontend 够用，写它会额外拉 Docker Hub 镜像 |

## 改文档的规矩

`docs/01–11` 是历史设计记录。要改结论，先看 `docs/12-review-claims.md`；不要在没有新证据时改写已经实测过的段落。
