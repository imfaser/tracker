# Windows 部署指南

本文覆盖三种在 Windows 上使用 pychat 的方式，按需要选一种：

| 方式 | 适合 | 需要 |
|---|---|---|
| A. 本机直接跑 | 开发、调试、单机使用 | Python 3.14、uv、Node 24 |
| B. Docker Desktop | 本机跑与 NAS 相同的镜像 | Docker Desktop（WSL2） |
| C. 从 Windows 发布到 NAS | 当前生产环境 | OpenSSH 客户端、NAS 上的 Docker 与目录 |

所有命令都在 Windows PowerShell 5.1 及以上验证；推荐 PowerShell 7（`pwsh`）。注意 PowerShell 里 `curl` 是 `Invoke-WebRequest` 的别名，本文一律写 `curl.exe`。

## 1. 前置条件

- Windows 10 21H2+ / Windows 11，x64。
- [uv](https://docs.astral.sh/uv/) 0.12+（`uv sync` 会自动下载 Python 3.14）。
- Node.js 24 + npm（只在前端开发或构建时需要；生产镜像里会构建）。
- 可选：Docker Desktop 4.x，使用 WSL2 backend。
- 网络可达：
  - docling-serve：`http://192.168.16.24:6029`
  - 模型接口：`https://token-plan-cn.xiaomimimo.com/v1`
  - 可选：Phoenix：`http://192.168.16.24:6013`

解压后的目录结构：

```text
pychat\
  server\        FastAPI + Pydantic AI
  frontend\      Vite + React（界面来自 pydantic/ai-chat-ui）
  docs\          设计与运维文档
  README.md
```

## 2. 配置密钥

`server\config\pychat.toml` 里只写占位符：

```toml
[agent.model]
api_key = "{$MIMO_API_KEY}"
```

真正的值有两种给法，任选一种：

**方式一：`server\.env`（推荐给本机长期使用）**

```powershell
Copy-Item server\.env.example server\.env
notepad server\.env
```

填入一行：

```text
MIMO_API_KEY=你的key
```

保存为 UTF-8（Windows 11 的记事本默认就是无 BOM）。`server\.env` 已在 `.gitignore` 里，不要提交。

**方式二：环境变量（推荐给一次性命令）**

```powershell
# 只在当前 PowerShell 窗口有效
$env:MIMO_API_KEY = "你的key"

# 或写入当前用户的环境变量（新开的窗口生效）
[Environment]::SetEnvironmentVariable("MIMO_API_KEY", "你的key", "User")
```

`python-dotenv` 不会覆盖已经存在的环境变量，所以环境变量的优先级更高。

不打印密钥地确认键名存在：

```powershell
(Get-Content server\.env) -match '^MIMO_API_KEY='
```

## 3. 方式 A：本机直接跑

后端：

```powershell
cd server
uv sync
uv run python -m pychat
```

打开 `http://127.0.0.1:8000`。前端 `dist` 不存在时只提供 API，属正常。

前端开发态（热更新，`/api` 代理到 8000）：

```powershell
cd frontend
npm install
npm run dev
```

打开 `http://127.0.0.1:5173`。

生产态（由 FastAPI 直接服务构建产物）：

```powershell
cd frontend
npm run typecheck
npm run build
```

然后重启后端，`http://127.0.0.1:8000` 就是完整界面。

没有模型 key 时用离线配置验证管道：

```powershell
cd server
$env:PYCHAT_CONFIG = "config/pychat.test.toml"
uv run python -m pychat
```

检查：

```powershell
curl.exe -s http://127.0.0.1:8000/api/health
```

期望包含 `"ok":true`、`"docling":true`、`"tracing":true`。

> 首次运行时 Windows 会弹出防火墙提示，勾选“专用网络”，否则同网段的其他机器访问不到 8000。

## 4. 方式 B：Docker Desktop

在仓库根目录执行（注意是 `server/Dockerfile`，构建上下文是仓库根目录）：

```powershell
docker build -t pychat:latest -f server/Dockerfile .
```

```powershell
docker run -d --name pychat --restart unless-stopped `
  -p 6032:8000 `
  --env-file server/.env `
  -v "${PWD}/data:/app/data" `
  pychat:latest
```

```powershell
curl.exe -s http://127.0.0.1:6032/api/health
```

说明：

- Docker Desktop 的 File sharing 必须允许项目所在的盘符。
- 容器内以 uid 10001 运行。如果 bind mount 报权限错误，改用命名卷：
  ```powershell
  docker run -d --name pychat --restart unless-stopped -p 6032:8000 `
    --env-file server/.env -v pychat-data:/app/data pychat:latest
  ```
- 镜像里已包含前端构建产物；本机不需要装 Node 也能跑 Docker。
- npm 依赖走 `frontend/.npmrc` 里的 npmmirror；Docker Hub 基础镜像拉不下来时见第 7 节。

## 5. 方式 C：从 Windows 发布到 NAS（当前生产）

前提：`ssh 192.168.16.24` 可免密登录（或每次输入密码），NAS 已装 Docker，源码目录是 `/vol2/1000/app/pychat/src`。

**5.1 首次准备（只需一次）**

NAS 上的密钥文件（600）和数据目录（容器内 uid 10001 可写）：

```powershell
ssh 192.168.16.24
```

```sh
umask 077
read -rs KEY && printf 'MIMO_API_KEY=%s\n' "$KEY" > /vol2/1000/app/pychat/.env
mkdir -p /vol2/1000/app/pychat/data
chown -R 10001:10001 /vol2/1000/app/pychat/data
exit
```

**5.2 同步源码**

只传构建需要的文件，不要把 `node_modules`、`.venv`、`data`、`.env` 带上去：

```powershell
$dst = "192.168.16.24:/vol2/1000/app/pychat/src"
ssh 192.168.16.24 "mkdir -p /vol2/1000/app/pychat/src/server /vol2/1000/app/pychat/src/frontend"

scp -r server/src server/config server/prompts server/tests "${dst}/server/"
scp server/pyproject.toml server/uv.lock server/Dockerfile "${dst}/server/"

scp -r frontend/src frontend/public "${dst}/frontend/"
scp frontend/package.json frontend/package-lock.json frontend/.npmrc `
    frontend/index.html frontend/components.json frontend/tsconfig.json `
    frontend/vite.config.ts "${dst}/frontend/"
```

**5.3 构建镜像**

构建可能超过 SSH 的交互超时，放到后台并写日志：

```powershell
ssh -n 192.168.16.24 "cd /vol2/1000/app/pychat/src && setsid nohup docker build --progress=plain -t pychat:latest -f server/Dockerfile . > /tmp/pychat-build.log 2>&1 < /dev/null & echo ok"
```

进度与结果：

```powershell
ssh 192.168.16.24 "tail -5 /tmp/pychat-build.log; docker images pychat --format '{{.CreatedAt}}'"
```

**5.4 替换容器**

密钥和数据都在 NAS 上，不随代码同步：

```powershell
ssh 192.168.16.24 "docker rm -f pychat >/dev/null 2>&1; docker run -d --name pychat --restart unless-stopped -p 6032:8000 --env-file /vol2/1000/app/pychat/.env -v /vol2/1000/app/pychat/data:/app/data pychat:latest"
```

```powershell
curl.exe -s http://192.168.16.24:6032/api/health
```

期望返回：

```json
{"ok":true,"model":"mimo-v2.6-pro","docling":true,"tracing":true,"documents":1}
```

## 6. 验证清单

```powershell
# 后端静态检查与单测
cd server
uv run ruff check .
uv run pytest -q

# 前端类型检查与构建
cd ..\frontend
npm run typecheck
npm run build
```

页面验证：

1. 打开 `http://192.168.16.24:6032/`（或本机对应的端口）。
2. 左下角「文档」→ 上传一份 xlsx，状态变成“已就绪”。
3. 提问“这张表里 … 是多少？”，展开工具活动应能看到 `run_code` 卡片和思考过程。
4. Phoenix（可选）：项目 `pychat` 下应出现 `agent run` / `chat mimo-v2.6-pro` / `running tool` span。

## 7. 网络与镜像源（大陆环境）

- **npm**：`frontend/.npmrc` 已配置 `registry=https://registry.npmmirror.com/`；`Dockerfile` 在 `npm ci` 之前复制它。
- **Docker Hub**：NAS 的 `docker.fnnas.com` 偶尔对 `node:24-alpine` 返回 401。先走备用镜像再打成本地名，Dockerfile 本身不写死镜像源：

  ```powershell
  ssh 192.168.16.24 "docker pull 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine; docker tag 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine node:24-alpine"
  ```

- **GitHub Releases**：直连 `github.com/.../releases/download/...` 可能 504。给 URL 加代理前缀即可，例如：

  ```powershell
  curl.exe -L -o tool.zip "https://ghproxy.net/https://github.com/<owner>/<repo>/releases/download/<tag>/<asset>"
  ```

- **uv / PyPI**：默认源即可；如果很慢，可临时设置 `$env:UV_DEFAULT_INDEX = "https://pypi.tuna.tsinghua.edu.cn/simple"`。

## 8. 常见问题

| 现象 | 处理 |
|---|---|
| `curl` 报参数错误 | PowerShell 的 `curl` 是别名，改用 `curl.exe` |
| POST 中文 JSON 报 `json_invalid` | PowerShell 5 的 `Out-File -Encoding utf8` 会写 BOM；改用 `[System.IO.File]::WriteAllText($path, $body, (New-Object System.Text.UTF8Encoding($false)))` |
| 8000 端口被占用 | `Get-NetTCPConnection -LocalPort 8000 -State Listen` 找到 PID 后 `Stop-Process -Id <pid>` |
| 上传一直失败，健康检查 `docling:false` | docling-serve 不可达或未启动；`curl.exe http://192.168.16.24:6029/health` 应返回 `{"status":"ok"}` |
| 上传成功但模型说找不到文件 | 看 `server/data/work/manifest.json` 的 `status` / `error`，再 `docker logs pychat` |
| Phoenix 没有 trace | `server/config/pychat.toml` 的 `[observability] enabled` 要为 `true`，`/api/health` 的 `tracing` 要为 `true` |
| 换电脑后聊天记录没了 | 会话历史存在浏览器 IndexedDB，换浏览器或清站点数据即丢，属预期行为 |
| Docker 构建很慢/超时 | 先确认 `.npmrc` 已进镜像；再按第 7 节处理基础镜像与 GitHub 访问 |

## 9. 安全

- 不要把 `server/.env`、NAS 的 `/vol2/1000/app/pychat/.env` 提交或打包。
- 服务本身**没有认证**，只适合内网；暴露到公网前必须加反向代理和认证。
- 上传上限 64 MiB（`MAX_UPLOAD_BYTES`）。
- 怀疑 key 泄漏时，在服务商后台轮换，并更新 NAS 与本机的值。

## 10. 用 gitleaks 自查

```powershell
# 安装（大陆网络下 winget 可能下载失败，可改用第 7 节的代理方式下载 release zip）
winget install --id Gitleaks.Gitleaks -e

# 扫描源码（跳过依赖与数据目录）
gitleaks dir . --redact --no-banner
```

`gitleaks dir` 会把 `node_modules` / `.venv` 一起扫，量大且多为库里的假阳性；建议先复制一份只含源码的目录再扫，或把依赖目录排除。真实密钥应只存在于未纳入版本管理的 `server/.env` 或系统环境变量里。
