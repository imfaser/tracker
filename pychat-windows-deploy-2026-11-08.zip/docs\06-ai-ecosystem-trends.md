# 06 · GitHub Trending 实测：现在大家在造什么

数据抓取时间：2026-11-08，`github.com/trending?since=weekly`（用 Docling 转成 markdown 后读的，裸 fetch 拿不到正文）。

## 1. 本周榜单（AI 相关部分）

| 仓库 | 语言 | Stars | 本周 + | 它是什么 |
|---|---|---|---|---|
| [mattpocock/skills](https://github.com/mattpocock/skills) | Shell | 317.9k | 9,664 | "Skills for Real Engineers"，作者自己的 `.agents` 目录 |
| [anthropics/skills](https://github.com/anthropics/skills) | Python | 188.9k | 2,796 | Agent Skills 官方仓库 |
| [thedotmack/claude-mem](https://github.com/thedotmack/claude-mem) | TS | 114.6k | 7,482 | 跨会话持久记忆：抓 agent 做了什么、压缩、下次注入 |
| [D4Vinci/Scrapling](https://github.com/D4Vinci/Scrapling) | Python | 99.4k | 8,712 | 抓取框架，单请求到全站爬 |
| [pingdotgg/t3code](https://github.com/pingdotgg/t3code) | TS | 51.5k | **17,100** | 编码 agent（本周第一） |
| [Nutlope/hallmark](https://github.com/Nutlope/hallmark) | CSS | 50.4k | 6,624 | "Anti-AI-slop design skill"——反 AI 味的设计规约 |
| [vercel-labs/agent-browser](https://github.com/vercel-labs/agent-browser) | Rust | 47.0k | 1,476 | 给 agent 用的浏览器 CLI |
| [Donchitos/Claude-Code-Game-Studios](https://github.com/Donchitos/Claude-Code-Game-Studios) | Shell | 36.7k | 5,719 | 49 个 agent + 72 个 skill 模拟游戏工作室 |
| [max-sixty/worktrunk](https://github.com/max-sixty/worktrunk) | Rust | 12.0k | 2,292 | git worktree 管理，专为并行 agent 工作流 |
| [jakubkrehel/skills](https://github.com/jakubkrehel/skills) | Markdown | 11.6k | 1,938 | 一堆"把界面做好看"的 skill |

## 2. 四个能看出来的趋势

### 2.1 Agent Skills 已经变成分发单元

前十里有 **四个**是 `SKILL.md` 仓库，而且 `anthropics/skills` 已经 189k star。这说明生态达成了共识：

> 能力不是以"库"分发，而是以"`SKILL.md` + 可选脚本"分发。

原因是它能解决工具/库解决不了的问题：**上下文**。一个 skill 平时只占一行 description，模型觉得需要才加载正文。对比"把所有能力写成 system prompt"，这是数量级的差别。

这也是 Pydantic AI 有 `Skills` 能力（Harness 里）的原因——同样的形态，Python 侧的实现。

### 2.2 上下文与记忆成了独立产品

`claude-mem` 114k star，做的事很朴素：抓 session、压缩、下次注入。它火说明**默认的上下文管理不够用**，而"记忆"正在从框架特性变成独立基础设施。

对我们的启发：文档助手的记忆不是"聊天记录"，而是**文档结构 + 曾经的结论**。这块别自己发明，先用 Pydantic AI 的 Step Persistence / Memory。

### 2.3 并行 agent 需要操作系统级支持

`worktrunk`（git worktree 管理）+ `t3code`（本周涨星第一）说明一件事：当一个人同时跑 5 个 agent，**冲突的不是模型，是工作区**。worktree 隔离、端口隔离、数据库隔离，这些"无聊"的东西正在被产品化。

我们自己已经在用这个思路（OpenChamber 的 worktree），写进文档是为了提醒：**这个项目以后多 agent 改代码时，先开 worktree**。

### 2.4 "界面质量"开始被编码

`hallmark`（反 AI 味设计）和 `jakubkrehel/skills`（把界面做好看）都进了前十。这在两年前不存在。

含义：**"AI 生成的 UI 很丑"已经是可以被规约解决的问题**，而不是审美问题。对 pychat 直接有用——我们正好要写聊天界面，把这几条规则抄进 `AGENTS.md` 比让模型自由发挥强。

## 3. 对 pychat 的三个具体动作

### 动作一：把领域知识写成 Skill，而不是塞进 system prompt

现在 `agents.py` 里的 `INSTRUCTIONS` 是一条长字符串，常驻上下文。等规则变多（预算表怎么读、合同怎么摘、报表怎么对齐），应该拆成：

```
server/src/pychat/skills/
├─ excel-analysis/SKILL.md     # 多 sheet、公式缓存、单位陷阱
├─ contract-review/SKILL.md    # 条款抽取、风险标注
└─ report-format/SKILL.md      # 输出格式规范
```

用 Pydantic AI Harness 的 `Skills` 能力按需加载：模型先看到一行描述，判断相关才读正文。**这跟 trending 里那四个仓库是同一套机制。**

### 动作二：给仓库写 `AGENTS.md` + 项目级 skills

不是给产品用的，是给"以后来改这个仓库的 coding agent"用的。内容应该是：目录约定、`sdk_version=7` 这种不能忘的常量、`data_only=True` 这种坑、部署端口 6032。

### 动作三：E2E 用真浏览器验，不靠肉眼

`agent-browser` 的思路：把"打开页面 → 上传文件 → 提问 → 断言出现某段文字"脚本化。我们本地已经有浏览器面板，可以先用它手工过一遍，再抽成 Playwright 脚本。

## 4. 明确不建议跟的风

| 潮流 | 为什么不跟 |
|---|---|
| 把 `claude-mem` 这类记忆层直接接进 MVP | 多一套存储 + 多一个隐私面；先把"单次会话+文档"跑通 |
| 引入"多 agent 编排" | 一个文档助手不需要 orchestrator；等真有多角色需求（审阅者/撰写者）再说 |
| 自建 skill 市场/插件系统 | 我们只有 3 个 skill，硬编码目录就够；生态才刚形成，标准还会变 |
| 追 trending 里的 star 数选技术 | `t3code` 一周涨 17k 不代表它适合当你的聊天前端；选型看的是契约和稳定性 |

一句话：**trending 告诉你"形态"，不告诉你"该装什么"**。这里的形态是——能力用 SKILL.md 分发、上下文要主动管理、界面质量要规约化。
