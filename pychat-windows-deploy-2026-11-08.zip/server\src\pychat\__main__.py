"""``python -m pychat`` runs the server on the bind address from the config."""

from __future__ import annotations

import uvicorn

from pychat.config import load_config
from pychat.main import app


def main() -> None:
    """Start uvicorn with host and port taken from ``[server].bind``."""
    config = load_config()
    host, _, port = config.server.bind.rpartition(":")
    uvicorn.run(app, host=host or "0.0.0.0", port=int(port or 8000))


if __name__ == "__main__":
    main()
