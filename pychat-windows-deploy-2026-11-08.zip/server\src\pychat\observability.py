"""Phoenix/OpenInference wiring.

Pydantic AI emits OpenTelemetry spans when the ``Instrumentation`` capability is
attached. ``OpenInferenceSpanProcessor`` rewrites them into OpenInference
attributes, which is the format Phoenix renders (model, tool, retrieval panels).
"""

from __future__ import annotations

import logging

from openinference.instrumentation.pydantic_ai import OpenInferenceSpanProcessor
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from pychat.config import ObservabilityConfig

log = logging.getLogger(__name__)


def setup_observability(config: ObservabilityConfig) -> TracerProvider | None:
    """Install the global tracer provider, or return ``None`` when disabled.

    Called from the FastAPI lifespan before the agent is built, so no span can
    be created against the previous (no-op) provider.
    """
    if not config.enabled:
        return None

    provider = TracerProvider(
        resource=Resource.create(
            {
                "service.name": "pychat",
                "openinference.project.name": config.project_name,
            }
        )
    )
    provider.add_span_processor(OpenInferenceSpanProcessor())

    headers = {"Authorization": f"Bearer {config.api_key}"} if config.api_key else None
    exporter = OTLPSpanExporter(
        endpoint=f"{config.endpoint.rstrip('/')}/v1/traces",
        headers=headers,
    )
    # Batching keeps export off the request path; one second is short enough
    # that a trace shows up in Phoenix while the answer is still streaming.
    provider.add_span_processor(
        BatchSpanProcessor(exporter, schedule_delay_millis=1000, export_timeout_millis=10_000)
    )
    trace.set_tracer_provider(provider)
    log.info("tracing to Phoenix at %s (project %s)", config.endpoint, config.project_name)
    return provider


def shutdown_observability(provider: TracerProvider | None) -> None:
    """Flush buffered spans before the process exits."""
    if provider is None:
        return
    provider.shutdown()
    log.info("tracing provider shut down")
