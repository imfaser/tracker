"""Uploaded document registry and ingestion pipeline.

The registry is a single ``manifest.json`` inside the sandbox work directory:
the model reads it directly, so the backend exposes no "list documents" tool.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from fastapi import UploadFile
from pydantic import BaseModel, Field

from pychat.docling import DoclingConverter

log = logging.getLogger(__name__)

MAX_UPLOAD_BYTES = 64 * 1024 * 1024
_SUFFIX_KINDS: dict[str, str] = {
    ".xlsx": "excel",
    ".xlsm": "excel",
    ".xls": "excel",
    ".csv": "excel",
    ".docx": "word",
    ".doc": "word",
    ".pdf": "pdf",
    ".pptx": "slides",
    ".md": "text",
    ".html": "text",
    ".htm": "text",
    ".txt": "text",
}


class DocumentEntry(BaseModel):
    """One uploaded file and the state of its Docling conversion."""

    id: str
    filename: str
    size: int
    kind: str
    status: Literal["ready", "failed"] = "ready"
    uploaded_at: str = Field(
        default_factory=lambda: datetime.now(UTC).isoformat(timespec="seconds")
    )
    json_file: str | None = None
    md_file: str | None = None
    error: str | None = None


class DocumentStore:
    """Manages ``uploads/`` and ``work/`` plus the manifest the model reads."""

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir
        self.upload_dir = data_dir / "uploads"
        self.work_dir = data_dir / "work"
        self.manifest_path = self.work_dir / "manifest.json"
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()
        self._entries: dict[str, DocumentEntry] = {}
        self._load()

    def _load(self) -> None:
        if not self.manifest_path.exists():
            self._flush()
            return
        try:
            raw = json.loads(self.manifest_path.read_text(encoding="utf-8"))
            for item in raw.get("documents", []):
                entry = DocumentEntry.model_validate(item)
                self._entries[entry.id] = entry
        except OSError, ValueError:
            log.exception("manifest is unreadable; starting with an empty registry")

    def _flush(self) -> None:
        payload = {"documents": [entry.model_dump() for entry in self._entries.values()]}
        tmp = self.manifest_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.manifest_path)

    def list(self) -> list[DocumentEntry]:
        """Newest first."""
        return sorted(self._entries.values(), key=lambda entry: entry.uploaded_at, reverse=True)

    def get(self, doc_id: str) -> DocumentEntry | None:
        """Return one entry or ``None``."""
        return self._entries.get(doc_id)

    def raw_path(self, doc_id: str) -> Path | None:
        """Return the original upload, rejecting ids that are not plain hex."""
        # Ids are generated hex; refusing anything else keeps the glob injection-free.
        if not doc_id.isalnum():
            return None
        matches = list(self.upload_dir.glob(f"{doc_id}.*"))
        return matches[0] if matches else None

    async def ingest(self, upload: UploadFile, converter: DoclingConverter) -> DocumentEntry:
        """Persist the upload, convert it through Docling, and register it.

        Conversion failures are recorded on the entry instead of raised: the UI
        needs to show which file failed and why.
        """
        original = Path(upload.filename or "upload").name
        suffix = Path(original).suffix.lower()
        if suffix not in _SUFFIX_KINDS:
            raise ValueError(f"不支持的文件类型：{suffix or '(无扩展名)'}")
        doc_id = uuid.uuid4().hex[:12]
        destination = self.upload_dir / f"{doc_id}{suffix}"

        size = 0
        with destination.open("wb") as handle:
            while chunk := await upload.read(1 << 20):
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    handle.close()
                    destination.unlink(missing_ok=True)
                    raise ValueError(f"文件超过 {MAX_UPLOAD_BYTES // (1024 * 1024)} MiB 上限")
                handle.write(chunk)

        entry = DocumentEntry(
            id=doc_id,
            filename=original,
            size=size,
            kind=_SUFFIX_KINDS[suffix],
        )
        await self._convert(entry, destination, converter)
        async with self._lock:
            self._entries[doc_id] = entry
            self._flush()
        return entry

    async def reconvert(self, doc_id: str, converter: DoclingConverter) -> DocumentEntry:
        """Retry conversion for an entry currently marked failed."""
        entry = self.get(doc_id)
        source = self.raw_path(doc_id)
        if entry is None or source is None:
            raise KeyError(doc_id)
        await self._convert(entry, source, converter)
        async with self._lock:
            self._entries[doc_id] = entry
            self._flush()
        return entry

    async def _convert(
        self, entry: DocumentEntry, source: Path, converter: DoclingConverter
    ) -> None:
        try:
            files = await converter.convert(source, self.work_dir, entry.id)
            entry.status = "ready"
            entry.json_file = files["json_file"]
            entry.md_file = files["md_file"]
            entry.error = None
        except Exception as exc:
            log.exception("conversion failed for %s", entry.filename)
            entry.status = "failed"
            entry.json_file = None
            entry.md_file = None
            entry.error = f"{type(exc).__name__}: {exc}"[:800]

    async def delete(self, doc_id: str) -> None:
        """Remove the registry entry and every derived file."""
        raw = self.raw_path(doc_id)
        async with self._lock:
            entry = self._entries.pop(doc_id, None)
            if entry is None:
                raise KeyError(doc_id)
            for path in (
                raw,
                self.work_dir / f"{doc_id}.json",
                self.work_dir / f"{doc_id}.md",
            ):
                if path is not None:
                    path.unlink(missing_ok=True)
            self._flush()

    def manifest_text(self) -> str:
        """Compact manifest for the agent instructions."""
        ready = [entry for entry in self.list() if entry.status == "ready"]
        if not ready:
            return "（暂无可用文档）"
        lines = []
        for entry in ready:
            lines.append(
                f"- id={entry.id} · {entry.filename} · kind={entry.kind} · "
                f"json=/work/{entry.json_file} · md=/work/{entry.md_file}"
            )
        return "\n".join(lines)
