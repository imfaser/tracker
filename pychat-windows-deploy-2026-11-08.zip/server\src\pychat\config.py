"""Configuration loader: one TOML file, no ambient environment soup.

Secrets are referenced as ``{$ENV_NAME}`` and substituted at load time. Missing
secrets fail startup: a chat server that silently runs with the wrong key is
harder to debug than one that refuses to start.
"""

from __future__ import annotations

import os
import re
import tomllib
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

ROOT = Path(__file__).resolve().parents[2]
_PLACEHOLDER = re.compile(r"\{\$([A-Z0-9_]+)\}")


class ModelConfig(BaseModel):
    """Provider and decoding settings for one agent."""

    model_config = ConfigDict(extra="forbid")

    name: str
    base_url: str = ""
    api_key: str = ""
    temperature: float | None = None
    max_tokens: int = 4096
    timeout_s: float = 300


class DoclingConfig(BaseModel):
    """How the converter reaches docling-serve."""

    model_config = ConfigDict(extra="forbid", validate_default=True)

    service_url: str = "http://192.168.16.24:6029"
    timeout_s: float = 600


class AgentConfig(BaseModel):
    """Agent-level settings that are deployment-specific."""

    model_config = ConfigDict(extra="forbid")

    instructions_file: Path
    model: ModelConfig


class ObservabilityConfig(BaseModel):
    """Phoenix / OTLP tracing settings."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    endpoint: str = "http://192.168.16.24:6013"
    project_name: str = "pychat"
    api_key: str = ""


class ServerConfig(BaseModel):
    """HTTP listener and on-disk data locations."""

    model_config = ConfigDict(extra="forbid", validate_default=True)

    bind: str = "0.0.0.0:8000"
    data_dir: Path = Path("./data")
    cors_origins: list[str] = Field(default_factory=list)

    @field_validator("data_dir")
    @classmethod
    def _absolute(cls, value: Path) -> Path:
        return value if value.is_absolute() else (ROOT / value).resolve()


class AppConfig(BaseModel):
    """Whole application configuration."""

    model_config = ConfigDict(extra="forbid")

    server: ServerConfig = Field(default_factory=ServerConfig)
    docling: DoclingConfig = Field(default_factory=DoclingConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    agent: AgentConfig

    @field_validator("agent")
    @classmethod
    def _absolute_prompt(cls, value: AgentConfig) -> AgentConfig:
        if not value.instructions_file.is_absolute():
            value.instructions_file = (ROOT / value.instructions_file).resolve()
        return value

    def ensure_dirs(self) -> None:
        """Create the data directories; called after validation, never in a validator."""
        for sub in ("uploads", "work"):
            (self.server.data_dir / sub).mkdir(parents=True, exist_ok=True)


def _substitute(node: Any) -> Any:
    if isinstance(node, str):

        def repl(match: re.Match[str]) -> str:
            key = match.group(1)
            if key not in os.environ:
                raise RuntimeError(f"missing environment variable: {key}")
            return os.environ[key]

        return _PLACEHOLDER.sub(repl, node)
    if isinstance(node, dict):
        return {key: _substitute(value) for key, value in node.items()}
    if isinstance(node, list):
        return [_substitute(value) for value in node]
    return node


def load_config(path: Path | None = None) -> AppConfig:
    """Load and validate the TOML config.

    Args:
        path: Defaults to ``$PYCHAT_CONFIG`` or ``config/pychat.toml``.

    Raises:
        RuntimeError: A ``{$VAR}`` placeholder has no matching environment variable.
        pydantic.ValidationError: The file is malformed or contains unknown keys.
    """
    config_path = path or Path(os.environ.get("PYCHAT_CONFIG", ROOT / "config" / "pychat.toml"))
    with config_path.open("rb") as handle:
        raw = tomllib.load(handle)
    config = AppConfig.model_validate(_substitute(raw))
    config.ensure_dirs()
    return config
