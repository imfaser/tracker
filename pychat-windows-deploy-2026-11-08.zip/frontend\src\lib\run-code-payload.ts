import { z } from 'zod'

const runCodeInputSchema = z
  .object({
    code: z.unknown().transform((value) => (typeof value === 'string' ? value : '')),
    // Pydantic AI only sends `restart` when it is true. Without `.optional()`
    // zod 4 rejects the whole object for the missing key, and the `.catch`
    // below then hands back `code: ''` — an empty CODE block for every call.
    restart: z
      .unknown()
      .optional()
      .transform((value) => value === true),
  })
  .catch({ code: '', restart: false })

const runCodeOutputSchema = z
  .looseObject({
    output: z.unknown().optional(),
    result: z.unknown().optional(),
  })
  .refine((value) => Object.hasOwn(value, 'output') || Object.hasOwn(value, 'result'))

export type RunCodeResult = z.infer<typeof runCodeOutputSchema>

export function parseRunCodeInput(input: unknown) {
  return runCodeInputSchema.parse(input)
}

export function isRunCodeOutput(output: unknown): output is RunCodeResult {
  return runCodeOutputSchema.safeParse(output).success
}
