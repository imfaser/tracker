# 05 · 部署：192.168.16.24

## 1. 目标机勘查结果（实测）

```
$ ssh 192.168.16.24 "hostname; uname -a; docker --version"
nas
Linux nas 6.18.18.c1126-trim #1126 SMP PREEMPT_DYNAMIC ... x86_64 GNU/Linux
Docker version 28.5.2, build ecc6942
```

| 项 | 值 |
|---|---|
| CPU | 24 核 |
| 内存 | 23 GiB（已用 7.4 GiB，可用 16 GiB） |
| 磁盘 | `/` 126 G，已用 15 G，**可用 105 G** |
| Docker | 28.5.2，只有 `bridge / host / none` 三个网络 |
| Compose | **所有容器都没有 compose project label** —— 说明现在是用 `docker run` 或 dpanel 单容器方式起的，没有现成的 compose 约定可循 |

### 已占端口

`6001 6002 6003 6005 6006 6007 6010 6011 6012 6013 6014 6015 6016 6018 6019 6027 6028 6029 6030 6031`

空闲：`6004 6008 6009 6017 6020–6026 6032+`

**本项目用 `6032`**（Web 入口），API 不对外发布。

### 可直接复用的邻居服务

| 服务 | 端口 | 对本项目的价值 |
|---|---|---|
| docling-serve | 6029 | 文档解析后端 |
| gitea | 6011 | 代码托管（建议直接当 git remote） |
| phoenix | 6013 | LLM trace（OTLP 4317 未发布到宿主） |
| openobserve | 6014 | 日志/指标 |

## 2. 拓扑

```
             ┌────────────── nas (192.168.16.24) ──────────────┐
LAN:6032 ──► │  web (nginx:alpine)                             │
             │    ├─ /            → dist/ (SPA)                │
             │    └─ /api/*       → api:8000  (SSE 不缓冲)     │
             │                                                 │
             │  api (uv:python3.14-slim)                       │
             │    ├─ uvicorn :8000                             │
             │    └─ MCPToolset("http://docling-mcp:8000/mcp") │
             │                                                 │
             │  docling-mcp (python:3.12-slim)                 │
             │    └─ docling-mcp-server (streamable-http)      │
             │         └─ 转发到 192.168.16.24:6029            │
             │                                                 │
             │  volume: data → /data （api 与 docling-mcp 都挂）│
             └─────────────────────────────────────────────────┘
```

**三个容器**，不是两个。原因是一条硬事实（uv 官方文档）：

> 工具环境忽略 `.python-version` 和项目的 `requires-python`。

也就是说，在 3.14 的 api 镜像里 `uvx --from=docling-mcp` 起出来的进程**不是 3.14**，是 uv 自己挑的一个解释器；而且首次启动要联网下载。把它做成独立容器有两个好处：

1. **Python 版本解耦**：docling-mcp 用 3.12（它的依赖链还没完全跟上 3.14），api 用 3.14，互不干涉；
2. **启动可预测**：镜像构建期就把包装好，不依赖运行时网络。

代价是多一个容器 + 一个内部端口。值。

> 开发期仍可以用 stdio（`uvx ... --transport stdio`），改一行 `MCPToolset` 的构造参数即可。生产用 http。

## 3. Dockerfile

### server

```dockerfile
# server/Dockerfile
FROM ghcr.io/astral-sh/uv:python3.14-bookworm-slim

WORKDIR /app
ENV UV_COMPILE_BYTECODE=1 \
    UV_LINK_MODE=copy \
    UV_NO_DEV=1

# 1) 只装依赖，最大化层缓存
COPY pyproject.toml uv.lock ./
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --locked --no-install-project

# 2) 装项目本身
COPY src ./src
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --locked

ENV PATH="/app/.venv/bin:$PATH"
EXPOSE 8000
CMD ["uvicorn", "pychat.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

要点：

- `uv.lock` 必须进 git（uv 官方：锁文件是**跨平台**的 universal lock）。
- `--locked` 而不是 `--frozen`：前者会**断言锁文件是最新的**，后者只是不检查。CI/镜像构建要前者。
- **不要在镜像里 `uv pip install`**（官方明确不推荐改项目环境）。
- api 镜像里不需要 `uvx`，所以不必预装任何 MCP 工具。

### docling-mcp

```dockerfile
# server/docling-mcp/Dockerfile
FROM python:3.12-slim

RUN pip install --no-cache-dir uv \
 && uv tool install --python 3.12 "docling-mcp==3.3.0"

ENV PATH="/root/.local/bin:$PATH"
EXPOSE 8000

CMD ["docling-mcp-server", \
     "--transport", "streamable-http", \
     "--host", "0.0.0.0", "--port", "8000", \
     "--tools", "conversion"]
```

`uv tool install` 的版本是**钉死**的（`==3.3.0`）。uvx 的默认行为是"首次取最新、之后用缓存"，在生产里等于版本不可复现。

### frontend

```dockerfile
# frontend/Dockerfile
FROM node:24-alpine AS build
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html
```

### nginx.conf（SSE 的关键在这）

```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    client_max_body_size 50m;

    location /api/chat {
        proxy_pass http://api:8000;
        proxy_http_version 1.1;
        proxy_set_header Connection '';
        proxy_set_header Host $host;

        # 这三行是流式的命门
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding off;

        # 长回答 + 长工具调用（docling 转换可能要 60s+）
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }

    location /api/ {
        proxy_pass http://api:8000;
        proxy_set_header Host $host;
        client_max_body_size 50m;
    }

    location / {
        try_files $uri $uri/ /index.html;   # SPA fallback
    }
}
```

⚠️ 少了 `proxy_buffering off`，用户会看到"转圈 30 秒 → 整段突然出现"。这个 bug 在开发环境看不出来（Vite proxy 不一定缓冲），只在生产暴露。

## 4. compose

```yaml
# deploy/compose.yaml
name: pychat

services:
  docling-mcp:
    build: ../server/docling-mcp
    restart: unless-stopped
    environment:
      DOCLING_MCP_CONVERSION_MODE: remote
      DOCLING_MCP_SERVICE_URL: http://192.168.16.24:6029
      DOCLING_MCP_SERVICE_TIMEOUT: "600"
    volumes:
      - data:/data                  # 必须和 api 挂同一个路径：模型传的是 /work/...
    expose:
      - "8000"
    mem_limit: 1g
    healthcheck:
      test: ["CMD", "python", "-c", "import socket;socket.create_connection(('127.0.0.1',8000),2)"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 20s

  api:
    build: ../server
    restart: unless-stopped
    env_file: ../server/.env
    environment:
      PYCHAT_DATA_DIR: /data          # uploads / work / history 三个子目录
      PYCHAT_MCP_URL: http://docling-mcp:8000/mcp
    volumes:
      - data:/data
    expose:
      - "8000"
    mem_limit: 4g
    depends_on:
      docling-mcp:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8000/api/health')"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 40s
    logging:
      driver: json-file
      options: { max-size: "20m", max-file: "3" }

  web:
    build: ../frontend
    restart: unless-stopped
    ports:
      - "6032:80"
    depends_on:
      api:
        condition: service_healthy
    logging:
      driver: json-file
      options: { max-size: "20m", max-file: "3" }

volumes:
  data:
```

`mem_limit: 4g`：宿主机 23 G，docling-serve 那类模型服务才是吃内存的大头，api 给 4 G 足够，也是防止一次超大上传把整机拖死。

## 5. 部署步骤

```bash
# 1. 代码（推荐用 gitea :6011 当 remote）
git clone ssh://git@192.168.16.24:6012/pychat.git /volume1/docker/pychat

# 2. 配置
cp server/.env.example server/.env
chmod 600 server/.env
#   改 PYCHAT_MODEL / DEEPSEEK_API_KEY / PYCHAT_DOCLING_URL

# 3. 起
cd /volume1/docker/pychat/deploy
docker compose up -d --build
docker compose ps
docker compose logs -f api | head -50
```

> 没有现成 compose 目录约定（第 1 节）；`/volume1/docker/pychat` 是我建议的路径，实际以你 dpanel 里的习惯为准。

验证：

```bash
curl -s http://192.168.16.24:6032/api/health
# {"ok":true,"model":"test","docling":"http://192.168.16.24:6029"}

# SSE 是否真的流式（应当每行间隔出现）
curl -N -s -X POST http://192.168.16.24:6032/api/chat \
  -H 'content-type: application/json' \
  -d '{"id":"t1","trigger":"submit-message","messages":[{"id":"m1","role":"user","parts":[{"type":"text","text":"你好"}]}]}'
```

`curl -N` 看到的是 `data: {...}` 一行行往外冒，而不是最后一次性吐出来。

## 6. 运行期注意

| 事项 | 说明 |
|---|---|
| 首次请求慢 | 已经是独立容器 + 构建期安装，不再有 uvx 下载延迟。真正慢的是 docling-serve 首次加载模型 |
| docling 冷启动 | docling-serve 已经跑了 30 小时，模型是热的；如果我们自己重启它，第一批 PDF 会慢很多 |
| 上传目录 | `/data/uploads` 命名 `<id>.<ext>`，`/data/work` 存预处理产物，`/data/history` 存会话 JSON；都没有 GC，MVP 靠人工清，第二期加 TTL |
| 单 worker | 因为取消 token 在内存里 + 一个 MCP 子进程。要扩副本，先把取消状态挪出去（用什么都行），再 `--workers N` |
| docling-mcp 缓存 | 进程内 LRU（默认 10 篇）。重启即丢，所以**解析结果要落库**，不要依赖它 |
| 时区/日志 | 容器默认 UTC；需要本地时间在 compose 里加 `TZ=Asia/Shanghai` |

## 7. 回滚

```bash
docker compose down
docker image tag pychat-api:latest pychat-api:bad-$(date +%s)
git checkout <prev-sha>
docker compose up -d --build
```

数据只有 `data` 一个 volume，回滚不影响。以后真要接数据库，迁移脚本要能往后退一步（或者只做 forward-only + 备份）。
