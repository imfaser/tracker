# 10 · 版本、Skills、浏览器调试

这份是"开发期外挂"清单：依赖怎么钉、技能怎么写、页面怎么调。

## 1. 版本策略

**原则：全部取最新，用锁文件钉死。**

- 后端：`uv.lock` 进 git；升级走 `uv lock --upgrade`，别手改版本号。
- 前端：`package-lock.json` 进 git；升级走 `npm update`。
- 本机 `uv` 现在是 **0.12.24**，最新是 **0.13.7**——先升，否则 `uv sync --locked` 的行为和镜像里不一致。

四个还是 0.x 的依赖要单独盯（它们会在 minor 里改行为）：

| 包 | 现在 | 风险 |
|---|---|---|
| `pydantic-ai-harness` | 0.66.0 | `CodeMode` 的 API |
| `@assistant-ui/react` | 0.15.33 | primitive 组合方式 |
| `oxfmt` | 0.77.0 | 格式化结果会变 |
| `ty` | 0.0.99 | 诊断集合会变 |

升级节奏：每月一次，跑一遍契约测试（08 §6.6）再合。

## 2. 今日实测矩阵

日期 2026-11-08，全部来自 npm registry / PyPI 实时查询。

### 后端

| 包 | 版本 |
|---|---|
| Python | 3.14（本机 3.14.3） |
| uv | 0.13.7（本机待升） |
| pydantic | 2.14.3 |
| pydantic-ai | 2.66.0 |
| pydantic-ai-harness | 0.66.0 |
| fastapi | 0.162.2 |
| uvicorn | 0.54.0 |
| httpx | 0.28.1 |
| openpyxl | 3.1.5 |
| ruff | 0.17.4 |
| ty | 0.0.99 |
| pytest | 9.2.0 |
| pytest-asyncio | 1.4.1.post1 |
| pytest-timeout | 2.4.0 |
| logfire（可选） | 5.5.0 |

### 前端

| 包 | 版本 |
|---|---|
| react / react-dom | 19.3.1 |
| @types/react / @types/react-dom | 19.3.0 |
| typescript | 7.0.2 |
| vite | 8.3.6 |
| @vitejs/plugin-react | 6.2.1 |
| @tanstack/react-router | 1.170.46 |
| @assistant-ui/react | 0.15.33 |
| @assistant-ui/react-data-stream | 0.12.41 |
| @assistant-ui/react-markdown | 0.14.25 |
| @assistant-ui/react-devtools | 1.2.27 |
| assistant-stream | 0.3.56 |
| swr | 2.5.1 |
| tailwindcss / @tailwindcss/vite | 4.3.5 |
| shadcn（CLI） | 4.23.0 |
| zod | 4.6.7 |
| oxlint | 1.92.0 |
| oxfmt | 0.77.0 |
| vitest | 5.1.0 |

### 开发期工具

| 包 | 版本 | 用途 |
|---|---|---|
| @playwright/test | 1.65.0 | E2E |
| @playwright/mcp | 0.0.84 | 让 agent 驱动浏览器（MCP） |
| chrome-devtools-mcp | 1.12.0 | 让 agent 看真 Chrome 的 console / network（MCP） |

## 3. Skills：给"以后来改这个仓库的 agent"用的

OpenCode 的项目级约定（官方文档原文）：`SKILL.md` 放在 `.opencode/skills/<skill-id>/`，`description` 写"什么时候该用它"。也兼容 `.agents/skills`。

```
.opencode/skills/
├─ pychat-dev/SKILL.md
├─ docling-quirks/SKILL.md
└─ stream-contract/SKILL.md
```

每个 skill 一个目录，相关脚本/参考文档放旁边：

```
docling-quirks/
├─ SKILL.md
└─ references/
   └─ measured-behaviour.md
```

### 三个该写的 skill

| skill | 内容 | 为什么值得写 |
|---|---|---|
| `pychat-dev` | 怎么起服务、端口 6032/8000、配置在 `config/pychat.toml`、验收命令、`docker compose` 怎么调 | 新人/agent 第一次进仓库最花时间的就是这个 |
| `docling-quirks` | xlsx 的 sheet 名会丢、公式缓存值的坑、`.doc/.xls` 要 LibreOffice、`--tools conversion`、`init_timeout=30` / `read_timeout=600` 不是默认值 | 这些是踩出来的，不写下来下次还踩 |
| `stream-contract` | `sdk_version=7`、`x-vercel-ai-ui-message-stream: v1`、`[DONE]`、`ASGITransport` 会缓冲所以 SSE 要按 ASGI 消息测 | 协议细节一句话说不清，但改坏了前端就白屏 |

`SKILL.md` 骨架：

```markdown
---
name: docling-quirks
description: Docling 解析 Excel/Word 的已知坑与验证方法。改 ingest 或 docling 相关代码前加载。
---

## 什么时候用

- 改 `src/pychat/ingest/` 里的预处理
- 调整 `MCPToolset` 超时或 `--tools` 参数
- 有人说"Excel 读出来的数不对"

## 关键事实

- `export_docling_document_to_markdown` 不包含 sheet 名；anchor overview 也是扁平的。
- `data_only=True` 读到的是 Excel 缓存值；openpyxl 新生成、没被 Excel 打开过的文件这里是空的。
- `.doc/.xls/.rtf` 需要 LibreOffice，`docling-serve-cpu` 镜像是否内置**未验证**。

## 验证

\`\`\`bash
uv run python -m pychat.ingest.excel path/to/budget.xlsx
\`\`\`
```

### 产品里的同一套形态

仓库里的 skill 是给 coding agent 的；产品里的同构物是 `Capability(defer_loading=True)`：

```python
refund_policy = Capability[None](
    id="refund-policy",
    description="退款条款、时限、例外情况。命中的问题才加载。",
    defer_loading=True,
)
```

模型平时只看到一行 description，需要时才加载正文。**这是同一个机制**，只是一个给人用、一个给模型用。

## 4. 浏览器调试：三件套

| 工具 | 解决什么 | 怎么用 |
|---|---|---|
| `@assistant-ui/react-devtools` | 看 runtime 状态、消息 parts、事件流 | 挂一个组件，dev 环境开 |
| `chrome-devtools-mcp` | 看真 Chrome 的 console、network、DOM | 配进项目 `opencode.jsonc`，让 agent 直接操作 |
| `@playwright/test` + `@playwright/mcp` | 回归脚本 / 让 agent 跑交互 | `npx playwright test`；MCP 用于探索 |

### 4.1 DevTools 挂载

```tsx
// src/App.tsx（仅 dev）
import { DevTools } from '@assistant-ui/react-devtools'

export function App() {
  const runtime = useChatRuntime()
  return (
    <AssistantRuntimeProvider runtime={runtime}>
      <Thread ... />
      {import.meta.env.DEV && <DevTools />}
    </AssistantRuntimeProvider>
  )
}
```

### 4.2 MCP 配到项目里

`opencode.jsonc`（V2 形状，`mcp.servers`）：

```jsonc
{
  "mcp": {
    "servers": {
      "chrome-devtools": {
        "type": "local",
        "command": ["npx", "-y", "chrome-devtools-mcp@1.12.0"]
      },
      "playwright": {
        "type": "local",
        "command": ["npx", "-y", "@playwright/mcp@0.0.84"]
      }
    }
  }
}
```

`chrome-devtools-mcp` 需要本机装了 Chrome；在容器里跑不了，所以只配在本机，别配到 NAS。

### 4.3 三个典型场景

| 场景 | 用哪个 |
|---|---|
| "消息气泡渲染错了" | DevTools 看 parts → 再看组件 |
| "流是断的/顺序不对" | chrome-devtools 的 Network → 看 SSE 帧；或者直接 `curl -N` |
| "回归：上传→提问→出表格" | Playwright 脚本，进 CI |

**注意**：别用 Playwright 的 `page.waitForTimeout` 当断言。等元素、等文本、等响应，不要等时间——CI 必 flaky。

## 5. 依赖清单（照抄）

### `server/pyproject.toml`

```toml
[project]
requires-python = ">=3.14"
dependencies = [
  "pydantic-ai-slim[openai,mcp]>=2.66,<2.67",
  "pydantic-ai-harness[codemode]==0.66.0",
  "fastapi>=0.162",
  "uvicorn[standard]>=0.54",
  "python-multipart>=0.0.20",
  "openpyxl>=3.1",
]

[dependency-groups]
dev = [
  "pytest>=9.2",
  "pytest-asyncio>=1.4",
  "pytest-timeout>=2.4",
  "httpx>=0.28",
  "ty==0.0.99",
]
lint = ["ruff>=0.17,<0.18"]
```

> 不再需要 `pydantic-settings`：配置是 TOML + `pydantic.BaseModel`（09 §3）。

### `frontend/package.json`

```jsonc
{
  "dependencies": {
    "react": "^19.3.1",
    "react-dom": "^19.3.1",
    "@assistant-ui/react": "^0.15.33",
    "@assistant-ui/react-data-stream": "^0.12.41",
    "@assistant-ui/react-markdown": "^0.14.25",
    "@tanstack/react-router": "^1.170.46",
    "swr": "^2.5.1",
    "zod": "^4.6.7"
  },
  "devDependencies": {
    "typescript": "^7.0.2",
    "vite": "^8.3.6",
    "@vitejs/plugin-react": "^6.2.1",
    "tailwindcss": "^4.3.5",
    "@tailwindcss/vite": "^4.3.5",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "oxlint": "^1.92.0",
    "oxfmt": "^0.77.0",
    "vitest": "^5.1.0",
    "@playwright/test": "^1.65.0",
    "@assistant-ui/react-devtools": "^1.2.27"
  }
}
```

## 6. 装的时候要注意

| 事项 | 说明 |
|---|---|
| `playwright` 要单独装浏览器 | `npx playwright install chromium`；Docker 里要 `--with-deps` |
| `ty` 0.0.99 在 CI 先不卡 | 见 08 §7 |
| `oxfmt` 0.77 别进 CI 门禁 | 格式化结果还会变（04 §8） |
| `chrome-devtools-mcp` 只在有 Chrome 的机器上配 | 容器/CI 里没有 |
| `@assistant-ui/react-devtools` 只在 `import.meta.env.DEV` 引入 | 否则会打进生产包 |

## 7. 不做

| 不做 | 原因 |
|---|---|
| Storybook | 一个页面，DevTools + Playwright 够 |
| ESLint / Prettier | oxlint + oxfmt 已覆盖，见 04 §8 |
| 自建 skill 市场 / 插件系统 | 三个 skill，目录 + `SKILL.md` 就够 |
| 把每个 skill 都常驻 prompt | 那就失去 skill 的意义了；靠 description 触发 |
