# 12 · 待审批清单

每一条都是"我写过、但站不住或会跑崩"的东西。`状态` 三档：

- **CONTRADICTED** —— 与事实相反，必须改。
- **UNSAFE** —— 照抄会报错/不生效。
- **TRADEOFF** —— 不是错，是要你拍板的设计选择。

审计来源：B = 03 Docling（含活体 `/v1/capabilities`、docling-mcp 3.3.0 源码、`result.json`）；C = 04/10 前端（含 npm 包 `.d.ts` 实测）。A（01/02）与 D（05/07/08/09/11）仍在跑，回来后追加。

## 一、会直接跑崩（先批这些）

| ID | 位置 | 我写的 | 结论 | 证据 | 修法 |
|---|---|---|---|---|---|
| **B2** | 03 §3.2 | `json.loads(resp.json()["document"]["json_content"])` | CONTRADICTED | `result.json` 里 `json_content` 是**对象**（PSCustomObject），`responses.py` 定义也是 `DoclingDocument` | 直接返回该对象，去掉 `json.loads` |
| **B12** | 03 §7 / 02 §4.1 | 生产用 `--tools conversion` 收敛工具数 | CONTRADICTED | 逐文件数：conversion 5 / generation 11 / manipulation 5。`export_docling_document_to_markdown` 在 generation，三个 anchor 工具在 manipulation——**这一刀正好砍掉最常用的 4 个** | 删掉该建议；要收敛就在 Pydantic AI 侧用工具过滤 |
| **B18** | 03 §5 | `ocr_lang=["iso:zh"]` | CONTRADICTED | docling 2.142.1 `options.py`：`ocr_lang` 是 **BCP-47**（`zh-Hans`），全字段无 `iso:` 前缀 | 改 `["zh-Hans","en"]` |
| **C9** | 04 §3.2 | `<ThreadPrimitive.Composer />` | UNSAFE | `thread.d.ts` 导出里**没有** `Composer` | 用 `ComposerPrimitive.Root/Input/Send` |
| **C10** | 04 §3.2 | `<ThreadPrimitive.Messages />` 空标签 | UNSAFE | `Props` 是 `{components} \| {children}` 必选联合 | 必须传 `children={...}` 或 `components={{Message}}` |
| **C12** | 10 §4.1 | `import { DevTools }` | UNSAFE | 包只导出 `DevToolsModal` / `DevToolsPanel` | 改 `DevToolsModal` |
| **C27** | 04 §6 | `react({ babel: {...} })` "不生效且不报错" | CONTRADICTED | `Options` 接口无 `babel` 字段，TS 对象字面量会触发 excess-property 报错 | 改成"TS 下直接编译报错" |
| **C30** | 04 §6 | `reactCompilerPreset()` 内部已打包 babel 插件 | CONTRADICTED | 它是 optional **peer**，没打包 | 安装行补 `@babel/core` + `babel-plugin-react-compiler` |
| **C40** | 04 §8 | oxlint `plugins: [... "react-hooks"]` | UNSAFE | 无 `react-hooks` 插件名（hooks 规则在 `react` 下）；且 `plugins` 会**覆盖**默认集，静默关掉 `oxc`/`unicorn` | 去掉 `react-hooks`，显式补全列表 |

## 二、结论错但不崩

| ID | 位置 | 我写的 | 结论 | 证据 | 修法 |
|---|---|---|---|---|---|
| **B5** | 03 §2 | "公式列是空的"被当成 Docling 的行为 | OVERGENERALIZED | `msexcel_backend.py` 用 `data_only=True`——**Docling 就是读缓存值**。空是因为我的测试文件由 openpyxl 生成、没有缓存值 | 收窄为"无缓存值的文件会空；真实 Excel 另存的 xlsx 大概率正常"。副作用：**公式文本本身永远拿不到**，那是唯一需要 openpyxl（`data_only=False`）的地方 |
| **B4** | 03 §2 | "糊成一张连续文档，没有任何分隔标记" | OVERGENERALIZED | markdown 里是**三张独立表格**，缺的只是 sheet 归属 | 改成"表格边界在，sheet 归属不可恢复" |
| **B7** | 03 §3.1 | "`_cache` 在 site-packages，路径不稳定" | CONTRADICTED | `docling_cache.py:48` 支持 `CACHE_DIR` 环境变量，设了就用它 | 改成"设 `CACHE_DIR` 即有稳定路径，可挂载" |
| **B9** | 03 §7 | "3.3.0 正好跨过 MCP SDK v2 断点，所以钉它" | OVERGENERALIZED | 断点在 3.0.0；3.3.0 与 3.5.0 同在 v2 一侧，这条理由区分不了 | 换成"已验证的冒烟基线" |
| **B10** | 03 §7 | "3.4/3.5 动过工具签名，升级前看 MIGRATION" | CONTRADICTED | 3.4/3.5 只是**新增可选参数**（`page_no`、OCR），非 breaking；MIGRATION 讲的是 v1→v2 | 看 CHANGELOG；删掉"动过签名" |
| **B13** | 03 §7 | "21 个里 6 个有用、8 个编辑型" | CONTRADICTED（算术） | 其余是 15 个，不是 8 个 | 改成 6 有用 + 8 编辑 + 7 其他 |
| **B16** | 03 §1 | `GET /v1/health` 等四个都在 `/v1/` 下 | CONTRADICTED | `/health`、`/ready`、`/version` 是**顶层** | 改路径 |
| **B23** | 03 §1 | "`timings` 在这个版本是空对象" | OVERGENERALIZED | 未开 profiling 才是空，不是版本特性 | 加限定 |
| **B24** | 03 §2 | "耗时 0.75 秒" | CONTRADICTED（口径） | 服务端 `processing_time` 是 **7ms**；0.75s 是含上传的端到端 | 分开写 |
| **B25** | 03 全文 | Excel 方案同时出现三种 | CONTRADICTED（自相矛盾） | §2 写 openpyxl 直读、§3.3 写删掉 openpyxl、§3 写 Docling JSON | 只留一条 |
| **C5** | 04 §3.1 | `body` 可返回 object | 轻 | 签名要求 `Promise<object \| undefined>` | 写成 `async` |
| **C15** | 04 §2 | `react-markdown ^0.14.24` | 不一致 | 最新 0.14.25，10/README 都写 0.14.25 | 统一 |
| **C16** | 04/10 | 0.x 包用 `^` | 与自己的原则冲突 | 10 说"务必钉精确版本" | 改成精确版本号 |
| **C28** | 04 §6 | 安装只写两个包 | 漏装 | `@rolldown/plugin-babel` 把 `@babel/core` 列为非 optional peer | 补第三个 |
| **C31** | 04 §6 | 插件顺序"两说都有" | 含糊 | README 与 run-deck 都是 `react()` 先 | 写死 |
| **C33** | 04 §6 vs §11 | "先不上编译器" vs "先只靠 Compiler" | 自相矛盾 | 同文档两处 | 二选一 |
| **C34** | 04 §2 vs 10 §5 | 两份依赖清单不同 | 不一致 | 04 缺 zod/oxfmt/vitest/playwright/devtools | 合成一份 |
| **C37** | 04 §7 | `npx shadcn@latest add @assistant-ui/thread` | 非官方路径 | 官方是 `npx assistant-ui@latest add thread` | 改 |
| **C43** | 04 §8 | oxfmt "内置 import / tailwind 排序" | 需限定 | 这两项**默认关闭**，要显式开 | 加一句 |

## 三、要你拍板的设计选择（没有对错，只有取舍）

| ID | 选择 | 选项 | 我的建议 |
|---|---|---|---|
| **T1** | Excel 走哪条 | (a) Docling JSON 一路到底：MCP `convert` → `save_docling_document` → 挂 `CACHE_DIR` → 模型 `json.load`（**零自写解析代码**）<br>(b) 一条 12 行传输工具，直接返回 `json_content`（不依赖 MCP 缓存路径）<br>(c) openpyxl 直读（**已否**：只覆盖 xlsx，且 03 里那段从未实测） | **(a)**。B7 证明 `CACHE_DIR` 可控，于是"路径不稳定"这个反对理由消失了；这是唯一真正零代码、且不枚举格式的方案。(b) 作为 a 跑不通时的退路 |
| **T2** | 三个容器还是两个 | (a) 独立 `docling-mcp` 容器（http）<br>(b) api 里 `uvx` 起 stdio | **(a)**。`uvx` 忽略项目 `.python-version`，且首次联网拉包；跑在生产里不可复现 |
| **T3** | `sdk_version` | 5 / 6 / 7 | **7**。官方说 7 的 wire 等于 6，默认 5 会吞掉工具审批态且不报错 |
| **T4** | Commit 语言 | subject 英文 + body 中文 / 全中文 / 全英文 | 英文 subject + 中文 body |
| **T5** | dishka | 用 / 不用 | **不用**（只有一个 agent、一份配置、一个 toolset；`Agent.override` 覆盖测试需求） |
| **T6** | 前端 runtime 包 | (a) `@assistant-ui/ai-sdk` + `useChatRuntime`（当前）<br>(b) `@assistant-ui/react-data-stream` + `useDataStreamRuntime`（v4 legacy） | **(a)**。官方表格明写新项目用 v7；协议层不变，只换包 |
| **T7** | 会话历史放哪 | (a) client：浏览器持有，服务端无状态（删 02 §6/§8）<br>(b) server：`manage_message_history='server'` + 落盘 `history/` | **(a)** 给 MVP。等有登录/多设备再切 (b) |

## 五、D 审计（05 / 07 / 08 / 09 / 11）

| ID | 位置 | 我写的 | 结论 | 证据 | 修法 |
|---|---|---|---|---|---|
| **D1** | 05 §3 | `FROM ghcr.io/astral-sh/uv:python3.14-bookworm-slim` | CONTRADICTED（构建必失败） | 官方构建矩阵只有 `python3.14-trixie-slim` / `-trixie` / `-alpine`，**没有 bookworm 变体** | 改 `python3.14-trixie-slim`；§2 拓扑图里同一处也要改 |
| **D2** | 08 §3.2 / 11 §4 | `[tool.ruff.lint.flake8-todos] task-tags = [...]` | CONTRADICTED（配置解析失败） | 合法键是 `[tool.ruff.lint] task-tags`，没有 `flake8-todos` 子表 | 移到 `[tool.ruff.lint]` 下 |
| **D3** | 08 §6.6 | "`thread` 模式只报告、不中断，会继续等" | CONTRADICTED（反了） | 官方：`thread` 方法超时后 **`os._exit()` 杀掉整个进程**，没有 teardown、没有 JUnit | 改成"进程被杀，CI 表现为测试进程莫名退出"；真要防挂死用测试体内的 `asyncio.timeout()` |
| **D4** | 08 §6.3 | 不写 `asyncio_default_test_loop_scope` 会告警 | CONTRADICTED（张冠李戴） | 告警来自 `asyncio_default_fixture_loop_scope`；test 那个键不写就是 function，不告警 | 改注释；两个键仍都写上（无害且自解释） |
| **D5** | 08 §2.3 | "3.14 起 uv 会使用 free-threaded" | OVERGENERALIZED | 原文是"**允许**使用，GIL 版仍优先；只有 PATH 上 free-threaded 排在前面才用" | 改成"可能被选中；要确定性就 pin `3.14+gil`" |
| **D6** | 09 §3 | `@field_validator("server")` 里 `ensure_dirs` | UNSAFE（静默不执行） | `[server]` 整节缺失时用的是默认值，而 pydantic v2 **默认不校验默认值** | 加 `validate_default=True`，或把建目录挪到 `model_post_init` |
| **D7** | 05 §2 | "docling-mcp 依赖链还没跟上 3.14" | UNVERIFIED | PyPI 声明 `requires-python >=3.10`，未见 3.14 限制 | 删掉这个理由；拆容器是因为 **uvx 忽略项目 Python**，不是 docling 不支持 3.14 |
| **D8** | 11 §1.6 | commit 正则 `(feat\|fix\|docs\|style\|refactor\|perf\|test\|build\|ci\|chore)` | CONTRADICTED | type 表里有 `revert`，正则里没有 → 合法的 `revert: ...` 会被拒 | 补 `revert` |
| **D9** | 11 §1.6 | 白名单 `Merge ` / `Revert ` | UNSAFE（不全） | Git 默认还有小写 `merge branch 'x'`、`fixup!`、`squash!` | 白名单补 `^merge ` / `^fixup!` / `^squash!` |
| **D10** | 05 §4 | compose 里 `mem_limit: 4g` | TRADEOFF | Compose v2 仍支持，但官方推荐 `deploy.resources.limits` | 二选一，写明用的哪种 |
| **D11** | 05 §1 | `/volume1/docker/pychat`、"以 dpanel 习惯为准" | UNVERIFIED | 目标机上没有 compose project label，未验证该目录约定 | 标注"建议路径，未在目标机确认" |

## 六、A 审计（01 / 02）

| ID | 位置 | 我写的 | 结论 | 证据 | 修法 |
|---|---|---|---|---|---|
| **A1** | 01 §1/§2 · 04 全文 | 前端用 `@assistant-ui/react-data-stream` 的 `useDataStreamRuntime` | **CONTRADICTED（推翻选型）** | assistant-ui 官方 runtime 表：`ai@^4` → `react-data-stream`（v4 legacy，"no new features"）；`ai@^7` → **`@assistant-ui/ai-sdk`**（latest）。原文："New projects should target v7" | 改 `@assistant-ui/ai-sdk@0.0.17` + `useChatRuntime` + `ai@^7`。**协议不变**（pydantic 发的就是 v7 UI message stream），变的是客户端包 |
| A2 | 01 §2 | 响应头 `x-vercel-ai-ui-message-stream: v1` 是识别依据 | UNVERIFIED | pydantic 文档正文无此头；`UIEventStream.response_headers` 可自定义 | 删掉，别当协议依据 |
| **A7** | 01 §4 vs 02 §6/§8 | 01 说 client 模式、服务端无状态；02 却写 `history/*.json` + `asyncio.Lock` + `on_cancel` 落库 | **CONTRADICTED（自相矛盾）** | 两文档自身 | 二选一。MVP 建议 **client**：删 02 §6/§8 的落盘，服务端真无状态 |
| **A13** | 02 §4.1 | `from pydantic_ai.mcp import MCPToolset, StdioTransport` | **UNSAFE（ImportError）** | 官方 stdio 示例是 `from fastmcp.client.transports import StdioTransport`；`pydantic_ai.mcp` 无该符号 | 改导入路径 |
| A19 | 02 §3 vs §5 | `list_cached_documents` 既是我自建 capability 的 tool，又进 `CodeMode(tools=[...])` 的 MCP 名单 | UNSAFE（疑似同名冲突） | 两处同名 | capability 侧改名 |
| A26 | 02 §6 | "用 `sanitize_filename` 拼路径" | CONTRADICTED（不存在的 API） | Pydantic AI 无此函数 | 换成"正则白名单 + `Path.resolve()` 校验父目录" |
| **A28** | 02 §7 | `Agent(tool_timeout=120)` 兜住所有工具 | 设计缺陷 | 官方："Tool timeouts are enforced by `FunctionToolset` only… MCP server… read neither" | MCP 那条只有 `read_timeout`；表里要写清 |
| **A30** | 02 §8 | `ConversationTypeAdapter.dump_json(cancelled.conversation)` | **UNSAFE（AttributeError）** | `RunCancelled` 没有 `.conversation`，只有 `all_messages()` / `usage` / `conversation_id` | 用 `all_messages()` 自己拼 `Conversation` |
| A36 | 02 §4 | `## 4. MCP：…` 标题连续出现两次 | 文档缺陷 | 189/191 行重复 | 删一行 |
| **A37** | 02 §5 | "Code Mode 一轮搞定"，没提沙箱预算 | 设计缺陷（上线即可能踩） | 官方默认：执行 **30s**、堆 **256 MiB**、嵌套调用 **100** 次、`max_retries=3` | 写进 §5.3；大表遍历很可能撞 30s |
| A38 | 01 §5 | 论据是"`/v1/result` 的 OpenAPI schema 为空" | 论据可疑 | 未能证实；但结论（用 MCP）成立 | 换论据：docling-mcp 已封装 remote/local、缓存、anchor |
| A39 | 01 §5 | "工具数：0" | 易误读 | 实际仍有 1 个原生 `run_code` + 折叠的 docling 工具 | 改成"Excel 路径不新增工具" |
| A16/A17 | 02 §4.1 | "21 个工具、8 个编辑型、`--tools conversion`" | UNVERIFIED | README 未给这些数字；B12 已实测为 5/11/5 | 用实测数（见 B12），并**删掉 `--tools conversion`** |
| A12 | 02 §5.3 | JSON 化会转换 `Decimal`/`UUID`/`datetime` | VERIFIED，但漏例外 | `bytes`/`bytearray` 原样穿过 | 补一句 |

## 七、四份审计已全部回来

汇总：**会跑崩 13 条、结论错 18 条、待你拍板 7 条**。

最需要你先定的两条，因为它们改变架构而不是措辞：

1. **T6（前端 runtime 包）**：`@assistant-ui/ai-sdk` + `useChatRuntime`。协议层不用动。
2. **T7（历史放哪边）**：client（无状态，删 02 §6/§8）还是 server（改 01 §4）。



## 八、后续变更（2026-11-08）

T1 由 (a) 改为 (b)：转换不再走 docling-mcp，改为 `httpx2` 直接 POST docling-serve 的 `/v1/convert/file`。

- 新证据：MCP 只被 `direct_call_tool` 调两个固定工具，工具发现、参数 schema、让模型选工具这些价值全部没用上；同一个 stdio 会话还把上传串行化了。
- 实测 docling-serve 1.38.1 返回 `document.json_content`（已经是对象，`groups[].name` 里保留 sheet 名）和 `document.md_content`，与 (b) 的假设一致；`to_formats` 以重复字段（`{"to_formats": ["json", "md"]}`）提交。
- 副作用：`docling-mcp` / `docling-slim` / `docling-core` 三个依赖消失；`[docling].cache_dir` 删除；上传不再有进程内互斥锁。
- 保留：`DoclingConverter.convert(source, work_dir, doc_id)` 签名不变，`documents.py` 与上传/重试/删除接口未改。
