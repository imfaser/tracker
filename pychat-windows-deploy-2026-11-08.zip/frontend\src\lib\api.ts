export type DocumentEntry = {
  id: string;
  filename: string;
  size: number;
  kind: string;
  status: "ready" | "failed";
  uploaded_at: string;
  json_file: string | null;
  md_file: string | null;
  error: string | null;
};

type DocumentList = { documents: DocumentEntry[] };

async function json<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const text = await response.text();
    let detail = text;
    try {
      const parsed = JSON.parse(text) as { detail?: string };
      detail = parsed.detail ?? text;
    } catch {
      // Keep the raw body.
    }
    throw new Error(detail || `HTTP ${response.status}`);
  }
  return (await response.json()) as T;
}

export const fetchDocuments = (url: string): Promise<DocumentList> =>
  fetch(url).then((response) => json<DocumentList>(response));

export async function uploadDocument(file: File): Promise<DocumentEntry> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch("/api/documents", { method: "POST", body });
  return json<DocumentEntry>(response);
}

export async function deleteDocument(id: string): Promise<void> {
  const response = await fetch(`/api/documents/${id}`, { method: "DELETE" });
  await json<{ ok: boolean }>(response);
}

export async function reconvertDocument(id: string): Promise<DocumentEntry> {
  const response = await fetch(`/api/documents/${id}/reconvert`, { method: "POST" });
  return json<DocumentEntry>(response);
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MiB`;
}
