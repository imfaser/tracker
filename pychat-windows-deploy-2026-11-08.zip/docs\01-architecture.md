# 01 · 端到端架构

## 1. 全景

```
┌──────────────────────── Browser ────────────────────────┐
│  React 19 + Vite 8                                      │
│  ├─ TanStack Router       页面/路由（类型安全）          │
│  ├─ assistant-ui          聊天 UI 骨架（primitive）      │
│  │   └─ useDataStreamRuntime  ← 直接读 Vercel 数据流     │
│  ├─ SWR                   非流式数据（会话列表/文件列表） │
│  └─ shadcn/ui + Tailwind  组件与样式                     │
└──────────────────────┬──────────────────────────────────┘
                       │ POST /api/chat  (SSE, text/event-stream)
                       │ POST /api/files (multipart)
┌──────────────────────▼──────────────────────────────────┐
│  Python server (FastAPI + uvicorn)                      │
│  ├─ api/chat.py     VercelAIAdapter.dispatch_request()   │
│  ├─ api/files.py    上传 → openpyxl 摊平成 CSV → /data/work │
│  ├─ agent.py        Agent(config) + CodeMode(mount=/work) │
│  └─ config          pychat.toml（每个 agent 一份 model）  │
└───────┬───────────────────────────────┬─────────────────┘
        │ LLM (OpenAI 兼容 / DeepSeek 等)│ MCP (http 或 stdio)
        │                               ▼
        │                    ┌──────────────────────────┐
        │                    │ docling-mcp              │
        │                    │   └─ docling-serve :6029 │
        │                    └──────────────────────────┘
        │
        ▼
┌──────────────────────────────────────────────┐
│ 本地文件系统 /data                            │
│ uploads（原始文件）· work（CSV/meta）· history（会话 JSON）│
└──────────────────────────────────────────────┘
```

三层职责划得很干净：

- **前端只负责渲染流和交互**，不持有业务状态机，不做协议转换。
- **Python 只负责 agent 编排和文档理解**，不碰 UI。
- **Docling 只负责"文件 → 结构化文档"**，不做检索、不做问答。

## 2. 为什么是 Vercel AI Data Stream Protocol

这是整套方案里最关键的决策，值得说清楚。

### 被否掉的方案

| 方案 | 为什么不用 |
|---|---|
| 自定义 WebSocket 协议 | 前后端各写一套序列化；断线重连、取消、错误语义全靠自己发明；assistant-ui 的所有组件用不上 |
| 后端跑 Node BFF（AI SDK `streamText`） | 多一个进程、多一种语言、多一层转发；而 Pydantic AI 已经原生说这个协议了 |
| AG-UI / CopilotKit | Pydantic AI 也支持，但 AG-UI 的生态更偏 CopilotKit 全家桶；我们要的是"轻" |
| 纯 SSE 自己拼 JSON | 就是第一种方案的变体，同样的问题 |

### 事实依据

Pydantic AI 官方文档明确支持两种 UI 协议：AG-UI 和 **Vercel AI Data Stream**。后者由 `pydantic_ai.ui.vercel_ai.VercelAIAdapter` 实现，`dispatch_request()` 一句就能把 Starlette/FastAPI 的请求变成流式响应：

```python
@app.post('/api/chat')
async def chat(request: Request) -> Response:
    return await VercelAIAdapter.dispatch_request(
        request, agent=agent, sdk_version=7
    )
```

协议本体是 SSE：`data: {json}\n\n`，并且带响应头 `x-vercel-ai-ui-message-stream: v1`，前端据此识别。

### `sdk_version` 怎么选（重要）

从 Pydantic AI 的 API 文档里挖到的确切定义：

> `sdk_version: Literal[5, 6, 7] = 5`
> 默认 5 是为了向后兼容。设 6 会启用 tool approval 流（`approval-requested` 这类 v6 才有的状态）。**7 发出的 wire 与 6 完全相同**（v7 的 data-stream 协议等于 v6），接受 7 只是为了让配置反映客户端真实的大版本，并为将来 v7 独有的 chunk 预留。

结论：**显式写 `sdk_version=7`**。默认值 5 会让前端拿不到工具审批状态，而错误很难查——它不报错，只是少 chunk。

## 3. 一次对话的时序

```
用户: "帮我看下 budget.xlsx 里 Q3 的差旅超了多少"
 │
 ├─ assistant-ui Composer 组装 UIMessage（含附件引用）
 │
 ├─ POST /api/chat  {messages:[...], id, trigger}
 │      ▲ 整个历史由浏览器持有（默认 manage_message_history='client'）
 │
 ├─ VercelAIAdapter.build_run_input(body) → Pydantic AI 的 message_history
 │
 ├─ Agent.run_stream_events()
 │    ├─ run_code：Path('/work/9f3a1c').iterdir() → 汇总.csv / 明细.csv / _meta.json
 │    ├─ run_code：csv.reader 读「汇总」，定位 Q3 列，decimal 算差值
 │    ├─ 要文档原文时：Docling MCP 工具（convert → anchor 取片段）
 │    └─ 模型继续，边生成边发事件
 │
 ├─ 事件流 → Vercel chunk（text-delta / tool-input-available /
 │            tool-output-available / finish / [DONE]）
 │
 └─ 浏览器按 chunk 增量渲染；assistant-ui 的 primitive 自动处理
    打字机、工具卡片、错误、重试、分支
```

取消语义有两个，别搞混（文档里专门强调过）：

- **一方取消**（`ctx.cancel()`、`CancellationToken`、`timeout=`）→ 适配器发 `abort` chunk，前端保留半截消息。
- **浏览器 `stop()`** → 服务端只看到连接断开（`asyncio.CancelledError`），**不发 `abort`**。想要"停止按钮也走一方取消"，就得自己维护 token 注册表并暴露 `POST /api/chat/{id}/cancel`。

MVP 阶段接受第二种行为即可（用户点了停止，本来也不需要半截消息落库）。

## 4. 历史放在哪边

适配器有两个开关，默认值容易踩：

| 参数 | 默认 | 含义 |
|---|---|---|
| `manage_message_history` | `'client'` | 浏览器每次回传全量历史，服务端无状态 |
| `manage_system_prompt` | `'server'` | 系统提示由服务端注入，客户端传来的 system 会被剥掉 |

**MVP 用默认值（client）**：服务端无状态，扩副本不用协调。

代价是历史完全由客户端控制 —— 文档也明说了这是个信任边界：`messages` 数组不可信，适配器会剥掉不该有的 part，但**工具返回值、审批结果会随历史回传**。所以：

- 工具结果里不要放"能凭它越权"的东西（比如完整文件系统路径、内部 token）；
- 想上多用户/权限，就切 `manage_message_history='server'`：适配器只取本轮新增的 user message，历史从本地 `history/` 读。这条路需要 `conversation_id`。

## 5. 文件解析：只有一条通道，三种调用方

原则：**不写 Docling 的 HTTP 客户端**。docling-mcp 已经把转换、缓存、按 anchor 取片段、带 `max_size` 的 markdown 导出都实现完了，再手写一遍是给一个连 OpenAPI 都没写清字段的接口（`/v1/result/{task_id}` 的 schema 是空的）做适配层。

同一个 `MCPToolset`，按场景有三种调用方式：

| 调用方 | 用哪个 | 何时用 |
|---|---|---|
| 代码（预处理） | `toolset.direct_call_tool()` | 上传即解析，确定性、可重试、与模型无关 |
| 模型（Code Mode） | `run_code` 里的工具函数 | 对话中"读一下这个文件/链接"，模型自己决定看哪、看多少 |
| 模型（裸挂） | `Agent(toolsets=[docling])` | 调试，看模型会怎么用这些工具 |

**Code Mode 是让这条路成立的关键**。裸挂 MCP 时，`export_docling_document_to_markdown` 的返回值直接进上下文，一次几千到几万 token；套上 `CodeMode` 后，模型写一段 Python 在沙箱里 `convert → 看 overview → 只取命中那段`，上下文里只进它 return 的那几百字。

### Excel 不配"工具"，配"工作目录"

Docling 的 markdown 丢 sheet 名、公式列是空（实测，见 03）。但解决办法**不是**再给模型加 `list_sheets` / `read_sheet` 这类工具——那是把"读表格"当成一次性原子操作，模型只能按你设计好的粒度问。

`CodeMode` 有 `mount`：

```python
CodeMode(
    mount=MountDir(virtual_path='/work', host_path='/data/work', mode='read-only'),
)
```

沙箱里 `pathlib`、`csv`、`json`、`decimal` 都能用（Monty 允许这些 stdlib）。所以正确做法是：

1. 上传时用 `openpyxl` 把 xlsx **预处理**成每个 sheet 一个 CSV + 一个 `_meta.json`（sheet 名、行列数、公式原文），落到 `/data/work/<doc_id>/`；
2. 模型在 `run_code` 里 `Path('/work/<doc_id>').iterdir()` 看有哪些 sheet，`csv.reader` 读它想要的那张，`decimal` 自己算差值。

**工具数：0。** 模型拿到的是"一个目录"，不是"一个我只能按你设计的方式调用的函数"。这正是你担心的那点——Python 能读 CSV、能算数，别把它挡在工具背后。

细节见 [03 §3](./03-docling-documents.md)。

## 6. 模块边界（建议的目录）

```
pychat/
├─ server/
│  ├─ pyproject.toml            # uv 管理，requires-python >=3.14
│  ├─ uv.lock
│  ├─ src/pychat/
│  │  ├─ main.py               # FastAPI app 装配
│  │  ├─ config.py             # AppConfig / ModelConfig / AgentConfig
│  │  ├─ api/
│  │  │   ├─ chat.py           # VercelAIAdapter 入口
│  │  │   └─ files.py          # 上传 + 预处理
│  │  ├─ agent.py              # build_agent(config, docling)
│  │  ├─ capabilities/         # Capability 单元（可 defer_loading）
│  │  ├─ ingest/excel.py       # openpyxl → 每 sheet 一个 CSV（预处理）
│  │  └─ store/history.py      # Conversation 存本地 JSON
│  └─ tests/
│     ├─ unit/                 # 纯函数、预处理
│     ├─ integration/          # 起 app + 假 MCP
│     └─ contract/             # 协议契约（SSE chunk）
├─ frontend/                   # 见 04
├─ data/
│  ├─ uploads/                 # 原始文件
│  ├─ work/                    # 预处理产物（挂给沙箱）
│  └─ history/                 # 会话 JSON
├─ deploy/compose.yaml
└─ docs/
```

对比我上一版删掉的东西：`clients/docling.py`（不该写）、`ingest/dispatch.py`（路由只有四行，放 `files.py` 里）、`ingest/office.py`（Docling 由 MCP 管，没有本地实现）。

## 7. 部署拓扑

一个对外端口就够：

```
Internet/LAN ──► :6032  nginx (静态 SPA + /api 反向代理)
                   └─► api:8000 (FastAPI, 容器内网)
                          ├─► 192.168.16.24:6029 (docling-serve)
                          └─► /data  (uploads / work / history 三个子目录)
```

pgvector 是第二期的事（做 RAG 才需要），MVP 不连数据库。

细节见 [05-deployment.md](./05-deployment.md)。

## 8. 上下文怎么控：Code Mode 就是答案

上一版这里留了个"要不要把解析结果塞进上下文"的开放问题——**现在不需要讨论了**，因为 Code Mode 加 mount 已经把它变成实现细节：

- 预处理产物落盘（CSV / markdown），**不主动进上下文**；
- 模型在 `run_code` 里按需读、按需过滤，`return` 什么就只进什么；
- Docling 的转换结果同理：`convert → overview → 取一段`，全程在一个沙箱里跑完。

所以设计上要守的只有一条：**任何工具/文件都不允许"默认全量返回"**。目录给出去，让模型自己切。

