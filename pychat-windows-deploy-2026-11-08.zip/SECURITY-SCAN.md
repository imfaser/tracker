# 敏感信息扫描报告

- 日期：2026-11-08
- 工具：gitleaks 8.30.1（`gitleaks dir`，默认规则集）
- 源码树：168 个文件 / 约 1.20 MB，排除 `node_modules`、`.venv`、`data`、`dist`、`.git`、`.openchamber`

## 结果

**0 条命中。**

补充扫描与说明：

- `server/.env` 存在，但当前内容为 `MIMO_API_KEY=`（空值），没有写入任何密钥。
- 本机实际使用的密钥来自 Windows 环境变量 `MIMO_API_KEY`，不在任何文件里。
- NAS 上的密钥在 `/vol2/1000/app/pychat/.env`（权限 600），不在本压缩包内。
- 对 `server/` 目录做全量扫描（约 75 MB，包含 `.venv`）命中 2 条，均为第三方库里的占位字符串，不是项目密钥：
  - `server/.venv/Lib/site-packages/google/protobuf/descriptor_pb2.py`
  - `server/.venv/Lib/site-packages/openai/_client.py`
- 本压缩包已排除：`.env`、`data/`、`node_modules/`、`.venv/`、`dist/`、`.git/`、`.openchamber/`。

## 建议

如果这份会话记录会被分享，建议在模型服务商后台轮换 `MIMO_API_KEY`：该值曾在一次 `docker inspect` 的终端输出中出现。轮换后同步更新本机环境变量和 NAS 的 `/vol2/1000/app/pychat/.env`，再重启容器。

## 复现

```powershell
gitleaks dir . --redact --no-banner
```
