import { CalculatorIcon, FileSearchIcon, ListIcon, type LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'

export interface Suggestion {
  icon: LucideIcon
  label: string
  prompt: string
}

// pychat answers questions about the uploaded spreadsheets and documents, so
// the starters point at the data rather than at the agent itself.
const DEFAULT_SUGGESTIONS: Suggestion[] = [
  { icon: ListIcon, label: '有哪些文档？', prompt: '现在有哪些文档可以查？' },
  { icon: CalculatorIcon, label: '汇总一张表', prompt: '汇总一下 ' },
  { icon: FileSearchIcon, label: '查找条款', prompt: '这份文件里关于 ' },
]

interface WelcomeScreenProps {
  onSelect: (prompt: string) => void
  /** The composer, rendered inline so an empty chat opens on one centred column. */
  composer?: ReactNode
  suggestions?: Suggestion[]
}

/**
 * First-run view for an empty conversation. An empty chat with only a text box
 * gives no sense of what the agent is for, so this states the purpose, puts the
 * composer where the eye already is, and offers a few one-click ways in.
 */
export function WelcomeScreen({ onSelect, composer, suggestions = DEFAULT_SUGGESTIONS }: WelcomeScreenProps) {
  return (
    // The padding sits on the children rather than here: the composer brings its
    // own, and the same box it occupies on this screen it occupies once the
    // conversation starts — otherwise it visibly narrowed on the first send.
    <div className="animate-fade-in mx-auto flex w-full max-w-3xl flex-col items-center text-center">
      {/* h2: the header's conversation title is the page's h1. */}
      <h2 className="px-4 text-2xl font-semibold tracking-tight text-balance sm:text-3xl">有什么可以帮你？</h2>
      <p className="text-muted-foreground mt-2 max-w-md px-4 text-sm text-balance">
        上传 Excel / Word / PDF，然后直接问。数字来自文件，Excel 公式只读取缓存值。
      </p>

      {composer && <div className="mt-7 w-full">{composer}</div>}

      <ul className="mt-5 flex flex-wrap justify-center gap-2 px-4">
        {suggestions.map((suggestion) => (
          <li key={suggestion.label}>
            <button
              type="button"
              onClick={() => {
                onSelect(suggestion.prompt)
              }}
              className="text-muted-foreground hover:border-primary/40 hover:bg-accent/50 hover:text-foreground focus-visible:ring-ring flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition-colors focus-visible:ring-2 focus-visible:outline-none"
            >
              <suggestion.icon className="text-primary size-3.5" />
              {suggestion.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
