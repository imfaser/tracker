# 07 · MVP 边界、验收与风险

## 1. 范围

### P0 —— 不做完就不能叫 MVP

| # | 能力 | 完成标志 |
|---|---|---|
| 1 | chat 流式对话 | 浏览器里逐字出字，不是一次性刷出 |
| 2 | 上传 xlsx / docx / pdf | 落盘 `data/uploads/<id>.<ext>`，返回 id 和 url |
| 3 | Docling MCP 接入 | 模型能调 `convert_document_into_docling_document` 拿到 document_key |
| 4 | Code Mode | 模型一次 `run_code` 里完成"转换 + 定位 + 只取片段" |
| 5 | Excel 直读工具 | 问"有几个 sheet / Q3 多少"能答对 |
| 6 | 单页 UI | 一个页面：消息流 + 输入框 + 上传按钮 |

### P1 —— 能明显提升体验，但不阻塞

- 会话落盘与重新载入（`Conversation.dump_json` → `/data/history`，见 02 §6）
- 前端会话列表：读 `/data/history` 的文件名 + 首条消息
- 文件列表 / 删除 / 重新解析
- 停止按钮走一方取消（token 存内存；多副本时再换共享存储）
- markdown 表格/代码高亮美化（`@assistant-ui/react-markdown` + shiki）
- 错误态：docling 超时、文件过大、模型 429

### P2 —— 有价值但先别做

- 登录 / 多用户 / 配额
- React Compiler、TanStack Start SSR
- 观测：Phoenix OTLP
- 移动端适配
- 文档多到装不进上下文时的检索层（到时候再选型，现在没有向量库）

### 明确不做

多租户 RBAC、插件市场、语音、视频解析、Excel 写回、自有模型训练。

## 2. 验收标准（可机械验证）

| 场景 | 期望 |
|---|---|
| 上传 6 KB 的 2 sheet xlsx，问"几个 sheet" | 回答含 `2`，且提到 `汇总` / `明细` 两个名字 |
| 同一个文件，问"销售 Q3 多少" | `143000`（模型在沙箱里读 `/work/<id>/汇总.csv` 算出来，不是 Docling） |
| 上传 docx，问"第 2 节讲什么" | 内容来自 Docling 的 markdown，不是模型编的 |
| 上传一张中文扫描图 | OCR 出中文；乱码率可接受（人工判） |
| 发一条长问题 | 首字节 < 2 s，之后持续有增量 |
| 上传 20 MB PDF | 不出现 500；要么成功，要么有明确错误提示 |
| 点停止 | 前端立即停止渲染（不要求落库） |

前两条是**回归红线**：只要"上传 → 摊平 CSV → 模型读出正确数字"这条链断了，Excel 就是假的。

## 3. 风险表

按"会不会让 MVP 失败"排序，不是按发生概率。

| # | 风险 | 概率 | 影响 | 缓解 |
|---|---|---|---|---|
| 1 | **Docling 的 Excel 保真度不够**（sheet 名丢、公式空、合并单元格错位） | 已发生（实测） | 高 | 数值问答走 `excel_tools`（openpyxl），Docling 只负责版面；产品文案不要说"完整还原 Excel" |
| 2 | `docling-serve-cpu` 没装 LibreOffice，`.doc/.xls/.rtf` 全挂 | 中 | 中 | 部署前打一次 legacy 文件；不行就在 UI 里明确拒绝这类格式 |
| 3 | `pydantic-ai-harness` 是 0.x，`CodeMode` API 变动 | 中 | 中 | 钉 `==0.66.0`；契约测试；升级单独一个 PR |
| 4 | Pydantic AI ↔ AI SDK 7 协议漂移 | 低 | 高（前端静默白屏） | `sdk_version=7` 显式写；契约测试断言 `finish` chunk |
| 5 | assistant-ui 还是 0.15，primitive 组合方式会变 | 中 | 低 | 用官方 registry 组件（`npx shadcn add @assistant-ui/thread`），别手拼 |
| 6 | docling 并发差，几个人同时上传就排队 | 中 | 中 | 压测 3/5/10 并发；必要时加队列 + "解析中"状态 |
| 7 | 上传文件没有 GC，磁盘涨 | 高 | 低 | 第二期加 TTL；现在加一条 cron 清理 7 天前的 |
| 8 | 中文 OCR 默认 `auto` 引擎选错 | 中 | 中 | 显式 `ocr_preset=rapidocr` + `ocr_lang=["iso:zh","iso:en"]`，拿真实扫描件验 |
| 9 | 模型上下文被整篇文档撑爆 | 高（不治） | 高 | Code Mode 过滤；工具返回片段不返回全文；P1 上 RAG |
| 10 | 多 worker 下取消/会话状态错乱 | 低（单 worker） | 中 | 先单 worker；要扩副本再说 |

### 最需要提前说清的一条

风险 1 不是"技术债"，是**产品预期**。如果评审时对"用 AI 读 Excel"的想象是"它能看懂那张表里的所有东西"，那这个 MVP 会让人失望。实际能力是：

- 你能问"Q3 销售多少" —— 能。
- 你能问"这个表做得有没有问题" —— 勉强（版面能看，公式丢了）。
- 你能问"帮我把这张表改成另一种样式" —— 不能（Docling 只读）。

先把这句话对齐，后面都好谈。

## 4. 待你拍板的 5 件事

| # | 问题 | 选项 | 我的倾向 |
|---|---|---|---|
| 1 | 用哪个模型 | `deepseek:deepseek-v4.1-flash` / `openai:...` / 本地 ollama | 先用 DeepSeek，便宜且中文好；`PYCHAT_MODEL` 已可切 |
| 2 | 要不要登录 | 不登录（内网）/ 简单口令 / 真用户体系 | MVP 不登录，但上传目录按 IP+时间分桶，避免互相看到 |
| 3 | 文件留多久 | 永久 / 7 天 / 会话结束即删 | 7 天 + 手动清空 |
| 4 | 代码放哪 | 直接 scp / gitea(6011) | gitea，顺手有 CI 钩子 |
| 5 | 端口 | 6032 / 别的 | 6032（实测空闲） |

## 5. 工期（粗估，不含评审等待）

| 阶段 | 内容 | 人日 |
|---|---|---|
| A | 后端骨架 + chat 流式 + 契约测试 | 1 |
| B | 上传 + Docling MCP + Code Mode 跑通 | 1–1.5 |
| C | Excel 工具 + 提示词调优 | 0.5–1 |
| D | 前端（assistant-ui + 上传 + markdown） | 1–1.5 |
| E | Docker 打包 + 部署 + 验收清单 | 0.5 |
| 合计 | | **4–5.5 人日** |

真正的变数在 B：docling-mcp 在容器里跑通、文件回取（URL）、首次下载缓存。这三件事顺利就 1 天，不顺利能拖到 3 天。

## 6. 已经能开始的第一件事

不是写代码，是打三个电话/三次验证：

```bash
# 1. legacy Office 到底能不能转
curl -s -F "files=@test.doc" -F "to_formats=md" \
  http://192.168.16.24:6029/v1/convert/file | head -c 400

# 2. 带公式缓存的真实 Excel，合计列能不能读出来
#    （用 Excel 另存的 xlsx，不是 openpyxl 生成的）

# 3. 中文扫描件 OCR
curl -s -F "files=@invoice.jpg" -F "to_formats=md" \
  -F "ocr_preset=rapidocr" -F "ocr_lang=iso:zh,iso:en" \
  http://192.168.16.24:6029/v1/convert/file | head -c 800
```

这三条结果决定 03 里那张"输入格式"表哪些要打折，也决定 P0 里的"上传支持哪些格式"。
