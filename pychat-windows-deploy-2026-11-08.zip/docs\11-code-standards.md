# 11 · 代码规范：Commit、Docstring、注释

AI 写代码最大的问题是**没有固定标准**：同一个仓库里两种 docstring 风格、commit 一会儿 `fix bug` 一会儿 `feat: xxx`。所以规范不自己发明，引两份现成的，能机器卡的交给 ruff。

- Commit：[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/)
- Docstring：[Google Python Style Guide §3.8](https://google.github.io/styleguide/pyguide.html#38-comments-and-docstrings)

## 1. Commit message

### 1.1 格式（规范原文）

```
<type>[optional scope]: <description>

[optional body]

[optional footer(s)]
```

三条硬规则（原文的 MUST）：

1. 必须以 type 开头，后面是可选 scope、可选 `!`、**必需的冒号 + 空格**。
2. `feat` 只能用于新功能，`fix` 只能用于修 bug。
3. 破坏性变更用 `!` 或 `BREAKING CHANGE:` footer 标出。

### 1.2 本仓库的 type 与 scope

| type | 用在哪 |
|---|---|
| `feat` | 新功能（新端点、新能力） |
| `fix` | 修 bug |
| `docs` | 只改文档 |
| `refactor` | 不改行为的重构 |
| `perf` | 性能 |
| `test` | 测试 |
| `build` | 依赖、Dockerfile、pyproject |
| `ci` | CI 配置 |
| `chore` | 杂项（清缓存、改 ignore） |

scope 用目录或模块名，小写：`chat` / `files` / `ingest` / `config` / `agent` / `ui` / `deploy` / `docs`。

### 1.3 写法

- description：**祈使句、小写开头、句尾不加句号**，≤ 72 字符。
- body：说**为什么**，别复述 diff。每行 72 换行。
- footer：`BREAKING CHANGE:`、`Refs:`、`Closes:`。

### 1.4 语言

选一个，别混：

**推荐：type/scope/subject 用英文，body 可用中文。**

理由不是审美——changelog 生成器、commit 校验、`git log --grep` 都按英文 type 工作；而 body 是给人看的，中文更省事。

```
feat(ingest): flatten xlsx into per-sheet csv

Docling 的 markdown 会丢 sheet 名和公式缓存值，所以上传时用 openpyxl
自己摊平，模型在 CodeMode 的 mount 里读 CSV。

Refs: #12
```

### 1.5 好 / 坏对照

```
# 坏
fix bug
update code
feat: 修改了一些东西。
Fix: Add New Feature

# 好
fix(chat): emit abort chunk on first-party cancel
feat(config): load per-agent model from toml
docs(03): record measured xlsx behaviour
refactor(agent): drop dishka, build agent from config
build: bump pydantic-ai to 2.66.0
```

### 1.6 机器卡住它

零依赖做法：一个 `commit-msg` hook。

```bash
mkdir -p .githooks
cat > .githooks/commit-msg <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
msg_file="$1"
first=$(head -n1 "$msg_file")

# 允许 merge / revert 的默认消息
case "$first" in
  "Merge "*|"Revert "*) exit 0 ;;
esac

pattern='^(feat|fix|docs|style|refactor|perf|test|build|ci|chore)(\([a-z0-9._/-]+\))?!?: .{1,72}$'
if ! printf '%s' "$first" | grep -Eq "$pattern"; then
  echo "✗ commit message 不合规：" >&2
  echo "  $first" >&2
  echo "  期望：<type>(<scope>): <subject>" >&2
  echo "  例：  feat(ingest): flatten xlsx into per-sheet csv" >&2
  exit 1
fi
EOF
chmod +x .githooks/commit-msg
git config core.hooksPath .githooks
```

`core.hooksPath` 要提交到仓库说明里（或写进 `AGENTS.md`），否则别人 clone 下来不会生效。

想要现成的：`conventional-pre-commit`（pre-commit 生态）也行，但那就多一个 Node/Python 运行时依赖。上面 20 行够用。

## 2. Docstring：Google 风格

### 2.1 什么时候必须有（原文）

> A docstring is mandatory for every function that has one or more of the following properties:
> **being part of the public API**, **nontrivial size**, **non-obvious logic**.

反过来：一行的、名字自解释的私有函数，不要硬写 `"""Return x."""`——那是噪声。

### 2.2 结构

- 第一行一句话摘要，句号结尾。
- `Args:` / `Returns:` / `Yields:` / `Raises:` / `Attributes:` 各自成段，标题行以冒号结尾。
- 段落内缩进 2 或 4 空格，**同一文件内保持一致**。
- **有类型注解就别在 docstring 里重复类型**（原文：description "should include required type(s) if the code does not contain a corresponding type annotation"）。
- 只返回 `None` 时省略 `Returns:`。
- `Yields:` 描述 `next()` 返回的对象，不是生成器本身。
- 不要文档化"调用方违反 API 时才抛"的异常。

风格二选一，**同一文件内统一**：描述式 `"""Fetches rows."""` 或祈使式 `"""Fetch rows."""`。

### 2.3 本项目的例子

```python
def extract_workbook(src: Path, out_dir: Path) -> WorkbookMeta:
    """Flatten an xlsx workbook into one CSV per sheet plus a meta file.

    Spreadsheet names and formula text are preserved in ``_meta.json``
    because Docling's markdown export drops both.

    Args:
        src: Workbook to read. Must have an ``.xlsx`` or ``.xlsm`` suffix.
        out_dir: Directory to write ``<sheet>.csv`` and ``_meta.json`` into.
            Created if missing.

    Returns:
        Sheet names, dimensions, merged ranges, and formula cells per sheet.

    Raises:
        ValueError: If ``src`` is not a readable Excel container.
    """
```

```python
class DoclingConfig(BaseModel):
    """Where the Docling MCP server and its backend live.

    Attributes:
        mcp_url: Streamable HTTP endpoint. Empty means spawn the stdio server.
        service_url: docling-serve base URL the MCP server forwards to.
    """
```

注意 `extract_workbook` 里那句"为什么"——**docstring 解释契约，注释解释取舍**。Docling 丢 sheet 名这件事属于取舍，不该写进 `Returns:`。

## 3. 注释：只写"为什么"

Google 的原话最狠：

> On the other hand, **never describe the code**. Assume the person reading the code knows Python (though not what you're trying to do) better than you do.

翻译成可执行的规则：

| 该写 | 不该写 |
|---|---|
| 为什么这样而不是那样 | 这行代码在干什么 |
| 外部系统的坑（Docling 丢 sheet 名） | `# 遍历 rows` |
| 不变量（"这里必须只读"） | `# 定义变量` |
| 反直觉的性能取舍 | 把函数名翻译一遍 |

对照（AI 最常写出的那种"教程味"）：

```python
# 坏：描述代码，读者看得懂
# 循环遍历每一行
for row in rows:
    ...

# 坏：教程式旁白
# 首先我们导入 openpyxl，然后加载工作簿
wb = load_workbook(src, data_only=True)

# 好：解释取舍
# data_only=True 读的是 Excel 保存时缓存的计算结果；
# openpyxl 新生成、没被 Excel 打开过的文件这里是空的。
wb = load_workbook(src, data_only=True)
```

其他规则：

- 行内注释与代码间隔至少 2 空格：`x = 1  # 单位是秒`。
- 完整句子，首字母大写，带标点。
- TODO 带归属：`# TODO(imfaser): 支持 .xlsm`，配 ruff 的 `TD` 规则。
- **不要留注释掉的代码**（ruff `ERA001`），要留就删掉，历史在 git 里。
- 注释语言：中文可以，但**术语保留英文**（`sheet`、`mount`、`SSE`），别自造译名。

## 4. 交给 ruff 卡

```toml
[tool.ruff.lint]
select = [
  "E4","E7","E9","F","I","UP","B","SIM","ASYNC","FAST","PT","RUF100",
  "D",      # pydocstyle
  "ERA001", # 注释掉的代码
  "TD",     # TODO 格式
  "FIX",    # FIXME
]
ignore = [
  "E501", "PT011",
  "D100",   # 模块 docstring（小模块不需要）
  "D104",   # 包 __init__
  "D105",   # 魔术方法
  "D107",   # __init__（类 docstring 已描述）
]

[tool.ruff.lint.pydocstyle]
convention = "google"

[tool.ruff.lint.flake8-todos]
task-tags = ["TODO", "FIXME"]
```

`convention = "google"` 让 D 规则按 Google 的段落名与缩进检查，不是泛泛的 PEP 257。

## 5. 给 AI 的四条硬规矩

1. **先看邻居再下笔**：同一目录里已有的 docstring 是描述式还是祈使式、注释用中文还是英文，照着写。仓库一致性 > 个人偏好。
2. **不许混风格**：一个文件里不能既有 `"""Fetch rows."""` 又有 `"""Fetches rows."""`。
3. **注释只写"为什么"**：写不出"为什么"，说明这行不需要注释。
4. **一次提交只做一件事**：`refactor` 和 `feat` 不要挤在一个 commit 里，否则 revert 会把功能一起带走。

## 6. 提交前自检

```bash
uv run ruff format .
uv run ruff check --fix .
uv run ty check
uv run pytest -m "not integration"
git log --oneline -5        # 看最近 5 条，格式对不对
```

最后一条比前四条都管用——**看邻居**。
