# 08 · 工程化：uv / ruff / ty / pytest

这篇回答"配置用什么、测试怎么分、超时怎么办"。目标是**一套能跑、能卡、不过度**的子集。

## 1. 一页命令表

```bash
# 初始化
uv init --app .                          # 已存在 pyproject 则跳过
uv python pin 3.14                       # 写 .python-version
uv add "pydantic-ai-slim[openai,mcp]" "pydantic-ai-harness[codemode]" \
       fastapi "uvicorn[standard]" python-multipart pydantic-settings openpyxl
uv add --dev pytest pytest-asyncio pytest-timeout ty
uv add --group lint ruff

# 本地日常
uv sync
uv run uvicorn pychat.main:app --reload
uv run ruff format . && uv run ruff check --fix .
uv run ty check
uv run pytest

# CI / 镜像（可复现）
uv sync --locked --no-dev
uv run --frozen ruff format --check .
uv run --frozen ruff check .
uv run --frozen ty check
uv run --frozen pytest -m "not integration"
```

## 2. uv

### 2.1 三块配置各管什么

| 位置 | 管什么 |
|---|---|
| `[project].dependencies` | 发布依赖（PEP 621） |
| `[dependency-groups]` | **本地开发依赖**（PEP 735），不进发布元数据 |
| `[tool.uv]` | uv 私有：`package`、`default-groups`、`sources`、`workspace`… |

dev 依赖只有一个正确写法：`uv add --dev X` 会写进 `[dependency-groups].dev`。**不要再手写 `[tool.uv].dev-dependencies`**——官方标注"eventually will be deprecated and removed"。

`dev` 组默认参与 sync；想把 lint 工具单独拆一组，用 `uv add --group lint ruff`。

### 2.2 `sync` 的三个开关，别混用

| 命令 | 语义 | 用在哪 |
|---|---|---|
| `uv sync` | 默认 **exact**：删掉环境里多余的包 | 本地 |
| `uv sync --locked` | **断言**锁文件是最新的，否则报错 | CI、Docker |
| `uv sync --frozen` | 不检查锁是否最新，以锁为唯一事实 | 只在明确知道锁过期时 |
| `uv sync --no-dev` | 排除 dev 组 | 生产镜像 |
| `uv sync --no-install-project` | 只装依赖，不装项目 | Docker 分层第一步 |

`uv run` 会先 lock + sync（默认 **inexact**，不删多余包）。所以本地永远用 `uv run`，别去激活 venv 再 `uv pip install`——官方原文："It is *not* recommended to modify the project environment manually"。

### 2.3 Python 3.14 的两个细节

- **`requires-python` 要自己写**。`uv python pin 3.14` 只生成 `.python-version`（"实际选哪个"），不会改 `requires-python`（"允许哪些"）。
- **3.14 起 uv 会在没有显式指定的情况下使用 free-threaded 解释器**（3.13 的 `t` 变体不会）。我们依赖不少 C 扩展，建议在需要时把 pin 写成 `3.14+gil`，避免某台机器拿到 free-threaded 版导致轮子缺失。写进文档就有人会踩。

### 2.4 `uvx` 不等于项目环境

官方原文：工具环境**忽略 `.python-version` 和 `requires-python`**。

这对我们有两个直接后果：

1. 在 3.14 的 api 镜像里 `uvx --from=docling-mcp`，跑起来的**不是 3.14**；
2. `uvx` 首次会取**最新版**再缓存，版本不可复现。

所以生产拆成独立容器 + `uv tool install "docling-mcp==3.3.0"`（见 05）。开发期用 `uvx` 无所谓，但把版本钉上。

### 2.5 Docker

官方姿势（和我在 05 里写的一致）：

```dockerfile
COPY --from=ghcr.io/astral-sh/uv:0.13.7 /uv /uvx /bin/
ENV UV_COMPILE_BYTECODE=1 UV_LINK_MODE=copy UV_NO_DEV=1
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --locked --no-install-project
COPY . /app
RUN --mount=type=cache,target=/root/.cache/uv uv sync --locked
```

三条容易漏的：

- `.venv` 必须进 `.dockerignore`（它是平台相关的，镜像里要重建）。
- `UV_LINK_MODE=copy`：cache mount 和 `.venv` 在不同文件系统，不加会打一堆 warning。
- `uv.lock` **必须进 git**，它是跨平台的 universal lock。

## 3. ruff

### 3.1 `check` 和 `format` 的分工

| 命令 | 做什么 |
|---|---|
| `ruff check --fix` | lint + 安全修复 |
| `ruff format` | 格式化，Black 的 drop-in 替代 |

**`ruff format` 不排 import**。要排就 `ruff check --select I --fix` 再 format。官方明确不要和 Black 交替使用。

### 3.2 规则集：显式选择，别开 `ALL`

`select = ["ALL"]` 的问题是"升级 ruff 就会突然多出新规则"，而且会撞上互相冲突的 pydocstyle 规则。整类开 `E`/`W` 也会引入 `E5xx`/`W191` 这些**和 formatter 冲突**的规则。

我们的集合（每个都有明确理由）：

```toml
[tool.ruff.lint]
select = [
  "E4", "E7", "E9",  # pycodestyle 里真正报错的那部分
  "F",               # Pyflakes：未用导入 / 未定义名
  "I",               # isort：formatter 不排序 import
  "UP",              # pyupgrade：3.14 下把老写法现代化
  "B",               # bugbear：可变默认值这类陷阱
  "SIM",             # simplify：可简化写法
  "ASYNC",           # ★ async 函数里调阻塞 API
  "FAST",            # ★ FastAPI 专用三条
  "PT",              # ★ pytest 写法
  "RUF100",          # 清理失效的 noqa
  "D",               # ★ docstring（Google 风格，见 11）
  "ERA001",          # ★ 注释掉的代码
  "TD",              # ★ TODO 格式
  "FIX",             # ★ FIXME
]
ignore = [
  "E501",   # 行长交给 formatter；E501 只是 best-effort
  "PT011",  # pytest.raises 强制 match：初期噪声大，稳定后再开
  "D100",   # 模块 docstring：小模块不强制
  "D104",   # 包 __init__
  "D105",   # 魔术方法
  "D107",   # __init__（类 docstring 已描述）
]

[tool.ruff.lint.pydocstyle]
convention = "google"

[tool.ruff.lint.flake8-todos]
task-tags = ["TODO", "FIXME"]
```

带 ★ 的三组是这个技术栈的正收益：`ASYNC` 能在 CI 阶段抓住"在 async 端点里同步读文件"，`FAST` 抓 FastAPI 的 `response_model`/`Annotated` 误用，`PT` 抓 `pytest.raises` 过宽。

`per-file-ignores` 给测试放宽：`"tests/**" = ["S101", "PT"]`。

### 3.3 版本要钉

```toml
[tool.ruff]
required-version = ">=0.17,<0.18"
```

否则不同机器上的 ruff 判定不一致，CI 和本地会打架。

## 4. ty：能用，但别当唯一门禁

现状（官方 README 原文）：

> **ty is currently in beta.** ty uses `0.0.x` versioning. ty does not yet have a stable API; **breaking changes, including changes to diagnostics, may occur between any two versions**.

所以定位是：

| 用它做 | 别用它做 |
|---|---|
| 本地写完代码扫一遍 | CI 里唯一的阻断项 |
| 抓 `possibly-unresolved-reference` 这类低级错 | 替代 FastAPI 的契约测试 |
| 渐进收紧 | 开 `--error all`（官方明确"wouldn't recommend it"） |

配置（显式写 `python-version`，因为文档里默认值有 3.14/3.15 的分歧）：

```toml
[tool.ty.environment]
python-version = "3.14"

[tool.ty.rules]
dynamic-function-decorator-return = "error"
missing-type-argument = "error"
unsound-return-statement = "error"
possibly-unresolved-reference = "warn"

[tool.ty.terminal]
error-on-warning = false     # 只有 error 级才非 0 退出
```

**ty 不做运行时校验**：`Field(gt=0)` 它不管；`model_validate` 的字典内容它不逐字段查；自定义 validator 的输入类型它建模不全。这些必须靠测试补，不是靠类型检查器。

`ty==0.0.*` 钉死——它自己说了任意两版之间诊断会变。

## 5. pyproject.toml（可直接粘）

```toml
[project]
name = "pychat"
version = "0.1.0"
requires-python = ">=3.14"
dependencies = [
    "pydantic-ai-slim[openai,mcp]>=2.66,<2.67",
    "pydantic-ai-harness[codemode]==0.66.0",
    "fastapi>=0.162",
    "uvicorn[standard]>=0.54",
    "python-multipart>=0.0.20",
    "pydantic-settings>=2.6",
    "openpyxl>=3.1",
]

[build-system]
requires = ["uv_build>=0.13.7,<0.14"]
build-backend = "uv_build"

[dependency-groups]
dev = [
    "pytest>=9.2",
    "pytest-asyncio>=1.4",
    "pytest-timeout>=2.4",
    "ty==0.0.99",
]
lint = ["ruff>=0.17,<0.18"]

[tool.ruff]
line-length = 100
target-version = "py314"
required-version = ">=0.17,<0.18"

[tool.ruff.lint]
select = ["E4","E7","E9","F","I","UP","B","SIM","ASYNC","FAST","PT","RUF100","D","ERA001","TD","FIX"]
ignore = ["E501", "PT011", "D100", "D104", "D105", "D107"]

[tool.ruff.lint.pydocstyle]
convention = "google"

[tool.ruff.lint.flake8-todos]
task-tags = ["TODO", "FIXME"]

[tool.ruff.lint.per-file-ignores]
"tests/**" = ["S101", "PT"]

[tool.ruff.format]
quote-style = "double"

[tool.ty.environment]
python-version = "3.14"

[tool.ty.rules]
dynamic-function-decorator-return = "error"
missing-type-argument = "error"
unsound-return-statement = "error"
possibly-unresolved-reference = "warn"

[tool.ty.terminal]
error-on-warning = false

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]                 # 没做 editable 安装时兜底
asyncio_mode = "auto"
asyncio_default_fixture_loop_scope = "function"
asyncio_default_test_loop_scope = "function"   # 不写会出 PytestDeprecationWarning
addopts = "-q --strict-markers --strict-config"
timeout = 30
timeout_method = "thread"            # Windows 没有 SIGALRM；显式写便于跨平台
markers = [
    "unit: 纯内存，无 IO / 网络",
    "integration: 进程内 ASGI + 假 MCP / 假模型",
    "contract: 外部契约（MCP 工具名、AI SDK 协议）",
    "e2e: 真 uvicorn + 真 MCP 子进程",
    "live: 需要真实 API key / 网络",
]
filterwarnings = ["error"]
```

`asyncio_default_test_loop_scope` 和 `asyncio_default_fixture_loop_scope` **两个都要写**。只写第一个的症状是：session 级 async fixture 在 A loop 里连上，测试在 B loop 里跑，报 `attached to a different loop`。

标记不要手写——**目录即标记**，用一个 hook 自动打，这样移动文件不会忘：

```python
# tests/conftest.py
import pytest

_MARKERS = {
    "unit": pytest.mark.unit,
    "integration": pytest.mark.integration,
    "contract": pytest.mark.contract,
    "e2e": pytest.mark.e2e,
}


def pytest_collection_modifyitems(items):
    for item in items:
        nodeid = item.nodeid.replace("\\", "/")
        for folder, mark in _MARKERS.items():
            if f"/{folder}/" in nodeid:
                item.add_marker(mark)
```

最后一行 `filterwarnings = ["error"]` 值得单独说：上一版 pychat 就踩过 `InstrumentationSettings(version=2)` 触发 `PydanticAIDeprecationWarning`、在 warnings-as-errors 下把测试打挂。**这是好事**——它会逼你在升级时处理弃用，而不是等线上。

## 6. 测试：分四层，别只写一种

### 6.1 分层与边界

| 层 | 测什么 | 要不要起进程 | 我们的例子 |
|---|---|---|---|
| **单元** | 纯函数、纯逻辑 | 不起 | `extract_workbook()` 把 xlsx 摊平成 CSV + meta；路径拼接的越权校验 |
| **集成** | app + 假依赖 | 起 app，不起外部服务 | `POST /api/chat` 返回 200 + SSE；上传后 `/work/<id>` 里有文件 |
| **契约** | 协议形状 | 起 app | 响应头 `x-vercel-ai-ui-message-stream: v1`；chunk 序列里有 `finish` |
| **E2E** | 浏览器 + 真后端 | 全起 | 上传 → 提问 → 断言页面出现某段文字（手工先用，后续 Playwright） |

MVP 的优先级：**契约 > 集成 > 单元**。因为最怕的是"某天升级 pydantic-ai，前端静默白屏"——那是契约层能抓、单测抓不到的。

### 6.2 目录

```
server/tests/
├─ conftest.py            # 共享 fixture（container / app / tmp data dir）
├─ unit/
│   ├─ test_excel.py
│   └─ test_paths.py
├─ integration/
│   ├─ test_chat_stream.py
│   └─ test_upload.py
└─ contract/
    └─ test_vercel_protocol.py
```

CI 里快的先跑：`pytest -m "not integration"`，再跑 `pytest -m integration`。

### 6.3 异步与事件循环

```toml
asyncio_mode = "auto"                            # 不用每个测试加 @pytest.mark.asyncio
asyncio_default_fixture_loop_scope = "function"  # 显式写，否则 pytest-asyncio 会告警
```

`asyncio_mode="strict"` 更显式，但每个 async fixture 都要标注；MVP 用 `auto` 省事，等测试多了再收紧。

### 6.4 替换 LLM

```python
import pytest
from pydantic_ai import models
from pydantic_ai.models.test import TestModel

# 全局兜底：任何没被 override 的真模型请求直接失败
models.ALLOW_MODEL_REQUESTS = False


@pytest.fixture
def agent_with_test_model(agent):
    with agent.override(model=TestModel(call_tools=[])):
        yield agent
```

`TestModel` **默认会调用 agent 上挂的所有工具**（`call_tools="all"`）。如果 agent 挂了真的 docling `MCPToolset`，单测一跑就会起 uvx 子进程、打远端——所以必须 `TestModel(call_tools=[])`，要测某个工具时再 `call_tools=["..."]`。

要精确控制流式分片，用 `FunctionModel(stream_function=...)`；要断言工具调用顺序，用 Pydantic Evals 的 agentic evaluator。

### 6.5 假 MCP：用进程内 FastMCP，别起子进程

全项目最贵的测试依赖是 docling。单测/集成里**不要**起 `uvx`，把 FastMCP 实例直接交给 `MCPToolset`：

```python
from fastmcp import FastMCP
from pydantic_ai.mcp import MCPToolset

@pytest.fixture
def fake_docling():
    srv = FastMCP("docling-fake")

    @srv.tool
    def convert_document_into_docling_document(source: str) -> dict:
        return {"document_key": "doc-1", "from_cache": False}

    @srv.tool
    def export_docling_document_to_markdown(document_key: str) -> dict:
        return {"document_key": document_key, "markdown": "# hello"}

    return MCPToolset(srv)      # 进程内 server，无网络、无子进程
```

这是官方支持的用法（`MCPToolset` 第一个位置参数可以直接吃 FastMCP server），协议是真的、网络是假的。真 `uvx docling-mcp` 只出现在 `contract/`（验工具名有没有变）和 `e2e/`（验子进程生命周期）。

**契约测试要断言的只有一件事**：真 server 的 `list_tools()` 里包含我们依赖的 6 个名字。名字变了，`CodeMode(tools=[...])` 会静默少一个工具——这比报错更难查。

### 6.6 SSE 怎么测（我原来写错了，这是更正版）

先说事实，这条来自 httpx 源码（`httpx/_transports/asgi.py`）：**`ASGITransport` 会把所有 `http.response.body` 收集完，再拼成一个 body 返回**。

所以：

| 写法 | 结果 |
|---|---|
| `resp.text` | 只验证最终字符串，流式坏了也是绿的 |
| `client.stream(...)` + `aiter_lines()` + `ASGITransport` | **还是绿的**——传输层已经缓冲了 |

要证明"逐块发送"，只能在 **ASGI 消息层**数 `http.response.body` 的条数：

```python
# tests/support/asgi.py
import json


async def collect_messages(app, method, path, body: dict, headers: dict | None = None):
    raw = json.dumps(body).encode()
    scope = {
        "type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
        "method": method, "scheme": "http", "path": path, "raw_path": path.encode(),
        "query_string": b"", "root_path": "",
        "headers": [(b"content-type", b"application/json"),
                    (b"content-length", str(len(raw)).encode()),
                    *[(k.lower().encode(), v.encode()) for k, v in (headers or {}).items()]],
        "server": ("testserver", 80), "client": ("test", 1),
    }
    messages = []
    state = {"sent": False}

    async def receive():
        if not state["sent"]:
            state["sent"] = True
            return {"type": "http.request", "body": raw, "more_body": False}
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message):
        messages.append(message)

    await app(scope, receive, send)
    return messages
```

```python
# tests/integration/test_chat_sse.py
from pydantic_ai.models.function import FunctionModel
from tests.support.asgi import collect_messages


async def stream_three(messages, info):
    for piece in ["你", "好", "世界"]:
        yield piece


async def test_streams_frame_by_frame(app, agent):
    with agent.override(model=FunctionModel(stream_function=stream_three)):
        msgs = await collect_messages(
            app, "POST", "/api/chat",
            {"id": "c1", "trigger": "submit-message",
             "messages": [{"id": "m1", "role": "user",
                           "parts": [{"type": "text", "text": "hi"}]}]},
            {"accept": "text/event-stream"},
        )

    start = next(m for m in msgs if m["type"] == "http.response.start")
    headers = {k.decode().lower(): v.decode() for k, v in start["headers"]}
    assert headers["content-type"].startswith("text/event-stream")
    assert headers.get("x-vercel-ai-ui-message-stream") == "v1"

    bodies = [m["body"] for m in msgs if m["type"] == "http.response.body" and m.get("body")]
    raw = b"".join(bodies).decode()

    assert len(bodies) >= 3, "响应被整体缓冲，不是真流式"
    frames = [f for f in raw.split("\n\n") if f.strip()]
    assert all(f.startswith("data: ") for f in frames)
    assert '"type":"finish"' in raw or '"type": "finish"' in raw
    assert raw.rstrip().endswith("data: [DONE]")
```

`len(bodies) >= 3` 是这条测试的核心——它才是"真流式"和"攒完再发"的分界线。

要断言**首块延迟**，进程内做不到（没有真实时间线），得起 uvicorn 走真端口：

```python
async with client.stream("POST", url, json=payload) as r:
    async for line in r.aiter_lines():
        if line.startswith("data: "):
            break       # 此刻记 perf_counter，与请求开始比
```

阈值给宽一点（< 2s），否则 CI 必 flaky。

### 6.6 超时：测试侧和产品侧要分开

**测试侧**：`pytest-timeout` 的 `timeout = 30`。

⚠️ 它有个真实局限：默认 `--timeout-method=thread`（Windows）**只能报告，不能中断**——测试挂死时它会打堆栈然后继续等。所以它**不是**死锁的解法，只是兜底。

上一版 pychat 那个"两个 `Request` 实例读 body 死锁"就是典型：`pytest-timeout` 会让你看到堆栈，但不会救你。真正的解法是不犯那个错（见 02 §2.1）。

**产品侧**（Pydantic AI 的分层，详见 02 §7）：

| 层 | 参数 |
|---|---|
| 单次模型请求 | `ModelSettings(request_timeout=120, first_event_timeout=30)` |
| 单次工具 | `Agent(tool_timeout=120)` |
| MCP 建连 / 单次请求 | `MCPToolset(init_timeout=30, read_timeout=600)` |
| 整个 run | `timeout=900` |
| 资源 | `UsageLimits(request_limit=30, total_tokens_limit=200_000)` |

注意 `def` 工具的超时**只包住 await，线程会跑完**；重活写 `async def`。

### 6.7 没有 DI 容器，测试怎么隔离

不需要容器：`main.py` 暴露 `create_app(cfg, docling)`，测试直接给一份临时配置和一个假 toolset。

```python
# conftest.py
import pytest
import pytest_asyncio

from pychat.config import AgentConfig, AppConfig, DoclingConfig, ModelConfig, ServerConfig


@pytest.fixture
def cfg(tmp_path) -> AppConfig:
    return AppConfig(
        server=ServerConfig(data_dir=tmp_path),
        docling=DoclingConfig(service_url="http://unused"),
        agent=AgentConfig(
            instructions_file=tmp_path / "prompt.md",
            model=ModelConfig(base_url="http://x", name="m", api_key="k"),
        ),
    )


@pytest_asyncio.fixture
async def app(cfg, fake_docling):
    from pychat.main import create_app
    return create_app(cfg, fake_docling)
```

三条规矩：

1. **配置用构造出来的，不读磁盘、不读 `.env`**——测试之间不会互相污染。
2. **`data_dir=tmp_path`**：文件系统隔离靠参数注入，不靠 `monkeypatch` 全局常量。
3. **`docling` 传假的（进程内 FastMCP）**：单测永远不起 uvx 子进程。

只有当测试本身就在验"配置加载"时，才写临时 toml 文件：

```python
def test_config(tmp_path, monkeypatch):
    monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-test")
    cfg_path = tmp_path / "pychat.toml"
    cfg_path.write_text('[agent]\ninstructions_file = "p.md"\n'
                        '[agent.model]\nbase_url = "u"\nname = "n"\n'
                        'api_key = "{$DEEPSEEK_API_KEY}"\n', encoding="utf-8")
    cfg = load_config(cfg_path)
    assert cfg.agent.model.api_key == "sk-test"
```

## 7. CI（最小可用）

```yaml
- run: uv sync --locked --no-dev --group dev
- run: uv run --frozen ruff format --check .
- run: uv run --frozen ruff check .
- run: uv run --frozen ty check          # 先不卡门禁，看告警
- run: uv run --frozen pytest -m "not integration"
- run: uv run --frozen pytest -m integration
```

`ty check` 放在"先不卡"的位置：它是 beta，诊断会在 0.0.x 之间变。跑一个月、把误报记下来，再决定是 `continue-on-error` 还是真卡。

## 8. 反模式清单

| 别做 | 为什么 |
|---|---|
| `select = ["ALL"]` | 升级就多规则，还会撞上互相冲突的风格规则 |
| 整类开 `E` / `W` | 和 `ruff format` 冲突（`E501`、`W191`…） |
| 既钉 pre-commit 的 `rev:` 又钉 `dependency-groups` 的 ruff，还不一起升 | 两处版本漂移 |
| `ty --error all` | 官方明确不推荐 |
| 把 ty 当唯一门禁 | 0.0.x，任意两版之间诊断会变 |
| 用 `uv pip install` 改项目环境 | 官方不推荐；用 `uv add` / `uv sync` |
| 手写 `[tool.uv].dev-dependencies` | 将废弃；用 `dependency-groups` |
| 在测试里 monkeypatch 全局配置常量 | 传构造好的 `AppConfig` + `data_dir=tmp_path`，否则测试会互相污染 |
| 用 `resp.text` 测 SSE | 流被读完才返回，等于没测 |
| 只写单测、不写契约测试 | 抓不到"协议变了导致前端白屏" |
