# pychat

上传 Excel / Word / PDF，在聊天里问答。后端 Python（Pydantic AI + docling-serve + Code Mode），前端 React（Pydantic AI Chat UI），一个容器即可部署。

## 它怎么工作

```text
浏览器 ──POST /api/documents──▶ FastAPI
                                  │ 保存原文件
                                  └─ POST /v1/convert/file ─▶ docling-serve（192.168.16.24:6029）
                                                   │
                                                   └─ 产出 <id>.json / <id>.md 到 data/work

浏览器 ──POST /api/chat──────▶ FastAPI ──▶ Pydantic AI Agent
                                            └─ 唯一的工具 run_code
                                               沙箱只读挂载 /work
                                               模型自己读 manifest.json / json / md 并计算
```

- **没有自写的 Docling 解析器，也没有自写的 Excel 解析器。** 传输层只是一次 `httpx2` POST，JSON/Markdown 由 docling-serve 返回；Excel 的 sheet 名只存在于 Docling JSON 的 `groups[].name` 里，模型在沙箱里按结构取数。
- **没有数据库、Redis、向量库。** 会话历史在浏览器（client 模式），服务端无状态；文档索引就是 `data/work/manifest.json`。
- **协议是 Vercel AI SDK v7 的 UI message stream。** 后端 `sdk_version=7`，前端直接用 `@ai-sdk/react` 的 `useChat` + `DefaultChatTransport`。聊天界面来自 `pydantic/ai-chat-ui`（MIT），工具调用、思考过程和活动折叠都是它现成的组件。

## 本地启动

需要 Python 3.14、uv、Node 24。

```bash
# 1. 密钥（只走环境变量；缺失会启动失败，而不是静默用错 key）
cp server/.env.example server/.env
# 编辑 server/.env，填 MIMO_API_KEY

# 2. 后端
cd server
uv sync
uv run python -m pychat          # http://127.0.0.1:8000

# 3. 前端（开发态，代理 /api 到 8000）
cd ../frontend
npm install
npm run dev                      # http://127.0.0.1:5173
```

生产态不需要 Node 运行时：`npm run build` 的产物由 FastAPI 的 `StaticFiles` 直接服务（`/` 挂载，带 SPA 回退）。

不想调真实模型时，用离线配置：

```bash
PYCHAT_CONFIG=config/pychat.test.toml uv run python -m pychat
```

它把模型换成 `TestModel`：上传、流式协议和 UI 都能跑，但不会产生真实回答，也不需要 API key。

## 配置

只有一份：`server/config/pychat.toml`。`{$NAME}` 在加载时从环境变量替换，缺变量直接失败。

| 段 | 关键项 | 说明 |
|---|---|---|
| `[server]` | `bind` / `data_dir` / `cors_origins` | `data_dir` 下是 `uploads/`、`work/` |
| `[docling]` | `service_url` / `timeout_s` | `httpx2` 直连 docling-serve 的 `/v1/convert/file` |
| `[agent.model]` | `base_url` / `name` / `api_key` | 每个 agent 一份完整模型配置，不做回落 |

## 部署（192.168.16.24）

镜像里包含前端构建产物，运行时只需要一个容器；docling-serve 用 NAS 上已有的 `192.168.16.24:6029`。

> Windows 本机运行、Docker Desktop 构建、以及从 Windows 发布到 NAS 的完整步骤：见 [docs/13-windows-deploy.md](./docs/13-windows-deploy.md)。

```bash
# 在 NAS 的源码目录（本仓库解压位置）
cd /vol2/1000/app/pychat/src

# Docker Hub 镜像源（docker.fnnas.com）偶发 401 时，先走备用镜像再打成本地名；
# Dockerfile 里不写死镜像源，保持可移植。
docker pull 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine
docker tag 6xbrkv9mhdnp8e.xuanyuan.run/library/node:24-alpine node:24-alpine

docker build -t pychat:latest -f server/Dockerfile .

# 密钥文件（600；容器通过 --env-file 读取）
umask 077
printf 'MIMO_API_KEY=%s\n' "$MIMO_API_KEY" > /vol2/1000/app/pychat/.env

# 数据目录必须让容器内的 uid 10001 可写
mkdir -p /vol2/1000/app/pychat/data
chown -R 10001:10001 /vol2/1000/app/pychat/data

docker rm -f pychat 2>/dev/null || true
docker run -d --name pychat --restart unless-stopped \
  -p 6032:8000 \
  --env-file /vol2/1000/app/pychat/.env \
  -v /vol2/1000/app/pychat/data:/app/data \
  pychat:latest

curl http://192.168.16.24:6032/api/health
```

- 端口：`6032 → 8000`
- 数据：`/vol2/1000/app/pychat/data`（uploads / work）
- 容器内以 uid 10001 运行；docling-serve 是 NAS 上独立的服务，不在此容器内
- 更新：重新 `docker build` 后 `docker rm -f pychat` 再 `docker run`（命令同上）

## 开发命令

```bash
# 后端
cd server
uv run ruff format . && uv run ruff check .
uv run pytest

# 前端
cd frontend
npm run lint
npm run typecheck
npm run build
```

## 目录

```text
server/
  config/pychat.toml     唯一配置
  prompts/chat.md        系统提示词（含 DoclingDocument 结构说明）
  src/pychat/
    config.py            TOML + {$ENV} 替换
    docling.py           httpx2 调 docling-serve，落盘 JSON/MD
    documents.py         上传、manifest、失败重试
    agent.py             模型 + CodeMode + /work 挂载
    main.py              API + SPA
  tests/                 config / documents 单测
frontend/
  src/App.tsx               侧边栏 + 顶栏 + 聊天页
  src/Chat.tsx              会话、流式消息、工具/思考活动
  src/components/           上游 ai-chat-ui 组件 + documents-dialog
  src/lib/config.ts         模型列表（单模型，写死）
docs/                    调研与方案（历史记录）
```

## 已知边界

- Docling 的 xlsx 后端是 `data_only=True`：读 Excel 保存时的缓存值。**公式文本 `=SUM(...)` 永远拿不到**，只有值。
- 没有公式缓存值的 xlsx（例如 openpyxl 生成、从未被 Excel 打开保存）合计列会是空的。
- Monty 沙箱默认 30 秒 / 256 MiB / 100 次嵌套调用；超大表的全量遍历可能撞上限。
- 转换走 docling-serve 的同步接口：复杂 PDF 会占住一个 HTTP 请求直到完成（`timeout_s` 默认 600 秒）；docling-serve 不可用时上传失败，聊天不受影响。
- 会话历史存在浏览器 IndexedDB 里（按浏览器、按站点隔离），换设备或清站点数据即丢。
