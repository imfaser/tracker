# 09 · 配置：一份文件，一个 agent，16 行

## 1. 原则

1. **一个配置文件是唯一真相**，不是几十个散落的 `os.getenv`。
2. **秘密只走环境变量**：配置里写 `{$DEEPSEEK_API_KEY}`，加载时替换，缺失就启动失败。
3. **写错字段就启动失败**（`extra="forbid"`），不要静默忽略。
4. **能写死在代码里的，不进配置**。配置只放"部署时会变"的东西。

第 4 条是克制：`code_mode` 永远是开的、`/work` 永远是只读的、单轮 run 永远是 900s——这些是设计决定，不是部署参数。放进配置只会让人以为可以调。

## 2. `config/pychat.toml`（全文）

```toml
[server]
bind = "0.0.0.0:8000"
data_dir = "./data"          # uploads / work / history 三个子目录

[docling]
mcp_url = ""                 # 空 = stdio（开发）；生产填 http://docling-mcp:8000/mcp
service_url = "http://192.168.16.24:6029"

[agent]
instructions_file = "./prompts/chat.md"

[agent.model]
base_url = "https://api.deepseek.com/v1"
name = "deepseek-v4.1-flash"
api_key = "{$DEEPSEEK_API_KEY}"
thinking = false             # 对话优先首字延迟
max_tokens = 8192
```

就这样。

以后真加第二个 agent 时，它长成 `[agents.extract.model]`，**并且写完整的一份**，不从 `chat` 继承任何字段——这是 wordbook 那条规矩里唯一值得保留的部分（抽取要 `temperature=0`、整理要 `thinking=true`，一旦"缺省复用"，调一个会悄悄改掉另一个）。但现在只有一个，不需要为它预留目录结构。

### 为什么用 TOML

`.jsonc` 好看，但 Python 里要处理注释：`json5` 多一个依赖，自己正则去 `//` 会被 `https://` 打断。TOML 的注释是天生的，而且 **`tomllib` 是标准库**——连 `pydantic-settings` 都不需要了。

## 3. Schema

```python
# src/pychat/config.py
from __future__ import annotations

import os
import re
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

_PLACEHOLDER = re.compile(r"\{\$([A-Z0-9_]+)\}")


class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    base_url: str
    name: str
    api_key: str
    api: Literal["chat", "responses"] = "chat"
    thinking: bool = False
    temperature: float | None = None
    max_tokens: int = 4096
    timeout_s: float = 120          # 单次 HTTP


class DoclingConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mcp_url: str = ""               # 空 = stdio
    service_url: str = "http://192.168.16.24:6029"


class AgentConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    instructions_file: Path
    model: ModelConfig


class ServerConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    bind: str = "0.0.0.0:8000"
    data_dir: Path = Path("./data")


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    server: ServerConfig = Field(default_factory=ServerConfig)
    docling: DoclingConfig = Field(default_factory=DoclingConfig)
    agent: AgentConfig

    @field_validator("server")
    @classmethod
    def ensure_dirs(cls, v: ServerConfig) -> ServerConfig:
        for sub in ("uploads", "work", "history"):
            (v.data_dir / sub).mkdir(parents=True, exist_ok=True)
        return v
```

## 4. 加载

```python
def _substitute(node):
    if isinstance(node, str):
        def repl(m: re.Match[str]) -> str:
            key = m.group(1)
            if key not in os.environ:
                raise RuntimeError(f"missing env var: {key}")
            return os.environ[key]
        return _PLACEHOLDER.sub(repl, node)
    if isinstance(node, dict):
        return {k: _substitute(v) for k, v in node.items()}
    if isinstance(node, list):
        return [_substitute(v) for v in node]
    return node


def load_config(path: Path) -> AppConfig:
    with path.open("rb") as fh:
        return AppConfig.model_validate(_substitute(tomllib.load(fh)))
```

启动时：

```python
cfg = load_config(Path(os.environ.get("PYCHAT_CONFIG", "config/pychat.toml")))
```

校验失败就别启动。**不要 catch 成默认值**——那会把"配置写错了"变成"行为不对劲"。

## 5. 配置 → Agent

```python
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings


def build_model(cfg: ModelConfig) -> OpenAIChatModel:
    return OpenAIChatModel(
        cfg.name,
        provider=OpenAIProvider(base_url=cfg.base_url, api_key=cfg.api_key),
    )


def build_settings(cfg: ModelConfig) -> ModelSettings:
    return ModelSettings(
        temperature=cfg.temperature,
        max_tokens=cfg.max_tokens,
        thinking=cfg.thinking,
        timeout=cfg.timeout_s,                    # 单次请求
        request_timeout=cfg.timeout_s * 2,        # 含重试的整个请求
    )


def build_agent(cfg: AgentConfig, docling: MCPToolset) -> Agent:
    return Agent(
        build_model(cfg.model),
        model_settings=build_settings(cfg.model),
        instructions=cfg.instructions_file.read_text(encoding="utf-8"),
        toolsets=[docling],
        capabilities=[CodeMode(tools=DOCLING_TOOLS, mount=WORKSPACE)],
    )
```

`WORKSPACE` 是模块常量：

```python
WORKSPACE = MountDir(virtual_path="/work", host_path="./data/work", mode="read-only")
```

`build_agent` 是纯函数：配置进、agent 出。没有全局单例、没有容器、没有工厂类。测试传一份改过的 `AgentConfig` 就行。

## 6. 故意不做的

| 不做 | 原因 |
|---|---|
| `limits`（requests / tokens 预算） | 那是批量流水线才需要的成本闸门；单轮对话看账单就够 |
| 每个 agent 的 `run_timeout` / `tool_timeout` | 写死 900 / 120，真要调就是改代码的事 |
| `code_mode = true` 开关 | 永远是开的，没有关掉的场景 |
| `workspace_mode` 可选值 | 永远 `read-only`；可写是安全边界问题，不该由配置决定 |
| `headers` / `reasoning_effort` / `max_retries` | 现在没有哪种 provider 需要 |
| 配置热加载 | 改完重启。热加载要处理并发写和半更新，不值 |
| PostgreSQL / Redis / 向量库 | 会话是 `Conversation.dump_json` 一个文件，文档是 CSV |
| 全局 `settings` 单例被到处 import | 只在 `main.py` load 一次，往下传 |

## 7. 和 wordbook 的差别（为什么那边有预算，这里没有）

| | wordbook | pychat |
|---|---|---|
| 形态 | 离线批处理：几十本词典、每本多轮工具调用 | 在线单轮对话 |
| 成本失控点 | 一次批量跑几小时，必须有并发/预算/turn 上限 | 一次一个问题，用户在看 |
| 失败恢复 | job lease、`max_attempts`、paused 批次 | 重发一次 |
| 配置复杂度 | 值得 | 得不偿失 |

同一套"每个角色一份完整 model"的原则，在 pychat 里只剩一个 agent，所以连 `[agents.<name>]` 这层目录都不需要。
