# 02 · 后端运行时：Pydantic AI + MCP + Code Mode

这篇只讲**运行时怎么装配**。工程化（uv / ruff / ty / pytest）在 [08](./08-python-engineering.md)，配置在 [09](./09-configuration.md)。

## 1. 装配关系

```
uvicorn
  └─ FastAPI app
       ├─ lifespan: load_config + 打开 MCPToolset + 挂到 app.state
       ├─ POST /api/chat   → VercelAIAdapter.dispatch_request(agent, sdk_version=7)
       ├─ POST /api/files  → 落盘 + openpyxl 预处理成 CSV
       └─ GET  /api/files/{id}/raw
                 │
                 ├─ Agent(capabilities=[CodeMode(mount=/work)])
                 │     └─ MCPToolset(uvx docling-mcp)  ← stdio 子进程
                 └─ /data/{uploads,work,history}
```

三层各有明确边界：

| 层 | 只做 | 不做 |
|---|---|---|
| FastAPI | 协议、上传、DI 装配 | 业务判断 |
| Agent + CodeMode | 决定"看什么、看多少" | 文件格式解析 |
| 预处理（Python） | xlsx → CSV、落盘、建 meta | 被模型调用 |

> 上图是**开发**形态（stdio 子进程）。生产是独立的 `docling-mcp` 容器，`MCPToolset` 换成 URL，见 [05](./05-deployment.md)。

## 2. chat 端点

```python
from fastapi import APIRouter
from starlette.requests import Request
from starlette.responses import Response

from pydantic_ai.ui.vercel_ai import VercelAIAdapter

router = APIRouter(prefix="/api")


@router.post("/chat", response_model=None)
async def chat(request: Request) -> Response:
    cfg = request.app.state.cfg
    agent = build_agent(cfg.agent, request.app.state.docling)
    return await VercelAIAdapter.dispatch_request(
        request, agent=agent, sdk_version=7
    )
```

SSE 编码、chunk 序列化、错误 chunk 都由适配器负责，不要自己写 `StreamingResponse`。

app 级的两个东西挂在 `app.state` 上，`lifespan` 里赋值：

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = load_config(Path(os.environ.get("PYCHAT_CONFIG", "config/pychat.toml")))
    app.state.cfg = cfg
    async with make_docling(cfg.docling) as docling:
        app.state.docling = docling
        yield
```

这就是上一版用 dishka 干的事，去掉一层抽象之后是 6 行。

### 2.1 为什么这里不会踩上一版那个坑

上一版 pychat（`D:\code\tmp\old-ag`）用 dishka，`chat.py:25-27` 留了一条硬警告：

> 请求必须取 dishka 注入的 `Request`，不要用 FastAPI 的 `request: Request`：那会造出第二个 `Request` 实例，两个实例各缓存一份 `_body`，第二次读 body 会一直等 `http.disconnect`，形成死锁。

症状是：in-process 测试挂死，生产请求永久悬挂，没有异常、没有超时。

**不用 DI 之后，这个坑天然消失**——路由里只有一个 `Request`，适配器读一次 body，没有第二个包装层。

要守住的是别把它重新引进来：**不要在 `chat()` 里再构造一个 `Request`**（比如为了"先解析一下 body 再交给适配器"），也不要套一层中间件把 body 读走。要读，就在交给适配器之前读完，让 `_body` 缓存住。

### 2.2 `sdk_version` 必须显式给

API 文档原文：

> `sdk_version: Literal[5, 6, 7] = 5` —— 默认 5 向后兼容；6 启用 tool approval 流；**7 的 wire 与 6 相同**。

默认值 5 的症状是：工具审批卡片不出现，**而且不报错**。上一版 pychat 也是直接写死的 7。

## 3. 组合：Capability，不是容器

官方定义（原文）：

> A capability is a **reusable, composable unit of agent behavior**. Instead of threading multiple arguments through your `Agent` constructor — instructions here, model settings there, a toolset somewhere else — you can bundle related behavior into a single capability.

能力能带：tools、lifecycle hooks、instructions、**model settings**、**models**。所以这个项目的组合只有三段：

```
Agent
 ├─ model         ← config.agents.<name>.model（每个 agent 独立，见 09）
 ├─ capabilities  ← 代码里的行为单元（可复用、可 defer_loading 变"技能"）
 └─ toolsets      ← MCP 之类的连接（进程级共享）
```

```python
# src/pychat/capabilities/docling_docs.py
from pydantic_ai import Capability, RunContext

docling_docs = Capability[None](
    id="docling-docs",
    description="Read Word/PDF/images/web pages through Docling.",
)


@docling_docs.instructions
async def hint(ctx: RunContext[None]) -> str:
    return "文档正文一律用 Docling 工具取，不要凭记忆复述。"


@docling_docs.tool
async def list_cached_documents(ctx: RunContext[None]) -> list[dict]:
    """List documents already converted in this session."""
    ...
```

```python
WORKSPACE = MountDir(virtual_path="/work", host_path="./data/work", mode="read-only")


def build_agent(cfg: AgentConfig, docling: MCPToolset) -> Agent:
    return Agent(
        build_model(cfg.model),                 # 模型来自这个 agent 的配置
        model_settings=build_settings(cfg.model),
        instructions=cfg.instructions_file.read_text(encoding="utf-8"),
        toolsets=[docling],
        capabilities=[
            CodeMode(tools=DOCLING_TOOLS, mount=WORKSPACE),
            docling_docs,
        ],
    )
```

`build_agent` 是纯函数：配置进、agent 出。没有容器、没有工厂类、没有全局单例。

### 3.1 那 dishka 呢

**不用。** 上一版 pychat 用 dishka 是为了 `AgentStateBuilder`——从「全局配置 + 请求体」合成本次运行的生效配置。那件事现在被拆成两半：静态部分归配置文件（09），动态部分归 agent 构造函数的参数。

| 原来的诉求 | 现在由谁解决 |
|---|---|
| 全局配置 | `load_config()` 在 `main.py` 里跑一次，往下传 |
| 进程级 MCP 连接 | 模块级 `MCPToolset` + lifespan 里开关 |
| 每请求状态 | 路由函数里构造一个 dataclass |
| 测试替换实现 | `Agent.override(model=...)` + 进程内 FastMCP（08 §6） |

一个进程、一份配置、一个 toolset、agent 每请求新建——dishka 在这里省不掉任何代码，只多一个概念。等真出现"多租户、每用户凭证、按租户切实现"再引入，那时它解决的是真问题。

### 3.2 deps 只放"每请求变化的东西"

`deps_type` 只要类型，实例在调用时给：

```python
@dataclass
class Deps:
    conversation_id: str
    base_dir: Path


agent = Agent(model, deps_type=Deps)


@agent.tool
async def lookup(ctx: RunContext[Deps], q: str) -> str:
    ...
```

静态的东西（模型名、超时、路径）**不要**塞 deps——它们在配置里。deps 里只该有"这次请求才有"的值。

推论：**不要往 tool 签名里塞任何框架的注入标记**（`FromDishka[...]`、`Depends(...)`）。Pydantic AI 会把非 `RunContext` 的参数当成模型要生成的工具入参，然后给它们编 JSON Schema——那不是注入点。

### 3.3 测试里换实现

不需要容器：

```python
with agent.override(model=TestModel(call_tools=[]), toolsets=[MCPToolset(fake_fastmcp)]):
    ...
```

细节见 08 §6。

## 4. MCP：Docling 只有这一条入口

## 4. MCP：Docling 只有这一条入口

### 4.1 一个 toolset

```python
from pydantic_ai.mcp import MCPToolset, StdioTransport

docling = MCPToolset(
    StdioTransport(
        command="uvx",
        args=[
            "--from=docling-mcp==3.3.0",
            "docling-mcp-server",
            "--transport", "stdio",
            "--tools", "conversion",        # 只加载转换组
        ],
    ),
    init_timeout=30,          # 默认 5s：首次 uvx 下载会超
    read_timeout=600,         # 默认 300s：大 PDF / 大表会超
)
```

两个超时的默认值都不够用（`init_timeout=5`、`read_timeout=300`），必须改。

**不要写 docling-serve 的 HTTP 客户端**。docling-mcp 已经把转换、缓存、按 anchor 取片段、带 `max_size` 的 markdown 导出实现完了；再写一遍等于给一个连 OpenAPI 都没写清响应 schema 的接口（`/v1/result/{task_id}` 是空 schema）做适配层。

### 4.2 三种调用方

| 谁 | 怎么调 | 用在哪 |
|---|---|---|
| 模型（Code Mode） | `run_code` 里的普通函数 | 对话中按需读文档 |
| 代码（预处理） | `await docling.direct_call_tool(name, args)` | 上传即转换，确定性 |
| 模型（裸挂） | `Agent(toolsets=[docling])` | 调试用，生产不这么挂 |

`direct_call_tool` 的签名（文档确认）：`(name, args, *, metadata=None, use_task=False) -> Any`。

### 4.3 `--tools conversion` 的理由

docling-mcp 默认加载 `conversion, generation, manipulation` 共 21 个工具，其中 8 个是"往缓存文档里加段落/标题/表格"的编辑型工具。对聊天助手来说这些是纯噪声：占工具位、降低选择准确率。

## 5. Code Mode：把"读文档"还给模型

### 5.1 为什么必须上

裸挂 MCP 时，`export_docling_document_to_markdown` 的返回**整篇进上下文**。一份 40 页的 Word 就是几万 token，一次问答就烧掉半窗。

`CodeMode` 把工具折进 `run_code`：模型写一段 Python，在 Monty 沙箱里连调多个工具、过滤、只把要的那几百字 `return` 出去。

```python
from pydantic_ai import Agent
from pydantic_ai_harness import CodeMode

agent = Agent(
    model,
    toolsets=[docling],
    capabilities=[
        CodeMode(
            tools=[
                "convert_document_into_docling_document",
                "export_docling_document_to_markdown",
                "get_overview_of_document_anchors",
                "search_for_text_in_document_anchors",
                "get_text_of_document_item_at_anchor",
                "list_cached_documents",
            ],
            mount=MountDir(
                virtual_path="/work",
                host_path=str(settings.work_dir),
                mode="read-only",
            ),
        )
    ],
)
```

模型实际写的东西大概长这样：

```python
key = (await convert_document_into_docling_document(source='/work/9f3a1c/report.docx'))['document_key']
hits = (await search_for_text_in_document_anchors(document_key=key, text='违约金'))['result']
text = (await get_text_of_document_item_at_anchor(document_key=key, document_anchor=hits.split()[0]))['text']
text[:500]
```

一次 `run_code`，两轮往返变一轮，上下文只进 500 字。

### 5.2 `mount`：唯一的"文件系统"入口

```python
from pydantic_monty import MountDir
```

- `mode='read-only'`：模型只能读，不能改我们的数据（生产用这个）。
- `mode='overlay'`（默认）：写只在本次 `run_code` 内可见，结束后丢弃。
- `mode='read-write'`：写穿到宿主，**别给模型开**。

沙箱里能用的 stdlib（官方列表）：`sys, typing, asyncio, math, json, re, unicodedata, datetime, time, random, os, pathlib, collections, itertools, functools, dataclasses, copy, base64, binascii, bisect, csv, decimal, hashlib, os.path, tomllib`。

**没有第三方库**：`openpyxl`、`pandas`、`pyyaml` 都用不了。这决定了"xlsx 必须在上传时摊平成 CSV"（见 03 §3），而不是让模型在沙箱里解。

其他限制：`asyncio.gather` 只接受位置参数；默认没有时钟和随机数（`datetime.now()` / `time.time()` 会失败，除非配 `os_access`）；没有 `import *`。

### 5.3 不能忘的两件事

1. `pydantic-ai-harness` 是 **0.66.0，0.x**，minor 会变更行为 → `==0.66.0` 钉死，升级单独一个 PR。
2. 工具返回值会按 JSON schema 过一遍：`Decimal`/`UUID`/`datetime` 变成字符串，`dict[int, str]` 的 key 变字符串。模型拿到的数字是 `str`，要 `decimal.Decimal(x)` 转。

## 6. 会话历史：本地文件，不进数据库

`Conversation` 自带序列化，不需要 DB：

```python
from pydantic_ai import ConversationTypeAdapter

# 存
payload = ConversationTypeAdapter.dump_json(result.conversation)
settings.history_dir.joinpath(f"{result.conversation_id}.json").write_bytes(payload)

# 读
conv = ConversationTypeAdapter.validate_json(path.read_bytes())
result = agent.run_sync('继续说', conversation=conv)
```

`Conversation` 里除了消息，还有 `usage`、`conversation_id`、上次暂停的 deferred tool requests。

为什么不上 Postgres（顺带纠正一下：Pydantic AI 的 Step Persistence **是**支持 PostgreSQL 的，也支持 SQLite / MongoDB / 文件）：

- MVP 只有一个用户、几段对话，一个 JSON 文件就是全部状态；
- 没有数据库就没有连接池、迁移、备份、时区这些事；
- 真要换，`dump_json` 的输出直接塞 `jsonb` 列，一行代码的事。

⚠️ 一个必须处理的并发点：同一会话的两次请求会同时读写同一个文件。用 `asyncio.Lock`（按 conversation_id 分桶）串行化，或者文件名带时间戳 + 读时取最新。**别用 `sanitize_filename` 之外的方式拼路径**——`conversation_id` 来自客户端时要做白名单校验。

## 7. 超时：分四层，别只设一个

Pydantic AI 的官方分法（每一层的失败表现都不一样）：

| 层 | 参数 | 默认 | 失败表现 |
|---|---|---|---|
| 单次模型请求的单个尝试 | provider SDK 自带 | 各家不同 | 重试 |
| 一整个模型请求（含重试/流式读到底） | `ModelSettings(request_timeout=..., first_event_timeout=...)` | 无 | 由 Pydantic AI 强制执行，**任何 provider 都一样** |
| 单次工具调用 | `Agent(tool_timeout=...)` 或 `@tool(timeout=...)` | 无 | 模型收到 `'Timed out after N seconds.'`，消耗该工具的重试预算 |
| 连接 MCP server | `MCPToolset(init_timeout=...)` | 5s | 起不来 |
| 单次 MCP 请求 | `MCPToolset(read_timeout=...)` | 300s | 工具报错，默认按可重试处理 |
| 整个 run | run 方法的 `timeout=` | 无 | `UsageLimits` 之外的另一条兜底 |
| 资源预算 | `UsageLimits(requests/tool_calls/tokens/cost)` | 无 | 超限中止 |

注意两点：

- `def` 工具（同步函数）的 timeout **只包住 await，不会真的停掉工作线程**——线程会跑完。所以重活写成 `async def`，或者放到线程池里由你别的地方兜。
- 超时是**产品语义**，不只是稳定性：docling 转换 60s 是正常的，别把 `read_timeout` 设成 30s 然后怪 Docling。

建议值：

```python
ModelSettings(request_timeout=120, first_event_timeout=30)
Agent(tool_timeout=120)                 # 普通工具
MCPToolset(init_timeout=30, read_timeout=600)   # docling
run timeout=900                          # 一次对话最多 15 分钟
```

## 8. 取消

浏览器点停止 = 断连，服务端只看到 `CancelledError`，**不发 `abort` chunk**。想要"停止也落半截历史"，得用一方取消：

```python
from pydantic_ai import CancellationToken, RunCancelled

tokens: dict[str, CancellationToken] = {}


async def on_cancel(cancelled: RunCancelled) -> None:
    payload = ConversationTypeAdapter.dump_json(cancelled.conversation)
    settings.history_dir.joinpath(f"{cancelled.conversation_id}.json").write_bytes(payload)
```

`CancellationToken` 要能从 `POST /api/chat/{id}/cancel` 打到**同一个进程**。内存字典只适用于单 worker；多副本时得用共享存储（用什么再说，现在不做）。

MVP 建议：先不做，接受"停止后不落库"。

## 9. 模型

```python
Agent('deepseek:deepseek-v4.1-flash')     # DEEPSEEK_API_KEY
Agent('openai:gpt-6.1-sol')
Agent('ollama:qwen3')
```

本地不配 key 时用 `TestModel()`，让前后端管道能先跑通（`PYCHAT_MODEL=test`）。

## 10. 这一版删掉了什么，为什么

| 删掉 | 原因 |
|---|---|
| `clients/docling.py`（自写 HTTP 客户端） | 官方 MCP 已经实现，且 REST 的响应 schema 没契约 |
| `list_sheets` / `read_sheet` / `list_uploaded_files` 三个工具 | `CodeMode(mount=...)` 给了目录，模型自己能读；工具只会把粒度写死 |
| `ingest/dispatch.py` | 路由逻辑四行，放 `files.py` |
| Postgres / pgvector | MVP 不需要；`Conversation.dump_json` 落文件足够 |
| `public_base_url` + `/api/files/{id}/raw` 给 MCP 回取 | 文件在 `/work` 里，docling-mcp 直接读路径 |
