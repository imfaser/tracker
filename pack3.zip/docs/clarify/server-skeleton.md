# server 骨架（FastAPI + dishka + pydantic-ai 流式出口）

- 日期: 2026-09-29
- 状态: clarify 完成，进入实现
- 关联: `docs/clarify/harness-state.md`（上一轮的 State 澄清，本任务的直接前置）

## Why Layer

- **业务本质**: 给 pychat 立一个最小可运行的 server 基座——把已有 config / schema / telemetry 串进 FastAPI 生命周期，用 dishka 做 DI，跑通一条流式 chat 出口。长期演进起点，本次只搭骨架、不写业务。
- **问题归属**: 技术问题（脚手架 + 选型验证）。
- **非代码解法**: 外部模板（Pydantic AI 官方样板）要贴合本项目 schema / config / dishka 约定反而要拆改，判定自己搭。

**成功标准**

| # | 标准 | 可验证点 |
|---|---|---|
| S1 | 启动 | 服务起得来，lifespan 正常进出、无异常 |
| S2 | 输出 | 流式 chat 出口返回**严格 Vercel AI data stream**（`sdk_version=7`），`curl` 能逐块看到内容；内容由配置里的 `test` 模型真实产出，不做 mock |
| S3 | DI 生效 | 容器能解析 AppConfig（APP）/ AgentState（REQUEST）；每请求得到新的 AgentState |
| S4 | telemetry | lifespan 启动时 bootstrap、关闭时 shutdown，不报错 |
| S5 | 质量门禁 | `uv run ruff check` / `uv run ty check` / `uv run pytest` 全绿 |

## 代码库现状速写

| 位置 | 现状 |
|---|---|
| `packages/core` | `AppConfig`（`core/config.py:47`）、生成物 `schema.py`、`configure_logging`（`core/logging.py:87`） |
| `packages/harness` | `State`/`StateBuilder`（`harness/state.py`）、`create_model`（`provider.py:154`）、`Orchestrator.get_graph()`（`agent/orchestrator.py:72`）；两个 `__init__.py` 为空 |
| `packages/telemetry` | 仅 `TelemetryBackend` 协议（`backends/base.py:8`）与 `PhoenixBackend`；无模块级 bootstrap/teardown 包装 |
| `server` | 只有打印 hello 的 `main()`；console script `server`，`just dev` = `uv run server` |
| `tests` | 仅 `tests/unit/`（5 个文件）+ `tests/fixtures/`；无根 `conftest.py` |

**关键事实（带出处）**

1. `test` 不是配置里的 provider，而是 schema 的协议枚举（`schema/provider.json:22`）；`TestStrategy.build()` 返回字面量 `"test"`（`harness/provider.py:106-114`），等价 pydantic-ai 内置 TestModel（离线、不调 LLM）。
2. `StateBuilder.add_source` 现行签名 `HarnessConfig | Mapping[str, Any]`，优先级 0/1，`build()` **同步**（`harness/state.py:42-92`）。
3. `Orchestrator.agent_config` 硬编码 `config.harness["orchestrator"]`（`orchestrator.py:59`）；`get_graph()` 走 `create_model(state, config.provider[model_name])`（`:86`）。
4. dishka：`FastapiProvider` 把 `Request` 作为 context data 传给 provider 工厂（工厂以 `fastapi.Request` 形参取 REQUEST-scoped 值）；路由用 `DishkaRoute`，`setup_dishka(container, app)`，lifespan 关 `app.state.dishka_container`。HTTP 只有 APP → REQUEST 两级。
5. Vercel 请求体：`RequestData = SubmitMessage | RegenerateMessage`；`SubmitMessage` 的 `trigger` 有默认、`id` 与 `messages` **必填**、`extra='allow'`（`request_types.py:411-428`）——`model/think/effort` 能被带进来。
6. `sdk_version: Literal[5, 6, 7] = 5`，**7 与 6 线上协议相同**（`_adapter.py:152-156`）。
7. Starlette `Request.body()` 缓存 `_body`：线上只读一次，第二次命中缓存；只有 `request.stream()` 会绕过缓存。
8. `fastapi` / `dishka` **不在 `uv.lock`**（必须新增）；`uvicorn` / `httpx` / `httpx2` 在 lock 内。`.venv` 未被 `glob` 覆盖（受 `.gitignore` 影响），实际安装态以 `uv sync` 后为准。
9. 兄弟项目 `chatbot1/server`、`deepview/server` 结构可借鉴（DI 组织 / lifespan / 路由写法），**不照搬**。
10. **请求体只能读一次**：Starlette 的 `_body` 缓存在 `Request` 实例上（`requests.py:254-260`），不写 scope；一次请求会造出多个实例（dishka 中间件一个、路由一个）。第一个实例读掉 wire 之后，其余实例再读会一直等响应结束（测试客户端 `testclient.py:299-304`，生产环境 uvicorn 等客户端断开）才拿到 `http.disconnect` → **死锁**。解法：`server/request_body.py` 的 `read_body()` 读一次并写 `scope["pychat.request_body"]`，下游 `reuse_body()` 回填给路由实例再交给适配器（实测：修复前 `POST /chat/stream` 必死锁，修复后 200）。
11. **`trigger` 必须在 wire 上显式给出**：`RequestData = SubmitMessage | RegenerateMessage` 用 `Discriminator('trigger')`，而 `SubmitMessage.trigger` 的默认值只作用于 Python 侧构造——pydantic 提取 tag 时只看输入，缺 `trigger` 直接 `union_tag_not_found` → 422（实测锁定）。

## Prompt Layer

### A. 任务分解

| # | 子任务 | 可独立验证点 |
|---|---|---|
| T1 | 根 `pyproject.toml` 加 `fastapi` / `uvicorn` / `dishka` | `uv sync` 成功，import 通过 |
| T2 | 新建 `config.jsonc`（git 忽略）：logging + `test` 协议 provider + `orchestrator` harness 段 | `AppConfig()` 装载成功 |
| T3 | `State`/`StateBuilder` → `AgentState`/`AgentStateBuilder`，新增 `Request` 来源，`build()` 改 async | 全量 pytest 绿 |
| T4 | `server/container.py`：`AppProvider`(AppConfig, APP) + `AgentStateProvider`(AgentState, REQUEST) + `FastapiProvider` | 容器能 resolve 两者 |
| T5 | `server/app.py`：`create_app` + lifespan（logging → telemetry → yield → shutdown → close）+ `setup_dishka` + `/health` | 起服务无异常 |
| T6 | `server/routers/chat.py`：`POST /chat/stream`，`DishkaRoute` + `FromDishka[AgentState]`，**每请求**新建 agent | `curl -N` 见 SSE |
| T7 | `server/__init__.py::main` 改为 uvicorn 入口 | `uv run server` 起得来 |
| T8 | 测试：单测（合成/优先级/解析）+ 集成（in-process ASGI + PM2 真进程） | 新增测试通过 |
| T9 | 门禁三者全绿 | - |

### B. 涉及文件

| 类别 | 文件 |
|---|---|
| 新建 | `config.jsonc`；`server/src/server/{app,container,request_body}.py`；`server/src/server/routers/{__init__,chat}.py`；`tests/fixtures/config.server.jsonc`；`tests/integration/{conftest,test_server_app,test_pm2_server}.py` |
| 写入 | 根 `pyproject.toml`；`server/src/server/__init__.py`；`packages/harness/src/harness/state.py`、`provider.py`、`agent/orchestrator.py`；`tests/unit/{test_state,test_orchestrator,test_provider}.py` |
| 只读 | `core/schema.py`（生成物，禁改）；`schema/*.json`；`config.example.jsonc`；兄弟项目 |

### C. 接口契约 / 数据契约

- **HTTP**: `POST /chat/stream`；请求体 = Vercel AI UI message stream payload（`trigger` / `id` / `messages` 三者必填，`model`/`think`/`effort` 可选额外字段）；响应 = SSE `text/event-stream`。
- **辅助端点**: `GET /health` → `{"status": "ok"}`。
- **DI 暴露**: `FromDishka[AgentState]`、`FromDishka[AppConfig]`。
- **`AgentState` 来源优先级（显式）**: `HarnessConfig`(0) < `Request`(1) < `Mapping`(2)。
- **`Request` 来源字段映射**: body `model` → `model_name`，`think` → `thinking_enabled`，`effort` → `effort`。
- **入口**: `server = "server:main"`；`just dev` = `uv run server`。
- **`sdk_version = 7`**。

### D. 校验规则

- 配置：沿用 `AppConfig`（provider/harness 非空、`api_key` minLength 1、`base_url` 匹配 `^https?://`）。
- `Request` 来源：复用 `_from_mapping` 的白名单与类型校验（未知键报错、`None` = 不表态、`effort` 经 `Effort(...)` 归一）。
- 请求体：必填字段缺失由 `VercelAIAdapter` 校验 → **422**（实测：缺 `trigger`/`id`/`messages` 均 422）；`content-type` 非 JSON → **415**（实测）。
- 不改 schema → 不跑 codegen。

### E. 第三方依赖清单

| 包 | 状态 | 用途 |
|---|---|---|
| `pydantic-ai` 2.47.0 | 已装 | Agent / VercelAIAdapter / TestModel |
| `starlette` | 已装（transitive） | `Request` / 流式响应 |
| `fastapi` | **新增**（根 pyproject） | Web 框架 |
| `uvicorn` | **新增**（根 pyproject） | ASGI server |
| `dishka` | **新增**（根 pyproject） | DI 容器 + FastAPI 集成 |
| `httpx` / `httpx2` | lock 内，待实测 | 集成测试的 ASGI 客户端 |

### F. 运行环境与启动方式

- `uv run server`（`just dev`）；uvicorn 拉起，lifespan 由 FastAPI 管理。
- bind 地址：`SERVER_HOST` / `SERVER_PORT` 环境变量，缺省 `127.0.0.1:8000`（只由 `server/__init__.py::main` 读取；集成测试靠它换端口，避免撞开发端口）。
- 配置路径：`CONFIG_FILE` → `config.jsonc`。
- 生命周期：uvicorn 启动 → lifespan startup（logging / telemetry）→ 请求 → 停止 → lifespan shutdown（telemetry flush → `container.close()`）。
- **dev server 用 PM2 常驻**：每次 `pm2 start` 前先 `pm2 delete pychat-server`（PM2 保留旧实例/缓存），验收完 `pm2 delete`。

### G. 作用过程

```
user --POST /chat/stream--> FastAPI(DishkaRoute)
   └─ FromDishka[AgentState] ← AgentStateProvider (REQUEST)
        ├─ add_source(cfg.harness["orchestrator"])   # 兜底 (0)
        └─ add_source(request)                        # 覆盖 (1), 读 body
   └─ 路由内: Orchestrator(cfg, state).get_graph() -> Agent("test")   # 每请求新建
   └─ VercelAIAdapter.dispatch_request(request, agent, sdk_version=7)
        -> agent.run_stream_events() -> VercelAIEventStream -> SSE chunks
   └─ StreamingResponse(text/event-stream) --逐块--> user

lifespan:
  startup : configure_logging(cfg.logging) -> telemetry.bootstrap()（telemetry 段存在时）
  shutdown: telemetry.shutdown() -> container.close()
```

### H. 测试与验证策略

- 框架 pytest + anyio，根目录跑。
- fixture：unit 复用 `clean_env`；integration 新建 `tests/fixtures/config.server.jsonc`（含 `orchestrator` 段 + `test` provider）。
- mock：`AppConfig` / AgentState 合成 / `/chat/stream` in-process ASGI 都直接测；telemetry 用假 backend 记录调用顺序，真上报手动。
- 真 uvicorn/PM2 进程生命周期不自动化。

### I. 参考材料

| 材料 | 用途 | 形态 |
|---|---|---|
| dishka FastAPI 集成文档 | `FastapiProvider` / `DishkaRoute` / lifespan 关闭 | 外部文档，已读 |
| dishka scope 文档 | APP → REQUEST | 外部文档，已读 |
| pydantic-ai Vercel AI 文档 | `dispatch_request` / `sdk_version` | 外部文档，已读 |
| `chatbot1/server`、`deepview/server` | 结构参考（不照搬） | 仓库外，同工作区 |

### J. 约束条件（正向）

- 一律 `uv run`；pytest 在根目录跑。
- 中文 Google docstring、半角标点、无模块级常量、纯函数优先。
- 通过 ruff / ty / pytest。
- 按长期演进起点打造。

### K. 性能要求

本任务不涉及（骨架，无热路径）。

### L. 边界情况

- `config.jsonc` 缺失/非法 → 启动明确失败。
- `telemetry` 段为 `None` → 跳过 bootstrap/shutdown。
- 非法请求体 → 422；`content-type` 不对 → 415（均已实测锁定）。
- 客户端断开 → SSE 生成器取消。
- `test` 模型输出固定文本（非"真实生成"），符合 G1 的"不用 mock"语义。
- 请求体非 JSON → `Request` 来源返回空表态，配置兜底生效。

### M. 禁止行为（反向）

- 不照搬兄弟项目代码。
- 不改 `schema/*.json`，不跑 codegen。
- 不引入业务逻辑（MCP、工具、持久化、多轮历史）。
- 不加认证；CORS 非必要不加。
- 不把 `config.jsonc` 纳入版本控制。
- 不给 agent 做 APP-scoped provider（agent 是每请求产物）。

## Reasoning Layer

### 已知事实

见上文「关键事实」1-9。

### 隐含假设

| # | 假设 | 验证方式 | 结果 |
|---|---|---|---|
| 1 | body 字段名即 `model` / `think` / `effort` | 用户裁决 | 成立（用户指定） |
| 2 | dishka provider 工厂可用 `async def` | 文档 / spike | 待实测 |
| 3 | `test` 条目填占位 `api_key` / `base_url` 能过 schema | 读 `provider.json` | 成立 |
| 4 | `harness` 直接用 `Request` 不算越界 | 用户裁决（单应用） | 成立 |
| 5 | `httpx2` 可作 ASGI 客户端 | spike | 待实测 |

### 关键推断

1. **必须显式优先级**：上一轮 `harness-state.md` 已预警"覆盖型来源 >= 2 时二分退化"。加入 `Request` 后正好命中，故改用显式优先级 `HarnessConfig(0) < Request(1) < Mapping(2)`。
2. **`add_source(request)` 撞异步边界**：body 是协程而 `build()` 同步 → 取 `build()` 改 async（最忠于"直接用 request"）；代价是既有 StateBuilder 单测与调用点加 `await`。
3. **agent 是每请求产物**：REQUEST 内合成 AgentState → 新建 Agent → 请求结束即弃；不做 APP-scoped agent provider。
4. **telemetry 不进 DI**：由 lifespan 直接管，对应图中 `lifespan → telemetry`，也免去为可选段造 provider。

### 风险点

1. `State`→`AgentState` 改名 × `build()` 改 async → blast radius 覆盖 `state.py` / `provider.py` / `orchestrator.py` + 3 个测试文件。
2. 新依赖会拉入大量 transitive 包，需确认 aliyun 镜像可达。
3. 集成测试客户端：`httpx` vs `httpx2` 需实测，否则换 `httpx.AsyncClient` 并显式加测试依赖。
4. 段名口径：新 `config.jsonc` 必须用 `orchestrator`（示例文件写的是 `code`）。
5. 关闭顺序：`telemetry.shutdown()` 必须先于 `container.close()`。
6. 上一轮文档 `harness-state.md` 的契约（`build()` 同步、禁止 Protocol 来源抽象）需同步更新，避免两份文档打架。

## Test Plan

### 测试基础设施

- 框架 pytest + anyio，根目录 `uv run pytest`。
- **单测超时 `timeout = "10"`**（`[tool.pytest]`，pytest-timeout，signal 方法）：死锁类缺陷必须立刻失败并打印线程栈，不能挂住整个会话；慢用例用 `@pytest.mark.timeout` 单独放宽。
- fixture：unit 复用 `tests/unit/conftest.py` 的 `clean_env`；integration 用 `tests/fixtures/config.server.jsonc`。
- **PM2 真进程测试**（`tests/integration/test_pm2_server.py`，`@pytest.mark.slow` + `@pytest.mark.timeout(120)`）：`pm2 delete` → 用独立 app 名 `pychat-server-test` 与随机空闲端口 `pm2 start "uv run server"` → 轮询 `/health` 就绪 → 真 HTTP 打 `/chat/stream` → 断言 SSE 分片拼回 `success (no tool calls)` → teardown `pm2 delete`；未装 pm2 时 skip。环境（`CONFIG_FILE` / `SERVER_PORT`）在 `pm2 start` 的 CLI env 里给，PM2 会透传给应用（实测）。
- mock：合成与 ASGI 直接测；telemetry 用假 backend 断言 `bootstrap → yield → shutdown` 且 shutdown 早于 close。

### 测试范围划分

| 档 | 覆盖 | 成本 |
|---|---|---|
| 单元 | `AppConfig` 装载、AgentState 三来源合成与优先级、body 解析、`test` 协议建模 | 低 |
| 集成 | in-process ASGI：`/chat/stream` 合法/非法 body、`/health`、lifespan 起停；PM2 真进程：启动 + 真 HTTP 流式（`slow`） | 中 |
| 手动 | 真实 telemetry（Phoenix endpoint / 鉴权） | 高，不自动化 |

### 成功标准细化成可测场景

- **S1**：S1.1 lifespan 进出无异常；S1.2 `/health` 200；S1.3 `telemetry=null` 跳过；S1.4 配置非法启动失败；S1.5 PM2 真进程起来后 `/health` 通（自动化）。
- **S2**：S2.1 返回 `text/event-stream` 且 ≥1 chunk；S2.2 锁定 `sdk_version=7`；S2.3 缺必填 body → 422、content-type 不对 → 415；S2.4 真进程 `curl -N`/httpx 流式可见（自动化，`slow`）。
- **S3**：S3.1 容器解析 AppConfig（APP）；S3.2 每请求得到新 AgentState；S3.3 正确取到 body 的 `model/think/effort`；S3.4 AppConfig 跨请求复用。
- **S4**：S4.1 假 backend bootstrap/shutdown 各一次；S4.2 shutdown 先于 close。
- **S5**：S5.1 三者全绿。

### 回归风险

- 改名 + async 化 → 3 个单测文件同步。
- 新依赖 → lock 变化、镜像可达性。
- 集成客户端 → `httpx`/`httpx2` 可用性。
- 段名 → `orchestrator`。

## 开放问题（待 explore 深挖）

- **`Request` 来源的字段名与前端契约**（`think` 是否最终叫 `thinking_enabled`）——需要前端对齐后定；本任务按用户口径实现，留在文档里备查。
- **优先级在第三类来源出现时的形态**（是否引入显式 priority 参数）——本任务用固定三段优先级，后续来源变多时再评估。
- **真实 telemetry 上报链路**（Phoenix endpoint / 鉴权）——需真实环境，手动验证。
