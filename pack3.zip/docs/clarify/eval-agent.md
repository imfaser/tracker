# eval:独立的 agent 评测库(动态系统提示词 + LLM as Judge)

- 日期: 2026-09-29
- 状态: clarify 完成, 待实现
- 关联: `docs/clarify/server-skeleton.md`(上一轮 server 骨架), `docs/clarify/harness-state.md`(State 契约)

## Why Layer

- **业务本质**: 改 agent 的提示词/harness 之后没有可靠的回归感知, 只能手工发消息肉眼验收. `eval` 把"agent 应有行为"写成可重复跑的用例, 一条命令给出通过/失败, 并把 trace 留在 Phoenix. 测的对象是 agent, 所以刻意不经 `server` 那套 HTTP/dishka 栈.
- **问题归属**: 工程问题(缺一条可重复的评测回路).
- **非代码解法**: Phoenix UI 手工发 prompt 看 trace(零代码但不可重复、无断言); 直接挂根 `tests/` 下用 pydantic-evals 的 pytest 集成(零新库但被 server 相关 fixture 绑住, 正是要避开的). 判定自建独立库.

**成功标准**

| # | 标准 | 可验证点 |
|---|---|---|
| S1 | 一条命令跑完 | `uv run eval` 无参数跑完全部 case, 不启 server、不碰 HTTP; 退出码 0 全过 / 非 0 有失败(**自己汇总 `report.cases[*].assertions`, 不能读 `report.failures`**) |
| S2 | 动态提示词注入生效 | 两个 case 分别用 `mimo-v2.6-pro` / `mimo-v2.6-flash` 回答同一个身份问题, 各自自称对应模型; judge 判"合理" |
| S3 | Phoenix 可见 | Phoenix `pychat` 项目里能看到两个 case 的 agent trace, 且评测结论作为 span annotation 写回(2 条 `LLMJudge` 实测可见) |

## 代码库现状速写

| 位置 | 现状 |
|---|---|
| 根 `pyproject.toml` | uv workspace `members = ["packages/*", "server"]`; 根管全部运行时依赖; `[tool.pytest] testpaths = ["tests"]`, `timeout = "10"`, `filterwarnings = ["error"]` |
| `packages/core` | `AppConfig`(init kwargs > `PYCHAT_*` env > `CONFIG_FILE` 文件, 按段深合并)、生成物 `schema.py`(禁手改) |
| `packages/harness` | `AgentState`/`AgentStateBuilder`、`create_model`(各协议策略)、`Orchestrator`/`OrchestratorDeps` |
| `packages/telemetry` | `TelemetryBackend` 协议 + `PhoenixBackend`(裸类, `bootstrap()`/`shutdown()`) |
| `server` | `build_telemetry()` 私有实现, 只在 lifespan 里 bootstrap; `POST /chat/stream` 是唯一 agent 出口 |
| `tests/` | 根一棵树(unit + integration + fixtures); `eval/` 下文件不会被根 pytest 收集 |

**关键事实(带出处)**

1. agent 现状**完全没有系统提示词**: `Agent(model, deps_type=..., capabilities=[Instrumentation(...)])`(`packages/harness/src/harness/agent/orchestrator.py:95-99`).
2. "deps 里保留的模型名称"= `OrchestratorDeps.model_name`(`orchestrator.py:22`), `make_deps()` 从 `AgentState.model_name` 复制(`:72`); `AgentState.model_name` 来自 `harness.default_model` 兜底 / 请求体 `model` 覆盖.
3. 模型在 Agent**构造时**绑定(`orchestrator.py:94`)→ 换模型必须换 Agent.
4. **动态提示词机制实测成立**(离线 spike): `Agent.instructions` 装饰的函数读 `RunContext.deps`, 每次 run 求值; 同一 Agent 换 deps, `ModelRequest.instructions` 跟着变.
5. `pydantic-evals==2.47.0` 已在 lock 与 venv(挂在 `pydantic-ai-slim` 的 `evals` extra 下), 无下载成本.
6. `pydantic-evals` **没有自带 CLI**(`entry_points` 为空, 无 `__main__`)→ 命令行必须由 `eval` 自己封 console script.
7. pydantic-evals 真实 API(本地 introspection): `Case(name, inputs, metadata, expected_output, evaluators)`; `Dataset(name=..., cases, evaluators, report_evaluators)`(`name` 必填 keyword-only); `Dataset.evaluate(task, *, max_concurrency, repeat, ...) -> EvaluationReport`; `Evaluator.evaluate(ctx) -> float|bool|dict`.
8. `LLMJudge(rubric, model, include_input, include_expected_output, model_settings, score, assertion)`, `model` 接受 pydantic-ai 的 `Model` **实例**; 默认 judge 是 `openai:gpt-5.2` → **必须显式传 model**.
9. `report.failures` **不是**"失败用例"(实测: 断言为 `False` 的 case 也在 `failures=[]` 里); 断言结果在 `report.cases[i].assertions[name].value`(LLMJudge 给出 `bool`), evaluator 崩溃在 `report.cases[i].evaluator_failures`.
10. `ReportCase` 带 `trace_id`/`span_id`(无 OTel provider 时全 0).
11. 真实 `config.jsonc`(已读, 未泄密): provider = `test` / `mimo-v2.6-pro` / `mimo-v2.6-flash`(后两个 `protocol: mimo`); `harness.orchestrator.default_model = "test"`, `available_models` 含三个, `thinking.enabled = false`; telemetry = phoenix, project `pychat`, endpoint `http://192.168.16.24:6013/v1/traces`, `batch = false`.
12. Arize 文档的范式是"评估 Phoenix 里已有历史 span"(拉 span dataframe → 评 → 写回标注), 与本次"现场跑 agent 评"不同; 只有写回标注那一半以后再借鉴.

## Prompt Layer

### A. 任务分解

| # | 子任务 | 可独立验证点 |
|---|---|---|
| T1 | 根 `pyproject.toml`: `members` 加 `"eval"`, `sources` 登记, 根依赖加 `eval` | `uv sync` 成功 |
| T2 | 新建 `eval/`(uv_build src 布局, console script `eval = "eval:main"`) | `uv run eval` 可执行 |
| T3 | `harness` 加动态系统提示词(读 `ctx.deps.model_name`) | 现有单测仍绿; 离线 spike 已验机制 |
| T4 | `telemetry` 提出 `build_backend(config)`, `server.app.build_telemetry` 改为委托 | 现有 telemetry/server 测试不加改动仍绿 |
| T5 | eval 侧装配: `AppConfig` → `AgentState`(按 case 指定 model) → `Orchestrator.get_graph()` | 不经 server 拿到 agent |
| T6 | 评测集: 两个 case(pro / flash 各一), judge = `LLMJudge(model=mimo-v2.6-flash)` | 两 case 结果不同 |
| T7 | CLI: bootstrap Phoenix(若配置) → 跑评测 → 打印报告 → 退出码 | 一条命令出表 |
| T8 | 门禁: `ruff` / `ty` 全绿 + 根 `pytest` 全绿 | - |

### B. 涉及文件

| 类别 | 文件 |
|---|---|
| 新建 | `eval/pyproject.toml`; `eval/src/eval/{__init__,cli,dataset,runner}.py`; `packages/telemetry/src/telemetry/backends/factory.py` |
| 写入 | 根 `pyproject.toml`; `packages/harness/src/harness/agent/orchestrator.py`; `packages/telemetry/src/telemetry/__init__.py`; `server/src/server/app.py` |
| 只读 | `core/config.py`、`core/schema.py`(禁改)、`harness/state.py`、`harness/provider.py` |

### C. 接口契约 / 数据契约

- **命令**: `uv run eval`, **无参数**; 退出码 0 = 全部断言通过, 非 0 = 有失败.
- **评测输入**: `PromptCase(model_name: str, message: str)`(frozen dataclass, 即 `InputsT`), case 的 `metadata` 不用, 模型选择走 `inputs`(task 只能看到 inputs, 看不到 metadata).
- **期望值**: `expected_output = model_name`, 只给 judge 的 rubric 用, 不做字符串匹配.
- **agent 注入**: `@agent.instructions` 动态函数, 提示词中文、半角标点, 内容 = "被问身份时回答正在使用 {model_name} 模型".
- **judge**: 单个 `LLMJudge`, `model` 传我们自己构造的 MiMo 模型实例, `include_input=True`, `include_expected_output=True`.
- **不暴露**: HTTP 端点(本任务不涉及).

### D. 校验规则

- 配置: 沿用 `AppConfig`(provider/harness 非空等).
- 模型合法性: 沿用 `Orchestrator.get_graph()` 的 `available_models` 闸门.
- judge 模型必须是**真实模型**: `test` 协议返回字符串标识而非 `Model`, 构造 judge 时显式报错.
- 通过判定: 断言 `value` 为 bool(LLMJudge 实测); 汇总时同时计入 `evaluator_failures`.
- 不改 schema → 不跑 codegen.

### E. 第三方依赖清单

| 包 | 状态 | 用途 |
|---|---|---|
| `pydantic-evals>=2.47.0` | 已在 lock/venv, 本次显式声明 | Dataset / LLMJudge / 报告 |
| `pydantic-ai` 2.47.0 | 已装 | Agent / Model |
| `core` / `harness` / `telemetry` | workspace | 配置、agent、Phoenix 上报 |
| 测试依赖 | **无新增**(eval 不进 pytest) | - |

### F. 运行环境与启动方式

`uv run eval`; 不启 uvicorn/dishka/HTTP. 配置走 `CONFIG_FILE`(缺省 `config.jsonc`)+ `PYCHAT_*`, 由 `AppConfig` 装载. Phoenix 只在 telemetry 段存在且选 phoenix 时 bootstrap, 跑完 shutdown.

### G. 作用过程

```
uv run eval
  └─ AppConfig()                                  ← CONFIG_FILE / PYCHAT_*
  └─ build_backend(config.telemetry)?.bootstrap()  ← 缺省/未选 phoenix = 跳过
  └─ Dataset[PromptCase, str, None](cases=[pro, flash], evaluators=[LLMJudge(flash)])
       └─ 每 case: AgentStateBuilder(harness 兜底 + {"model_name": case.model_name}).build()
                   → Orchestrator(config, state).get_graph()
                   → agent.run(case.message, deps)   ← instructions 读 deps.model_name
                   → output 交 LLMJudge 判"自称是否与 expected_output 一致"
  └─ report.print() + 汇总断言 → SystemExit(0 / 失败数)
```

### H. 测试与验证策略

- 框架: 根 `pytest` 只管库内行为、原样不动; **eval 不写 pytest 用例**(用户口径, 离线单测也不加).
- eval 的验证靠真跑一次 + 看终端 + 看 Phoenix.
- 离线可验的部分已用一次性 spike 钉死: instructions 注入内容、`LLMJudge` 断言值形状、`failures` 语义、dataclass 当 `InputsT`.

### I. 参考材料

| 材料 | 用途 | 形式 |
|---|---|---|
| pydantic-ai Agent `instructions` 文档 | 动态提示词 | 外部链接(页面截断, 机制改由签名 + spike 证实) |
| Arize pydantic-evals 文档 | Dataset / LLMJudge / Phoenix 接入 | 外部链接, 已读 |
| 本地 `pydantic_evals` introspection | 真实 API、无 CLI、断言值形状 | 已实测 |

### J. 约束条件(正向)

- 一律 `uv run`; 中文 Google docstring + **半角标点**(提示词中文但标点半角, 不碰 RUF001/002/003, 不留 lint 口子).
- `ruff` / `ty` / 根 `pytest` 全绿.
- 复用 `Orchestrator` / `AppConfig` / `PhoenixBackend`, 不重写模型构造与配置装载.

### K. 性能要求

每次评测 ≈ 4 次真实 LLM 调用(2 个被测 + 2 次 judge). 数据集小, 不设并发调优; 保持 pydantic-evals 默认 `max_concurrency`.

### L. 边界情况

- 上游模型不通 / key 失效 → 明确报错, 不静默.
- Phoenix 不通(评测仍应给出报告, 但 trace 丢失, 不能算 S3 达标).
- 模型不照指令自报名称 → judge 判失败, 属真实评测结论, 不是工具 bug.
- `telemetry` 段缺省 → 跳过 bootstrap/shutdown.
- judge 与 case 用同一个 `mimo-v2.6-flash` 时存在自恋偏置(见风险 1).

### M. 禁止行为(反向)

- 不依赖 `server`(不 import `server.*`).
- 不把 eval 用例塞进根 `tests/`.
- 不改 `schema/*.json`, 不跑 codegen.
- 不提交真实 `config.jsonc`.
- 不给 CLI 加参数(用户口径: 一条命令跑完).

## Reasoning Layer

### 已知事实

见上文「关键事实」1-12.

### 隐含假设

| # | 假设 | 验证方式 |
|---|---|---|
| 1 | 两个 mimo 模型现网可用(key 有效、`token-plan-cn.xiaomimimo.com` 可达) | 真跑一次 `uv run eval` |
| 2 | 模型会照指令自报名称 | 真跑; 漂移则改提示词措辞 |
| 3 | bootstrap 后 agent span 会落到 LAN Phoenix, `ReportCase.trace_id` 非全 0 | 真跑 + Phoenix UI |
| 4 | 显式声明 `pydantic-evals` 不引发新下载 | `uv sync` |
| 5 | async `Dataset.evaluate` 可直接 await `agent.run(...)` | 真跑 |

### 关键推断

1. **改动面极小**: harness 一处 + 新 `eval/` 包 + telemetry 工厂抽取; 不动 schema、不动 server 行为.
2. **case 差异只能放 `inputs`**: pydantic-evals 的 task 签名只吃 inputs, 拿不到 `metadata` → 用 `PromptCase` 数据类承载"哪个模型 + 问什么".
3. **判定不用字符串匹配**: 用户指定 LLM as Judge; `LLMJudge` 的 `model` 接受 `Model` 实例 → 复用 `harness.provider.create_model`, 不引入 OpenAI.
4. **退出码必须自己汇总**: `report.failures` 语义反证(事实 9) → 从 `assertions[*].value` + `evaluator_failures` 统计.
5. **telemetry 工厂上移到 `telemetry` 包**: `server.app.build_telemetry` 保持存在(测试在 patch 它)但改为委托 `telemetry.build_backend`, eval 直接用后者 → 既不让 eval import `server`, 也不让两处各写一份后端选择逻辑.
   - 自我反驳: 若 `build_telemetry` 的签名/语义被测试锁死到"必须在 server 里实现", 那就退回"eval 自己写 3 行"; 实测测试只 import 与 patch, 委托可行.
6. **提示词中文 + 半角标点**: 满足"中文"诉求同时不破 lint 契约.

### 风险点

1. **judge 自恋偏置**: case `mimo-v2.6-flash` 由 `mimo-v2.6-flash` 自己判(用户指定用 flash 当 judge). 影响有限(判的是"你有没有自称 flash"), 但要知道这不是独立裁判.
2. **`default_model = "test"`**: eval 若图省事取 `default_model` 会拿到固定文本模型 → eval 显式写死两个 mimo key, 不读 default_model.
3. **两处网络**: 上游(外网)+ Phoenix(LAN). 报错要能区分, 否则排障困难.
4. **`failures` 语义坑**(事实 9): 写错就是"假绿"门禁.
5. **Instrumentation 硬编码在 `get_graph()`**: eval 忘 bootstrap 会静默丢 trace, S3 无声失败.
6. **`LLMJudge` 默认 judge = `openai:gpt-5.2`**: 忘传 model 会去连 OpenAI(无 key 直接报错).
7. **eval 代码要过 `ruff`/`ty`**(根 exclude 不含 `eval/`).

## Test Plan

### 测试基础设施

- 框架: 根 `pytest` 原样(只管库内行为); eval 不进 pytest.
- mock 策略: **好 mock** = 动态 instructions 注入内容(TestModel, 零成本, 已用一次性 spike 验证, 本次不再固化成用例); **不好 mock** = 真模型调用与 Phoenix 上报(伪造链路成本 > 收益, 改真跑 + 看 trace_id/UI).
- 通用 setup: 跑前确认 `CONFIG_FILE`/`config.jsonc` 就位; telemetry 段存在则 bootstrap 并在 finally shutdown.

### 测试范围划分

| 档 | 覆盖 | 成本 |
|---|---|---|
| 单元 | 本次不做(用户口径) | - |
| 集成(真跑) | `uv run eval`: 2 case × (被测 + judge) ≈ 4 次 LLM 调用 | 中(需 key + 外网) |
| 手动 | Phoenix UI 看 trace; 标注写回不做 | 高 |

### 成功标准细化成可测场景

- **S1**: S1.1 `uv run eval` 无参数跑完; S1.2 不启 server、不 depend `server` 包; S1.3 退出码由断言汇总(不读 `failures`).
- **S2**: S2.1 pro case 自称 pro; S2.2 flash case 自称 flash(对照组, 证明由注入驱动); S2.3 judge 判通过; S2.4 反向验证: 把某 case 的 `expected_output` 改成另一个模型名, judge 应判失败(防 judge 恒真)—— 实现后手工跑一次确认.
- **S3**: S3.1 Phoenix `pychat` 项目可见两个 case 的 agent trace; S3.2 trace 能区分模型; S3.3 **评测结论作为 span annotation 写回 Phoenix**(已实现, 实测 2 条 `LLMJudge` 标注落在各 case 的评测根 span 上).

### 回归风险

- harness 加 instructions → 现有 `test` 协议集成断言 `success (no tool calls)` 不受影响(TestModel 忽略 instructions); 但**真实模型下 server 输出会开始自报名称**, 属行为变更.
- 根 `pyproject.toml` 加 member → `uv.lock` 变化, 确认无其他包被牵连.
- `telemetry` 抽工厂 + `server.app.build_telemetry` 委托 → 现有单测/集成测试(patch `server_app.build_telemetry`)必须原样通过.
- `ruff`/`ty` 开始扫 `eval/`.

## 实现期发现(2026-09-29)

### 1. 真因: Phoenix 的 "默认槽位" 覆盖语义(已修)

首次真跑时 eval 的 span 一条都没进 Phoenix, 排查结论(源码 + 探针实测):

- `telemetry` 在 eval 里**确实开了**: `cli.evaluate()` 调 `build_backend(config.telemetry).bootstrap()`. 探针证明主上下文发的 span 能落到 Phoenix.
- 真因在 phoenix 侧: `phoenix.otel.otel.TracerProvider.add_span_processor` 默认 `replace_default_processor=True`, 会 **shutdown 并移除** `register()` 建的默认 OTLP processor(`packages/../.venv/.../phoenix/otel.py:280-315`).
- pydantic-evals 在每个 case 的 `context_subtree()` 里按标准 OTel 语义调 `provider.add_span_processor(SimpleSpanProcessor(内存 exporter))`(用于它自己的 span tree / requests / tokens 指标), **不带那个 phoenix 专有开关** → 我们的导出链路被静默掐断, 且不可逆: 之后连主上下文发的 span 也不再上报(实测 `outside-after-task` 未落地).
- 修法: `PhoenixBackend.bootstrap()` 在挂完 OpenInference processor 后把该导出器从 "默认槽位" 降级为普通 processor(`provider._default_processor = None`), 使后续任何 `add_span_processor` 都不再影响它. 探针验证 + 真跑验证: 修复后两个模型的 span 均落 Phoenix.
- 附带收益: server 侧同样免疫(任何三方库按标准语义挂 processor 都不会再掐掉上报).

### 2. 真跑结论: judge 判过, 但模型实际没按指令自报(评测口径需要收紧)

Phoenix 里的 span 证实**注入是生效的**(动态提示词进了请求):

- `llm.input_messages.0`(system)= `当用户问你是谁或你是什么模型时, 回答你正在使用 mimo-v2.6-pro 模型.`
- `model_request_parameters.instruction_parts[0].dynamic = true`
- 但 `llm.output_messages.0` = `你好！我是MiMo，由小米公司大模型Core团队开发的大语言模型...`(flash 同样报品牌名)

即: **提示词没打过模型的品牌话术**, 而 `LLMJudge` 用当前 rubric("给出该模型名或等价说法即通过")把它判成了通过 —— 属于 S2.4 想防的"假绿". 待定项:

- rubric 是否收紧为"回答必须字面包含 `<expected>`";
- 提示词措辞是否加强(明确"不要说厂商/品牌名");
- judge 模型是否换成判别力更强的一个(或交叉判).

### 3. 评测结论写回 Phoenix(已实现, 对齐官方文档)

**为什么之前 Phoenix 里"看不到测试"**: 之前只做到了 trace 上报(span 在), 但没有把评测结论写回, 而"评测结果"在 Phoenix 里就是 **span annotation**, 需要额外调一次标注接口. 现在已按官方文档实现:

- 客户端: `arize-phoenix-client` 的 `client.spans.log_span_annotations(span_annotations=[...], sync=True)`, 每条标注为 `{name, annotator_kind, span_id, identifier, result: {label, score, explanation}}`(`from phoenix.client.__generated__.v1 import SpanAnnotationData`).
- base URL 与采集端点是两回事: 配置里 `telemetry.phoenix.endpoint` 是 OTLP 采集端点(`.../v1/traces`), 客户端要的是去掉该路径的 base URL(`annotations.base_url()`).
- 对齐方式: 不用文档里"按 input 字符串匹配"的做法 —— **任务自己开一个评测根 span**(`eval <模型名>`), 记下它的 `span_id`, 判定直接落在它上面. 实测该 span 是 agent span 的父节点, 同一条 trace.
- 顺带纠正: `ReportCase.trace_id/span_id` 实测**恒为全 0**(pydantic-evals 的 case span 依赖 logfire, 未配置时没有), 所以不能拿它对齐 —— 这也是自开根 span 的原因.
- 实测(2026-09-29 16:22): `POST /v1/span_annotations?sync=true → 200`, 2 条标注; 从 Phoenix 侧查得 `name=LLMJudge, annotator_kind=LLM, label=pass, score=1` 挂在 `eval mimo-v2.6-pro` / `eval mimo-v2.6-flash` 两个 span 上, 各有 judge 的 explanation.

文档里另一半(**把 Phoenix 里已有的 trace 捞出来当评测数据源**, `client.spans.get_spans_dataframe(query=SpanQuery()...)`)仍未采用: 我们现在的数据源是"评测现场跑 agent", 可重复性更好; 若以后要做"给线上真实流量补评测", 再按那半接.

## 开放问题(待 explore 深挖)

- **Trace 驱动的评测数据源**(文档另一半): 用 `client.spans.get_spans_dataframe(SpanQuery()...)` 把 Phoenix 里已有 trace 捞出来当 case, 用于"给线上真实流量补评测"; 现在是"现场跑 agent"模式, 可重复性更好, 两种可按需并存.
- **自恋偏置**: judge 是 `mimo-v2.6-flash`, 实测它会把 `我是MiMo` 解释成"与 mimo-v2.6-pro 等价"而判通过; 若要把 S2 的"自称对应模型"做硬, 需要收紧 rubric 或换判别力更强的 judge.
- **更多 case 维度**: 当前只有"自报身份"一个维度(用户要求两个 case 即可); 以后要加拒答/工具调用等维度时再扩评测集.
