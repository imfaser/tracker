# harness 运行时配置合成（State / StateBuilder）

- 日期: 2026-09-29
- 状态: clarify 完成, 已进入实现

## Why Layer

- **业务本质**: 为 "agent 创建前的运行时配置" 提供一个合成载体 `State`：把配置级默认（`HarnessConfig`）合成出这一次运行的生效值（模型名 / 思考开关 / 思考强度），在创建模型与 agent 之前交给它们。覆盖只影响本次运行，绝不写回共享配置。
- **帮谁**: 调用方（server 阶段按请求定制）、后端维护者（一眼看清生效配置的来源与优先级）。
- **痛点**: 配置来源一旦多于一个，就缺一个明确的合成点；没有它只能把值到处传，或改共享配置（后者会让后续用户拿到被改过的配置）。
- **不要**: 不 mutate 全局 config；不预留今天用不到的抽象件；不写怪代码。
- **问题归属**: 技术问题（架构 / 抽象边界），非业务流程、非协作问题。
- **非代码解法**: 已评估。pydantic-ai 的 run 级覆盖解决的是 "运行时怎么覆盖"，State 解决的是 "运行前怎么把多来源合成生效配置"，两者不重复。仍走澄清流程。

**成功标准**

| # | 标准 | 可验证点 |
|---|---|---|
| S1 | 默认路径 | 不带任何覆盖时，State 的生效值完全等价于 `HarnessConfig` 段 |
| S2 | 覆盖路径 | 合成接受逐字段覆盖：只覆盖表态字段，未表态回退兜底；只影响本次 State |
| S3 | 无污染 | 覆盖不写回共享配置；后续与并发调用读到的仍是配置级默认 |
| S4 | 简洁可读 | 新增抽象克制（一个 State 值对象 + 一个 StateBuilder）；风格与仓库一致；ty / ruff / pytest 全绿 |
| S5 | 可离线验证 | 用 `test` 协议在无网络下跑通 S1 - S3 |

## 代码库现状速写

```
core/config.py: AppConfig(BaseSettings)
   └─ 三来源装载: init > env(PYCHAT_) > config.jsonc, 按段深合并
        ↓
harness/agent/orchestrator.py: Orchestrator(config)
   └─ get_graph(deps) → 现状只校验 available_models 然后 return None（半成品）
        ↓
harness/provider.py: create_model(model_name, provider_config, agent_config)
   └─ ModelBuilder → match protocol → 5 个平级 ModelStrategy
```

- **已有相关实现**: `core/config.py:68 settings_customise_sources` 已是一套 "多来源优先级合并"（按来源类型定序，不看登记顺序）。State 沿用同一范式。
- **风格约定**: 中文 Google docstring（`Args:` / `Returns:` / `Raises:`）、半角标点（RUF001/002/003）、纯函数优先、`match` 做分派、运行时值对象用 `@dataclass`、pydantic 只用于配置格式与装载。
- **事实源**: `schema/*.json` → codegen → `core/schema.py`；本次不改 schema，不跑 codegen。
- **集成点**: State 插在 `Orchestrator` 与 `provider.create_model` 之间，取代散落的 `agent_config.thinking` 读取。

## Prompt Layer

### A. 任务分解
1. 新增 `State`（frozen dataclass，字段全必填）。
2. 新增 `StateBuilder`：`add_source`（`@overload` 签名 + `match case` 分派）+ `build()` 合成。
3. 优先级合成：来源类型定序 + 同类型后登记胜。
4. `Mapping` 来源的白名单校验（未知键报错）。
5. `provider.py` 改吃 `State`。
6. `Orchestrator(config, state)` 在**构造时**接收外部合成好的 State，`get_graph()` 无参返回真正的 Agent（State 不在 Orchestrator 内创建）。
7. 测试：新增 `tests/unit/test_state.py`，更新 `tests/unit/test_provider.py`。

### B. 涉及文件
| 类别 | 文件 |
|---|---|
| 新建 | `packages/harness/src/harness/state.py`；`tests/unit/test_state.py` |
| 写入 | `packages/harness/src/harness/provider.py`；`packages/harness/src/harness/agent/orchestrator.py`；`tests/unit/test_provider.py` |
| 只读 | `core/schema.py`（生成物，禁改）；`schema/harness.json`；`config.example.jsonc` |
| 不涉及 | `core/config.py` |

### C. 接口契约 / 数据契约

**State（生效值，字段全必填，不存在 "未表态"）**

| 字段 | 类型 | 兜底来源 | 可被覆盖 |
|---|---|---|---|
| `model_name` | `str` | `HarnessConfig.default_model` | 是 |
| `thinking_enabled` | `bool` | `HarnessConfig.thinking.enabled` | 是 |
| `effort` | `Effort` | `HarnessConfig.thinking.effort` | 是 |

**StateBuilder**
- `add_source(source) -> Self`：`@overload` 签名 `HarnessConfig` / `Mapping[str, Any]`；重复登记允许，依次入列。
- `build() -> State`：按优先级合成。

**优先级**: 来源**类型**定序（`HarnessConfig` 最低 < `Mapping` 最高），与登记顺序无关；同类型多来源时后登记覆盖先登记。

**`Mapping` 来源键**: `model_name` / `thinking_enabled` / `effort`（即 `State` 的字段名）。

**provider 契约变更**: `create_model(state, provider_config)`、`ModelBuilder(state, provider_config)`、`ModelStrategy.build(state, provider_config)`、`_thinking_settings(state)`。

**Orchestrator 契约变更**: 构造签名 `Orchestrator(config, state)`、`get_graph() -> Agent[OrchestratorDeps, str]`、`make_deps() -> OrchestratorDeps`。**State 由调用方在外部合成，构造时传入，Orchestrator 不创建 State**。`OrchestratorDeps` 保留（含 `model_name` 与 `update(dict)`），`model_name` 由 `State.model_name` 复制而来。

### D. 校验规则
- `Mapping` 键白名单：未知键报错（带键名），不静默忽略。
- `Mapping` 值类型：`model_name: str`、`thinking_enabled: bool`；`effort` 经 `Effort(...)` 归一（非法值抛 `ValueError`）。
- 来源类型未注册 → `TypeError`，信息含 `type(source)`。
- `build()` 校验：合成后三个字段齐全（缺兜底时报错，不产出残缺 State）。
- `match` 分支顺序：具体类型分支必须在 `Mapping` 之前（`Mapping` 是宽分支）。
- 模型可用性（`available_models`）校验保留在 `Orchestrator`。
- `effort` 被覆盖型来源显式设定但 `thinking_enabled=False` → 打 warning 后忽略。

### E. 第三方依赖清单
不新增。只用 stdlib（`dataclasses` / `typing` / `collections.abc`）与已有 pydantic / pydantic-ai。

### F. 运行环境与启动方式
uv workspace（CPython 3.14）。库代码改动，无独立启动入口；验证走 `uv run pytest` / `uv run ty check` / `uv run ruff check`。

### G. 作用过程
```
                              ┌────── 外部合成 ──────┐
HarnessConfig ──add_source──┐                         ↓
                            ├─→ StateBuilder ──build()──→ State ─────────────┐
Mapping(dict) ──add_source──┘  (类型定序: HarnessConfig < Mapping)            │
                                                                             ↓
                                              Orchestrator(config, state).get_graph() ──→ Agent
                                              (create_model(state, provider))
```

### H. 测试与验证策略
- 框架：pytest，`tests/unit/`（纯逻辑，不触 IO / 网络 / 进程）。
- fixture：`HarnessConfig(...)` / `State(...)` kwargs 直接构造；需要干净环境时用 `tests/unit/conftest.py` 的 `clean_env`。
- mock 策略：**不需要 mock**。`State` / `StateBuilder` 无 IO、无外部状态、输入输出可纯函数化（好 mock 判定成立），但直接用真对象成本更低；provider 侧用 `test` 协议离线验证，不 mock 网络。
- 单元覆盖合成与校验；真实 provider 协议的思考档位生效与否属手动验证。

### I. 参考材料
| 材料 | 用途 | 形态 |
|---|---|---|
| `core/config.py:68 settings_customise_sources` | 多来源优先级范式（按类型定序） | Python，仓库内 |
| `provider.py:140 ModelBuilder.build` | `match` 分派范式 | Python，仓库内 |
| pydantic-ai 模型设置优先级 model < agent < run | 已在用，本任务不改 | 外部框架 |

### J. 约束条件（正向）
- 代码简洁，风格与仓库一致：中文 Google docstring、半角标点。
- 不用 `*,` 关键字-only 标记。
- 无模块级全局常量 / 注册表。
- 纯函数优先，易改易测。
- `ty check` / `ruff check` / `pytest` 全绿。

### K. 性能要求
本任务不涉及（State 构造与合成为微秒级，无热路径）。

### L. 边界情况
- 只登记 `Mapping`、未登记 `HarnessConfig` → `build()` 报错（缺兜底，产不出全字段）。
- `Mapping` 传空 `{}` → 等价 "全不表态"，合法。
- 同一来源登记两次 → 后登记覆盖先登记。
- 两个 `Mapping` 来源键冲突 → 后登记胜。
- `HarnessConfig.thinking` 未配置 → `thinking_enabled=True`、`effort=Effort.medium`（**已裁决**，见 Reasoning 风险 1）。
- `effort` 被覆盖型来源显式设定但 `thinking_enabled=False` → warning 后忽略。
- `model_name` 不在 `available_models` → `Orchestrator` 抛 `ValueError`。

### M. 禁止行为（反向）
- 禁止 mutate 全局 `AppConfig` / 任何共享配置对象。
- 禁止引入 `Protocol` 来源抽象 / 注册表 / 插件机制。
- 禁止改 `schema/*.json`（State 不是配置格式，不进事实源，不跑 codegen）。
- 禁止多余注释、禁止中文全角标点。
- 禁止新增第三方依赖。
- 禁止提前做 request 来源（server 阶段再做）。
- 禁止把 "未表态" 的 `None` 泄漏进 `State`。

## Reasoning Layer

### 已知事实
1. `Thinking` 字段自带默认值：`enabled: bool = True`、`effort: Effort = Effort.medium`（`core/schema.py:57-62`）。
2. `HarnessConfig.thinking: Thinking | None = None`（段本身可选）；`default_model` 与 `available_models` 才是必填（`core/schema.py:65-71`）。
3. 现状 `thinking is None` → 返回空 `ModelSettings()`，即 "完全不下发思考设置"，与 "下发 `thinking=False`" 语义不同（`provider.py:27-29`）。
4. `Effort` = `low/medium/high/max`。
5. `AppConfig` / `HarnessConfig` 均非 `Mapping` 子类（实测 `issubclass` 为 False）→ `match case Mapping()` 不会截胡。
6. `create_model` 在 pychat 内无外部调用者；`_thinking_settings` 被 4 个策略调用，`ModelBuilder` 仅被 `create_model` 调用。blast radius 很小。
7. `get_graph()` 现状校验后 `return None`，是半成品；`Orchestrator` 无外部调用者，签名可安全调整。
8. `VllmStrategy` 额外下发 `extra_body.chat_template_kwargs.enable_thinking`；`TestStrategy` 在有 thinking 时 warning。
9. workspace 根下有兄弟项目（`chatbot` / `chatbot1` / `deepview`）含同名 `core/schema.py`、`create_model`，检索易混淆。
10. ty 对 `@overload` + `-> Self` + `match case` 组合**验证通过**（spike 实测，ruff 亦通过）。

### 隐含假设
| # | 假设 | 验证方式 | 结果 |
|---|---|---|---|
| 1 | `match case Mapping()` 不匹配 `AppConfig` | 实测 `issubclass` | 成立 |
| 2 | "有兜底就不可能为空" | 读 schema | **不成立**：`thinking` 段可选（见风险 1） |
| 3 | `@overload` + `Self` + `match case` 在 ty 下可用 | 写 spike 实测 | **成立** |
| 4 | provider 配置按 `state.model_name` 从 `config.provider[...]` 取 | 现有 `create_model` 调用约定 | 成立 |
| 5 | `model_name` 从 State 复制进 Deps 即满足运行时需要 | 用户裁决 + `RunContext.deps` 语义 | 成立 |
| 6 | State 不进 schema、不跑 codegen | 本次不改 schema | 成立 |

### 关键推断
1. **`create_model` 签名变更影响面极小** —— rg 显示无存量调用点，只需同步 `provider.py` 与 `test_provider.py`。推翻尝试：orchestrator 接线后会新增调用点，但那是本次新增。
2. **"来源类型定序" 在当前 2 类来源下完备** —— 来源角色二分（兜底 / 覆盖）各一类。推翻尝试：server 阶段出现第二个覆盖型来源时会退化，需显式优先级（已记入风险 3）。
3. **`model_name` 复制进 `OrchestratorDeps` 是必要的** —— `RunContext.deps` 是 agent 运行期读取依赖的入口，State 是构造期产物。推翻尝试：能否 `deps_type=State`？技术可行但会让 "配置合成" 与 "运行依赖" 两个边界混淆（上次 `ModelSpec` 翻车的根因）。
4. **表态与优先级必须同列存储** —— 合成要按 `(优先级, 登记序)` 稳定排序，分两处存易错位。

### 风险点
1. **`thinking` 未配置的语义冲突（已裁决）** —— "有兜底就不可能为空" 对 `model_name` 成立、对 `thinking` 不成立。裁决：未配置 → **开启**（`thinking_enabled=True`、`effort=medium`）。行为变更：从 "不下发思考设置" 变为 "明确开思考 medium"，连带 vLLM 会下发 `enable_thinking: true`、`TestStrategy` 会 warning。
2. **ty 兼容性** —— 已实测通过，风险解除。
3. **优先级方案在 "覆盖型来源 >= 2" 时退化** —— server 阶段加 request 时重审。
4. **warning 刷屏** —— 已收敛为 "仅当覆盖型来源显式设定 effort 且思考关闭" 才告警，避免每次关思考都刷。
5. **`get_graph()` 返回值变更** —— 从 `None` 变为 `Agent[OrchestratorDeps, str]`，是修复也是行为变更。
6. **已知技术债（用户决定保留）** —— `OrchestratorDeps.update(dict)` 是 untyped 逃生舱，与 "易测" 约束有张力，不阻塞。
7. **兄弟项目同名符号干扰** —— 实际改动只在 `pychat/`。

## Test Plan

### 测试基础设施
- 框架：pytest（根目录 `uv run pytest`），用例放 `tests/unit/`。
- fixture 策略：`HarnessConfig(...)` / `State(...)` 用 kwargs 直接构造，用例独有，不共享；需要干净环境时用 `clean_env`。
- mock 策略：不 mock。纯值对象与纯合成直接用真对象；provider 用 `test` 协议离线验证。真实网络与真实 key 的协议验证属手动。

### 测试范围划分
| 档 | 覆盖 | 成本 |
|---|---|---|
| 单元 | State 构造、StateBuilder 合成与优先级、白名单与类型校验、错误分支、`_thinking_settings` 映射、`create_model(test 协议)`、`Orchestrator.build_state/make_deps/get_graph` | 低，全测 |
| 集成 | 本任务不涉及（`get_graph` 用 `test` 协议无 IO，归单元） | - |
| 手动 | 真实 anthropic / openai / vllm 协议的思考档位是否生效 | 高（需真实 key），不自动化 |

### 成功标准细化成可测场景
- **S1 默认路径**：S1.1 兜底出全字段；S1.2 `thinking` 未配置 → `enabled=True`、`effort=medium`；S1.3 `thinking` 已配置 → 跟随配置。
- **S2 覆盖路径**：S2.1 覆盖 `model_name`；S2.2 覆盖 `thinking_enabled`；S2.3 覆盖 `effort`；S2.4 部分覆盖其余回退兜底；S2.5 两个 `Mapping` 后登记胜。
- **S3 无污染**：S3.1 `build()` 后源配置对象未被修改；S3.2 连续两次 `build()` 结果一致；S3.3 `State` frozen 不可变。
- **S4 简洁可读**：S4.1 ty / ruff / pytest 全绿；S4.2 无模块级常量、无 `Protocol` 来源抽象。
- **S5 可离线验证**：S5.1 `test` 协议无网络跑通 S1 - S3。

### 回归风险
- `provider.py` 签名变更 → `tests/unit/test_provider.py` 需同步。
- `thinking` 未配置语义变更（见 Reasoning 风险 1）→ 影响 vLLM 下发与 `TestStrategy` 告警，需补用例锁定新语义。
- `get_graph()` 返回值变更 → 补用例锁定返回类型与模型可用性校验。

## 开放问题（待 explore 深挖）

- **优先级在覆盖型来源 >= 2 时的退化**（Reasoning 风险 3）——留给 explore：需要权衡 "显式优先级参数" 与 "来源角色二分" 哪个更符合 server 阶段的 request 语义，属于需要读运行时调用链才能定的取舍，不适合当场拍。
- **真实协议的思考档位映射是否准确**（anthropic adaptive/budget、openai reasoning.effort、vllm enable_thinking）——留给 explore：需要读 pydantic-ai 与各上游文档确认，超出本任务范围，且需要真实 key 手动验证。
