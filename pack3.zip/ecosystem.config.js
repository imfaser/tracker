// PM2 应用定义(开发用常驻进程)。启动/重启前必须先 `pm2 delete pychat-server`:
// PM2 会缓存同名旧实例, 直接 start 会拿到旧进程。
//
// 用法:
//   pm2 delete pychat-server; pm2 start ecosystem.config.js
//   集成测试用同一份配置, 通过环境变量换名换端口(PM2_APP_NAME / SERVER_PORT / CONFIG_FILE),
//   因此不碰开发实例。
const appName = process.env.PM2_APP_NAME || "pychat-server";
const host = process.env.SERVER_HOST || "127.0.0.1";
const port = process.env.SERVER_PORT || "8000";
const configFile = process.env.CONFIG_FILE || "config.jsonc";

module.exports = {
  apps: [
    {
      name: appName,
      interpreter: "none",
      script: "uv",
      args: "run server",
      cwd: __dirname,
      autorestart: false,
      watch: false,
      env: {
        PYTHONUNBUFFERED: "1",
        CONFIG_FILE: configFile,
        SERVER_HOST: host,
        SERVER_PORT: port,
      },
    },
  ],
};
