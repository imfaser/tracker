"""server 包入口: 以 uvicorn 拉起 FastAPI 应用."""

from __future__ import annotations

import os


def main() -> None:
    """启动服务(uvicorn factory 模式).

    bind 地址由 `SERVER_HOST` / `SERVER_PORT` 环境变量给出, 缺省 `127.0.0.1:8000`
    (环境变量只在这一层读取, 是唯一的外部边界).
    """
    import uvicorn

    uvicorn.run(
        "server.app:create_production_app",
        factory=True,
        host=os.getenv("SERVER_HOST", "127.0.0.1"),
        port=int(os.getenv("SERVER_PORT", "8000")),
    )
