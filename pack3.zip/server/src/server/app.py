"""FastAPI 应用工厂与 lifespan."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from core.config import AppConfig
from core.logging import configure_logging
from core.schema import Telemetry
from dishka import AsyncContainer
from dishka.integrations.fastapi import setup_dishka
from fastapi import FastAPI
from telemetry import build_backend
from telemetry.backends.base import TelemetryBackend

from server.container import make_container
from server.routers.chat import router as chat_router


def build_telemetry(config: Telemetry | None) -> TelemetryBackend | None:
    """按 telemetry 配置段构造追踪后端.

    后端选择逻辑在 telemetry 包内, 这里只做对 lifespan 稳定的薄入口(便于测试替换).

    Args:
        config (Telemetry | None): telemetry 配置段, 缺省表示不启用追踪.

    Returns:
        TelemetryBackend | None: 对应的追踪后端; 未配置时返回 None.
    """
    return build_backend(config)


def create_app(container: AsyncContainer) -> FastAPI:
    """创建 FastAPI 应用: 装配 lifespan、路由与 dishka 集成.

    Args:
        container (AsyncContainer): 外部装配好的 dishka 容器.

    Returns:
        FastAPI: 可直接交给 ASGI server 的应用实例.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        config = await container.get(AppConfig)
        configure_logging(config.logging)
        backend = build_telemetry(config.telemetry)
        if backend is not None:
            backend.bootstrap()
        try:
            yield
        finally:
            if backend is not None:
                backend.shutdown()
            await container.close()

    app = FastAPI(title="pychat", lifespan=lifespan)

    @app.get("/health")
    async def health() -> dict[str, str]:
        """健康检查端点."""
        return {"status": "ok"}

    app.include_router(chat_router)
    setup_dishka(container=container, app=app)
    return app


def create_production_app() -> FastAPI:
    """按默认容器创建生产应用, 供 ASGI server 以 factory 模式拉起.

    Returns:
        FastAPI: 装配好容器与 lifespan 的应用实例.
    """
    return create_app(container=make_container())
