"""dishka 容器装配: 应用级与请求级依赖."""

from __future__ import annotations

from core.config import AppConfig
from dishka import AsyncContainer, Provider, Scope, make_async_container, provide
from dishka.integrations.fastapi import FastapiProvider
from harness.state import AgentState, AgentStateBuilder
from starlette.requests import Request


class AppProvider(Provider):
    """应用级依赖: 装载一次, 活到应用结束."""

    @provide(scope=Scope.APP)
    def config(self) -> AppConfig:
        """从 config.jsonc / 环境变量装载应用配置.

        Returns:
            AppConfig: 全局唯一的应用配置.
        """
        return AppConfig()


class AgentStateProvider(Provider):
    """请求级依赖: 每请求合成一份 AgentState, 用完即弃."""

    @provide(scope=Scope.REQUEST)
    async def agent_state(self, request: Request, config: AppConfig) -> AgentState:
        """按配置兜底 + 请求体覆盖合成本次运行的生效配置.

        这里的 Request 是 FastapiProvider 绑定的那一个, 路由侧也用 `FromDishka[Request]` 取同一
        实例, 因此 body 只读一次(缓存在 `_body` 上), 下游复用不会造成二次读 wire 的死锁.

        Args:
            request (Request): 当前请求, 由 FastapiProvider 注入.
            config (AppConfig): 应用配置, 提供 harness 兜底段.

        Returns:
            AgentState: 本次请求的生效运行时配置.
        """
        await request.body()
        return await (
            AgentStateBuilder()
            .add_source(config.harness["orchestrator"])
            .add_source(request)
            .build()
        )


def make_container() -> AsyncContainer:
    """装配容器: 自定义 provider + dishka 的 FastAPI 集成 provider.

    Returns:
        AsyncContainer: 可直接交给 setup_dishka 的异步容器.
    """
    return make_async_container(AppProvider(), AgentStateProvider(), FastapiProvider())
