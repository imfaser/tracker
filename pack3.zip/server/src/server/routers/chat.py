"""聊天路由: 每请求合成 AgentState 并新建 agent, 交出 Vercel AI data stream."""

from __future__ import annotations

from core.config import AppConfig
from dishka.integrations.fastapi import DishkaRoute, FromDishka
from fastapi import APIRouter
from fastapi.responses import Response
from harness.agent.orchestrator import Orchestrator
from harness.state import AgentState
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from starlette.requests import Request

router = APIRouter(prefix="/chat", route_class=DishkaRoute, tags=["chat"])


@router.post("/stream", response_model=None)
async def chat(
    request: FromDishka[Request],
    state: FromDishka[AgentState],
    config: FromDishka[AppConfig],
) -> Response:
    """把当前请求转成一次 agent 流式运行, 并以 Vercel AI data stream 返回.

    请求必须取 dishka 注入的 Request(与 AgentStateProvider 同一个实例), 不要用 FastAPI 的
    `request: Request`: 那会造出第二个 Request 实例, 两个实例各缓存一份 `_body`, 第二次读 body
    会一直等 http.disconnect, 形成死锁.

    agent 必须连同 deps 一起交给适配器: 动态系统提示词从 `ctx.deps.model_name` 取身份说明,
    只传 agent 不传 deps 会让运行时拿到 None.

    Args:
        request (Request): 当前请求, 由 dishka 注入, 同时承载 Vercel AI 的输入.
        state (AgentState): 本次请求的生效运行时配置.
        config (AppConfig): 应用配置.

    Returns:
        Response: SSE 流式响应.
    """
    orchestrator = Orchestrator(config, state)
    deps = orchestrator.make_deps()
    agent = orchestrator.get_graph(deps)
    return await VercelAIAdapter.dispatch_request(request, agent=agent, deps=deps, sdk_version=7)
