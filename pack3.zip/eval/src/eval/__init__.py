"""pychat agent 评测: 一次跑一个模型的自报身份, judge 按 0-100 打分, 结论写回 Phoenix."""

from __future__ import annotations

import json

import anyio
from core.config import AppConfig
from core.logging import configure_logging
from dishka import Provider, Scope, make_async_container, provide
from harness.agent.orchestrator import Orchestrator, OrchestratorDeps, orchestrator_harness_config
from harness.provider import create_model
from harness.state import AgentStateBuilder
from openinference.semconv.trace import (
    OpenInferenceMimeTypeValues,
    OpenInferenceSpanKindValues,
    SpanAttributes,
)
from opentelemetry import trace
from pydantic_evals import Case, Dataset
from pydantic_evals.evaluators import LLMJudge
from telemetry import Uploader, build_backend

from eval.dataset import PromptCase, grade_of


class EvalProvider(Provider):
    """评测侧依赖: 照 server 的 AppProvider 写法, 应用级构造一次."""

    @provide(scope=Scope.APP)
    def config(self) -> AppConfig:
        """装载应用配置.

        Returns:
            AppConfig: 应用配置.
        """
        return AppConfig()

    @provide(scope=Scope.APP)
    def uploader(self, config: AppConfig) -> Uploader:
        """构造结论写回器.

        Args:
            config (AppConfig): 应用配置, 提供 telemetry 段.

        Returns:
            Uploader: 把结论写成 Phoenix span 标注的写回器.
        """
        return Uploader(config.telemetry)


async def run() -> None:
    """线性跑完一次评测: 跑被测 agent -> judge 打分 -> 写回 Phoenix.

    被测模型与 judge 都硬编码在这里: 一次只测一个模型, 换模型就改下面那两行.

    标注写回排在 telemetry 收尾之后是硬约束: shutdown 会 flush 尚未上报的 span, 而标注要按 span id
    落到已存在的 span 上, 写早了服务端查不到该 span, 会直接 404.
    """
    model_name = "mimo-v2.6-pro"
    judge_name = "mimo-v2.6-flash"
    question = "你好, 请问你是谁? 你是什么模型?"
    passing_score = 60.0

    container = make_async_container(EvalProvider())
    try:
        config = await container.get(AppConfig)
        uploader = await container.get(Uploader)
        configure_logging(config.logging)
        backend = build_backend(config.telemetry)
        if backend is not None:
            backend.bootstrap()
        try:
            state = await (
                AgentStateBuilder()
                .add_source(orchestrator_harness_config(config))
                .add_source({"model_name": model_name})
                .build()
            )
            judge_state = await (
                AgentStateBuilder()
                .add_source(orchestrator_harness_config(config))
                .add_source({"model_name": judge_name})
                .build()
            )
            judge = LLMJudge(
                rubric=(
                    "判定回答是否如实报出了 Expected Output 指定的模型标识(那个字符串本身). "
                    "分数只写在 score 字段, 用 0-100 的整数: "
                    "100 = 回答里字面出现了该模型标识, 且没有说成别的型号; "
                    "70 = 出现了该模型标识, 但同时报了厂商/品牌/别的型号, 或表述含糊; "
                    "30 = 只报了厂商或品牌(例如只说自己是 MiMo), 没有出现该模型标识本身; "
                    "0 = 报成了别的模型标识, 答非所问, 或拒绝回答. "
                    '厂商名与品牌名不等于模型标识: 例如期望是 mimo-v2.6-pro 时, 只回答"我是MiMo"'
                    "(没有写出该标识)只能给 30 分, 不能给 100 分."
                ),
                model=create_model(judge_state, config.provider[judge_name]),
                include_input=True,
                include_expected_output=True,
                score={"include_reason": True},
                assertion=False,
            )
            dataset = Dataset[PromptCase, str, None](
                name="自报身份",
                cases=[
                    Case(
                        name=f"{model_name} 自报身份",
                        inputs=PromptCase(model_name=model_name, message=question),
                        expected_output=model_name,
                    )
                ],
                evaluators=[judge],
            )

            async def task(case: PromptCase) -> str:
                """跑一次被测 agent, 计时与打分交给 Dataset.

                Args:
                    case (PromptCase): 用例输入.

                Returns:
                    str: agent 的回答.
                """
                deps = OrchestratorDeps(model_name=case.model_name)
                agent = Orchestrator(config, state).get_graph(deps)
                return (await agent.run(case.message, deps=deps)).output

            tracer = trace.get_tracer("pychat-eval")
            with tracer.start_as_current_span(f"eval {model_name}") as span:
                span.set_attribute(
                    SpanAttributes.OPENINFERENCE_SPAN_KIND,
                    OpenInferenceSpanKindValues.EVALUATOR.value,
                )
                span.set_attribute(SpanAttributes.INPUT_VALUE, question)
                span.set_attribute(
                    SpanAttributes.INPUT_MIME_TYPE, OpenInferenceMimeTypeValues.TEXT.value
                )
                span.set_attribute(
                    SpanAttributes.METADATA,
                    json.dumps(
                        {"eval": True, "model_name": model_name, "judge_model_name": judge_name}
                    ),
                )
                report = await dataset.evaluate(task)
                span.set_attribute(SpanAttributes.OUTPUT_VALUE, report.cases[0].output)
                span.set_attribute(
                    SpanAttributes.OUTPUT_MIME_TYPE, OpenInferenceMimeTypeValues.TEXT.value
                )
                span_id = f"{span.get_span_context().span_id:016x}"
        finally:
            if backend is not None:
                backend.shutdown()

        report.print()
        grade = grade_of(report)
        label = "pass" if grade.score >= passing_score else "fail"
        uploaded = uploader.upload(span_id, label, grade.score, grade.reason)
        print(
            f"{model_name}: {label} {grade.score:.0f} 分 - {grade.reason}(写回 {uploaded} 条标注)"
        )
        if label != "pass":
            raise SystemExit(1)
    finally:
        await container.close()


def main() -> None:
    """命令行入口: 跑一次评测, 未达标即非零退出.

    console script 调的是同步入口, 异步流程在 `run` 里; 未达标由流程内抛 SystemExit,
    会原样穿出 anyio 决定退出码.
    """
    anyio.run(run)
