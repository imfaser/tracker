"""与 pydantic-evals 的对接层: 用例的输入形状与结论的读法.

pydantic-evals 按值类型分桶: 布尔结论进 `assertions`, 数值结论进 `scores`, 开了
include_reason 时值还会被 EvaluationReason 再包一层. 这些形状差异都收在本文件里摊平,
评测流程本身只拿百分制分数与解释.
"""

from __future__ import annotations

from dataclasses import dataclass

from pydantic_evals.evaluators import EvaluationReason
from pydantic_evals.reporting import EvaluationReport


@dataclass(frozen=True, slots=True)
class PromptCase:
    """一条评测用例的输入: 用哪个模型回答哪个问题.

    Attributes:
        model_name (str): provider 映射段的 key, 即本次被评测的模型, 同时期望的回答标识.
        message (str): 发给 agent 的用户消息.
    """

    model_name: str
    message: str


@dataclass(frozen=True, slots=True)
class Grade:
    """judge 给出的一条结论.

    Attributes:
        score (float): 百分制分数.
        reason (str): 解释文本.
    """

    score: float
    reason: str


def grade_of(report: EvaluationReport[PromptCase, str, None]) -> Grade:
    """从报告里掏出 judge 结论.

    judge 可能直接给百分制( 0-100 ), 也可能沿用它自己的示例给比例刻度( 0-1 ),
    值落在 [0, 1] 时按比例放大成百分制; 布尔结论按真值折成 100 / 0.

    Args:
        report (EvaluationReport[PromptCase, str, None]): 评测报告.

    Returns:
        Grade: 百分制分数与解释文本.

    Raises:
        ValueError: 报告里没有可取的结论.
    """
    for case in report.cases:
        for result in [*case.assertions.values(), *case.scores.values()]:
            value = result.value
            reason = result.reason
            if isinstance(value, EvaluationReason):
                value, reason = value.value, value.reason or reason
            if isinstance(value, bool):
                score = 100.0 if value else 0.0
            elif isinstance(value, int | float):
                score = float(value)
                score = score * 100.0 if 0.0 <= score <= 1.0 else score
            else:
                continue
            return Grade(score=score, reason=reason or "")
    raise ValueError("报告里没有可取的结论")
