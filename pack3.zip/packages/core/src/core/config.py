"""运行时配置装载模块.

提供从 JSONC 配置文件与 `PYCHAT_` 前缀环境变量装载应用配置的能力,
配置文件路径由 `CONFIG_FILE` 环境变量指定, 缺省为当前目录的 `config.jsonc`.
"""

from __future__ import annotations

import os
from typing import Annotated, Any

import json5
from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    InitSettingsSource,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

from core.schema import (
    HarnessConfig,
    Logging,
    McpLocalConfig,
    McpRemoteConfig,
    ProviderConfig,
    Telemetry,
)


def load_config_file(path: str) -> dict[str, Any]:
    """解析一个 JSONC 配置文件并返回顶层段字典.

    Args:
        path (str): JSONC 配置文件的路径.

    Returns:
        dict[str, Any]: 配置文件的顶层段字典, 键为段名(如 "logging", "provider").

    Raises:
        FileNotFoundError: 如果 path 指向的文件不存在.
    """
    with open(path, encoding="utf-8") as f:
        return json5.loads(f.read())


class AppConfig(BaseSettings):
    """应用配置模型: 字段即配置文件的顶层段, 类型直接复用 schema 生成的模型.

    各来源按优先级装载: 初始化参数 > 环境变量(`PYCHAT_` 前缀) > 配置文件; 多来源按段递归深合并, 环境变量提供同名字段的覆盖.

    Attributes:
        logging (Logging): 日志配置段.
        provider (dict[str, ProviderConfig]): 模型供应商配置段, 键为供应商名.
        harness (dict[str, HarnessConfig]): 应用运行配置段, 键为 harness 名.
        mcp (dict[str, McpLocalConfig | McpRemoteConfig] | None): MCP 服务器配置段, 可选, 默认为 None.
        telemetry (Telemetry | None): 链路追踪配置段, 可选, 默认为 None.
    """

    model_config = SettingsConfigDict(env_prefix="PYCHAT_", extra="forbid")

    logging: Logging
    provider: Annotated[dict[str, ProviderConfig], Field(min_length=1)]
    harness: Annotated[dict[str, HarnessConfig], Field(min_length=1)]
    mcp: Annotated[dict[str, McpLocalConfig | McpRemoteConfig], Field(min_length=1)] | None = None
    telemetry: Telemetry | None = None

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """定义配置来源的优先级顺序.

        Args:
            settings_cls (type[BaseSettings]): 当前的配置模型类.
            init_settings (PydanticBaseSettingsSource): 初始化参数来源.
            env_settings (PydanticBaseSettingsSource): 环境变量来源.
            dotenv_settings (PydanticBaseSettingsSource): .env 文件来源(本项目未启用).
            file_secret_settings (PydanticBaseSettingsSource): 密钥文件来源.

        Returns:
            tuple[PydanticBaseSettingsSource, ...]: 按优先级排列的配置来源序列,
            用于 pydantic-settings 按序取值.
        """
        path = os.getenv("CONFIG_FILE", "config.jsonc")
        try:
            file_data = load_config_file(path)
        except FileNotFoundError:
            file_data = {}
        return (
            init_settings,
            env_settings,
            InitSettingsSource(settings_cls, file_data),
        )
