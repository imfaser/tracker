"""应用日志配置: 设置 root 输出并治理第三方库日志(标准库实现)."""

from __future__ import annotations

import logging
import time
from typing import ClassVar

from core.schema import Logging


class LoggingConfigurator:
    """日志配置器: 按 Logging 配置一次性配置好应用日志.

    Args:
        cfg (Logging): logging 配置段, 含全局级别与第三方库治理规则.
    """

    _configured: ClassVar[bool] = False

    def __init__(self, cfg: Logging) -> None:
        self._cfg = cfg

    def configure(self) -> None:
        """应用日志配置, 进程内只生效一次."""
        if type(self)._configured:
            return
        self._setup_root_logger()
        self._govern_third_party()
        type(self)._configured = True

    def _setup_root_logger(self) -> None:
        """设置 root 输出: UTC 时间戳格式, stderr handler, 全局级别."""
        root = logging.getLogger()
        for handler in list(root.handlers):
            root.removeHandler(handler)
        formatter = logging.Formatter(
            "%(asctime)s %(levelname)8s %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%SZ",
        )
        formatter.converter = time.gmtime
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        root.addHandler(handler)
        root.setLevel(self._cfg.level.value)

    def _govern_third_party(self) -> None:
        """按治理规则处理第三方库日志: disabled 静音, redirect 重定向到 root."""
        third_party = self._cfg.third_party
        for name in third_party.disabled:
            self._silence(name)
        for name in third_party.redirect:
            self._reroute(name)
        logger = logging.getLogger(__name__)
        for name in sorted(set(third_party.redirect) & set(third_party.disabled)):
            logger.warning(
                "第三方日志库 %s 同时出现在 redirect 与 disabled, 按 disabled 静音处理", name
            )

    @staticmethod
    def _matches(name: str, target: str) -> bool:
        """判断 name 是 target 还是其子孙 logger 的名字."""
        return name == target or name.startswith(target + ".")

    def _silence(self, target: str) -> None:
        """静音 target 命名空间下所有已存在的 logger."""
        level = logging.CRITICAL + 1
        for logger_name in self._affected_loggers(target):
            lg = logging.getLogger(logger_name)
            lg.setLevel(level)
            lg.disabled = True
            lg.propagate = False
            lg.addFilter(lambda _: False)

    def _reroute(self, target: str) -> None:
        """把 target 命名空间下已存在的 logger 重定向到 root."""
        for logger_name in self._affected_loggers(target):
            log = logging.getLogger(logger_name)
            log.handlers = []
            log.propagate = True

    def _affected_loggers(self, target: str) -> list[str]:
        """返回 target 及所有已实例化的子孙 logger 的名字."""
        return [target, *(n for n in logging.Logger.manager.loggerDict if self._matches(n, target))]


def configure_logging(cfg: Logging) -> None:
    """按 logging 配置段配置应用日志(进程内一次).

    Args:
        cfg (Logging): logging 配置段.
    """
    LoggingConfigurator(cfg).configure()
