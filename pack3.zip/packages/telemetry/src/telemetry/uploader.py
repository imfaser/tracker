"""把评测结论写成 Phoenix 的 span 标注."""

from __future__ import annotations

import time

import httpx
from core.schema import Telemetry
from phoenix.client import Client
from phoenix.client.__generated__.v1 import SpanAnnotationData


class Uploader:
    """把一次评测的结论写成 Phoenix 的 span 标注.

    标注的形状在这里定死( name=LLMJudge, annotator_kind=LLM ), 调用方只给结论本身:
    span_id 定位写到哪条 span, label / score / explanation 是结论三件套.

    注意 base URL 与采集端点是两回事: 配置里的 `telemetry.phoenix.endpoint` 是 OTLP 采集端点
    ( 形如 http://host:port/v1/traces ), 客户端要的是去掉该路径的 base URL.

    标注只接受已存在的 span, 而 span 上报后要过一会儿才查得到; 因此写回遇到 "该 span 不存在"
    时会稍等重试, 重试用尽或遇到别的错误才抛出.

    Args:
        config (Telemetry | None): telemetry 配置段; 缺省或未选 phoenix 即不可用.
    """

    def __init__(self, config: Telemetry | None) -> None:
        self._client: Client | None = None
        phoenix = config.phoenix if config is not None and config.backend == "phoenix" else None
        if phoenix is not None and phoenix.endpoint is not None:
            self._client = Client(
                base_url=phoenix.endpoint.removesuffix("/v1/traces").rstrip("/") or None,
                api_key=phoenix.api_key,
                headers=dict(phoenix.headers) or None,
            )

    def upload(self, span_id: str, label: str, score: float, explanation: str) -> int:
        """把一条结论写到指定 span 上.

        Args:
            span_id (str): 目标 span 的 hex span id.
            label (str): 结论标签, 如 pass / fail.
            score (float): 百分制分数.
            explanation (str): 解释文本.

        Returns:
            int: 实际写入条数; 不可用时为 0.

        Raises:
            httpx.HTTPStatusError: 重试用尽仍查不到该 span, 或服务端报了别的错.
        """
        if self._client is None:
            return 0
        annotation = SpanAnnotationData(
            name="LLMJudge",
            annotator_kind="LLM",
            span_id=span_id,
            result={"label": label, "score": score, "explanation": explanation},
        )
        attempts_left = 5
        while True:
            try:
                inserted = self._client.spans.log_span_annotations(
                    span_annotations=[annotation], sync=True
                )
                return len(inserted or [])
            except httpx.HTTPStatusError as error:
                if error.response.status_code != 404 or attempts_left <= 1:
                    raise
                attempts_left -= 1
                time.sleep(1.0)
