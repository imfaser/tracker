"""telemetry 包: 链路追踪后端抽象."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class TelemetryBackend(Protocol):
    """链路追踪后端: 负责启动与停止一条可观测的链路输出.

    实现方在 bootstrap 后开始产生可观测数据, 在 shutdown 后停止并收尾.
    何时调用由调用方决定, 本协议不规定生命周期管理方式.
    """

    def bootstrap(self) -> None:
        """启动追踪, 使应用产生的 span 开始被采集."""

    def shutdown(self) -> None:
        """停止追踪并收尾, 确保已采集的 span 被完整导出."""
