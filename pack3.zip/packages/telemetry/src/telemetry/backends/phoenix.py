"""Phoenix 链路追踪后端: 将 OpenInference span 上报到 Phoenix."""

from __future__ import annotations

from typing import cast

from core.schema import Phoenix
from openinference.instrumentation.pydantic_ai import OpenInferenceSpanProcessor
from phoenix.otel import TracerProvider, register

from telemetry.backends.base import TelemetryBackend


class PhoenixBackend(TelemetryBackend):
    """Phoenix 后端: 按 Phoenix 配置启动 OpenTelemetry 追踪并上报 PydanticAI 的 span.

    Args:
        config (Phoenix): Phoenix 上报配置(项目名, 协议, endpoint, 鉴权, 批处理开关).
    """

    def __init__(self, config: Phoenix) -> None:
        self._config = config
        self._provider: TracerProvider | None = None

    def bootstrap(self) -> None:
        """启动追踪: 建立上报链路并注册为全局 tracer.

        register 建的 OTLP 导出器会被降级为普通 processor: phoenix 的
        TracerProvider.add_span_processor 默认 replace_default_processor=True, 会 shutdown 并移除此
        默认导出器; 三方库(pydantic-evals 等)按标准 OTel 语义挂自己的 processor 时不会带这个开关,
        导出链路会被静默掐断且不可恢复.
        """
        provider = cast(
            TracerProvider,
            register(
                project_name=self._config.project_name,
                protocol=self._config.protocol.value,
                endpoint=self._config.endpoint,
                api_key=self._config.api_key,
                headers=self._config.headers,
                batch=self._config.batch,
                verbose=False,
            ),
        )
        provider.add_span_processor(
            OpenInferenceSpanProcessor(),
            replace_default_processor=False,
        )
        provider._default_processor = None
        self._provider = provider

    def shutdown(self) -> None:
        """停止追踪, flush 尚未上报的 span."""
        if self._provider is not None:
            self._provider.shutdown()
            self._provider = None
