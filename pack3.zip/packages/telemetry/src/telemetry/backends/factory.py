"""追踪后端工厂: 按 telemetry 配置段挑选并构造后端实现.

后端选择是配置语义的一部分, 放在 telemetry 包内, 让 server 与离线评测等调用方共用一份判断,
不必各自重新声明 "缺省即关闭, 选中 phoenix 才启用".
"""

from __future__ import annotations

from core.schema import Phoenix, Telemetry

from telemetry.backends.base import TelemetryBackend
from telemetry.backends.phoenix import PhoenixBackend


def build_backend(config: Telemetry | None) -> TelemetryBackend | None:
    """按 telemetry 配置段构造追踪后端.

    Args:
        config (Telemetry | None): telemetry 配置段, 缺省表示不启用追踪.

    Returns:
        TelemetryBackend | None: 对应的追踪后端; 未配置或未选中 phoenix 时为 None.
    """
    if config is None or config.backend != "phoenix":
        return None
    return PhoenixBackend(config.phoenix or Phoenix())
