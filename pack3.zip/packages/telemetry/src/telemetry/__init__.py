"""telemetry 包: 链路追踪后端抽象与 Phoenix 实现.

后端通过 bootstrap(启动追踪)/ shutdown(停止收尾)两个动作暴露能力,
生命周期由调用方决定, 本包不做全局状态管理; 评测结论的写回由 Uploader 负责.
"""

from telemetry.backends.base import TelemetryBackend
from telemetry.backends.factory import build_backend
from telemetry.uploader import Uploader

__all__ = ["TelemetryBackend", "Uploader", "build_backend"]
