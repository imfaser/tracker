import logging
import typing

from core.schema import Effort, Protocol, ProviderConfig
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.openai import OpenAIChatModel, OpenAIResponsesModel
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings, ThinkingLevel

from harness.state import AgentState

type BuiltModel = str | AnthropicModel | OpenAIResponsesModel | OpenAIChatModel
"""建造者可能返回的结果: 各协议的真实模型, 或 test 协议的字符串标识."""


def _thinking_settings(state: AgentState) -> ModelSettings:
    """把 AgentState 的思考设置翻译成统一模型设置(各协议共用).

    `thinking_enabled=False` 映射为统一 `thinking=False`; 否则按 effort 映射到最接近的
    档位( `max` -> `xhigh` ).

    Args:
        state (AgentState): 生效运行时配置, 提供思考开关与强度档位.

    Returns:
        ModelSettings: 传给模型构造函数 settings 的统一模型设置.
    """
    if not state.thinking_enabled:
        return ModelSettings(thinking=False)
    effort_to_level: dict[Effort, ThinkingLevel] = {
        Effort.low: "low",
        Effort.medium: "medium",
        Effort.high: "high",
        Effort.max: "xhigh",
    }
    return ModelSettings(thinking=effort_to_level[state.effort])


@typing.runtime_checkable
class ModelStrategy(typing.Protocol):
    """单个 provider 协议的模型构造策略: 各协议平级实现, 互不继承."""

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        """构造该协议对应的模型对象."""


class AnthropicStrategy(ModelStrategy):
    """Anthropic 协议: 统一 thinking 交给 pydantic-ai 翻译成 adaptive 或 budget."""

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        return AnthropicModel(
            state.model_name,
            provider=AnthropicProvider(api_key=provider_config.api_key),
            settings=_thinking_settings(state),
        )


class OpenAIResponsesStrategy(ModelStrategy):
    """OpenAI Responses 协议: 统一 thinking 交给 pydantic-ai 翻译成 reasoning.effort."""

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        return OpenAIResponsesModel(
            state.model_name,
            provider=OpenAIProvider(
                api_key=provider_config.api_key, base_url=provider_config.base_url
            ),
            settings=_thinking_settings(state),
        )


class OpenAIChatStrategy(ModelStrategy):
    """OpenAI Chat 协议: 统一 thinking 交给 pydantic-ai 翻译成 reasoning_effort."""

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        return OpenAIChatModel(
            state.model_name,
            provider=OpenAIProvider(
                api_key=provider_config.api_key, base_url=provider_config.base_url
            ),
            settings=_thinking_settings(state),
        )


class VllmStrategy(ModelStrategy):
    """vLLM 协议: 与 openai-chat 同一套线上协议, 但思考字段不同, 单独一份实现.

    除统一 thinking 外, 再下发 vLLM 原生的 `enable_thinking` 开关, 不依赖旧版 vLLM
    缺失的 reasoning_effort 自动注入, 也不受服务端 `--default-chat-template-kwargs` 影响.
    """

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        settings = _thinking_settings(state)
        settings["extra_body"] = {
            "chat_template_kwargs": {"enable_thinking": state.thinking_enabled}
        }
        return OpenAIChatModel(
            state.model_name,
            provider=OpenAIProvider(
                api_key=provider_config.api_key, base_url=provider_config.base_url
            ),
            settings=settings,
        )


class MimoStrategy(ModelStrategy):
    """MiMo 协议: 与 openai-chat 同一套线上协议, 但思考开关的形状不同.

    MiMo 用嵌套的 `thinking: {"type": "enabled"|"disabled"}` 控制思维链, 没有思考强度
    概念, 因此不下发统一 thinking(会被翻译成 reasoning_effort), effort 直接忽略.
    认证: 官方同时支持 `api-key` 头与 Bearer, 这里用 Bearer(OpenAIProvider 默认行为).
    """

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        settings = ModelSettings(
            extra_body={"thinking": {"type": "enabled" if state.thinking_enabled else "disabled"}}
        )
        return OpenAIChatModel(
            state.model_name,
            provider=OpenAIProvider(
                api_key=provider_config.api_key, base_url=provider_config.base_url
            ),
            settings=settings,
        )


class TestStrategy(ModelStrategy):
    """test 协议: 无真实模型, 思考设置无从应用, 打日志告警后忽略."""

    def build(self, state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
        if state.thinking_enabled:
            logging.getLogger(__name__).warning(
                "protocol test 无真实模型, 无法应用思考设置, 已忽略"
            )
        return "test"


class ModelBuilder:
    """模型建造者: 按 provider 协议选出对应策略并构造模型.

    Args:
        state (AgentState): 生效运行时配置, 提供模型名与思考设置.
        provider_config (ProviderConfig): 该模型对应的 provider 配置.
    """

    def __init__(self, state: AgentState, provider_config: ProviderConfig) -> None:
        self.state = state
        self.provider = provider_config

    def build(self) -> BuiltModel:
        """按协议选出策略, 再让策略构造对应模型.

        Returns:
            构造好的 pydantic-ai 模型对象, 或 `test` 协议的字符串标识.

        Raises:
            ValueError: provider 协议不受支持.
        """
        match self.provider.protocol:
            case Protocol.anthropic:
                strategy: ModelStrategy = AnthropicStrategy()
            case Protocol.openai_response:
                strategy = OpenAIResponsesStrategy()
            case Protocol.openai_chat:
                strategy = OpenAIChatStrategy()
            case Protocol.vllm:
                strategy = VllmStrategy()
            case Protocol.mimo:
                strategy = MimoStrategy()
            case Protocol.test:
                strategy = TestStrategy()
            case _:
                raise ValueError(f"protocol {self.provider.protocol} not supported")
        return strategy.build(self.state, self.provider)


def create_model(state: AgentState, provider_config: ProviderConfig) -> BuiltModel:
    """按生效 AgentState 与 provider 配置构造模型.

    Args:
        state (AgentState): 生效运行时配置, 提供模型名与思考设置.
        provider_config (ProviderConfig): 该模型对应的 provider 配置.

    Returns:
        构造好的 pydantic-ai 模型对象, 或 `test` 协议的字符串标识.
    """
    return ModelBuilder(state, provider_config).build()
