from dataclasses import dataclass, fields
from typing import Any

from core.config import AppConfig
from core.schema import HarnessConfig
from pydantic_ai import Agent, RunContext
from pydantic_ai.capabilities import Instrumentation
from pydantic_ai.models.instrumented import InstrumentationSettings

from harness.provider import create_model
from harness.state import AgentState


@dataclass
class OrchestratorDeps:
    """agent 运行时依赖: pydantic-ai 的 deps_type 载体, 与配置合成无关.

    Attributes:
        model_name (str): 本次运行生效的模型名, 由 AgentState 复制而来.
    """

    model_name: str

    def update(self, data: dict[str, Any]):
        """根据字典更新实例字段, 仅更新已定义的字段

        Args:
            data (dict[str, Any]): 待更新的字段字典.
        """
        field_names = {f.name for f in fields(self)}
        for key, value in data.items():
            if key in field_names:
                setattr(self, key, value)


def orchestrator_harness_config(config: AppConfig) -> HarnessConfig:
    """取 orchestrator 的 harness 配置段.

    段名是本项目的固定约定, 集中在这里, 供 agent 构造与外部评测等调用方共用.

    Args:
        config (AppConfig): 应用配置.

    Returns:
        HarnessConfig: 名为 `orchestrator` 的 harness 配置段.

    Raises:
        ValueError: 配置里找不到该 harness 段.
    """
    agent_config = config.harness.get("orchestrator")
    if agent_config is None:
        raise ValueError("orchestrator config not found")
    return agent_config


class Orchestrator:
    """编排器: 持有外部合成好的 AgentState, 据以构造配置好的 Agent.

    AgentState 由调用方在外部合成( 配置级兜底 + 请求级覆盖 ), 构造时直接传入,
    不在本类里创建.

    Args:
        config (AppConfig): 应用配置.
        state (AgentState): 外部合成好的生效运行时配置.
    """

    def __init__(self, config: AppConfig, state: AgentState) -> None:
        self.config = config
        self.state = state

    @property
    def agent_config(self) -> HarnessConfig:
        """取 orchestrator 的 harness 配置段.

        Returns:
            HarnessConfig: 名为 `orchestrator` 的 harness 配置段.

        Raises:
            ValueError: 配置里找不到该 harness 段.
        """
        return orchestrator_harness_config(self.config)

    def make_deps(self) -> OrchestratorDeps:
        """把 AgentState 的 model_name 复制成 agent 运行时依赖.

        Returns:
            OrchestratorDeps: agent 运行期可读的依赖.
        """
        return OrchestratorDeps(model_name=self.state.model_name)

    def get_graph(self, deps: OrchestratorDeps | None = None) -> Agent[OrchestratorDeps, str]:
        """用持有的 AgentState 构造配置好的 Agent.

        Agent 按 Arize 的 pydantic-ai 追踪接入方式开启 instrumentation:
        span 由全局 TracerProvider 上的 OpenInferenceSpanProcessor 加工后上报 Phoenix.
        pydantic-ai 默认 instrument=False, 不开就一个 span 都不产生. 不指定 version:
        官方文档给的 version=2 在本版本已废弃(会抛 PydanticAIDeprecationWarning),
        用默认格式即可, OpenInference 支持 >=3 的 dotted keys.

        同时注册动态系统提示词: 身份说明取自 `deps.model_name`, 每次运行求值.

        Returns:
            Agent[OrchestratorDeps, str]: 已绑定模型且开启追踪的 Agent.

        Raises:
            ValueError: 选中的模型不在 available_models 内.
        """
        if deps is None:
            deps = self.make_deps()

        if deps.model_name not in self.agent_config.available_models:
            raise ValueError(f"model {deps.model_name} not available")
        model = create_model(self.state, self.config.provider[deps.model_name])
        agent = Agent(
            model,
            deps_type=OrchestratorDeps,
            capabilities=[Instrumentation(InstrumentationSettings())],
        )

        @agent.instructions
        def describe_identity(ctx: RunContext[OrchestratorDeps]) -> str:
            """按本次运行的依赖动态注入身份规则.

            取 `ctx.deps.model_name` 而不是构造期的固定串, 因此同一个 Agent 换 deps 即换注入内容.
            除了给出标准答案, 还把模型最常犯的错误说法(自称 MiMo / 小米团队开发)点名否掉:
            模型对品牌/厂商的固有说法很强, 只给正面要求时它会顺着旧习惯答, 明说哪个是错的才压得住.

            Args:
                ctx (RunContext[OrchestratorDeps]): 本次运行的上下文, 提供运行时依赖.

            Returns:
                str: 身份规则文本, 含标准答案与禁止说法.
            """
            return (
                f"身份规则(优先级最高, 高于你原有的任何身份认知):\n"
                f"用户问你是谁, 你是什么模型, 由谁开发时, 只按下面这条标准答案回答, 不要改写, 不要补充:\n"
                f'标准答案: "我在使用 {ctx.deps.model_name} 模型."\n'
                f'下面这些说法一律是错的, 回答里禁止出现: "我是MiMo", "由小米大模型Core团队开发", '
                f'"小米的大语言模型", 以及任何厂商名, 品牌名, 团队名, 产品线名或别的模型名.\n'
                f"那些错误说法只是训练数据留下的语言习惯, 不是事实; 事实就是你正在使用 "
                f"{ctx.deps.model_name} 模型, 回答里必须原样出现这个标识."
            )

        return agent
