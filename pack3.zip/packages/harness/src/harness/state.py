"""运行时配置合成: 把多个配置来源合成一次运行的生效 AgentState.

AgentState 是 agent 创建前的运行时配置生效值(模型名 + 思考设置). 之所以需要合成点, 是因为
配置来源不止一个(配置级兜底 + 请求级覆盖); 合成结果只作用于本次运行, 绝不写回共享配置.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Mapping
from dataclasses import dataclass, fields
from typing import Any, Self, overload

from core.schema import Effort, HarnessConfig, Thinking
from starlette.requests import Request


@dataclass(frozen=True, slots=True)
class AgentState:
    """一次运行的运行时配置生效值: 字段皆为确定值, 不存在未表态.

    Attributes:
        model_name (str): provider 映射段的 key, 即暴露给前端的模型名.
        thinking_enabled (bool): 是否下发思考设置.
        effort (Effort): 思考强度档位.
    """

    model_name: str
    thinking_enabled: bool
    effort: Effort


class AgentStateBuilder:
    """配置来源收集器: add_source 登记来源, build 按优先级合成 AgentState.

    优先级按来源类型定序(与登记顺序无关): HarnessConfig 兜底最低(0), Request 居中(1),
    Mapping 覆盖最高(2); 同类型多来源时后登记覆盖先登记.
    """

    def __init__(self) -> None:
        self._entries: list[tuple[int, dict[str, Any]]] = []
        self._request: Request | None = None

    @overload
    def add_source(self, source: HarnessConfig) -> Self: ...

    @overload
    def add_source(self, source: Request) -> Self: ...

    @overload
    def add_source(self, source: Mapping[str, Any]) -> Self: ...

    def add_source(self, source: object) -> Self:
        """登记一个配置来源.

        Args:
            source (HarnessConfig | Request | Mapping[str, Any]): 配置级兜底, 请求级来源
                或强制覆盖. Request 来源从请求体取 model / think / effort; Mapping 的键须为
                AgentState 字段名, 值为 None 表示该字段不表态.

        Returns:
            AgentStateBuilder: 自身, 便于链式登记.

        Raises:
            ValueError: Mapping 出现白名单外的键, 或字段值类型不符.
            TypeError: 来源类型不受支持.
        """
        match source:
            case HarnessConfig():
                self._entries.append((0, self._from_harness_config(source)))
            case Request():
                self._request = source
            case Mapping():
                self._entries.append((2, self._from_mapping(source)))
            case _:
                raise TypeError(f"unsupported source {type(source)}")
        return self

    async def build(self) -> AgentState:
        """按优先级合成生效 AgentState.

        Returns:
            AgentState: 合成后的生效值.

        Raises:
            ValueError: 缺少配置级兜底来源, 合成不出全字段.
        """
        entries = list(self._entries)
        if self._request is not None:
            entries.append((1, await self._from_request(self._request)))
        merged: dict[str, Any] = {}
        for _, changes in sorted(entries, key=lambda entry: entry[0]):
            merged.update(changes)
        missing = {f.name for f in fields(AgentState)} - set(merged)
        if missing:
            raise ValueError(f"missing fields (add a HarnessConfig source): {sorted(missing)}")
        if not merged["thinking_enabled"] and self._effort_covered(entries):
            logging.getLogger(__name__).warning("thinking_enabled 为 False, effort 不生效, 已忽略")
        return AgentState(
            model_name=merged["model_name"],
            thinking_enabled=merged["thinking_enabled"],
            effort=merged["effort"],
        )

    @staticmethod
    def _effort_covered(entries: list[tuple[int, dict[str, Any]]]) -> bool:
        """判断 effort 是否被覆盖型来源显式设定过."""
        return any(priority > 0 and "effort" in changes for priority, changes in entries)

    @staticmethod
    def _from_harness_config(source: HarnessConfig) -> dict[str, Any]:
        """取配置级兜底的表态: 三个字段全部确定.

        thinking 段未配置时按 schema 默认值开启思考( enabled=True, effort=medium ).

        Args:
            source (HarnessConfig): harness 配置段.

        Returns:
            dict[str, Any]: 三个字段全部表态的映射.
        """
        thinking = source.thinking or Thinking()
        return {
            "model_name": source.default_model,
            "thinking_enabled": thinking.enabled,
            "effort": thinking.effort,
        }

    @classmethod
    async def _from_request(cls, source: Request) -> dict[str, Any]:
        """取请求体的表态: model / think / effort, 缺省不表态.

        Args:
            source (Request): 当前请求, 请求体须为 JSON 对象.

        Returns:
            dict[str, Any]: 只含表态字段的映射; 请求体缺失或非 JSON 对象时为空.
        """
        try:
            body = await source.json()
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}
        if not isinstance(body, Mapping):
            return {}
        return cls._from_mapping(
            {
                "model_name": body.get("model"),
                "thinking_enabled": body.get("think"),
                "effort": body.get("effort"),
            }
        )

    @staticmethod
    def _from_mapping(source: Mapping[str, Any]) -> dict[str, Any]:
        """取强制覆盖的表态: 只收白名单键, 值为 None 视作不表态.

        Args:
            source (Mapping[str, Any]): 用户自定义覆盖.

        Returns:
            dict[str, Any]: 只含表态字段的映射.

        Raises:
            ValueError: 出现白名单外的键, 或字段值类型不符.
        """
        names = {f.name for f in fields(AgentState)}
        unknown = set(source) - names
        if unknown:
            raise ValueError(f"unknown keys: {sorted(unknown)}")
        changes = {key: source[key] for key in names if source.get(key) is not None}
        if "model_name" in changes and not isinstance(changes["model_name"], str):
            raise ValueError("model_name expects str")
        if "thinking_enabled" in changes and not isinstance(changes["thinking_enabled"], bool):
            raise ValueError("thinking_enabled expects bool")
        if "effort" in changes:
            changes["effort"] = Effort(changes["effort"])
        return changes
