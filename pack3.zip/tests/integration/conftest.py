"""tests/integration 专用 conftest: 按目录独立, integration 内共享的 fixture 放这里."""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from server.app import create_app
from server.container import make_container

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"
SERVER_CONFIG = FIXTURES / "config.server.jsonc"


@pytest.fixture
def server_config(monkeypatch: pytest.MonkeyPatch) -> Path:
    """把配置源指向 server 专用 fixture, 并清掉可能干扰的 PYCHAT_* 环境变量.

    只清配置相关变量, 不 wipe 整个 environ, 避免破坏 pytest 自身依赖的变量.

    Args:
        monkeypatch (pytest.MonkeyPatch): pytest 提供的环境隔离工具.

    Returns:
        Path: 当前生效的配置文件路径.
    """
    for key in list(os.environ):
        if key.startswith("PYCHAT_") or key == "CONFIG_FILE":
            monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("CONFIG_FILE", str(SERVER_CONFIG))
    return SERVER_CONFIG


@pytest.fixture
def client(server_config: Path) -> Iterator[TestClient]:
    """跑过 lifespan 的 in-process ASGI 客户端.

    Args:
        server_config (Path): 已生效的配置文件路径.

    Returns:
        Iterator[TestClient]: 可直接发请求的客户端, 退出时走 lifespan 关闭.
    """
    with TestClient(create_app(make_container())) as test_client:
        yield test_client
