"""PM2 真进程集成测试: 用 pm2 拉起真实 uvicorn, 打真 HTTP, 验证启动与流式出口.

与 in-process ASGI 测试互补: 这条链路覆盖真实进程生命周期(uvicorn + PM2)与真实端口.
用独立的 PM2 app 名与空闲端口, 不碰开发用的 `pychat-server`; 未装 pm2 时跳过.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import time
from collections.abc import Iterator
from pathlib import Path

import httpx
import pytest

APP_NAME = "pychat-server-test"


def _pm2(*args: str, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    """调用 pm2 命令.

    Args:
        *args (str): 传给 pm2 的参数.
        env (dict[str, str] | None): 传给 pm2 进程的环境变量; PM2 会把 start 时的环境透传给被拉起的
            应用(缺省 None 表示继承当前环境).

    Returns:
        subprocess.CompletedProcess[str]: 命令结果(不因非零退出码抛错).
    """
    return subprocess.run(
        ["pm2", *args], capture_output=True, text=True, timeout=60, check=False, env=env
    )


def _free_port() -> int:
    """取一个当前空闲的本地端口.

    Returns:
        int: 可用于 bind 的端口号.
    """
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _stream_body() -> dict[str, object]:
    """构造一个合法的 Vercel AI 请求体.

    Returns:
        dict[str, object]: 含 trigger / id / messages 的请求体.
    """
    return {
        "trigger": "submit-message",
        "id": "msg-1",
        "messages": [{"id": "m1", "role": "user", "parts": [{"type": "text", "text": "hi"}]}],
    }


def _wait_ready(port: int, deadline: float) -> None:
    """轮询 /health 直到服务就绪或超时.

    Args:
        port (int): 服务端口.
        deadline (float): time.monotonic() 口径的截止时刻.

    Raises:
        AssertionError: 截止时刻前服务仍未就绪.
    """
    last: Exception | None = None
    while time.monotonic() < deadline:
        try:
            if httpx.get(f"http://127.0.0.1:{port}/health", timeout=2.0).status_code == 200:
                return
        except httpx.HTTPError as exc:
            last = exc
        time.sleep(0.5)
    raise AssertionError(f"server on port {port} not ready before deadline: {last}")


@pytest.fixture
def pm2_server(server_config: Path) -> Iterator[int]:
    """用 pm2 + 仓库根 ecosystem.config.js 拉起真实 uvicorn, 就绪后交出端口, 结束时删进程.

    app 名 / 端口 / 配置路径都靠环境变量覆盖(见 ecosystem.config.js), 因此与开发实例互不干扰;
    每次 start 前先 delete: PM2 会保留旧实例, 不删会拿到缓存的旧进程.

    Args:
        server_config (Path): 服务读取的配置文件路径.

    Yields:
        int: 已就绪的服务端口.
    """
    if shutil.which("pm2") is None:
        pytest.skip("pm2 is not installed")

    port = _free_port()
    repo_root = Path(__file__).resolve().parents[2]
    app_env = {
        **os.environ,
        "PM2_APP_NAME": APP_NAME,
        "CONFIG_FILE": str(server_config),
        "SERVER_PORT": str(port),
    }

    _pm2("delete", APP_NAME)
    started = _pm2("start", str(repo_root / "ecosystem.config.js"), env=app_env)
    try:
        assert started.returncode == 0, started.stderr
        _wait_ready(port, deadline=time.monotonic() + 45)
        yield port
    finally:
        _pm2("delete", APP_NAME)


@pytest.mark.slow
@pytest.mark.timeout(120)
def test_pm2_server_serves_health_and_stream(pm2_server: int) -> None:
    """PM2 拉起的真进程: /health 可用, /chat/stream 返回可解析的 Vercel 流."""
    base_url = f"http://127.0.0.1:{pm2_server}"

    health = httpx.get(f"{base_url}/health", timeout=5.0)
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}

    with httpx.stream(
        "POST", f"{base_url}/chat/stream", json=_stream_body(), timeout=30.0
    ) as response:
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/event-stream")
        body = "".join(response.iter_text())

    chunks = [line for line in body.splitlines() if line.startswith('data: {"')]
    assert chunks, body
    deltas = [
        json.loads(chunk[len("data: ") :])["delta"]
        for chunk in chunks
        if '"type":"text-delta"' in chunk
    ]
    assert deltas, body
    assert "".join(deltas) == "success (no tool calls)"
