"""server 应用集成测试: in-process ASGI 打通 lifespan / DI / 流式出口."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import pytest
from core.config import AppConfig
from core.schema import Effort, Telemetry
from dishka import AsyncContainer, Scope
from fastapi.testclient import TestClient
from harness.state import AgentState
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from server.app import build_telemetry, create_app
from server.container import make_container
from starlette.requests import Request
from telemetry.backends.base import TelemetryBackend
from telemetry.backends.phoenix import PhoenixBackend

from server import app as server_app


def _stream_body(**overrides: Any) -> dict[str, Any]:
    """构造一个合法的 Vercel AI 请求体.

    Args:
        **overrides (Any): 覆盖默认字段的额外字段(如 model / think / effort).

    Returns:
        dict[str, Any]: 含必填 id 与 messages 的请求体.
    """
    body: dict[str, Any] = {
        "trigger": "submit-message",
        "id": "msg-1",
        "messages": [{"id": "m1", "role": "user", "parts": [{"type": "text", "text": "hi"}]}],
    }
    body.update(overrides)
    return body


def _request(body: object) -> Request:
    """构造一个内存里的 ASGI 请求, 供直接进入容器的 REQUEST 作用域.

    Args:
        body (object): 请求体对象, 会被序列化为 JSON 字节.

    Returns:
        Request: 可交 dishka context 使用的请求.
    """
    payload = json.dumps(body).encode()

    async def receive() -> dict[str, Any]:
        return {"type": "http.request", "body": payload, "more_body": False}

    return Request(
        {
            "type": "http",
            "http_version": "1.1",
            "method": "POST",
            "scheme": "http",
            "path": "/chat/stream",
            "raw_path": b"/chat/stream",
            "query_string": b"",
            "headers": [(b"content-type", b"application/json")],
            "client": ("127.0.0.1", 12345),
            "server": ("127.0.0.1", 8000),
            "state": {},
        },
        receive,
    )


def test_health_returns_ok(client: TestClient) -> None:
    """健康检查端点返回 200."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_chat_stream_returns_vercel_events(client: TestClient) -> None:
    """流式出口返回 text/event-stream, 且至少产出一个 Vercel data stream 分片."""
    response = client.post("/chat/stream", json=_stream_body())
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")

    chunks = [line for line in response.text.splitlines() if line.startswith('data: {"')]
    assert chunks, response.text
    deltas = [
        payload["delta"]
        for payload in (json.loads(chunk[len("data: ") :]) for chunk in chunks)
        if payload.get("type") == "text-delta"
    ]
    assert deltas, response.text
    assert "".join(deltas) == "success (no tool calls)"


def test_chat_stream_passes_sdk_version_7(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    """路由把 sdk_version 锁在 7, 不随默认值漂移."""
    seen: dict[str, Any] = {}
    original = VercelAIAdapter.dispatch_request

    async def recording_dispatch(request: Request, **kwargs: Any) -> Any:
        seen.update(kwargs)
        return await original(request, **kwargs)

    monkeypatch.setattr(VercelAIAdapter, "dispatch_request", recording_dispatch)

    assert client.post("/chat/stream", json=_stream_body()).status_code == 200
    assert seen["sdk_version"] == 7


def test_chat_stream_rejects_missing_required_fields(client: TestClient) -> None:
    """缺必填字段(id / messages)时返回 4xx, 不进 agent 运行."""
    response = client.post("/chat/stream", json={})
    assert 400 <= response.status_code < 500


def test_chat_stream_rejects_wrong_content_type(client: TestClient) -> None:
    """非 JSON content-type 被挡在 body 解析之前, 返回 4xx."""
    response = client.post(
        "/chat/stream", content=json.dumps(_stream_body()), headers={"content-type": "text/plain"}
    )
    assert 400 <= response.status_code < 500


async def test_container_resolves_agent_state_from_body(server_config: Path) -> None:
    """请求级 AgentState 取到 body 的 model / think / effort 覆盖."""
    container = make_container()
    try:
        async with container(
            {Request: _request(_stream_body(model="other", think=True, effort="high"))},
            scope=Scope.REQUEST,
        ) as request_container:
            state = await request_container.get(AgentState)
    finally:
        await container.close()
    assert state == AgentState(model_name="other", thinking_enabled=True, effort=Effort.high)


async def test_container_builds_new_agent_state_per_request(server_config: Path) -> None:
    """每个请求作用域各得一份新的 AgentState, 用完即弃."""
    container = make_container()
    states: list[AgentState] = []
    try:
        for body in (_stream_body(), _stream_body(model="other")):
            async with container(
                {Request: _request(body)}, scope=Scope.REQUEST
            ) as request_container:
                states.append(await request_container.get(AgentState))
    finally:
        await container.close()
    assert states[0] is not states[1]
    assert states[0].model_name == "test"
    assert states[1].model_name == "other"


async def test_container_reuses_app_config_across_requests(server_config: Path) -> None:
    """AppConfig 是 APP 作用域, 跨请求复用同一实例."""
    container = make_container()
    configs: list[AppConfig] = []
    try:
        for body in (_stream_body(), _stream_body()):
            async with container(
                {Request: _request(body)}, scope=Scope.REQUEST
            ) as request_container:
                configs.append(await request_container.get(AppConfig))
    finally:
        await container.close()
    assert configs[0] is configs[1]


def test_build_telemetry_skips_when_unconfigured() -> None:
    """telemetry 段缺省或未选后端时不构造任何后端."""
    assert build_telemetry(None) is None
    assert build_telemetry(Telemetry()) is None


def test_build_telemetry_builds_phoenix_backend() -> None:
    """选中 phoenix 时构造 PhoenixBackend, 且不在构造期做 IO."""
    backend = build_telemetry(Telemetry(backend="phoenix"))
    assert isinstance(backend, PhoenixBackend)


def test_lifespan_orders_bootstrap_shutdown_and_close(
    server_config: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """lifespan 顺序: bootstrap -> 关闭时 shutdown -> 最后关容器."""
    order: list[str] = []

    class RecordingBackend:
        def bootstrap(self) -> None:
            order.append("bootstrap")

        def shutdown(self) -> None:
            order.append("shutdown")

    def fake_build(_config: Telemetry | None) -> TelemetryBackend:
        return cast(TelemetryBackend, RecordingBackend())

    monkeypatch.setattr(server_app, "build_telemetry", fake_build)

    original_close = AsyncContainer.close

    async def recording_close(
        container_self: AsyncContainer, exception: BaseException | None = None
    ) -> None:
        order.append("close")
        await original_close(container_self, exception)

    monkeypatch.setattr(AsyncContainer, "close", recording_close)

    with TestClient(create_app(make_container())):
        assert order == ["bootstrap"]
    assert order == ["bootstrap", "shutdown", "close"]
