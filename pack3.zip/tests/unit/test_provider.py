"""provider.py 单元测试: 协议策略选型与 thinking/effort -> 模型设置的翻译.

不触网络: 只构造模型对象并检查其 settings, test 协议只做日志断言.
"""

from __future__ import annotations

import logging

import pytest
from core.schema import Effort, Protocol, ProviderConfig
from harness import provider
from harness.provider import (
    AnthropicStrategy,
    MimoStrategy,
    ModelStrategy,
    OpenAIChatStrategy,
    OpenAIResponsesStrategy,
    VllmStrategy,
    create_model,
)
from harness.state import AgentState
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.openai import OpenAIChatModel, OpenAIResponsesModel


def _provider(protocol: Protocol) -> ProviderConfig:
    return ProviderConfig(
        api_key="k", base_url="http://localhost:8000/v1", id="m", protocol=protocol
    )


def _state(
    model_name: str = "m",
    thinking_enabled: bool = True,
    effort: Effort = Effort.medium,
) -> AgentState:
    return AgentState(model_name=model_name, thinking_enabled=thinking_enabled, effort=effort)


def test_strategies_satisfy_protocol() -> None:
    """各协议策略都满足 ModelStrategy 协议(runtime_checkable)."""
    for strategy in (
        AnthropicStrategy(),
        MimoStrategy(),
        OpenAIResponsesStrategy(),
        OpenAIChatStrategy(),
        VllmStrategy(),
        provider.TestStrategy(),
    ):
        assert isinstance(strategy, ModelStrategy)


def test_create_model_selects_model_class_by_protocol() -> None:
    """按协议选到对应模型类, test 协议返回字符串标识."""
    assert isinstance(create_model(_state(), _provider(Protocol.anthropic)), AnthropicModel)
    assert isinstance(
        create_model(_state(), _provider(Protocol.openai_response)), OpenAIResponsesModel
    )
    assert isinstance(create_model(_state(), _provider(Protocol.openai_chat)), OpenAIChatModel)
    assert isinstance(create_model(_state(), _provider(Protocol.vllm)), OpenAIChatModel)
    assert isinstance(create_model(_state(), _provider(Protocol.mimo)), OpenAIChatModel)
    assert create_model(_state(), _provider(Protocol.test)) == "test"


def test_model_name_taken_from_state() -> None:
    """模型名来自 AgentState, 不再单独传参."""
    model = create_model(_state(model_name="gpt-4"), _provider(Protocol.openai_chat))
    assert isinstance(model, OpenAIChatModel)
    assert model.model_name == "gpt-4"


@pytest.mark.parametrize(
    ("effort", "expected"),
    [(Effort.low, "low"), (Effort.medium, "medium"), (Effort.high, "high"), (Effort.max, "xhigh")],
)
def test_enabled_effort_maps_to_unified_level(effort: Effort, expected: str) -> None:
    """thinking_enabled 时 effort 映射到统一 thinking 档位, max -> xhigh."""
    model = create_model(_state(effort=effort), _provider(Protocol.openai_chat))
    assert isinstance(model, OpenAIChatModel)
    assert model.settings == {"thinking": expected}


def test_disabled_maps_to_false() -> None:
    """thinking_enabled=False 映射为统一 thinking=False, 不携带 effort."""
    model = create_model(
        _state(thinking_enabled=False, effort=Effort.high), _provider(Protocol.openai_chat)
    )
    assert isinstance(model, OpenAIChatModel)
    assert model.settings == {"thinking": False}


def test_default_effort_maps_to_medium() -> None:
    """默认档位 medium 映射为统一 thinking=medium."""
    model = create_model(_state(), _provider(Protocol.openai_chat))
    assert isinstance(model, OpenAIChatModel)
    assert model.settings == {"thinking": "medium"}


def test_vllm_adds_enable_thinking_but_chat_does_not() -> None:
    """只有 vLLM 下发原生 enable_thinking; openai-chat 不掺 vLLM 字段."""
    vllm = create_model(_state(thinking_enabled=False), _provider(Protocol.vllm))
    assert isinstance(vllm, OpenAIChatModel)
    assert vllm.settings == {
        "thinking": False,
        "extra_body": {"chat_template_kwargs": {"enable_thinking": False}},
    }
    chat = create_model(
        _state(thinking_enabled=True, effort=Effort.low), _provider(Protocol.openai_chat)
    )
    assert isinstance(chat, OpenAIChatModel)
    assert chat.settings is not None
    assert "extra_body" not in chat.settings


def test_vllm_enable_thinking_follows_state() -> None:
    """vLLM 的 enable_thinking 跟随 AgentState 的思考开关."""
    vllm = create_model(_state(thinking_enabled=True, effort=Effort.high), _provider(Protocol.vllm))
    assert isinstance(vllm, OpenAIChatModel)
    assert vllm.settings is not None
    assert vllm.settings["extra_body"] == {"chat_template_kwargs": {"enable_thinking": True}}


def test_mimo_thinking_shape() -> None:
    """MiMo 下发嵌套 thinking.type, effort 无对应参数(忽略)."""
    on = create_model(_state(effort=Effort.max), _provider(Protocol.mimo))
    assert isinstance(on, OpenAIChatModel)
    assert on.settings == {"extra_body": {"thinking": {"type": "enabled"}}}

    off = create_model(_state(thinking_enabled=False), _provider(Protocol.mimo))
    assert isinstance(off, OpenAIChatModel)
    assert off.settings == {"extra_body": {"thinking": {"type": "disabled"}}}


def test_test_protocol_warns_when_thinking_enabled(caplog: pytest.LogCaptureFixture) -> None:
    """test 协议无法应用思考设置, 打 warning 并照常返回标识."""
    caplog.set_level(logging.WARNING)
    assert create_model(_state(), _provider(Protocol.test)) == "test"
    assert "无法应用思考设置" in caplog.text


def test_test_protocol_silent_when_thinking_disabled(caplog: pytest.LogCaptureFixture) -> None:
    """思考关闭时 test 协议不产生告警."""
    caplog.set_level(logging.WARNING)
    assert create_model(_state(thinking_enabled=False), _provider(Protocol.test)) == "test"
    assert "无法应用思考设置" not in caplog.text
