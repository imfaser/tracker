"""telemetry 包单元测试: mock register, 不触真实网络/导出.

覆盖: 后端抽象契约, PhoenixBackend 的 bootstrap/shutdown 接线, schema 模型默认值.
生命周期(何时 bootstrap/shutdown)由调用方/DI 容器决定, 本包不管理全局状态,
因此测试只验证后端自身的两个动作.
"""

from __future__ import annotations

import pytest
from core.schema import Phoenix, Telemetry
from telemetry import TelemetryBackend
from telemetry.backends.phoenix import PhoenixBackend


class _FakeProcessor:
    """OpenInferenceSpanProcessor 替身: 仅记录被 add."""


class _FakeProvider:
    """phoenix.otel.register 的假返回: 记录被挂的 processor 与被 shutdown."""

    def __init__(self) -> None:
        self.processors: list[tuple[object, bool]] = []
        self.shutdown_calls = 0

    def add_span_processor(self, processor: object, *, replace_default_processor: bool) -> None:
        self.processors.append((processor, replace_default_processor))

    def shutdown(self) -> None:
        self.shutdown_calls += 1


def _phoenix() -> Phoenix:
    """构造 Phoenix 段测试默认值."""
    return Phoenix(
        project_name="test-project",
        protocol="http/protobuf",
        endpoint="http://localhost:6006/v1/traces",
        api_key=None,
        headers={},
        batch=True,
    )


def test_phoenix_schema_defaults() -> None:
    """Phoenix 字段默认值: project_name=pychat, protocol=http/protobuf, batch=True."""
    cfg = Telemetry(backend="phoenix", phoenix=Phoenix())
    assert cfg.phoenix is not None
    assert cfg.phoenix.project_name == "pychat"
    assert cfg.phoenix.protocol.value == "http/protobuf"
    assert cfg.phoenix.endpoint is None
    assert cfg.phoenix.api_key is None
    assert cfg.phoenix.headers == {}
    assert cfg.phoenix.batch is True


def test_telemetry_backend_none_is_off() -> None:
    """backend=None(整段缺省)表示关闭; 配置里有 backend 才启用."""
    cfg = Telemetry()
    assert cfg.backend is None
    assert cfg.phoenix is None


def test_phoenix_backend_is_telemetry_backend() -> None:
    """PhoenixBackend 满足 TelemetryBackend 协议(runtime_checkable)."""
    backend = PhoenixBackend(Phoenix())
    assert isinstance(backend, TelemetryBackend)


def test_phoenix_bootstrap_wires_register_and_processor(monkeypatch: pytest.MonkeyPatch) -> None:
    """bootstrap 调 register 透传配置, 并补挂富化 processor(保留 exporter)."""
    fake_provider = _FakeProvider()
    captured: dict[str, object] = {}

    def fake_register(**kwargs: object) -> _FakeProvider:
        captured.update(kwargs)
        return fake_provider

    monkeypatch.setattr("telemetry.backends.phoenix.register", fake_register)
    backend = PhoenixBackend(_phoenix())
    backend.bootstrap()

    assert captured["project_name"] == "test-project"
    assert captured["protocol"] == "http/protobuf"
    assert captured["endpoint"] == "http://localhost:6006/v1/traces"
    assert captured["api_key"] is None
    assert captured["headers"] == {}
    assert captured["batch"] is True
    assert captured["verbose"] is False
    # 富化 processor 被挂上, 且 replace_default_processor=False 保留 exporter
    assert len(fake_provider.processors) == 1
    proc, replace = fake_provider.processors[0]
    assert proc.__class__.__name__ == "OpenInferenceSpanProcessor"
    assert replace is False


def test_phoenix_bootstrap_passes_api_key_and_headers(monkeypatch: pytest.MonkeyPatch) -> None:
    """显式 api_key/headers 原样透传给 register."""
    fake_provider = _FakeProvider()
    captured: dict[str, object] = {}

    def fake_register(**kwargs: object) -> _FakeProvider:
        captured.update(kwargs)
        return fake_provider

    monkeypatch.setattr("telemetry.backends.phoenix.register", fake_register)
    phoenix = Phoenix(
        project_name="p",
        api_key="secret-key",
        headers={"X-Custom": "v"},
        protocol="grpc",
        batch=False,
    )
    PhoenixBackend(phoenix).bootstrap()
    assert captured["api_key"] == "secret-key"
    assert captured["headers"] == {"X-Custom": "v"}
    assert captured["protocol"] == "grpc"
    assert captured["batch"] is False


def test_phoenix_shutdown_flushes_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    """shutdown 调 provider.shutdown(flush 导出), 并清引用, 可重复安全."""
    fake_provider = _FakeProvider()
    monkeypatch.setattr("telemetry.backends.phoenix.register", lambda **_: fake_provider)
    backend = PhoenixBackend(_phoenix())
    backend.bootstrap()
    assert backend._provider is fake_provider
    backend.shutdown()
    assert fake_provider.shutdown_calls == 1
    assert backend._provider is None
    # 未 bootstrap 就 shutdown 是安全 no-op
    PhoenixBackend(_phoenix()).shutdown()
