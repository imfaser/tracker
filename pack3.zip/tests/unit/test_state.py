"""state.py 单元测试: 多来源合成的优先级与校验.

纯逻辑, 不触 IO/网络/外部进程; Request 来源用内存构造的 ASGI 请求验证.
"""

from __future__ import annotations

import json
import logging
from dataclasses import FrozenInstanceError
from typing import Any, cast

import pytest
from core.schema import Effort, HarnessConfig, Thinking
from harness.state import AgentState, AgentStateBuilder
from starlette.requests import Request


def _harness(thinking: Thinking | None = None) -> HarnessConfig:
    return HarnessConfig(default_model="m", available_models=["m"], thinking=thinking)


def _raw_request(payload: bytes) -> Request:
    async def receive() -> dict[str, Any]:
        return {"type": "http.request", "body": payload, "more_body": False}

    return Request({"type": "http", "headers": []}, receive)


def _request(body: object) -> Request:
    return _raw_request(json.dumps(body).encode())


async def test_config_source_fills_all_fields() -> None:
    """配置级兜底把三个字段全部确定."""
    state = await (
        AgentStateBuilder().add_source(_harness(Thinking(enabled=True, effort=Effort.high))).build()
    )
    assert state == AgentState(model_name="m", thinking_enabled=True, effort=Effort.high)


async def test_missing_thinking_enables_default_effort() -> None:
    """thinking 段未配置时开启思考, 档位取 schema 默认 medium."""
    state = await AgentStateBuilder().add_source(_harness()).build()
    assert state == AgentState(model_name="m", thinking_enabled=True, effort=Effort.medium)


async def test_mapping_overrides_each_field() -> None:
    """Mapping 来源按字段覆盖."""
    state = await (
        AgentStateBuilder()
        .add_source(_harness())
        .add_source({"model_name": "other", "thinking_enabled": False, "effort": "low"})
        .build()
    )
    assert state == AgentState(model_name="other", thinking_enabled=False, effort=Effort.low)


async def test_partial_override_falls_back() -> None:
    """只覆盖表态字段, 其余回退兜底."""
    state = await (
        AgentStateBuilder().add_source(_harness()).add_source({"model_name": "other"}).build()
    )
    assert state == AgentState(model_name="other", thinking_enabled=True, effort=Effort.medium)


async def test_none_value_means_no_opinion() -> None:
    """Mapping 里的 None 表示不表态, 不覆盖兜底."""
    state = await (
        AgentStateBuilder()
        .add_source(_harness(Thinking(enabled=False, effort=Effort.high)))
        .add_source({"thinking_enabled": None, "effort": None})
        .build()
    )
    assert state == AgentState(model_name="m", thinking_enabled=False, effort=Effort.high)


async def test_priority_ignores_registration_order() -> None:
    """优先级按来源类型定序: Mapping 无论先后都覆盖 HarnessConfig."""
    base = _harness(Thinking(enabled=True, effort=Effort.low))
    first = await AgentStateBuilder().add_source({"effort": Effort.high}).add_source(base).build()
    second = await AgentStateBuilder().add_source(base).add_source({"effort": Effort.high}).build()
    assert first == second == AgentState(model_name="m", thinking_enabled=True, effort=Effort.high)


async def test_later_mapping_wins_among_mappings() -> None:
    """同类型多来源时后登记覆盖先登记."""
    state = await (
        AgentStateBuilder()
        .add_source(_harness())
        .add_source({"effort": "low"})
        .add_source({"effort": "high"})
        .build()
    )
    assert state.effort is Effort.high


async def test_empty_mapping_is_no_opinion() -> None:
    """空 Mapping 等价全不表态."""
    state = (
        await AgentStateBuilder()
        .add_source(_harness(Thinking(enabled=False)))
        .add_source({})
        .build()
    )
    assert state == AgentState(model_name="m", thinking_enabled=False, effort=Effort.medium)


def test_unknown_key_rejected() -> None:
    """Mapping 出现白名单外的键直接报错, 不静默忽略."""
    with pytest.raises(ValueError, match="unknown keys"):
        AgentStateBuilder().add_source({"nope": 1})


def test_bad_type_rejected() -> None:
    """Mapping 字段值类型不符直接报错."""
    with pytest.raises(ValueError, match="model_name expects str"):
        AgentStateBuilder().add_source({"model_name": 1})
    with pytest.raises(ValueError, match="thinking_enabled expects bool"):
        AgentStateBuilder().add_source({"thinking_enabled": "yes"})


def test_bad_effort_rejected() -> None:
    """effort 非法取值报错."""
    with pytest.raises(ValueError):
        AgentStateBuilder().add_source({"effort": "ultra"})


def test_unsupported_source_rejected() -> None:
    """未注册的来源类型报 TypeError."""
    with pytest.raises(TypeError, match="unsupported source"):
        AgentStateBuilder().add_source(cast(Any, 123))


async def test_missing_base_rejected() -> None:
    """缺配置级兜底时合成不出全字段."""
    with pytest.raises(ValueError, match="missing fields"):
        await AgentStateBuilder().add_source({"model_name": "m"}).build()


async def test_explicit_effort_with_thinking_off_warns(caplog: pytest.LogCaptureFixture) -> None:
    """覆盖型来源显式设定 effort 但思考关闭时告警后忽略."""
    caplog.set_level(logging.WARNING)
    await (
        AgentStateBuilder()
        .add_source(_harness())
        .add_source({"thinking_enabled": False, "effort": "high"})
        .build()
    )
    assert "effort 不生效" in caplog.text


async def test_no_warn_when_effort_not_covered(caplog: pytest.LogCaptureFixture) -> None:
    """effort 未被显式覆盖时不告警, 避免每次关思考都刷屏."""
    caplog.set_level(logging.WARNING)
    await AgentStateBuilder().add_source(_harness()).add_source({"thinking_enabled": False}).build()
    assert "effort 不生效" not in caplog.text


def test_state_is_immutable() -> None:
    """AgentState 是 frozen 值对象, 不可变(无污染)."""
    state = AgentState(model_name="m", thinking_enabled=True, effort=Effort.medium)
    with pytest.raises(FrozenInstanceError):
        state.model_name = "other"  # ty: ignore[invalid-assignment]


async def test_build_does_not_mutate_sources() -> None:
    """合成不写回共享配置对象."""
    base = _harness(Thinking(enabled=True, effort=Effort.low))
    await AgentStateBuilder().add_source(base).add_source({"effort": "max"}).build()
    assert base.thinking == Thinking(enabled=True, effort=Effort.low)
    assert (await AgentStateBuilder().add_source(base).build()).effort is Effort.low


async def test_request_overrides_each_field() -> None:
    """Request 来源从请求体取 model / think / effort 覆盖兜底."""
    state = await (
        AgentStateBuilder()
        .add_source(_harness())
        .add_source(_request({"model": "other", "think": False, "effort": "high"}))
        .build()
    )
    assert state == AgentState(model_name="other", thinking_enabled=False, effort=Effort.high)


async def test_request_loses_to_mapping() -> None:
    """Mapping 是强制覆盖, 优先级高于 Request."""
    state = await (
        AgentStateBuilder()
        .add_source(_harness())
        .add_source(_request({"model": "from-request"}))
        .add_source({"model_name": "from-mapping"})
        .build()
    )
    assert state.model_name == "from-mapping"


async def test_request_none_fields_are_no_opinion() -> None:
    """请求体只给部分字段时, 其余回退兜底."""
    state = await (
        AgentStateBuilder().add_source(_harness()).add_source(_request({"model": "other"})).build()
    )
    assert state == AgentState(model_name="other", thinking_enabled=True, effort=Effort.medium)


async def test_request_invalid_json_is_no_opinion() -> None:
    """请求体非 JSON 时不表态, 配置兜底生效."""
    state = await (
        AgentStateBuilder().add_source(_harness()).add_source(_raw_request(b"not json")).build()
    )
    assert state == AgentState(model_name="m", thinking_enabled=True, effort=Effort.medium)


async def test_request_non_object_json_is_no_opinion() -> None:
    """请求体是 JSON 数组时不表态."""
    state = await AgentStateBuilder().add_source(_harness()).add_source(_request([1, 2])).build()
    assert state == AgentState(model_name="m", thinking_enabled=True, effort=Effort.medium)


async def test_request_bad_type_rejected() -> None:
    """请求体字段类型不符时报错."""
    with pytest.raises(ValueError, match="model_name expects str"):
        await AgentStateBuilder().add_source(_harness()).add_source(_request({"model": 1})).build()
