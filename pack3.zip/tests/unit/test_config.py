"""config.py 运行时装载测试: 纯 env / CONFIG_FILE 指向 fixture jsonc / env 覆盖合并.

env 注入走 python-dotenv 自定义路径读取 tests/fixtures/config.env, 不 mock 任何
生产代码 (AppConfig 拿到的是真实 os.environ), 验证的是真实装载路径.

真实合并语义(pydantic-settings 对多 source 做递归字段级深合并, env source 靠后):
- 文件提供基底, env 提供同名字段的覆盖; 两者叶键互补, env 赢在冲突处.
- 例: 文件 provider 有 cfg-a+cfg-b, env 只给 cfg-a → cfg-b 保留, cfg-a 用 env 值.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from core.config import AppConfig, load_config_file
from core.schema import Level
from dotenv import dotenv_values
from pydantic import ValidationError

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"
CONFIG_JSONC = FIXTURES / "config.base.jsonc"
CONFIG_ENV = FIXTURES / "config.env"


def test_load_config_file_parses_jsonc() -> None:
    data = load_config_file(str(CONFIG_JSONC))
    assert data["logging"]["level"] == "INFO"
    assert data["provider"]["cfg-a"]["id"] == "file-model-a"
    assert data["mcp"]["cfg-mcp"]["type"] == "remote"


def test_dotenv_fixture_contains_expected_keys() -> None:
    """config.env 本身结构正确: CONFIG_FILE 指向 fixture jsonc, PYCHAT_* 为 JSON 段."""
    values = dotenv_values(CONFIG_ENV)
    assert values["CONFIG_FILE"] == "tests/fixtures/config.base.jsonc"
    assert "PYCHAT_LOGGING" in values
    assert "PYCHAT_PROVIDER" in values


def test_config_file_only_load(clean_env: None) -> None:
    """仅 CONFIG_FILE 指向 fixture jsonc → 全量装载, 字段正确."""
    os.environ["CONFIG_FILE"] = str(CONFIG_JSONC)
    cfg = AppConfig()
    assert cfg.logging.level is Level.info
    assert cfg.logging.third_party.redirect == ["httpx"]
    p = cfg.provider["cfg-a"]
    assert p.api_key == "file-key-a"
    assert p.modalities is not None
    assert cfg.harness["cfg-h"].default_model == "cfg-a"
    assert cfg.mcp is not None
    mcp_entry = cfg.mcp["cfg-mcp"]
    assert mcp_entry.type == "remote"


def test_env_loaded_via_dotenv_overrides_file(
    clean_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    """读取 tests/fixtures/config.env → 注入为真实 os.environ(monkeypatch 隔离, 不污染其他测试)."""
    for key, value in dotenv_values(CONFIG_ENV).items():
        if value is not None:
            monkeypatch.setenv(key, value)
    assert os.getenv("CONFIG_FILE") == "tests/fixtures/config.base.jsonc"

    cfg = AppConfig()
    # env 覆盖 logging.level 与 third_party; config.env 显式给了 disabled:[] → 覆盖文件 boto3
    assert cfg.logging.level is Level.warning
    assert cfg.logging.third_party.redirect == ["requests"]
    assert cfg.logging.third_party.disabled == []
    # env 覆盖 provider.cfg-a.api_key/base_url; 文件 cfg-a.modalities 仍在(env 未给)
    p = cfg.provider["cfg-a"]
    assert p.api_key == "env-key-a"
    assert p.base_url == "https://env.test/v1"
    assert p.modalities is not None and p.modalities.input
    # env 整段 harness 无 thinking → 文件 cfg-h.thinking 保留(深合并)
    h = cfg.harness["cfg-h"]
    assert h.default_model == "cfg-a"
    assert h.thinking is not None and h.thinking.effort.value == "high"


def test_env_adds_provider_key_file_keeps_others(clean_env: None) -> None:
    """env 只给 cfg-a 时文件其他 provider 保留; env 目标键覆盖."""
    os.environ["CONFIG_FILE"] = str(CONFIG_JSONC)
    os.environ["PYCHAT_PROVIDER"] = (
        '{"cfg-a":{"api_key":"env-only","base_url":"https://env.test/v1",'
        '"id":"env-model","protocol":"openai-chat"}}'
    )
    cfg = AppConfig()
    assert set(cfg.provider) == {"cfg-a"}
    assert cfg.provider["cfg-a"].api_key == "env-only"
    # logging 未给 env → 文件段保留
    assert cfg.logging.level is Level.info
    assert cfg.mcp is not None
    assert cfg.mcp["cfg-mcp"].enabled is True


def test_missing_config_file_and_env_raises(clean_env: None) -> None:
    """CONFIG_FILE 指向不存在路径 + 无 env → 必填段缺失, 校验失败(fail-fast)."""
    os.environ["CONFIG_FILE"] = str(FIXTURES / "nope.jsonc")
    with pytest.raises(Exception, match=r"logging|provider|harness"):
        AppConfig()


def test_harness_plain_loads(clean_env: None) -> None:
    """未声明 capabilities 的 harness 正常装载(本仓库未启用能力体系)."""
    os.environ["CONFIG_FILE"] = str(CONFIG_JSONC)
    cfg = AppConfig()
    assert cfg.harness["cfg-h-plain"].default_model == "cfg-a"


def test_harness_capabilities_rejected(clean_env: None) -> None:
    """本仓库裁剪了 capabilities: 声明该字段被 extra=forbid 拒绝, fail-fast."""
    os.environ["CONFIG_FILE"] = str(CONFIG_JSONC)
    os.environ["PYCHAT_HARNESS"] = (
        '{"cfg-h":{"default_model":"cfg-a","available_models":["cfg-a"],'
        '"capabilities":[{"capability":"instrumentation"}]}}'
    )
    with pytest.raises(ValidationError):
        AppConfig()
