"""orchestrator.py 单元测试: AgentState 在构造时传入, get_graph 据以构造 Agent.

用 test 协议离线验证, 不触网络.
"""

from __future__ import annotations

import pytest
from core.config import AppConfig
from core.schema import (
    Effort,
    HarnessConfig,
    Logging,
    Protocol,
    ProviderConfig,
    Thinking,
    ThirdParty,
)
from harness.agent.orchestrator import Orchestrator
from harness.state import AgentState, AgentStateBuilder
from pydantic_ai import Agent


@pytest.fixture(autouse=True)
def _no_config_file(clean_env: None, monkeypatch: pytest.MonkeyPatch) -> None:
    """隔离配置文件: 本文件只测 init kwargs, 不让 CONFIG_FILE 把文件数据混进来."""
    monkeypatch.setenv("CONFIG_FILE", "tests/fixtures/absent.jsonc")


def _config(available_models: list[str] | None = None) -> AppConfig:
    return AppConfig(
        logging=Logging(third_party=ThirdParty()),
        provider={
            "m": ProviderConfig(
                api_key="k", base_url="http://localhost:8000/v1", id="m", protocol=Protocol.test
            )
        },
        harness={
            "orchestrator": HarnessConfig(
                default_model="m",
                available_models=available_models or ["m"],
                thinking=Thinking(enabled=True, effort=Effort.low),
            )
        },
    )


async def test_get_graph_uses_state_given_at_init() -> None:
    """AgentState 在构造时传入, get_graph 只用它造 Agent, 不自己造 AgentState."""
    config = _config()
    state = await (
        AgentStateBuilder()
        .add_source(config.harness["orchestrator"])
        .add_source({"effort": "max"})
        .build()
    )
    orchestrator = Orchestrator(config, state)
    assert isinstance(orchestrator.get_graph(), Agent)
    assert state.effort is Effort.max


def test_get_graph_rejects_model_outside_allowlist() -> None:
    """选中的模型不在 available_models 内时报错."""
    config = _config()
    state = AgentState(model_name="nope", thinking_enabled=True, effort=Effort.low)
    with pytest.raises(ValueError, match="not available"):
        Orchestrator(config, state).get_graph()


def test_make_deps_copies_model_name() -> None:
    """AgentState 的 model_name 复制成 agent 运行时依赖."""
    config = _config()
    state = AgentState(model_name="m", thinking_enabled=False, effort=Effort.high)
    assert Orchestrator(config, state).make_deps().model_name == "m"


def test_agent_config_missing_harness_section() -> None:
    """找不到 harness 段时报错."""
    config = _config()
    config.harness.pop("orchestrator")
    state = AgentState(model_name="m", thinking_enabled=True, effort=Effort.low)
    with pytest.raises(ValueError, match="not found"):
        _ = Orchestrator(config, state).agent_config
