"""tests/unit 专用 conftest: 按目录独立, unit 内共享的 fixture 放这里."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


@pytest.fixture
def clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """清空 PYCHAT_* / CONFIG_FILE 环境变量, 保证配置装载测试的 env 起点干净.

    注意: 故意只清配置相关变量, 不 wipe 整个 environ, 避免破坏 pytest 自身依赖的
    变量(如 PATH, PYTEST_*), 也符合 "thinnest outer boundary" 原则.
    """
    for key in list(os.environ):
        if key.startswith("PYCHAT_") or key == "CONFIG_FILE":
            monkeypatch.delenv(key, raising=False)
