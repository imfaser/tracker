# AGENTS.md

`pychat` is a uv workspace: `packages/*` = reusable libraries, `server` = app entry (console script `server`). All commands run through `uv run …` (uv-managed CPython 3.14; there is no system `python` on PATH).

- 新增运行时依赖一律加到**根** `pyproject.toml` 的 `[project].dependencies`, 不要写进 `server/pyproject.toml`(workspace 统一在根管理, `uv.lock` 也只有根这一份)。
- `docs/clarify/*.md` 是需求/契约的事实源(如 `server-skeleton.md` 锁定了流式契约与验收方式), 改动前先读。

## Use Codegraph first, not Grep/Read

Codegraph indexes this codebase (the index lives in the parent workspace root's `.codegraph/`; run `codegraph status` to confirm the project path). **Before you Grep or Read files to understand code, ask Codegraph first** — its `explore`/`node` return the verbatim source of the relevant symbols plus their call paths and blast radius in one round trip.

- **Use the codegraph MCP server — do not shell out to the `codegraph` CLI.** Call the MCP tool `codegraph_explore` (symbols + call paths + blast radius). Pass `projectPath=<repo root or any path inside it>` to scope queries to this codebase.
- Codegraph reads source verbatim from disk on each call — treat shown code as already Read; do not re-Read those files.
- Grep/Read remain only for what codegraph does not index: config/docs, untracked/git-only concerns, and quick confirmations of one-liners. Start from codegraph, escalate to grep only when it misses.

## The one rule that matters：schema 是事实源

- 事实源是 `schema/*.json`（JSON Schema）。`packages/core/src/core/schema.py` 由 datamodel-codegen **生成，禁止手改**。
- 改完 schema 必须重跑：`uv run datamodel-codegen`（配置在根 `pyproject.toml` 的 `[tool.datamodel-codegen]`）。重跑必须无 diff（幂等）。完整校验链：regen-no-diff → `uv run ty check` → `uv run ruff check` → `uv run pytest`。
- **改 `schema/*.json` 前先读 `[tool.datamodel-codegen]` 上方的中文注释**——每个 codegen 行为坑都记在对应开关旁边。
- `schema/schema.json` 组合全量：logging / telemetry 整文件 `$ref`，provider / harness / mcp 内联 map 形状（`type: object` + `additionalProperties` `$ref` 条目 + `minProperties: 1`）；logging / provider / harness 必填，mcp / telemetry 可选。map 型段（provider / harness / mcp）的条目模型在各文件的 `$defs`，map 形状与条目联合（oneOf + discriminator）必须内联在使用点——放进 `$defs` 或整文件 `$ref` 都会让 codegen 生成 `RootModel` 包装类（`Provider`/`Harness`/`Mcp`/`McpConfig`），代码里全是 `.root` 噪音。
- 本仓库**已裁剪 capabilities**（harness 无能力体系）；需要时再按 codegen 范式加回（`schema/capabilities/<name>.json` + harness 判别式 union 加 `$ref`）。
- `config.example.jsonc` 是配置格式的**活文档**（字段语义 / 枚举 / 默认 / 段间引用），改 schema 或写配置前先读它，格式变更时同步维护。真实配置是 `config.jsonc`（git 忽略）。

## Runtime config loader

- 运行时装载是 `packages/core/src/core/config.py`（`AppConfig`），嵌入生成的 schema 模型而非重新声明形状。装载优先级：init kwargs > env（`PYCHAT_` 前缀）> `config.jsonc`；各来源**按段深合并**。配置文件路径由 `CONFIG_FILE` 环境变量（无前缀，独立于配置本身）决定，缺省 `config.jsonc`；用 `json5` 按 JSONC 解析。`ConfigSchema` 是文件格式契约。

## Server (FastAPI + dishka + pydantic-ai)

- 入口 `server/src/server/__init__.py::main`, 以 uvicorn factory 拉起 `server.app:create_production_app`; 即 `uv run server` / `just dev`。bind 读 `SERVER_HOST` / `SERVER_PORT`(缺省 `127.0.0.1:8000`)——这两个变量**刻意不带 `PYCHAT_` 前缀**, 否则会被 `AppConfig(extra="forbid")` 当成配置段直接报错。
- 装配在 `create_app` / `make_container`: lifespan 管 logging 与 telemetry(telemetry 不进 DI), dishka 只注册 3 项: `AppProvider`(AppConfig, APP) + `AgentStateProvider`(AgentState, REQUEST) + dishka 自带 `FastapiProvider`。
- **不给 agent 注册 DI provider**: agent 每请求新建、用完即弃, 由 `Orchestrator(config, state).get_graph()` 现场构造。
- `POST /chat/stream` 交出严格 Vercel AI data stream, `sdk_version=7` 写死在路由里(有测试锁住, 别改成"跟随默认值")。
- **请求对象只能用 `request: FromDishka[Request]`, 不要用 FastAPI 的 `request: Request`**: 后者会在路由层再造一个 `Request` 实例, 两个实例各缓存一份 `_body`, 第二次读 body 会一直等 `http.disconnect`(in-process 测试挂死, 生产请求永久悬挂)。共用 dishka 那一个实例, body 只读一次即可。
- `AgentState` 的请求级覆盖从 body 取 `model` / `think` / `effort`; harness 段名 `orchestrator` 在代码里硬编码。wire 上 `trigger` / `id` / `messages` 必填(缺任一即 4xx), **不替客户端补默认值**。
- **telemetry 真实接入 = 两半, 缺一半 Phoenix 里就是空的**: 上报侧由 `PhoenixBackend.bootstrap()` 建 provider + `OpenInferenceSpanProcessor`; **产生侧要 Agent 自己开**——`Orchestrator.get_graph()` 传 `capabilities=[Instrumentation(InstrumentationSettings())]`, 因为 pydantic-ai 默认 `instrument=False`, 不开连一个 span 都不产生(实测配好 telemetry 也查不到项目)。
- **别照抄 Arize 文档里的 `InstrumentationSettings(version=2)`**: 当前 pydantic-ai 已废弃 2/3/4, 会抛 `PydanticAIDeprecationWarning`, 而 pytest `filterwarnings = ["error"]` 会因此挂掉 5 个用例; 用默认格式即可(OpenInference 0.1.27 支持 >=3 的 dotted keys)。端点/项目名见本地 `config.jsonc` 的 `telemetry` 段(project 默认 `pychat`); 看 trace 用 Phoenix MCP(`getSpans` / `spanSearch`)或 `GET /v1/projects/pychat/spans`。

## Coding conventions

- Docstrings/class docs follow the **Google style, written in Chinese**: one-line summary first, then sectioned `Args:` / `Returns:` / `Raises:` / `Examples:` (only the sections that apply) — what it does + params, not how it works internally.
- **Never use Chinese full-width punctuation in code.** Docstrings/comments/string literals use half-width punctuation only: `，`→`, `, `。`→`. `, `：`→`: `, `；`→`; `, `、`→`, `, `（`/`）`→`(`/`)`, `“”`/`‘’`→`"`/`'`. Ruff enforces this via RUF001/002/003 — keep those rules enabled.
- Write code that is **easy to change and easy to test**: prefer pure functions with explicit parameters over hidden global/env state; keep env lookup and side effects at the thinnest outer boundary.
- **No module-level global variables/constants for values reused inside functions** — they make functions untestable and couple call sites. Repeated-use functions take parameters instead.

## Testing

Test tree under root `tests/`, split into three independent folders:

- `tests/unit/` — 单元测试: 单测单个模块/纯函数, 不触 IO/网络/外部进程。
- `tests/integration/` — 集成测试: 跨模块/真实 IO(文件、子进程、网络)的测试。
- `tests/fixtures/` — 不放任何代码(.py); 只放测试用到的静态资源: 图片、JSON、JSONC 等样例数据。

**成本原则(个人 MVP, 先算代价再决定写不写测试)**: 为了"完整模拟"而要搭大量脚手架的用例(mock 三方流 / 伪造时序 / 手搓整个外部系统)**坚决不做**, 这类场景留给集成测试用真实链路一次性覆盖, 保持"整条链路"的平衡; 断言不出来的部分用**日志/可观测性**替代(跑一次真链路、看日志确认行为), 不必为了写断言而造模拟层。便宜且能定位问题的用例(纯函数、配置装载、状态合成)才放 `tests/unit/`。

- **Run pytest from the repo root**: `uv run pytest`(全量), `uv run pytest tests/unit/test_x.py`(单文件), `uv run pytest -k <name>`(筛选)。必须在根目录跑。
- 全局 `timeout = "10"` 是硬闸门(死锁/挂起的用例必须被掐断并打印线程栈, 不能挂着整个会话); 慢用例用 `@pytest.mark.timeout(<秒>)` 单独放宽。TOML 里 `timeout` 必须写成字符串, 写成 int 会 `INTERNALERROR`。
- `tests/unit/` 与 `tests/integration/` 各自独立, `conftest.py` 按目录单独放(全局 fixture 放根 `tests/conftest.py`)。
- `network`/`slow` marker 已在 `pyproject.toml` 注册; `-m "not slow"` 可跳过 PM2 这类慢用例。
- 集成测试里的配置必须走 `server_config` fixture(把 `CONFIG_FILE` 指向 `tests/fixtures/config.server.jsonc` 并清掉 `PYCHAT_*`), 不要读真实 `config.jsonc`。
- **需要真进程 / 真 HTTP 的用例自己起服务、测完自己关**: `pm2 start ecosystem.config.js`(独立 app 名 + 随机端口, 见 `test_pm2_server.py` 的 `pm2_server` fixture), `finally` 里 `pm2 delete`。不复用常驻的 `pychat-server`, 也不许留下残留进程或占着的端口。

## Security

- **提交前必须跑 gitleaks 扫描整个项目**, 防止把密钥/凭据提交进仓库:
  `gitleaks detect --source . --no-banner`(无泄漏才算通过; 发现即修复再提交, 绝不提交真实密钥)。
- 真实配置放 `config.jsonc` / `.env`(均被 git 忽略); 仓库里只保留 `.example` 模板。

## Git commit convention

- Commit messages in Chinese, Conventional Commits format: `<type>(<scope>): <中文描述>`.
- Do **not** prefix messages with branch names (`dev`/`main` — the current branch already expresses that).
- `type`: `feat` / `fix` / `docs` / `refactor` / `style` / `test` / `perf` / `build` / `ci` / `chore` / `revert`.
- Split multiple topics into separate commits — **one commit, one thing**.

## Toolchain quirks

- Runtime is Python 3.14, but ruff `target-version` is py312 — an intentional floor, not a bug.
- `uv run ruff …` may print a harmless "rules have been removed / UP038" warning; ignore it (UP038 is deliberately ignored).
- Every tool config section in root `pyproject.toml` (`[tool.ruff]` / `[tool.ty]` / `[tool.pytest]` / `[tool.datamodel-codegen]`) carries Chinese comments explaining each non-default choice — read them before touching that config, and don't "fix" the choices they document.
- `justfile` wraps the quality commands as recipes: `just lint` / `lint-fix` / `format` / `format-check` / `typecheck`, plus `just sync` / `dev` / `test`.
- PM2 常驻 dev server: `just up` / `just down` / `just status` / `just logs`, 定义在根 `ecosystem.config.js`(`up` 就是 `pm2 start ecosystem.config.js`; 对已存在实例 PM2 会**原地重启并应用新 env**, 实测不需要先 `pm2 delete`)。app 名 / 端口 / 配置路径都可被环境变量覆盖(`PM2_APP_NAME` / `SERVER_PORT` / `CONFIG_FILE`), 集成测试正是靠这一点用独立 app 名 + 随机端口起自己的实例。
